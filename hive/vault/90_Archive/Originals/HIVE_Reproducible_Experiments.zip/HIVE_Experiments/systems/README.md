# HIVE scheduling and communication study

This experiment measures the consequences of explicit workload and resource assumptions in a discrete-event simulator. It does not run language models, measure hardware inference speed, estimate learning quality, or determine an optimal model size. All service durations and latencies are in normalized simulation units.

The corrected results show a large work difference between selective execution and broadcast execution. Topology changes are a separate, smaller comparison in the illustrated four-worker setting. The experiment uses one shared GPU and four shared CPU message-service lanes; extra specialists and routers do not receive extra compute capacity.

![Two-panel scheduling result: executed GPU work and selective-policy topology latency](graph_results.png)

## Files and reproduction

| File | Purpose |
|---|---|
| `graph_simulation.py` | Workload generator and corrected discrete-event simulator. |
| `graph_raw.json` | All 1,440 completed simulation runs, plus assumptions and configuration metadata. |
| `graph_summary.json` | 288 configuration-level aggregates, each containing five seeds. |
| `analyze_graph.py` | Reads the saved results, checks counts and selected raw/aggregate consistency, and regenerates the figure. It does not rerun the simulation. |
| `graph_results.png` | Rendered two-panel chart. |
| `graph_results.svg` | Vector version of the same chart. |

From this directory, regenerate only the figures with:

```bash
python analyze_graph.py
```

This requires NumPy and Matplotlib. The input paths are resolved relative to the script, so invocation from another directory also works. The script prints the plotted means and standard deviations as JSON. Running `graph_simulation.py` would regenerate the full grid; that is unnecessary to reproduce this analysis from the saved results.

## Exact completed scope

| Axis | Values |
|---|---|
| Worker count | 4, 8, 16 |
| Same-community destination preference | 0.2, 0.8 |
| Offered useful GPU load | 0.4, 0.8 |
| CPU-service and directed-link cost per step | 0.001, 0.03, 0.3 |
| Topology | Direct mesh, central hub, community tree, community bridges |
| Execution policy | Selective, broadcast |
| Random seeds | 0, 1, 2, 3, 4 |
| Tasks per run | 240 |

The full product is **1,440 runs and 345,600 simulated task executions**. There are **288 configurations with five seeds each**. These are not 345,600 independent experimental samples. The same workload is reused across the graph and policy comparisons and across communication-cost settings; this helps isolate their effects. There are 60 distinct worker-count/locality/load/seed specifications, each used in 24 graph/policy/cost combinations. Changing the load rescales interarrival times while preserving the seeded task generation for the corresponding worker-count/locality setting.

## Assumed workload and service model

Each task executes first on its origin worker. It then needs one, two, or three other workers, with probabilities 0.6, 0.3, and 0.1. Destination selection favors the origin's community according to the locality parameter, without replacement. The locality parameter is a preference, not a guaranteed fraction of local traffic. For four workers, communities contain two workers, so a task cannot select more than one same-community peer. For eight and sixteen workers, communities contain four workers.

Each worker execution receives a lognormal duration with mean one normalized unit and log-scale standard deviation 0.25. Durations are workload assumptions, not measured model service times. Interarrival times are exponential with mean `2.5 / offered_useful_load`.

All model computations use one serial GPU queue. A request or response pays `c` units of CPU service at every visited endpoint or router and `c` units for each traversed directed link. Four CPU service lanes are shared globally. Each endpoint/router permits one CPU message service at a time; each directed link permits one traversal at a time. Requests and responses follow shortest paths. A task completes after all responses required by its execution policy arrive.

The corrected CPU dispatcher waits until both a node and a CPU lane are available before allocating that lane. It does not reserve an otherwise idle CPU far into the future while waiting on a busy router. Event tie breaking is deterministic; the model does not claim strict FIFO ordering for requeued packets at every node. Model-compute service on the single GPU is FCFS by readiness event. All outstanding work is drained after the final task arrival.

## Execution policy is independent of topology

**Selective execution** sends requests only to the task's known required destinations. **Broadcast execution** sends a request to every peer, executes every peer, and awaits every response. Broadcast receives no simulated quality benefit. This is a precise workload comparison, not evidence that every practical multi-agent interaction is wasteful.

Each policy is evaluated on every topology:

| Topology | Connections and routing |
|---|---|
| Direct mesh | A direct permitted connection between every pair of workers. Selective traffic on this graph still contacts only required destinations. |
| Central hub | Every worker connects to one added router. |
| Community tree | Workers connect to their community router; community routers connect to a root router. |
| Community bridges | Direct connections within each community and between community leaders. |

The direct mesh pays no explicit cost for maintaining its larger connection set. Routing destinations are known correctly in advance. The model therefore compares service work, path lengths, and resource contention; it does not evaluate learned routing accuracy, authorization complexity, trust boundaries, graph maintenance, or semantic corruption.

## Finite workloads and offered load

The mean useful work per task is:

\[
E[W_{\mathrm{selective}}]=1+0.6(1)+0.3(2)+0.1(3)=2.5.
\]

If the configured useful offered load is \(\rho\), the arrival rate is \(\lambda=\rho/2.5\). Broadcast executes all \(n\) workers, so:

\[
E[W_{\mathrm{broadcast}}]=n,\qquad
\rho_{\mathrm{broadcast}}=\lambda n=\rho\frac{n}{2.5}.
\]

| Configured useful load | Selective expected GPU load | Broadcast, 4 workers | Broadcast, 8 workers | Broadcast, 16 workers |
|---:|---:|---:|---:|---:|
| 0.4 | 0.40 | 0.64 | 1.28 | 2.56 |
| 0.8 | 0.80 | 1.28 | 2.56 | 5.12 |

Loads above one exceed the modeled GPU's long-run service capacity. Those conditions accumulate a queue while arrivals continue. Their reported latency is a finite 240-task arrival-and-drain result, not a steady-state latency estimate. High message costs can also overload CPU or router resources even when expected GPU load is below one.

Reported throughput is the number of completed tasks divided by the interval from the first arrival to the last completion. It includes arrival gaps and final queue draining, so it should not be interpreted as saturation capacity. The latency p95 is computed within each finite run. A summary's averaged p95 is an average of five run-level percentiles, not a pooled percentile.

## Results shown in the figure

Both panels select locality preference 0.8 and configured useful load 0.8. They use the same five seeds. Panel A reads one direct-mesh/cost-0.3 slice so replicated workloads are not counted repeatedly; executed GPU work is independent of topology and communication cost for a fixed workload and policy. Panel B holds worker count at four, policy at selective, and per-node/per-link communication cost at 0.3.

### A. Actual simulated GPU work per task

| Available workers | Selective mean ± seed SD | Broadcast mean ± seed SD |
|---:|---:|---:|
| 4 | 2.5015 ± 0.0906 | 4.0098 ± 0.0473 |
| 8 | 2.4678 ± 0.0171 | 7.9999 ± 0.0159 |
| 16 | 2.5047 ± 0.0693 | 15.9964 ± 0.0538 |

Selective work stays near the configured expectation of 2.5 while broadcast work grows with the number of workers. This is an accounting consequence of the policy definitions, verified by executed simulations. It is not a discovery that a more accurate router can always identify the right specialists for free; the simulation assumes those destinations are known.

### B. Four-worker selective latency at high communication cost

| Topology | Mean latency ± seed SD | Mean of run p95s | Mean directed hops/message | Available directed edges |
|---|---:|---:|---:|---:|
| Direct links | 9.1313 ± 1.6283 | 18.7134 | 1.0000 | 12 |
| Community bridges | 9.7169 ± 1.7329 | 19.7143 | 1.4144 | 6 |
| Central hub | 10.2927 ± 1.7478 | 19.9586 | 2.0000 | 8 |
| Community tree | 11.3283 ± 1.7953 | 20.9122 | 2.8507 | 12 |

All four topologies execute the same useful GPU work. The differences come from communication paths and contention under the defined scheduler. The bridge graph uses half as many available directed edges as the direct mesh and has a somewhat higher mean latency in this selected setting. Connection count itself incurs no maintenance penalty in this simulator, so the table does not determine which tradeoff is best in a real system.

Error bars are **one between-seed standard deviation**, not confidence intervals. Five seeds characterize variation for these traces; they do not support a universal statistical ranking across applications. The figure was rendered and visually inspected for readable labels and correctly placed uncertainty bars.

## What to carry into the build plan

Use selective invocation as an explicit baseline, and measure the real cost and error rate of finding the required specialists. Compare topology while holding invocation policy fixed. Preserve total shared-resource accounting when adding workers. Benchmark connection and translation costs on the actual deployment hardware before choosing the graph.

The simulator contains no parameter-count-to-quality model, training process, hallucination mechanism, memory corruption model, tensor-versus-text payload benchmark, GPU batching, KV cache, model loading, or energy model. Its results cannot establish local-model tokens per second, cloud-model equivalence, a best parameter count, or a learning-speed improvement. They identify scheduling assumptions that the next empirical prototype should measure.
