"""Plot existing HIVE scheduling results without rerunning the simulation grid.

Inputs: graph_raw.json and graph_summary.json beside this script.
Outputs: graph_results.png and graph_results.svg beside this script.
All plotted work and time are synthetic normalized units, not hardware timings.
"""
from __future__ import annotations

import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


HERE = Path(__file__).resolve().parent
SEEDS = [0, 1, 2, 3, 4]
LOCALITY = 0.8
USEFUL_LOAD = 0.8
STEP_COST = 0.3
TOPOLOGIES = [
    ("direct_mesh", "Direct links"),
    ("community_bridges", "Community bridges"),
    ("central_hub", "Central hub"),
    ("community_tree", "Community tree"),
]


def select(rows, **conditions):
    selected = [row for row in rows if all(row[key] == value for key, value in conditions.items())]
    selected.sort(key=lambda row: row["seed"])
    if [row["seed"] for row in selected] != SEEDS:
        raise ValueError(f"Expected exactly five distinct seeds for {conditions}")
    return selected


def moments(values):
    return float(np.mean(values)), float(np.std(values, ddof=1))


def read_metrics():
    raw = json.loads((HERE / "graph_raw.json").read_text())
    summary = json.loads((HERE / "graph_summary.json").read_text())
    rows = raw["records"]
    if len(rows) != 1440 or summary["runs"] != len(rows):
        raise ValueError("Unexpected run count or disagreement between raw and summary inputs")
    if sum(row["tasks"] for row in rows) != 345600 or summary["tasks_simulated"] != 345600:
        raise ValueError("Unexpected simulated task count")

    # Select one representative graph/cost/load slice to avoid counting the same
    # generated workloads repeatedly. GPU work does not depend on the topology.
    work = {}
    for n in [4, 8, 16]:
        for policy in ["selective", "broadcast"]:
            selected = select(
                rows, n=n, locality=LOCALITY, offered_useful_load=USEFUL_LOAD,
                per_message_step_cost=STEP_COST, graph="direct_mesh", policy=policy,
            )
            mean, sd = moments([row["gpu_work"] / row["tasks"] for row in selected])
            work[n, policy] = {"mean": mean, "sd": sd}

    latency = {}
    for topology, _ in TOPOLOGIES:
        conditions = dict(
            n=4, locality=LOCALITY, offered_useful_load=USEFUL_LOAD,
            per_message_step_cost=STEP_COST, graph=topology, policy="selective",
        )
        selected = select(rows, **conditions)
        mean, sd = moments([row["mean_latency"] for row in selected])
        matches = [row for row in summary["aggregated"]
                   if all(row[key] == value for key, value in conditions.items())]
        if len(matches) != 1 or not np.isclose(matches[0]["mean_latency"], mean):
            raise ValueError(f"Raw/summary disagreement for {topology}")
        latency[topology] = {
            "mean": mean,
            "sd": sd,
            "mean_run_p95": float(np.mean([row["p95_latency"] for row in selected])),
            "directed_edges": selected[0]["directed_available_edges"],
            "mean_hops": float(np.mean([row["mean_hops"] for row in selected])),
        }
    return work, latency, summary


def plot(work, latency):
    navy, teal, orange, gray = "#18354A", "#087F8C", "#CC694A", "#526373"
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 11,
        "axes.labelcolor": navy,
        "text.color": navy,
        "xtick.color": gray,
        "ytick.color": navy,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.spines.left": False,
        "axes.spines.bottom": False,
        "svg.fonttype": "none",
        "savefig.facecolor": "#F6F8FA",
    })
    fig, axes = plt.subplots(1, 2, figsize=(15, 7.3), gridspec_kw={"width_ratios": [1, 1.12]})
    fig.patch.set_facecolor("#F6F8FA")
    fig.subplots_adjust(left=0.07, right=0.97, top=0.77, bottom=0.24, wspace=0.42)
    fig.text(0.07, 0.94, "HIVE scheduling study", fontsize=25, weight="bold")
    fig.text(0.07, 0.889,
             "Synthetic workloads on one shared GPU and four shared CPU lanes",
             fontsize=13.5, color=gray)

    ax = axes[0]
    ax.set_facecolor("white")
    counts = [4, 8, 16]
    positions = np.arange(len(counts))
    width = 0.31
    for policy, offset, color, label in [
        ("selective", -width / 2, teal, "Selective: required workers"),
        ("broadcast", width / 2, orange, "Broadcast: every worker"),
    ]:
        means = [work[n, policy]["mean"] for n in counts]
        errors = [work[n, policy]["sd"] for n in counts]
        bars = ax.bar(positions + offset, means, width, color=color, label=label,
                      yerr=errors, capsize=4, error_kw={"ecolor": navy, "lw": 1.25}, zorder=3)
        for bar, mean, error in zip(bars, means, errors):
            ax.text(bar.get_x() + bar.get_width() / 2, mean + error + 0.35,
                    f"{mean:.2f}", ha="center", va="bottom", fontsize=11, weight="bold")
    ax.set_title("A   Executed GPU work", loc="left", pad=19, fontsize=15, weight="bold")
    ax.set_xticks(positions, [str(n) for n in counts])
    ax.set_xlabel("Available worker models", labelpad=11)
    ax.set_ylabel("GPU service units per completed task", labelpad=10)
    ax.set_ylim(0, 18.6)
    ax.set_yticks([0, 4, 8, 12, 16])
    ax.grid(axis="y", color="#DFE6EB", linewidth=0.7, zorder=0)
    ax.tick_params(axis="both", length=0, pad=8)
    ax.legend(loc="upper left", frameon=False, fontsize=10, handlelength=1.2)

    ax = axes[1]
    ax.set_facecolor("white")
    means = [latency[topology]["mean"] for topology, _ in TOPOLOGIES]
    errors = [latency[topology]["sd"] for topology, _ in TOPOLOGIES]
    y = np.arange(len(TOPOLOGIES))
    ax.barh(y, means, xerr=errors, height=0.54,
            color=[teal, "#4196A0", "#79AFB5", "#A4C8CC"],
            capsize=4, error_kw={"ecolor": navy, "lw": 1.25}, zorder=3)
    for index, mean, error in zip(y, means, errors):
        ax.text(mean + error + 0.18, index, f"{mean:.2f}", va="center", fontsize=11, weight="bold")
    ax.set_yticks(y, [label for _, label in TOPOLOGIES])
    ax.invert_yaxis()
    ax.set_xlim(0, 14.5)
    ax.set_xticks([0, 4, 8, 12])
    ax.set_xlabel("Mean task latency in normalized time units", labelpad=11)
    ax.set_title("B   Four workers: topology overhead", loc="left", pad=19, fontsize=15, weight="bold")
    ax.text(0, 1.015, "Selective policy · high communication cost (c = 0.3)",
            transform=ax.transAxes, fontsize=10.5, color=gray, va="bottom")
    ax.grid(axis="x", color="#DFE6EB", linewidth=0.7, zorder=0)
    ax.tick_params(axis="both", length=0, pad=8)

    fig.text(0.07, 0.139,
             "Bars show five-seed means; error bars show ±1 between-seed standard deviation.",
             fontsize=11, color=gray)
    fig.text(0.07, 0.101,
             "Selected setting: locality preference 0.8; useful offered load 0.8. Each run contains 240 tasks and is fully drained.",
             fontsize=10.5, color=gray)
    fig.text(0.07, 0.061,
             "Normalized units are simulation assumptions, not hardware seconds or measurements of LLM performance.",
             fontsize=11, color=navy, weight="bold")
    fig.savefig(HERE / "graph_results.png", dpi=180)
    fig.savefig(HERE / "graph_results.svg")
    plt.close(fig)


def main():
    work, latency, summary = read_metrics()
    plot(work, latency)
    report = {
        "runs": summary["runs"],
        "task_instances": summary["tasks_simulated"],
        "gpu_work_per_task": [dict(workers=n, policy=policy, **work[n, policy])
                              for n in [4, 8, 16] for policy in ["selective", "broadcast"]],
        "four_worker_selective_latency": latency,
        "outputs": [str(HERE / "graph_results.png"), str(HERE / "graph_results.svg")],
    }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
