"""Synthetic discrete-event HIVE communication/scheduling study.

All times are assumed normalized units, NOT measurements of an LLM or GPU.
One common serial accelerator, four common CPU message-service lanes, one
serial queue per endpoint/router, and directed links are shared by all jobs.
Required task work is identical across graph variants. Broadcast additionally
runs unneeded workers; it does not receive invented accuracy improvements.
"""
from __future__ import annotations
import collections
import heapq
import json
import math
import pathlib
import statistics
import time
import numpy as np

HERE = pathlib.Path(__file__).resolve().parent


def graph(n, kind):
    groups = [list(range(i, min(n, i + 4))) for i in range(0, n, 4)]
    if n == 4:
        groups = [[0, 1], [2, 3]]
    adj = {i: set() for i in range(n)}
    def edge(a, b):
        adj.setdefault(a, set()).add(b)
        adj.setdefault(b, set()).add(a)
    if kind == "direct_mesh":
        for i in range(n):
            for j in range(i + 1, n): edge(i, j)
    elif kind == "central_hub":
        for i in range(n): edge(i, n)
    elif kind == "community_tree":
        root = n + len(groups)
        for g, members in enumerate(groups):
            for i in members: edge(i, n + g)
            edge(n + g, root)
    elif kind == "community_bridges":
        for members in groups:
            for k, i in enumerate(members):
                for j in members[k + 1:]: edge(i, j)
        leaders = [x[0] for x in groups]
        for k, i in enumerate(leaders):
            for j in leaders[k + 1:]: edge(i, j)
    else:
        raise ValueError(kind)
    paths = {}
    for src in range(n):
        todo = collections.deque([(src, (src,))])
        seen = {src}
        while todo:
            cur, path = todo.popleft()
            if cur < n: paths[src, cur] = path
            for nxt in sorted(adj[cur]):
                if nxt not in seen:
                    seen.add(nxt)
                    todo.append((nxt, path + (nxt,)))
    assert len(paths) == n*n
    return adj, paths, groups


def trace(n, locality, load, seed, jobs=240):
    rng = np.random.default_rng(seed + 100*n)
    _, _, groups = graph(n, "direct_mesh")
    membership = {i: g for g, ids in enumerate(groups) for i in ids}
    out = []
    t = 0.0
    # Expected useful compute per task: origin + 0.6*1 + 0.3*2 + 0.1*3 = 2.5.
    for j in range(jobs):
        t += float(rng.exponential(2.5/load))
        src = int(rng.integers(n))
        count = min(n-1, int(rng.choice([1,2,3], p=[.6,.3,.1])))
        candidates = [i for i in range(n) if i != src]
        dest = []
        for _ in range(count):
            same = [i for i in candidates if membership[i] == membership[src]]
            other = [i for i in candidates if membership[i] != membership[src]]
            pool = same if same and (not other or rng.random() < locality) else other
            chosen = int(rng.choice(pool))
            dest.append(chosen)
            candidates.remove(chosen)
        work = rng.lognormal(mean=-.5*.25**2, sigma=.25, size=n).tolist()
        out.append(dict(id=j, arrival=t, source=src, required=dest, work=work))
    return out


def simulate(n, kind, policy, packets_cost, jobs):
    adj, paths, groups = graph(n, kind)
    cpu = [0.0]*4
    node_free = {x: 0.0 for x in adj}
    link_free = {}
    gpu_free = 0.0
    gpu_work = 0.0
    cpu_work = 0.0
    link_hops = 0
    messages = 0
    events = []
    serial = 0
    pending = {}
    completed = {}
    per_job = {j["id"]: j for j in jobs}
    def push(t, event, payload):
        nonlocal serial
        serial += 1
        heapq.heappush(events, (t, serial, event, payload))
    def compute(t, job, worker, after):
        nonlocal gpu_free, gpu_work
        duration = job["work"][worker]
        gpu_work += duration
        gpu_free = max(t, gpu_free) + duration
        push(gpu_free, after, (job["id"], worker))
    def send(t, jobid, src, dst, after):
        nonlocal messages
        messages += 1
        push(t, "packet", (jobid, paths[src,dst], 0, after))
    for job in jobs: push(job["arrival"], "arrive", job["id"])
    while events:
        t, _, event, payload = heapq.heappop(events)
        if event == "arrive":
            job = per_job[payload]
            compute(t, job, job["source"], "origin_done")
        elif event == "origin_done":
            jid, _ = payload
            job = per_job[jid]
            targets = job["required"] if policy == "selective" else [i for i in range(n) if i != job["source"]]
            pending[jid] = len(targets)
            for target in targets: send(t, jid, job["source"], target, "request_done")
        elif event == "packet":
            jid, path, k, after = payload
            node = path[k]
            lane = min(range(4), key=lambda x: cpu[x])
            ready = max(t, cpu[lane], node_free[node])
            if ready > t:
                # Never reserve an idle CPU lane while waiting for a busy node.
                # Reconsider dispatch when both resources can actually be acquired.
                push(ready, "packet", payload)
                continue
            finish = t + packets_cost
            cpu[lane] = node_free[node] = finish
            cpu_work += packets_cost
            if k == len(path)-1:
                push(finish, after, (jid, node))
            else:
                edge = (node, path[k+1])
                edge_finish = max(finish, link_free.get(edge, 0.0)) + packets_cost
                link_free[edge] = edge_finish
                link_hops += 1
                push(edge_finish, "packet", (jid, path, k+1, after))
        elif event == "request_done":
            jid, worker = payload
            compute(t, per_job[jid], worker, "worker_done")
        elif event == "worker_done":
            jid, worker = payload
            send(t, jid, worker, per_job[jid]["source"], "response_done")
        elif event == "response_done":
            jid, _ = payload
            pending[jid] -= 1
            if pending[jid] == 0: completed[jid] = t
    assert len(completed) == len(jobs)
    latencies = [completed[j["id"]]-j["arrival"] for j in jobs]
    makespan = max(completed.values())-jobs[0]["arrival"]
    expected_work = sum(sum(j["work"][w] for w in ([j["source"]]+j["required"] if policy == "selective" else range(n))) for j in jobs)
    assert math.isclose(gpu_work, expected_work, rel_tol=1e-12)
    assert makespan + 1e-9 >= gpu_work
    assert cpu_work <= 4*makespan + 1e-7
    return dict(mean_latency=float(np.mean(latencies)), p95_latency=float(np.percentile(latencies,95)),
        throughput=len(jobs)/makespan, gpu_work=gpu_work, cpu_work=cpu_work,
        messages=messages, directed_hops=link_hops,
        mean_hops=link_hops/messages, directed_available_edges=sum(map(len,adj.values())),
        router_nodes=len(adj)-n, gpu_utilization=gpu_work/makespan,
        makespan=makespan, tasks=len(jobs))


def main():
    start = time.perf_counter()
    rows = []
    for n in [4,8,16]:
        for locality in [.2,.8]:
            for load in [.4,.8]:
                for cost in [.001,.03,.3]:
                    for seed in range(5):
                        jobs = trace(n, locality, load, seed)
                        for kind in ["direct_mesh","central_hub","community_tree","community_bridges"]:
                            for policy in ["selective","broadcast"]:
                                record = dict(n=n,locality=locality,offered_useful_load=load,per_message_step_cost=cost,
                                              seed=seed,graph=kind,policy=policy)
                                record["expected_actual_gpu_offered_load"] = load if policy == "selective" else load*n/2.5
                                record.update(simulate(n,kind,policy,cost,jobs))
                                rows.append(record)
    by = collections.defaultdict(list)
    for row in rows:
        key=tuple(row[k] for k in ["n","locality","offered_useful_load","per_message_step_cost","graph","policy"])
        by[key].append(row)
    aggregated=[]
    for key, values in by.items():
        record=dict(zip(["n","locality","offered_useful_load","per_message_step_cost","graph","policy"],key))
        record["seeds"]=len(values)
        for field in ["mean_latency","p95_latency","throughput","gpu_work","cpu_work","messages","directed_hops","mean_hops","directed_available_edges","router_nodes","gpu_utilization"]:
            record[field]=float(np.mean([v[field] for v in values]))
            record[field+"_sd"]=float(np.std([v[field] for v in values],ddof=1))
        aggregated.append(record)
    selected = [r for r in aggregated if r["locality"]==.8 and r["offered_useful_load"]==.8 and r["per_message_step_cost"] in [.001,.3]]
    raw=dict(config=dict(time_unit="normalized; one worker inference has mean service 1",gpu_servers=1,
          cpu_message_service_lanes=4,jobs_per_run=240,seeds=list(range(5)),
          costs="each node CPU service and each directed link traversal costs c",
          broadcast="all peers execute and all responses are awaited; no extra accuracy is assigned",
          routing="correct workload destinations are known; no routing accuracy is modeled",
          finite_run="240 arrivals followed by full drain; not steady-state throughput or latency",
          message_dispatch="work conserving; deterministic heap tie-breaking, not strict per-node FIFO",
          excluded_costs="edge maintenance, authentication, learned routing, model loading, batching, KV caches, accuracy",
          workload="fanout 1/2/3 with probability .6/.3/.1; group preference .2 or .8; mean worker work1"),
          records=rows,elapsed_seconds=time.perf_counter()-start)
    (HERE/"graph_raw.json").write_text(json.dumps(raw,indent=2))
    (HERE/"graph_summary.json").write_text(json.dumps(dict(aggregated=aggregated,selected=selected,
         runs=len(rows),tasks_simulated=sum(r["tasks"] for r in rows),elapsed_seconds=raw["elapsed_seconds"]),indent=2))
    print(json.dumps(dict(runs=len(rows),tasks_simulated=sum(r["tasks"] for r in rows),seconds=raw["elapsed_seconds"],
        selected=[r for r in selected if r["n"]==4 and r["policy"]=="selective"]),indent=2))


if __name__ == "__main__":
    main()
