# HIVE representation and boundary experiment

Executed on 2026-11-19. This is an actual CPU experiment using synthetic spatial data and injected message errors. It is **not** a pretrained vision-model test, a language-model benchmark, a training-speed estimate, or evidence for a particular LLM parameter count.

## Reproduce

```bash
python3 run_representation.py
```

Requires Python 3 and NumPy. The measured environment used NumPy 2.3.5. The executed run took 2.73 seconds before aggregation and JSON output. The script writes deterministic per-seed metrics to `raw_results.json` and aggregated means and intervals to `summary.json`; runtime measurements can vary.

To regenerate the two-panel figure from existing measurements, run `python3 analyze_representation.py`. This additionally requires Matplotlib (the executed plotting environment used version 3.10.8) and writes `representation_results.png` and `representation_results.svg`. The left scatterplot uses a clearly labeled zoomed accuracy axis; the right bar chart starts at zero. The figure includes 95% bootstrap intervals across seeds; some are smaller than the plotted markers. No new experiments are run by the plotting script.

## 1. Does a numerical path retain more information?

Each of 10 random seeds generates 5,000 independent scenes, each comprising four two-dimensional points with coordinates uniform between 0.01 and 0.99. A fixed exact geometry routine computes three labels per scene: the nearest of the first three points to the fourth query point; clockwise versus counterclockwise orientation of the first three points; and whether the two segments intersect. The representation is encoded and decoded, then the same exact routine recomputes the labels. No perception model is involved.

The reported accuracy is the average fraction of these three original labels retained. It is a task-preservation measurement. These tasks have different class balances, so this aggregate must not be described as a generic reasoning score or compared with a universal 50% chance baseline. No downstream learner is trained on the representation.

| Representation | Labels retained | All three retained | Mean payload bytes | Coordinate RMSE |
|---|---:|---:|---:|---:|
| Binary float32 | 100% | 100% | 32 | 1.30e-8 |
| Numeric JSON | 100% | 100% | 155.02 | 0 |
| Precise coordinate prose | 100% | 100% | 171 | 2.89e-9 |
| Coarse five-bin words | 86.97% | 68.14% | 82.49 | 0.05668 |
| Coarse five-bin numeric | 86.97% | 68.14% | 8 | 0.05668 |

The float32 payload consists of eight four-byte coordinates. JSON uses Python float precision and includes commas and brackets. Precise prose uses eight decimal places in sentences such as “Point 1 has x 0.12345678 and y 0.23456789.” The coarse conditions quantize every coordinate to one of five bin centers. One expresses the bin with a word, then decodes the actual emitted text with a regular expression and word-to-value lookup; the other stores the same bin index as a byte. Bit packing could shrink the coarse numerical payload further but was not implemented.

**Interpretation:** the five-bin verbal and numerical conditions have exactly the same accuracy for every seed, because they discard exactly the same information. The exact-coordinate prose control retains all labels in this sample. Human language is therefore not inherently responsible for the observed error. The supported finding is that preserving task-relevant precision matters and compact binary numbers avoid textual serialization overhead for this payload. The experiment does not test whether a language model can reconstruct exact coordinates from ordinary captions.

For the coarse conditions, the bootstrap 95% interval for mean label retention is 86.77–87.16%. Nearest-point, orientation and segment-intersection retention are 83.94%, 88.42% and 88.55%, respectively. Quantization can introduce ties and degenerate geometry; the fixed deterministic geometry routine handles these consistently, and this is part of the information-loss effect.

Payload bytes exclude message headers, metadata, evidence references, array descriptors and transport framing. No tokenizer was run, so there are no token counts or tokens-per-second claims. One hundred percent on this finite sample does not prove float32 or rounded prose is lossless on every possible geometric decision boundary.

## 2. Do private representations require translators?

Producer A and receiver B use independent random orthogonal transforms of the same centered eight-dimensional coordinate vector. A emits `(x - 0.5) @ Q_A`; B interprets a payload using `z @ Q_B.T + 0.5`. The two payloads have identical shape and numerical type but different meanings. A learned linear translator maps the A representation into the B representation using paired examples. It has 64 coefficients, fitted by ridge least squares with a fixed 1e-8 regularizer. Evaluation uses 5,000 independent held-out scenes per seed.

Training pairs are either exact or corrupted independently on both sides with Gaussian noise of standard deviation 0.02. Test representations are noise-free. The sample counts were fixed in advance. We do not select the best seed or tune a hyperparameter on the test set.

| Translator condition | Paired examples | Pair noise SD | Labels retained | Bootstrap 95% interval |
|---|---:|---:|---:|---:|
| No translator | 0 | 0 | 49.91% | 48.99–50.79% |
| Learned linear | 4 | 0 | 61.00% | 59.32–62.64% |
| Learned linear | 8 | 0 | 99.97% | 99.90–100% |
| Learned linear | 16 | 0 | 100% | 100–100% |
| Learned linear | 64 | 0 | 100% | 100–100% |
| Learned linear | 256 | 0 | 100% | 100–100% |
| Learned linear | 4 | 0.02 | 60.54% | 59.30–61.71% |
| Learned linear | 8 | 0.02 | 80.78% | 74.52–85.35% |
| Learned linear | 16 | 0.02 | 94.87% | 94.30–95.44% |
| Learned linear | 64 | 0.02 | 97.84% | 97.61–98.03% |
| Stale after encoder change | 64 | 0.02 | 50.26% | 49.10–51.56% |
| Learned linear | 256 | 0.02 | 98.95% | 98.89–99.00% |

After fitting the noisy 64-pair translator, the producer representation is replaced with a new independent rotation while the translator is left unchanged. Its accuracy falls from 97.84% to 50.26%. These independent coordinate systems are deliberately simple, linear and small. The paired-example requirements do not forecast the data needed to align arbitrary pretrained nonlinear models. With only eight exact pairs, some fitted systems are poorly conditioned; the fixed regularizer explains the small residual label loss rather than a universal eight-example limit.

**Interpretation:** numerical messages are useful only when sender and receiver agree about their meaning. Private alphabets do not supply that agreement. HIVE should bind translators to explicit encoder, decoder and representation versions, freeze a tested translator together with its endpoints, and revalidate or realign before promoting an updated encoder.

## 3. Do separate languages prevent contamination?

The harness constructs 3,000 messages per seed: 500 valid messages and 500 each of wrong-recipient, stale-representation, wrong-unit, unauthorized-writer, and well-formed-wrong-semantic messages. There are 30,000 messages in total. All payloads contain eight finite numbers. Wrong-unit messages express pixels rather than normalized coordinates. Stale representations contain values in an incompatible orthogonal coordinate system. Well-formed wrong-semantic messages contain the coordinates of an unrelated scene, with otherwise valid metadata and values.

| Boundary policy | Invalid messages accepted | Valid messages accepted | Unauthorized writes accepted per seed | Well-formed wrong semantics accepted |
|---|---:|---:|---:|---:|
| Shape only | 100% | 100% | 500 / 500 | 100% |
| Typed contract | 40% | 100% | 500 / 500 | 100% |
| Typed plus capability | 20% | 100% | 0 / 500 | 100% |
| Typed, capability and range | 20% | 100% | 0 / 500 | 100% |

The typed contract checks recipient, representation version and units. The capability policy additionally checks the simulated authenticated producer identity and permitted write namespace. The range policy also checks that decoded coordinates lie between zero and one.

**Interpretation:** type and authority checks can enforce the specified syntactic and write-access rules in this harness. They cannot establish semantic truth. Every well-formed but semantically wrong message passes all four policies. Numerical range checks add no benefit for this chosen corruption mix, because the remaining semantic errors remain in range.

This is a boundary-rule validation, not a measurement of neural cross-contamination or a security proof. The error mixture is deliberately balanced and does not estimate deployment error prevalence. “Unauthorized writes” are counted simulated acceptances; no actual memory service or model weights are updated. The authenticated identity is provided by the harness; cryptographic authentication, secure IPC, operating-system isolation, adapter isolation and gradient separation are not implemented. A sender can also lie about units or versions unless provenance is enforced outside the payload.

For implementation, enforce namespaces and permissions in trusted storage and process boundaries; keep private representations versioned; keep untrusted outputs in a staging area; require evidence and independent evaluation before memory or adapter promotion; and retain rollback. Distinct alphabets are an interface choice, not a substitute for those controls.

## Statistical and reproducibility notes

- `raw_results.json` contains per-seed metrics, not every individual scene or message. The source and fixed seeds regenerate all input data.
- Means weight the 10 seeds equally. Bootstrap intervals resample those 10 seed-level values 10,000 times with fixed bootstrap seed 934. These intervals describe variation in this synthetic setup; they omit dataset, architecture and real-world deployment uncertainty.
- At 100% observed retention the bootstrap interval is also 100–100%, which does not imply a universal guarantee.
- `roundtrip_ms_per_packet` measures this Python serialization loop, with allocation and decode, and should not be interpreted as communication latency, neural inference latency or device throughput.
- Validation confirmed all 10 seeds were present; coarse numerical and verbal retention matched per seed; JSON and float32 retained every tested label; all valid messages were accepted; capability checks blocked all injected unauthorized namespace writes; and semantic errors remained accepted.

## What to carry into the HIVE plan

1. Use compact, typed native representations where a downstream task needs their precision; retain source references and inspection paths.
2. Keep exact structured text as a legitimate debugging and interchange option. Measure compression and lost task information independently from the choice of language.
3. Make translator alignment, representation versions, units and provenance first-class testable contracts.
4. Treat authorized semantic mistakes as a separate failure mode from access violations or schema mismatches.
5. Repeat this experiment with real frozen encoders and actual application tasks before inferring model sizes, specialist count, learning speed or useful throughput.
