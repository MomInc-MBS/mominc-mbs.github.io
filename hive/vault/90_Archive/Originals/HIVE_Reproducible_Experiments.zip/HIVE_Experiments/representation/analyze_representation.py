#!/usr/bin/env python3
"""Plot current measured results; does not run or modify the experiments."""
from pathlib import Path
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
SUMMARY = json.loads((ROOT / "summary.json").read_text())

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 11,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.edgecolor": "#BCC7CF", "axes.labelcolor": "#253745",
    "xtick.color": "#526574", "ytick.color": "#526574",
    "text.color": "#20313D", "svg.fonttype": "none",
})

TEAL = "#007F82"
AMBER = "#C27518"
SLATE = "#738698"
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 7.7), gridspec_kw={"width_ratios": [1.12, 1]})
fig.patch.set_facecolor("white")
fig.subplots_adjust(left=.07, right=.965, bottom=.29, top=.78, wspace=.47)
fig.text(.07, .94, "HIVE · Representation and translator experiments", fontsize=22, weight="bold")
fig.text(.07, .89, "Measured synthetic geometry: preserve information, then preserve the meaning of its encoding.", fontsize=12.5, color="#526574")

reps = {r["method"]: r for r in SUMMARY["representation"]}
annotations = [
    ("binary_float32", "Binary float32", (33, 105), TEAL, "o"),
    ("numeric_json", "Numeric JSON", (142, 94.5), TEAL, "s"),
    ("precise_coordinate_prose", "Precise coordinate prose", (171, 105), TEAL, "D"),
    ("coarse_five_bin_words", "Coarse words", (94, 91.8), AMBER, "o"),
    ("coarse_five_bin_numeric", "Equally coarse numeric", (34, 79), AMBER, "s"),
]
for key, label, xytext, color, marker in annotations:
    r = reps[key]
    acc = r["accuracy"]
    x = r["mean_payload_bytes"]["mean"]
    y = 100 * acc["mean"]
    percent = f"{y:.2f}".rstrip("0").rstrip(".")
    label = f"{label}\n{x:.3g} B · {percent}%"
    err = np.array([[100 * (acc["mean"] - acc["ci95_low"])], [100 * (acc["ci95_high"] - acc["mean"])]])
    ax1.errorbar(x, y, yerr=err, fmt=marker, color=color, markersize=8,
                 capsize=3, elinewidth=1.6, markeredgecolor="white", markeredgewidth=.7, zorder=4)
    ax1.annotate(label, xy=(x, y), xytext=xytext, ha="center", va="center", fontsize=10.4,
                 bbox={"facecolor": "white", "edgecolor": "none", "pad": 1.3},
                 arrowprops={"arrowstyle": "-", "color": "#8B9BA6", "lw": .9, "shrinkA": 3, "shrinkB": 7})
ax1.set_title("A  Information retention and payload size", loc="left", fontsize=14, weight="bold", pad=18)
ax1.set_xlabel("Mean payload size (bytes)", labelpad=10)
ax1.set_ylabel("Original task labels preserved (%)", labelpad=10)
ax1.set_xlim(-7, 205)
ax1.set_ylim(75, 110)
ax1.set_xticks([0, 50, 100, 150, 200])
ax1.set_yticks([75, 80, 85, 90, 95, 100])
ax1.grid(axis="both", color="#E9EEF2", linewidth=.7)
ax1.set_axisbelow(True)
ax1.text(0, -.205, "Precise prose retains the tested labels. Coarse words and equally\ncoarse numbers lose the same information. Accuracy axis is zoomed.",
         transform=ax1.transAxes, fontsize=10.2, color="#526574", va="top", linespacing=1.5)

translator = SUMMARY["translator"]
rows = [
    next(r for r in translator if r["method"] == "no_translator"),
    next(r for r in translator if r["method"] == "learned_linear" and r["paired_examples"] == 64 and r["noise_std"] == .02),
    next(r for r in translator if r["method"] == "stale_after_encoder_change"),
]
labels = ["No translator", "Aligned translator\n64 noisy pairs", "Producer encoder changed\nOld translator retained"]
for y, r, color in zip([2, 1, 0], rows, [SLATE, TEAL, AMBER]):
    a = r["accuracy"]
    value = 100 * a["mean"]
    err = np.array([[100 * (a["mean"] - a["ci95_low"])], [100 * (a["ci95_high"] - a["mean"])]])
    ax2.barh(y, value, height=.52, color=color, zorder=3)
    ax2.errorbar(value, y, xerr=err, fmt="none", color="#20313D", capsize=5, elinewidth=1.4, zorder=4)
    ax2.text(value + 2.2, y, f"{value:.2f}%", ha="left", va="center", fontsize=11.3, weight="bold")
ax2.set_title("B  Private spaces require alignment", loc="left", fontsize=14, weight="bold", pad=18)
ax2.set_yticks([2, 1, 0], labels)
ax2.tick_params(axis="y", length=0, pad=12, labelsize=10.2)
ax2.set_xlim(0, 112)
ax2.set_ylim(-.7, 2.7)
ax2.set_xticks([0, 25, 50, 75, 100])
ax2.set_xlabel("Original task labels preserved (%)", labelpad=10)
ax2.grid(axis="x", color="#E9EEF2", linewidth=.7)
ax2.set_axisbelow(True)
ax2.text(0, -.205, "Changing this encoder invalidates its old translator even though\nthe vector shape and numerical type remain unchanged.",
         transform=ax2.transAxes, fontsize=10.2, color="#526574", va="top", linespacing=1.5)

fig.text(.07, .065,
         "Scope: 10 seeds × 5,000 four-point scenes; nearest point, orientation and segment crossing. Whiskers: 95% bootstrap intervals across seeds.\n"
         "Linear eight-dimensional encodings; no pretrained perception or language model. Payload bytes exclude headers; no token throughput measured.",
         fontsize=10.1, color="#526574", linespacing=1.6)
fig.savefig(ROOT / "representation_results.png", dpi=180, facecolor="white")
fig.savefig(ROOT / "representation_results.svg", facecolor="white")
plt.close(fig)
print("Saved representation_results.png and representation_results.svg")
