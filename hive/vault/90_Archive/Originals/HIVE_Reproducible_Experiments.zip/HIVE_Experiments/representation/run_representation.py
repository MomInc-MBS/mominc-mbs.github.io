#!/usr/bin/env python3
"""Small controlled HIVE representation experiments. No pretrained vision/LLM benchmark."""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
import json, re, time
from pathlib import Path
import numpy as np

OUT = Path(__file__).resolve().parent
SEEDS = list(range(10))
N_TEST = 5000
N_TRAIN = [4, 8, 16, 64, 256]
DIM = 8
BIN_WORDS = ["far_low", "low", "middle", "high", "far_high"]
WORD_VALUES = {w:(i+0.5)/5 for i,w in enumerate(BIN_WORDS)}

def orthogonal(rng):
    q, r = np.linalg.qr(rng.normal(size=(DIM,DIM)))
    return q @ np.diag(np.sign(np.diag(r)))

def geometry_labels(x):
    p = np.asarray(x).reshape(-1,4,2)
    # Three independent task labels: nearest point to query, orientation, segment crossing.
    nearest = np.argmin(np.sum((p[:,:3]-p[:,3:4])**2,axis=2),axis=1)
    def orient(a,b,c):
        d1=b-a;d2=c-a
        return d1[:,0]*d2[:,1]-d1[:,1]*d2[:,0]
    orientation=(orient(p[:,0],p[:,1],p[:,2])>0).astype(int)
    cross=((orient(p[:,0],p[:,1],p[:,2])*orient(p[:,0],p[:,1],p[:,3])<0)&
           (orient(p[:,2],p[:,3],p[:,0])*orient(p[:,2],p[:,3],p[:,1])<0)).astype(int)
    return np.stack([nearest,orientation,cross],axis=1)

def scores(true,pred):
    a=(true==pred)
    return dict(accuracy=float(a.mean()), all_three_correct=float(a.all(axis=1).mean()),
                nearest_accuracy=float(a[:,0].mean()),
                orientation_accuracy=float(a[:,1].mean()),
                segment_crossing_accuracy=float(a[:,2].mean()))

def packet(x,kind):
    if kind=="binary_float32":
        b=np.asarray(x,dtype="<f4").tobytes()
        return b,np.frombuffer(b,dtype="<f4").astype(float)
    if kind=="numeric_json":
        b=json.dumps([float(a) for a in x],separators=(",",":")).encode()
        return b,np.asarray(json.loads(b),dtype=float)
    if kind=="precise_coordinate_prose":
        words="; ".join(f"Point {i+1} has x {float(x[2*i]):.8f} and y {float(x[2*i+1]):.8f}" for i in range(4))+"."
        b=words.encode()
        vals=re.findall(r"has x ([0-9]+\.[0-9]+) and y ([0-9]+\.[0-9]+)",words)
        return b,np.asarray([float(y) for pair in vals for y in pair])
    ix=np.minimum((x*5).astype(int),4)
    if kind=="coarse_five_bin_words":
        words="; ".join(f"P{i+1} x {BIN_WORDS[ix[2*i]]} y {BIN_WORDS[ix[2*i+1]]}" for i in range(4))
        b=words.encode()
        pairs=re.findall(r"P\d+ x ([a-z_]+) y ([a-z_]+)",b.decode())
        decoded=np.asarray([WORD_VALUES[word] for pair in pairs for word in pair])
        return b,decoded
    if kind=="coarse_five_bin_numeric":
        b=ix.astype(np.uint8).tobytes()
        return b,(np.frombuffer(b,dtype=np.uint8).astype(float)+0.5)/5
    raise ValueError(kind)

def ci(values):
    a=np.asarray(values,dtype=float)
    rng=np.random.default_rng(934)
    means=a[rng.integers(0,len(a),size=(10000,len(a)))].mean(axis=1)
    return dict(mean=float(a.mean()),sd=float(a.std(ddof=1)),ci95_low=float(np.quantile(means,.025)),ci95_high=float(np.quantile(means,.975)))

def aggregate(rows,keys,metrics):
    groups={}
    for r in rows:
        key=tuple(r[k] for k in keys)
        groups.setdefault(key,[]).append(r)
    out=[]
    for key,rs in groups.items():
        item={k:v for k,v in zip(keys,key)}
        item["seeds"]=len(rs)
        for m in metrics:item[m]=ci([r[m] for r in rs])
        out.append(item)
    return out

def main():
    start=time.perf_counter()
    raw={"representation":[],"translator":[],"isolation":[]}
    methods=["binary_float32","numeric_json","precise_coordinate_prose","coarse_five_bin_words","coarse_five_bin_numeric"]
    for seed in SEEDS:
        rng=np.random.default_rng(seed)
        x=rng.uniform(.01,.99,size=(N_TEST,DIM))
        y=geometry_labels(x)
        for method in methods:
            decoded=[];byte_sizes=[]
            t=time.perf_counter()
            for row in x:
                b,z=packet(row,method)
                decoded.append(z);byte_sizes.append(len(b))
            decoded=np.asarray(decoded)
            raw["representation"].append(dict(seed=seed,method=method,n_test=N_TEST,
                mean_payload_bytes=float(np.mean(byte_sizes)),
                roundtrip_ms_per_packet=1000*(time.perf_counter()-t)/N_TEST,
                reconstruction_rmse=float(np.sqrt(np.mean((decoded-x)**2))),
                **scores(y,geometry_labels(decoded))))
        # Independent coordinate systems. Known paired examples allow a linear mapping.
        qa=orthogonal(rng);qb=orthogonal(rng);qa_new=orthogonal(rng)
        xtest=rng.uniform(.01,.99,size=(N_TEST,DIM))
        ztest=(xtest-.5)@qa
        test_y=geometry_labels(xtest)
        untreated=ztest@qb.T+.5
        raw["translator"].append(dict(seed=seed,method="no_translator",paired_examples=0,noise_std=0.,
            translator_parameters=0,reconstruction_rmse=float(np.sqrt(np.mean((untreated-xtest)**2))),
            **scores(test_y,geometry_labels(untreated))))
        for noise in [0.,.02]:
            for n in N_TRAIN:
                train=rng.uniform(.01,.99,size=(n,DIM))
                za=(train-.5)@qa+rng.normal(scale=noise,size=(n,DIM))
                zb=(train-.5)@qb+rng.normal(scale=noise,size=(n,DIM))
                # Fixed ridge term improves finite/noisy-pair conditioning; no test tuning.
                transform=np.linalg.solve(za.T@za+1e-8*np.eye(DIM),za.T@zb)
                reconstructed=ztest@transform@qb.T+.5
                raw["translator"].append(dict(seed=seed,method="learned_linear",paired_examples=n,noise_std=noise,
                    translator_parameters=DIM*DIM,reconstruction_rmse=float(np.sqrt(np.mean((reconstructed-xtest)**2))),
                    **scores(test_y,geometry_labels(reconstructed))))
                if noise==.02 and n==64:
                    stale=(xtest-.5)@qa_new@transform@qb.T+.5
                    raw["translator"].append(dict(seed=seed,method="stale_after_encoder_change",paired_examples=n,noise_std=noise,
                        translator_parameters=DIM*DIM,reconstruction_rmse=float(np.sqrt(np.mean((stale-xtest)**2))),
                        **scores(test_y,geometry_labels(stale))))
        # Fuzz a message-consumption/memory-write boundary. No actual weights are changed.
        types=["valid","wrong_recipient","stale_representation","wrong_units","unauthorized_writer","well_formed_wrong_semantics"]
        count=500
        events=[]
        for kind in types:
            for j in range(count):
                coords=rng.uniform(.01,.99,size=DIM)
                msg={"recipient":"vision_B","representation":"B_v1","units":"normalized_coordinates",
                     "auth_subject":"approved_bridge","write_namespace":"vision_B",
                     "payload":(coords-.5)@qb}
                if kind=="wrong_recipient":msg["recipient"]="vision_A"
                elif kind=="stale_representation":
                    msg["representation"]="B_v0";msg["payload"]=(coords-.5)@qa
                elif kind=="wrong_units":
                    msg["units"]="pixels_1000";msg["payload"]=(coords*1000-.5)@qb
                elif kind=="unauthorized_writer":
                    msg["auth_subject"]="unapproved_worker";msg["write_namespace"]="vision_A"
                elif kind=="well_formed_wrong_semantics":
                    wrong=rng.uniform(.01,.99,size=DIM);msg["payload"]=(wrong-.5)@qb
                events.append((kind,msg))
        for policy in ["shape_only","typed_contract","typed_plus_capability","typed_capability_and_range"]:
            accepted_bad=0;bad=0;valid_accept=0;valid=0;cross_write=0;semantic_accept=0;semantic_total=0
            for kind,msg in events:
                ok=np.asarray(msg["payload"]).shape==(DIM,) and np.isfinite(msg["payload"]).all()
                if policy!="shape_only":
                    ok=ok and msg["recipient"]=="vision_B" and msg["representation"]=="B_v1" and msg["units"]=="normalized_coordinates"
                if policy in ["typed_plus_capability","typed_capability_and_range"]:
                    ok=ok and msg["auth_subject"]=="approved_bridge" and msg["write_namespace"]=="vision_B"
                if policy=="typed_capability_and_range":
                    decoded=msg["payload"]@qb.T+.5
                    ok=ok and np.all((decoded>=0)&(decoded<=1))
                if kind=="valid":
                    valid+=1;valid_accept+=int(ok)
                else:
                    bad+=1;accepted_bad+=int(ok)
                if kind=="unauthorized_writer":cross_write+=int(ok)
                if kind=="well_formed_wrong_semantics":
                    semantic_total+=1;semantic_accept+=int(ok)
            raw["isolation"].append(dict(seed=seed,policy=policy,events=len(events),invalid_events=bad,
                invalid_accept_rate=accepted_bad/bad,valid_accept_rate=valid_accept/valid,
                unauthorized_cross_namespace_writes=cross_write,
                well_formed_semantic_corruption_accept_rate=semantic_accept/semantic_total))
    summary={
      "design":{"seeds":SEEDS,"spatial_scenes_per_seed":N_TEST,"geometric_tasks_per_scene":3,
        "representation_dimensions":DIM,"translator_parameter_count":DIM*DIM,
        "paired_sample_counts":N_TRAIN,"training_pair_noise_std":[0.,.02],
        "stress_events_per_seed":3000,
        "runtime_seconds":time.perf_counter()-start,
        "nature":"Actual CPU computation on synthetic geometry and injected messages; not a vision/LLM or GPU benchmark."},
      "representation":aggregate(raw["representation"],["method"],["accuracy","all_three_correct","nearest_accuracy","orientation_accuracy","segment_crossing_accuracy","mean_payload_bytes","reconstruction_rmse","roundtrip_ms_per_packet"]),
      "translator":aggregate(raw["translator"],["method","paired_examples","noise_std"],["accuracy","all_three_correct","reconstruction_rmse"]),
      "isolation":aggregate(raw["isolation"],["policy"],["invalid_accept_rate","valid_accept_rate","unauthorized_cross_namespace_writes","well_formed_semantic_corruption_accept_rate"]),
      "limitations":[
        "Ground-truth tasks operate on four 2D points; a representation supplies all necessary coordinates. This does not measure perception.",
        "The coarse verbal condition intentionally discards coordinate precision. Equally coarse numeric codes provide the same loss; precise numeric prose is a control against attributing information loss to human language itself.",
        "Payload bytes exclude headers, IDs, evidence metadata and transport overhead. No token counts or tokens-per-second are measured.",
        "Linear orthogonal spaces are easier to align than arbitrary nonlinear pretrained vision or language representations.",
        "Message checks consume simulated authenticated identities; actual cryptographic authentication, process sandboxing and gradient isolation are not implemented.",
        "The stress test has an artificial balanced corruption mix and establishes rule behavior, not a real-world failure probability.",
        "Well-formed semantically false messages remain accepted by structural and capability gates. These gates cannot guarantee truth.",
        "CPU serialization timings are illustrative measurements of this Python implementation, not performance predictions for the user's hardware."
      ]
    }
    (OUT/"raw_results.json").write_text(json.dumps(raw,indent=2))
    (OUT/"summary.json").write_text(json.dumps(summary,indent=2))
    print(json.dumps({"runtime_seconds":summary["design"]["runtime_seconds"],
        "representation":[{"method":r["method"],"accuracy":r["accuracy"]["mean"],"bytes":r["mean_payload_bytes"]["mean"]} for r in summary["representation"]],
        "translator":[{"method":r["method"],"n":r["paired_examples"],"noise":r["noise_std"],"accuracy":r["accuracy"]["mean"]} for r in summary["translator"]],
        "isolation":[{"policy":r["policy"],"invalid_accept":r["invalid_accept_rate"]["mean"],"cross_writes_per_seed":r["unauthorized_cross_namespace_writes"]["mean"],"semantic_accept":r["well_formed_semantic_corruption_accept_rate"]["mean"]} for r in summary["isolation"]]},indent=2))

if __name__=="__main__":main()

