# HIVE reproducible simulation bundle

This bundle accompanies **HIVE_Simulation_Findings_and_Starting_Plan.md**. It contains actual small-network training, numerical representation experiments, and a synthetic scheduling model. It does not benchmark pretrained LLMs or the user's GPU.

## Start here

1. Read HIVE_Simulation_Findings_and_Starting_Plan.md for the conclusions and proposed architecture.
2. Read learning/README.md, representation/README.md and systems/README.md for exact methods.
3. Inspect starting_configuration.json for the proposed real-model pilot.
4. Inspect each raw JSON and summary JSON before reusing a numerical claim.
5. The foundation/ folder contains the earlier build plan and its large code/paper catalog.

## Reproduce

The recorded environment used Python 3.12.14, NumPy 2.3.5 and Matplotlib 3.10.8. The experiment itself uses no network, model download, GPU or external service. Install the versions in requirements.txt if they are not already present.

~~~bash
python3 run_all.py
~~~

The scripts write results alongside their source. Running again overwrites those result files. Preserve the supplied raw results if you want a direct comparison. The complete original computation took roughly 80 seconds of wall time across the three studies on this environment; timings vary, and the root runner was not used for the original separately executed runs.

To regenerate plots and their consistency checks from existing data:

~~~bash
python3 run_all.py --plots-only
~~~

The individual study READMEs give more granular commands. Non-timing metrics are deterministic under the supplied seeds to ordinary floating-point tolerances. Figure bytes and measured runtime can differ across installations.

## What the records mean

- learning/: 360 fully trained MLP runs, five seeds, matched update/presentation budgets, approximate stored-parameter matching, held-out evaluation, grouping and routing sensitivities.
- representation/: coordinate precision, actual text/binary round trips, fitted private-space translators and deterministic message-gate injections.
- systems/: 1,440 finite arrival-and-drain scheduling runs using one simulated serial accelerator and four shared message CPU lanes. Normalized units are assumptions, not GPU seconds.
- biology_research.md and research_sources.json: primary-source mechanisms, code references and limits.
- environment.json: the CPU execution environment.
- manifest.json: SHA-256 hashes and byte sizes of the supplied files before rerunning.

## Interpretation

Organization helped strongly on constructed conflicting tasks, but isolation reduced transfer on shared tasks. Blocked replay was not universally beneficial. Precise text preserved the tested geometry; deliberately coarse words and equally coarse numbers lost the same information. Private representation changes invalidated old translators. Permissions blocked their specified invalid operations, while valid-looking semantic errors passed. Selective activation reduced work in the scheduling model because unnecessary broadcast computation was explicitly charged.

The real-model size recommendation is a proposed next experiment. Nothing here establishes an optimal billion-parameter count, local/cloud throughput parity, endless learning, human REM equivalence or permanent freedom from semantic corruption.

## Provenance

Created November 18, 2026. The bundle includes simulation source and links to research code; it does not redistribute third-party pretrained weights.

