# HIVE: biological cycles, compartmentalization, and direct representations

Research checked 2026-11-19. This note supports an engineering hypothesis; biological resemblance is not evidence that the resulting software will learn faster. Experimental results described below are primarily animal studies. Proposed software mechanisms are explicitly engineering inferences.

## 1. What the biological evidence supports

**Sleep has several interacting mechanisms, rather than one universal retraining phase.** Selectively disrupting hippocampal sharp-wave ripples after training impaired spatial memory in rats [B1]. These events are associated with replay and coordinated activity during quiet rest and non-REM sleep. A separate mouse experiment attenuated theta-associated activity selectively during REM sleep and impaired particular contextual and object-location memories [B2]. Together these are reasons to test multiple consolidation operations, not reasons to label all learning as REM or all replay as exclusively sleep dependent.

**Homeostasis suggests selective normalization, not indiscriminate forgetting.** Three-dimensional electron microscopy of 6,920 mouse cortical synapses found a smaller average axon–spine interface after sleep, with selective sparing of some large, stable synapses [B3]. This supports a selective renormalization hypothesis in the measured regions and conditions. It does not show that deleting the least recently retrieved software records is optimal, or that an LLM's weights can safely be scaled down after every session.

**The waste-clearance story is unresolved enough to require careful language.** Hauglund and colleagues connected coordinated norepinephrine, blood-volume, and cerebrospinal-fluid oscillations with NREM glymphatic transport and used interventions to examine the mechanism [B4]. Miao and colleagues, using different fluorescent-tracer measurements in male mice, found reduced clearance during sleep and anesthesia [B5]. The studies do not justify a universal statement that REM cleans waste. Tracer influx, redistribution, efflux, spatial scale, molecular properties, and experimental conditions matter. For HIVE, cleanup is justified by measurable software costs such as redundant state, stale indexes, blocked queues, and outdated caches; it need not depend on which biological account prevails.

**Body systems communicate across boundaries.** Borovikova and colleagues demonstrated neural regulation of inflammatory responses, including effects of acetylcholine on stimulated macrophage cultures and vagal stimulation in rats [B6]. Smith and colleagues showed that fermentation metabolites affect colonic regulatory T cells through an FFAR2/GPR43-dependent mechanism in mice [B7]. These are concrete counterexamples to the idea that digestive, immune, and neural systems keep themselves safe by speaking wholly incompatible languages. Receptors, location, cell state, dose, timing, and feedback determine whether and how a shared signal is interpreted.

**Engineering interpretation:** preserve specialized representations and establish narrow, validated interfaces. Borrow selective reception and controlled influence rather than trying to create secrecy through incompatible vocabularies.

## 2. An implementable lifecycle

The following phases are software designs inspired by the evidence, not claimed copies of human physiology. A first implementation should use one explicit scheduler and a small number of policies. Triggers should depend on verified-experience backlog, measured distribution change, retention risk, idle compute, and resource pressure. Do not assume that a human sleep duration or 90-minute cadence is appropriate for a computer.

| Phase | Work performed | Promotion or completion condition |
|---|---|---|
| Active operation | Serve from a versioned model; maintain bounded working state; capture observations, decisions, feedback, and provenance. Keep inferred and observed information distinct. | Return the result or an explicit unresolved state within a fixed task budget. |
| Short idle maintenance | Deduplicate events, repair indexes, expire caches, resolve temporal supersession, and attach source reliability. | No new model weights are required; preserve auditability for changed records. |
| Replay and consolidation | Train a candidate adapter or specialist with a mixture of verified new data and retained prior examples. Sample rare consequential examples as well as recent ones. | Candidate passes held-out acquisition, retention, calibration, and cross-domain regression checks. |
| Counterfactual rehearsal | Generate hypothetical cases, world-model rollouts, or difficult questions; label all products as synthetic. | Accept training targets only after independent checking appropriate to the task. Generated statements do not become observed facts. |
| Homeostasis and resource recovery | Prune redundant state, compact stores, clear obsolete intermediates, inspect inactive experts, and enforce memory/compute quotas. | Resource savings must meet a retention-loss budget, with recoverable snapshots where practical. |
| Promotion and rollback | Atomically promote a candidate; version its representation contracts and dependent adapters; monitor a canary workload. | Promote only after evaluation; revert when real performance departs from accepted bounds. |

A system can remain available indefinitely as a service by cycling bounded jobs and rotating components. That does not imply an unlimited reasoning episode, perfect permanent memory, or monotonically improving weights.

### Fair experiments for cycles

Compare immediate replay, periodic replay, and event-triggered replay with equal numbers of optimizer updates, equal replay capacity, and the same verified examples. Measure time to a fixed acquisition target, retained-task accuracy, peak memory, energy where measurable, and latency interruptions. Otherwise a scheduled condition can appear better simply because it consumed more training compute.

Treat a win from the small learning simulation as evidence about that dataset and optimization regime. It does not identify the optimal schedule for a billion-parameter language model.

## 3. What must be isolated

Different symbolic alphabets are not a memory-protection mechanism. The concrete failure modes require different boundaries.

| Failure mode | Required boundary | Measurement |
|---|---|---|
| An update for one skill harms another | Separate trainable parameter sets or adapters; freeze shared weights initially; regression-test any changed shared dependency. | Retained-task degradation after every update; dependency-aware rollback. |
| A false claim enters trusted memory | Domain namespaces, scoped write capabilities, source provenance, verification, explicit supersession, and quarantined candidate records. | False-write acceptance rate and downstream error caused by each accepted write. |
| One module misreads another's numbers | Representation identifier, encoder/checkpoint version, shape, dtype, units, reference frame, timestamp, and expected normalization; validate a translator on paired data. | Semantic agreement on held-out cases, out-of-distribution rejection, and calibration. |
| A subsystem overwhelms others | Per-domain quotas, backpressure, bounded queues, process isolation, deadlines, and idempotent event handling. | Tail latency, dropped work, recovery time, and influence outside the authorized scope. |
| Shared retrieval or routing sends irrelevant knowledge | Scope-aware retrieval and uncertainty-aware routing; retain an abstain/escalate path. | Routing errors and their total task cost; contamination under deliberately misleading inputs. |

Disjoint trainable parameters prevent one specific kind of direct update interference. They do not prevent bad routing, corrupted inputs, translator errors, invalid retrieval, or defects in shared infrastructure. A numerical payload can be false or misleading just as a sentence can. A successful schema check proves format compatibility, not truth.

The operational objective should be a measured bound on error propagation under defined tests. Absolute permanent zero contamination is not a credible guarantee for a changing learned system.

## 4. Direct representations: the useful part of the hypothesis

The proposed path is feasible: image or video → feature tensors → task-specific predictor, memory, matcher, or planner. A natural-language explanation can be generated when a person needs one. English does not need to mediate every internal operation.

Five primary implementations are directly relevant:

| Resource | What is actually supplied | HIVE use and limitation |
|---|---|---|
| DINOv3 [C1] | Pretrained visual encoders, dense patch features, examples for matching, segmentation and tracking; official ViT-S/16 has 21M parameters. | A compact frozen perception starting point with small task heads. This is an image encoder, not a general planner. Code and weights use the custom DINOv3 license. |
| V-JEPA 2 / 2.1 [C2] | Video representation learning and latent action-conditioned prediction/planning research. The current official repository lists an 80M ViT-B/16 V-JEPA 2.1 model as well as larger models. | Reference for learning and predicting in latent space. The 80M encoder is not by itself a complete working action-conditioned world model. Count video-token and predictor costs. |
| CLIP [C3] | Separate image and text encoders trained for a compatible embedding space; feature-extraction APIs and linear-probe examples. | A transparent baseline for image–text retrieval and simple feature-space decisions. Compatibility is learned, not a consequence of both outputs being vectors. |
| SONAR [C4] | Multilingual text and speech encoders with a common fixed-size representation and matching decoding machinery; documented 1,024-dimensional embeddings. | A concrete bridge between supported speech/text inputs. It is not a universal code for arbitrary modules, and its sentence compression is task dependent. |
| EGG [C5] | Communication games, learned discrete or continuous channels, population experiments, and REINFORCE/Gumbel-Softmax training. | Useful experimental scaffolding for private learned protocols. The repository was archived on 2026-08-10; treat it as research code rather than a maintained production dependency. |

### Why equal-sized vectors do not make a common language

Two encoders can represent the same information in different coordinate systems. If one emits `z` and another expects `Rz` for a rotation `R`, the same dimensionality and dtype do not make direct substitution correct. A compatible decoder, shared encoder, jointly trained interface, or separately learned alignment is required. This example is mathematical reasoning, not a claim that all model mismatches are rotations.

Start with shared, frozen representation contracts inside a domain and a small number of paired-data translators across domains. Keep the outer envelope inspectable even when the payload is a tensor or learned code. Version encoder and downstream consumers together; changing an encoder can invalidate stored embeddings and classifiers.

Suggested envelope fields are `schema_id`, `representation_id`, `encoder_version`, `domain`, `timestamp`, `shape`, `dtype`, `units`, `reference_frame`, `provenance`, `confidence`, `synthetic_flag`, `capability_scope`, and a shared-buffer handle. Confidence is a calibrated claim to be tested, not an authority token.

### Size and latency accounting

Numerical communication can avoid lossy verbal compression and autoregressive generation. It is not automatically smaller. For example, a proposed 256-token feature map with 384 values per token at float16 occupies 196,608 bytes before its envelope, while a 384-value pooled vector occupies 768 bytes. These are arithmetic examples, not reported DINOv3 output shapes or benchmarks. A short text description may be smaller still while losing spatial detail.

Therefore compare task success, task-relevant information retained, bytes transferred, encoder/translator compute, copying overhead, and end-to-end wall time. Use shared buffers or references when a large tensor need not be copied. Pool, quantize, or encode sparse objects only when downstream quality survives. Extra modalities can provide useful complementary information, but can also be redundant, noisy, costly, or misaligned; measure incremental benefit rather than assume learning-rate multiplication.

## 5. A concrete first experiment

Use one frozen visual encoder, two small task heads, and one shared numerical feature contract. Give each head a separate replay buffer, trainable parameters, write namespace, and evaluation set. Allow deliberate cross-domain transfer only through a registered translator or selected shared examples.

Compare four interfaces: a text description, pooled visual features, spatial patch features, and a learned discrete bottleneck. Match the training-data and compute budgets; report the cost of the encoder and any captioner. Test tasks where spatial details matter as well as tasks adequately described in a sentence. Include mismatched encoder versions and off-domain inputs to measure failures.

Then compare all-to-all, hub, and sparse modular communication under the same task graph and scheduling budget. A sparse graph with selective bridges is a plausible engineering starting hypothesis; its optimal degree cannot be established from sleep or immune biology.

For retention, run separate baselines with no replay, online replay, fixed-interval replay, and event-triggered replay. Do not make direct numerical communication, separate memories, replay, and a new router a single indivisible treatment; ablate them so a win can be attributed to a mechanism.

## Sources and retrievable reference IDs

All sources below are original studies or official research implementation repositories. Reference IDs are included for the parent research workflow; URLs are the persistent identifiers.

| ID | Primary source | Retrieved reference |
|---|---|---|
| B1 | Girardeau et al. (2009), [Selective suppression of hippocampal ripples impairs spatial memory](https://www.nature.com/articles/nn.2384); [author-hosted paper](https://buzsakilab.com/content/PDFs/Girardeau2009NatNeurosci.pdf) | `turn248838021search2`, `turn248838021search9` |
| B2 | Boyce et al. (2016), [Causal evidence for the role of REM sleep theta rhythm in contextual memory consolidation](https://pubmed.ncbi.nlm.nih.gov/27174984/) | `turn248838021search0` |
| B3 | de Vivo et al. (2017), [Ultrastructural evidence for synaptic scaling across the wake/sleep cycle](https://pubmed.ncbi.nlm.nih.gov/28154076/); [author manuscript](https://escholarship.org/uc/item/9sw6509h) | `turn636483471search0`, `turn636483471search1` |
| B4 | Hauglund et al. (2025), [Norepinephrine-mediated slow vasomotion drives glymphatic clearance during sleep](https://pubmed.ncbi.nlm.nih.gov/39788123/); [full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC12340670/) | `turn636483471search3`, `turn636483471search2` |
| B5 | Miao et al. (2024), [Brain clearance is reduced during sleep and anesthesia](https://www.nature.com/articles/s41593-024-01638-y); [full text](https://pmc.ncbi.nlm.nih.gov/articles/PMC11156584/) | `turn636483471search4`, `turn636483471search5` |
| B6 | Borovikova et al. (2000), [Vagus nerve stimulation attenuates the systemic inflammatory response to endotoxin](https://www.nature.com/articles/35013070) | `turn947151838search1` |
| B7 | Smith et al. (2013), [The microbial metabolites, short chain fatty acids, regulate colonic Treg cell homeostasis](https://pmc.ncbi.nlm.nih.gov/articles/PMC3807819/) | `turn947151838search3`, `turn910299042view3` |
| C1 | [DINOv3 official implementation](https://github.com/facebookresearch/dinov3) | `turn780549348view0`, `turn610294585view0`, `turn610294585view1`, `turn910299042view5` |
| C2 | [V-JEPA 2 and 2.1 official implementation](https://github.com/facebookresearch/vjepa2) | `turn780549348view1`, `turn610294585view2`, `turn910299042view6` |
| C3 | [CLIP official implementation](https://github.com/openai/CLIP) | `turn780549348view2`, `turn610294585view4` |
| C4 | [SONAR official implementation](https://github.com/facebookresearch/SONAR) | `turn780549348view3`, `turn610294585view5` |
| C5 | [EGG official implementation](https://github.com/facebookresearch/EGG) | `turn780549348view4`, `turn610294585view6`, `turn910299042view7` |
