# HIVE: actual small-network learning experiment

This experiment actually trains small NumPy neural networks and evaluates labels on held-out samples. It is a mechanism study of transfer, interference, capacity, grouping, and replay order. **It does not predict the optimal number of billions of LLM parameters, tokens per second, multimodal quality, or biological REM effects.**

## Files and reproduction

- `learning_sim.py`: fully specified data generator, MLP, Adam, training, and raw measurement.
- `raw_results.json`: all 360 configuration/seed run records, including per-domain accuracy matrices, probe curves, counts, and runtime. Seeds are independent; configurations within a seed are paired.
- `summary.json`: group means, standard deviations, descriptive t intervals, paired comparisons, validation, and metadata.
- `headline_results.json`: compact numerical comparison at the middle capacity.
- `analyze_results.py`: consistency checks, paired comparisons, this README, and figure generation.
- `learning_results.png` / `learning_results.svg`: a static empirical figure.

```bash
python3 learning_sim.py
python3 analyze_results.py
```

Requires Python and NumPy; plotting additionally requires Matplotlib. No network, downloaded weights, or GPU is used. BLAS is limited to one thread. The complete 360-run training grid took 14.32 seconds in this environment; individual runtime includes evaluation and host overhead and is not a device-independent latency claim.

## Design

Five seeds independently generate domain rules, data, initialization, and domain order. Each seed is paired across configurations. Four domains each supply 512 allowed training records and a separate 512-example held-out set. Every example has 16 Gaussian numerical features plus an explicit four-way one-hot domain tag. All architectures see identical tags, including the generalist. A parameter-free known-domain router provides an optimistic routing control; learning or discovering the tags is outside this experiment.

The shared component is `(.9*x0 + .7*x1 - .5*x2 + .4*x3*x4 - .35*sin(2*x5))/1.35`. Each domain has an independently sampled unit-norm linear private rule on features 6–15. The **shared** regime labels the sign of `shared + .12*private`. The **conflict** regime labels the sign of `sign[domain]*shared + .8*private`, where signs are `[+1,-1,+1,-1]`. Labels have no added noise. Covariates are identical across the two regimes; the label-generating rule changes. This deliberately constructs both positive-transfer and conflicting-task situations, so the study cannot establish how common either regime is in real workloads.

Each network is a one-hidden-layer ReLU MLP with two logits, optimized by Adam at learning rate .006. The pilot checked that training worked; no learning-rate search was performed. Every architecture uses the same optimizer settings. Parameter counts include every weight and bias but exclude the parameter-free router, replay records, and optimizer moments; the latter are separately reported. All experts are independent networks, not adapters sharing a frozen trunk.

The architecture conditions are:

1. One generalist handles all four domains.
2. Two experts handle mixed pairs `(0,1)` and `(2,3)`.
3. Two experts handle aligned pairs `(0,2)` and `(1,3)`.
4. Four experts each handle one domain.

Aligned grouping is an optimistic known-structure control: in the conflicting regime it groups domains sharing the sign of the common rule. It does not use held-out labels, but the task generator makes the appropriate grouping known to the experimenter. It was added after the first pilot identified that the original two-expert grouping mixed conflicting rules. No architecture was removed because it performed poorly.

The actual total parameter counts are:

| Target total parameters | 1 generalist | 2 experts | 4 experts |
|---:|---:|---:|---:|
| 1024 | 1,014 (44 hidden/expert) | 1,016 (22 hidden/expert) | 1,020 (11 hidden/expert) |
| 4096 | 4,096 (178 hidden/expert) | 4,052 (88 hidden/expert) | 4,056 (44 hidden/expert) |
| 8192 | 8,190 (356 hidden/expert) | 8,192 (178 hidden/expert) | 8,104 (88 hidden/expert) |

Every run processes four sequential stages of 90 minibatches of 32 examples: exactly **360 optimizer calls and 11,520 training presentations**. All minibatches contain a single domain. Sparse routing therefore updates one smaller expert at each call, while the generalist updates its entire larger network. **Equal presentations and approximately equal stored parameters do not mean equal executed compute.** Estimated matrix multiply-accumulates are reported separately: training uses `presentations * hidden * (2*input_dim + 3*output_dim)` and inference uses `hidden * (input_dim + output_dim)` per example. These estimates exclude activation, bias, optimizer, memory-transfer, routing, and evaluation costs.

## Replay and timing controls

All replay arms have a 256-record capacity, with 64 retained examples per domain. Records are chosen only from samples actually trained on by every schedule during the domain's first 60 current-domain minibatches. Prior-domain memory is made available only after that domain's stage. At most 192 prior-domain records can be used during the fourth stage; 256 exist once all stages finish. This is a balanced, preallocated memory policy, not a learned forgetting policy.

- **Current data only:** all 90 minibatches train on the current domain. No replay memory is accessed.
- **Interleaved replay:** after the first stage, repeat two current-domain batches and one old-domain batch 30 times.
- **Blocked replay:** use the exact same 60 current-domain and 30 old-domain minibatches, but perform all current-domain updates first and all old-domain replay afterward.

At the first stage, all schedules have 90 identical current-domain batches. Interleaved and blocked schedules always consume identical minibatch multisets in different order. The no-replay arm spends the same total presentation budget on additional current examples, so it can have a current-task acquisition advantage. This is deliberate accounting rather than free extra replay compute.

The blocked schedule does **not** implement biological sleep, REM, generative dreams, synaptic downscaling, a jointly optimized consolidation phase, or a sleep/wake controller. It tests whether moving the same rehearsal updates into one block changes this particular sequential optimizer's behavior.

## Results at approximately 4,096 total parameters

Numbers are final held-out accuracy percentages, averaged equally over four domains and five seeds; ± is the half-width of a descriptive 95% Student-t interval across seeds, not standard deviation. These intervals are not corrected for the number of grid comparisons.

| Rules | Organization | Current only | Interleaved | Blocked |
|---|---|---:|---:|---:|
| shared | 1 generalist | 90.44 ± 1.44 | 91.03 ± 1.61 | 90.54 ± 0.98 |
| shared | 2 mixed pairs | 89.79 ± 1.64 | 89.59 ± 1.22 | 88.55 ± 1.38 |
| shared | 2 aligned pairs | 90.15 ± 1.65 | 89.80 ± 1.37 | 89.20 ± 2.01 |
| shared | 4 isolated | 88.44 ± 0.95 | 87.00 ± 1.12 | 87.00 ± 1.12 |
| conflict | 1 generalist | 54.31 ± 1.93 | 74.47 ± 3.77 | 62.64 ± 2.51 |
| conflict | 2 mixed pairs | 60.78 ± 2.68 | 66.11 ± 5.95 | 62.79 ± 3.35 |
| conflict | 2 aligned pairs | 82.77 ± 2.15 | 83.88 ± 2.46 | 82.81 ± 2.29 |
| conflict | 4 isolated | 90.42 ± 1.17 | 88.98 ± 0.78 | 88.98 ± 0.78 |

![Empirical learning results](learning_results.png)

## What the evidence supports

The shared and conflict regimes select different organizational tradeoffs. Generalists can reuse shared knowledge on later domains. Separate networks protect parameters from updates aimed at other domains, but remove this direct transfer path. Choosing which domains share an expert matters substantially in the conflict regime, even when total parameters and update budgets stay fixed. An efficient grouping should be learned from measured transfer/interference, not assumed from topic labels alone.

Replay order matters where tasks share parameters. In this setup, blocked old-task-only updates can damage a newly learned conflicting task; interleaved replay often preserves a better compromise. Fully isolated experts produce exactly identical final outputs under interleaved versus blocked replay because other experts' updates cannot affect their parameters. Replaying isolated experts can nevertheless reduce their final accuracy relative to spending all updates on fresh current data, because the budget is fixed and replay draws from a smaller record set. A replay or sleep mechanism therefore needs a demonstrated benefit; biological naming is insufficient.

Three total capacities are included in the complete raw and summary files. Increasing capacity does not remove the need for a good organization and training schedule. These capacities were selected for a small CPU experiment, so the location of any maximum has no justified conversion into an LLM starting size.

## Metrics and limitations

Every run records accuracy on every domain before training and after each stage. Acquisition accuracy is the current domain's score at the end of its stage. Signed backward transfer is final minus acquisition accuracy for previously learned domains; positive values preserve improvements. Forgetting is the maximum post-acquisition score minus final score. Forward transfer compares accuracy just before a new domain is trained with that model's initial accuracy on the same domain. With isolated networks it is structurally zero because their parameters remain unchanged before their own task.

Current-domain probes occur at 30, 60, and 90 minibatches. The optional 80% learning-speed marker requires two consecutive probes at or above 80%; runs that fail to meet this threshold are censored (`null`), not assigned an invented training time. Probe evaluations never change hyperparameters, stopping, samples, or model selection. Evaluation labels are never optimized against. This marker is coarse and task-specific, not a claim of general learning efficiency.

Routing-error sensitivity evaluates each test set through wrong experts, then forms an expected mixture `(1-error_probability)*correct_accuracy + error_probability*mean_wrong_expert_accuracy` at 0%, 5%, 10%, and 20% error probabilities. Wrong routes preserve the original domain tag. This is a measured-output mixture under independent uniform wrong-expert selection; it is not a learned router, semantic ambiguity study, or adversarial robustness evaluation.

Validation includes finite differences for handwritten backprop (maximum relative error 6.02e-11), all run/update/presentation counts, total parameter matching within 1.2%, and the replay-order invariance implied by complete parameter isolation. The experiment measures neural interference, not malicious prompt injection, data poisoning, process isolation, language translation, truthfulness, or privacy boundaries. Separate expert languages alone are not tested and cannot be claimed to provide such boundaries.

These results motivate a real-model follow-up with learned routing, frozen shared representations plus separate adapters, measured pairwise transfer, bounded replay with provenance, a jointly scheduled consolidation phase, explicit retention gates, and task-level correctness per joule or second. They do not justify an assertion that HIVE already outperforms frontier models.
