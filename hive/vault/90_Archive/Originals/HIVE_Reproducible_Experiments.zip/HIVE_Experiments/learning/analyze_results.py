#!/usr/bin/env python3
"""Validate matching, compute paired summaries, and render the empirical figure."""
import json
import math
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
raw = json.loads((HERE / "raw_results.json").read_text())
summary = json.loads((HERE / "summary.json").read_text())
assert len(raw) == 360
assert all(r["updates"] == 360 and r["sample_presentations"] == 11520 for r in raw)
assert all(sum(r["optimizer_updates_by_expert"]) == 360 for r in raw)
assert all(sum(r["sample_presentations_by_domain"]) == 11520 for r in raw)
assert all(abs(r["total_parameters"] - r["target_total_parameters"]) / r["target_total_parameters"] < .012 for r in raw)
assert all(g["n_seeds"] == 5 for g in summary["groups"])

def select(regime, budget, grouping, schedule):
    return [r for r in raw if (r["regime"], r["target_total_parameters"], r["grouping"], r["schedule"])
            == (regime, budget, grouping, schedule)]

def group(regime, budget, grouping, schedule):
    return next(g for g in summary["groups"]
                if (g["regime"], g["target_total_parameters"], g["grouping"], g["schedule"])
                == (regime, budget, grouping, schedule))

def paired(a, b, label):
    aa = {r["seed"]: r for r in a}
    bb = {r["seed"]: r for r in b}
    differences = [aa[s]["final_mean_accuracy"] - bb[s]["final_mean_accuracy"] for s in sorted(aa)]
    sd = float(np.std(differences, ddof=1))
    return {"label": label, "n_seeds": len(differences),
            "mean_difference_percentage_points": 100 * float(np.mean(differences)),
            "descriptive_ci95_half_width_percentage_points": 100 * 2.776 * sd / math.sqrt(len(differences)),
            "per_seed_differences": differences}

# With complete parameter isolation, rearranging OTHER experts' updates must not
# affect a given expert. This is a useful invariant for both replay implementations.
for regime in ("shared", "conflict"):
    for budget in (1024, 4096, 8192):
        a = select(regime, budget, "one_per_domain", "interleaved_replay")
        b = select(regime, budget, "one_per_domain", "blocked_replay")
        for x, y in zip(a, b):
            assert x["seed"] == y["seed"]
            assert x["final_accuracy_by_domain"] == y["final_accuracy_by_domain"]

contrasts = []
for regime in ("shared", "conflict"):
    contrasts.extend([
        paired(select(regime, 4096, "one_per_domain", "no_replay"),
               select(regime, 4096, "all_domains", "no_replay"), f"{regime}: four isolated minus one generalist, no replay"),
        paired(select(regime, 4096, "similar_rule_pairs", "interleaved_replay"),
               select(regime, 4096, "mixed_rule_pairs", "interleaved_replay"), f"{regime}: aligned minus mixed pairs, interleaved"),
        paired(select(regime, 4096, "all_domains", "interleaved_replay"),
               select(regime, 4096, "all_domains", "blocked_replay"), f"{regime}: interleaved minus blocked, generalist"),
    ])
summary["additional_paired_contrasts_at_4096"] = contrasts
summary["validation"] = {
    "all_360_runs_complete": True,
    "all_presentations_and_update_counts_match": True,
    "all_parameter_counts_within_1_2_percent_of_target": True,
    "fully_isolated_replay_order_invariance": True,
    "handwritten_gradient_finite_difference_max_relative_error": max(c["relative_error"] for c in summary["metadata"]["gradient_check"]),
}
(HERE / "summary.json").write_text(json.dumps(summary, indent=2))

architectures = ("all_domains", "mixed_rule_pairs", "similar_rule_pairs", "one_per_domain")
names = ("1 generalist", "2 mixed pairs", "2 aligned pairs", "4 isolated")
schedules = ("no_replay", "interleaved_replay", "blocked_replay")
schedule_names = ("Current data only", "Interleaved replay", "Blocked replay")

rows = []
for regime in ("shared", "conflict"):
    for architecture, name in zip(architectures, names):
        values = [group(regime, 4096, architecture, schedule) for schedule in schedules]
        rows.append({"regime": regime, "architecture": name,
                     **{schedule: {"mean_percent": 100*g["final_mean_accuracy"]["mean"],
                                    "ci95_half_width_percentage_points": 100*g["final_mean_accuracy"]["ci95_t_half_width"]}
                        for schedule, g in zip(schedules, values)}})
(HERE / "headline_results.json").write_text(json.dumps({"comparison_at_target_parameters": 4096, "rows": rows,
                                                       "paired_contrasts": contrasts}, indent=2))

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                     "axes.spines.top": False, "axes.spines.right": False})
fig, axes = plt.subplots(1, 2, figsize=(12.5, 5.2), sharey=True)
colors = ("#596b7d", "#087f8c", "#e29537")
x = np.arange(4)
width = .24
for ax, regime in zip(axes, ("shared", "conflict")):
    for j, (schedule, label, color) in enumerate(zip(schedules, schedule_names, colors)):
        groups = [group(regime, 4096, a, schedule) for a in architectures]
        means = [100*g["final_mean_accuracy"]["mean"] for g in groups]
        errors = [100*g["final_mean_accuracy"]["ci95_t_half_width"] for g in groups]
        ax.bar(x + (j-1)*width, means, width, yerr=errors, capsize=2,
               label=label, color=color, error_kw={"linewidth": .8})
    ax.set_xticks(x, ("1\ngeneralist", "2 mixed\npairs", "2 aligned\npairs", "4\nisolated"))
    ax.set_title("Mostly shared rules" if regime == "shared" else "Conflicting rules")
    ax.set_ylim(0, 100)
    ax.set_yticks(np.arange(0, 101, 20))
    ax.grid(axis="y", alpha=.18)
    ax.set_axisbelow(True)
axes[0].set_ylabel("Final held-out accuracy (%)")
fig.legend(*axes[0].get_legend_handles_labels(), loc="lower center", ncol=3, frameon=False,
           bbox_to_anchor=(.5, .045))
fig.suptitle("Organization changes the tradeoff; replay timing is not universally beneficial", fontsize=14, y=.98)
fig.text(.5, .91, "Actual CPU MLP training · approximately 4,096 total parameters · five seeds · equal 11,520 presentations per run",
         ha="center", fontsize=10, color="#475569")
fig.text(.5, .012, "Whiskers: descriptive 95% t intervals across seeds. Known-domain routing. Synthetic tasks; no inference to LLM-scale performance.",
         ha="center", fontsize=8.5, color="#475569")
fig.subplots_adjust(left=.075, right=.985, top=.82, bottom=.22, wspace=.12)
fig.savefig(HERE / "learning_results.png", dpi=180)
fig.savefig(HERE / "learning_results.svg")

table = ["| Rules | Organization | Current only | Interleaved | Blocked |",
         "|---|---|---:|---:|---:|"]
for row in rows:
    cells = [f"{row[s]['mean_percent']:.2f} ± {row[s]['ci95_half_width_percentage_points']:.2f}" for s in schedules]
    table.append("| " + " | ".join([row["regime"], row["architecture"], *cells]) + " |")

size_table = ["| Target total parameters | 1 generalist | 2 experts | 4 experts |",
              "|---:|---:|---:|---:|"]
for budget in (1024, 4096, 8192):
    gs = [group("shared", budget, a, "no_replay") for a in ("all_domains", "mixed_rule_pairs", "one_per_domain")]
    size_table.append("| " + " | ".join([str(budget), *[f"{g['total_parameters']:,} ({g['hidden_units_per_expert']} hidden/expert)" for g in gs]]) + " |")

readme = f"""# HIVE: actual small-network learning experiment

This experiment actually trains small NumPy neural networks and evaluates labels on held-out samples. It is a mechanism study of transfer, interference, capacity, grouping, and replay order. **It does not predict the optimal number of billions of LLM parameters, tokens per second, multimodal quality, or biological REM effects.**

## Files and reproduction

- `learning_sim.py`: fully specified data generator, MLP, Adam, training, and raw measurement.
- `raw_results.json`: all {len(raw)} configuration/seed run records, including per-domain accuracy matrices, probe curves, counts, and runtime. Seeds are independent; configurations within a seed are paired.
- `summary.json`: group means, standard deviations, descriptive t intervals, paired comparisons, validation, and metadata.
- `headline_results.json`: compact numerical comparison at the middle capacity.
- `analyze_results.py`: consistency checks, paired comparisons, this README, and figure generation.
- `learning_results.png` / `learning_results.svg`: a static empirical figure.

```bash
python3 learning_sim.py
python3 analyze_results.py
```

Requires Python and NumPy; plotting additionally requires Matplotlib. No network, downloaded weights, or GPU is used. BLAS is limited to one thread. The complete {len(raw)}-run training grid took {summary['metadata']['elapsed_seconds']:.2f} seconds in this environment; individual runtime includes evaluation and host overhead and is not a device-independent latency claim.

## Design

Five seeds independently generate domain rules, data, initialization, and domain order. Each seed is paired across configurations. Four domains each supply 512 allowed training records and a separate 512-example held-out set. Every example has 16 Gaussian numerical features plus an explicit four-way one-hot domain tag. All architectures see identical tags, including the generalist. A parameter-free known-domain router provides an optimistic routing control; learning or discovering the tags is outside this experiment.

The shared component is `(.9*x0 + .7*x1 - .5*x2 + .4*x3*x4 - .35*sin(2*x5))/1.35`. Each domain has an independently sampled unit-norm linear private rule on features 6–15. The **shared** regime labels the sign of `shared + .12*private`. The **conflict** regime labels the sign of `sign[domain]*shared + .8*private`, where signs are `[+1,-1,+1,-1]`. Labels have no added noise. Covariates are identical across the two regimes; the label-generating rule changes. This deliberately constructs both positive-transfer and conflicting-task situations, so the study cannot establish how common either regime is in real workloads.

Each network is a one-hidden-layer ReLU MLP with two logits, optimized by Adam at learning rate .006. The pilot checked that training worked; no learning-rate search was performed. Every architecture uses the same optimizer settings. Parameter counts include every weight and bias but exclude the parameter-free router, replay records, and optimizer moments; the latter are separately reported. All experts are independent networks, not adapters sharing a frozen trunk.

The architecture conditions are:

1. One generalist handles all four domains.
2. Two experts handle mixed pairs `(0,1)` and `(2,3)`.
3. Two experts handle aligned pairs `(0,2)` and `(1,3)`.
4. Four experts each handle one domain.

Aligned grouping is an optimistic known-structure control: in the conflicting regime it groups domains sharing the sign of the common rule. It does not use held-out labels, but the task generator makes the appropriate grouping known to the experimenter. It was added after the first pilot identified that the original two-expert grouping mixed conflicting rules. No architecture was removed because it performed poorly.

The actual total parameter counts are:

{chr(10).join(size_table)}

Every run processes four sequential stages of 90 minibatches of 32 examples: exactly **360 optimizer calls and 11,520 training presentations**. All minibatches contain a single domain. Sparse routing therefore updates one smaller expert at each call, while the generalist updates its entire larger network. **Equal presentations and approximately equal stored parameters do not mean equal executed compute.** Estimated matrix multiply-accumulates are reported separately: training uses `presentations * hidden * (2*input_dim + 3*output_dim)` and inference uses `hidden * (input_dim + output_dim)` per example. These estimates exclude activation, bias, optimizer, memory-transfer, routing, and evaluation costs.

## Replay and timing controls

All replay arms have a 256-record capacity, with 64 retained examples per domain. Records are chosen only from samples actually trained on by every schedule during the domain's first 60 current-domain minibatches. Prior-domain memory is made available only after that domain's stage. At most 192 prior-domain records can be used during the fourth stage; 256 exist once all stages finish. This is a balanced, preallocated memory policy, not a learned forgetting policy.

- **Current data only:** all 90 minibatches train on the current domain. No replay memory is accessed.
- **Interleaved replay:** after the first stage, repeat two current-domain batches and one old-domain batch 30 times.
- **Blocked replay:** use the exact same 60 current-domain and 30 old-domain minibatches, but perform all current-domain updates first and all old-domain replay afterward.

At the first stage, all schedules have 90 identical current-domain batches. Interleaved and blocked schedules always consume identical minibatch multisets in different order. The no-replay arm spends the same total presentation budget on additional current examples, so it can have a current-task acquisition advantage. This is deliberate accounting rather than free extra replay compute.

The blocked schedule does **not** implement biological sleep, REM, generative dreams, synaptic downscaling, a jointly optimized consolidation phase, or a sleep/wake controller. It tests whether moving the same rehearsal updates into one block changes this particular sequential optimizer's behavior.

## Results at approximately 4,096 total parameters

Numbers are final held-out accuracy percentages, averaged equally over four domains and five seeds; ± is the half-width of a descriptive 95% Student-t interval across seeds, not standard deviation. These intervals are not corrected for the number of grid comparisons.

{chr(10).join(table)}

![Empirical learning results](learning_results.png)

## What the evidence supports

The shared and conflict regimes select different organizational tradeoffs. Generalists can reuse shared knowledge on later domains. Separate networks protect parameters from updates aimed at other domains, but remove this direct transfer path. Choosing which domains share an expert matters substantially in the conflict regime, even when total parameters and update budgets stay fixed. An efficient grouping should be learned from measured transfer/interference, not assumed from topic labels alone.

Replay order matters where tasks share parameters. In this setup, blocked old-task-only updates can damage a newly learned conflicting task; interleaved replay often preserves a better compromise. Fully isolated experts produce exactly identical final outputs under interleaved versus blocked replay because other experts' updates cannot affect their parameters. Replaying isolated experts can nevertheless reduce their final accuracy relative to spending all updates on fresh current data, because the budget is fixed and replay draws from a smaller record set. A replay or sleep mechanism therefore needs a demonstrated benefit; biological naming is insufficient.

Three total capacities are included in the complete raw and summary files. Increasing capacity does not remove the need for a good organization and training schedule. These capacities were selected for a small CPU experiment, so the location of any maximum has no justified conversion into an LLM starting size.

## Metrics and limitations

Every run records accuracy on every domain before training and after each stage. Acquisition accuracy is the current domain's score at the end of its stage. Signed backward transfer is final minus acquisition accuracy for previously learned domains; positive values preserve improvements. Forgetting is the maximum post-acquisition score minus final score. Forward transfer compares accuracy just before a new domain is trained with that model's initial accuracy on the same domain. With isolated networks it is structurally zero because their parameters remain unchanged before their own task.

Current-domain probes occur at 30, 60, and 90 minibatches. The optional 80% learning-speed marker requires two consecutive probes at or above 80%; runs that fail to meet this threshold are censored (`null`), not assigned an invented training time. Probe evaluations never change hyperparameters, stopping, samples, or model selection. Evaluation labels are never optimized against. This marker is coarse and task-specific, not a claim of general learning efficiency.

Routing-error sensitivity evaluates each test set through wrong experts, then forms an expected mixture `(1-error_probability)*correct_accuracy + error_probability*mean_wrong_expert_accuracy` at 0%, 5%, 10%, and 20% error probabilities. Wrong routes preserve the original domain tag. This is a measured-output mixture under independent uniform wrong-expert selection; it is not a learned router, semantic ambiguity study, or adversarial robustness evaluation.

Validation includes finite differences for handwritten backprop (maximum relative error {summary['validation']['handwritten_gradient_finite_difference_max_relative_error']:.2e}), all run/update/presentation counts, total parameter matching within 1.2%, and the replay-order invariance implied by complete parameter isolation. The experiment measures neural interference, not malicious prompt injection, data poisoning, process isolation, language translation, truthfulness, or privacy boundaries. Separate expert languages alone are not tested and cannot be claimed to provide such boundaries.

These results motivate a real-model follow-up with learned routing, frozen shared representations plus separate adapters, measured pairwise transfer, bounded replay with provenance, a jointly scheduled consolidation phase, explicit retention gates, and task-level correctness per joule or second. They do not justify an assertion that HIVE already outperforms frontier models.
"""
(HERE / "README.md").write_text(readme)
print(json.dumps({"validated_runs": len(raw), "paired_contrasts": contrasts}, indent=2))
