#!/usr/bin/env python3
"""A deliberately small, reproducible sequential-learning experiment for HIVE.

No downloaded model, no invented benchmark observations, and no LLM-scale claim.
All headline metrics come from actual NumPy MLP optimization and held-out labels.
"""
import os
for name in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[name] = "1"

import argparse
import json
import math
import time
from pathlib import Path

import numpy as np

N_DOMAINS = 4
FEATURES = 16
INPUT_DIM = FEATURES + N_DOMAINS
OUTPUT_DIM = 2
BATCH = 32
STEPS_PER_STAGE = 90
CURRENT_STEPS = 60
TRAIN_N = 512
TEST_N = 512
MEMORY_PER_DOMAIN = 64
BUDGETS = (1024, 4096, 8192)
SEEDS = tuple(range(5))
REGIMES = ("shared", "conflict")
SCHEDULES = ("no_replay", "interleaved_replay", "blocked_replay")
ARCHITECTURES = ((1, "all_domains"), (2, "mixed_rule_pairs"),
                 (2, "similar_rule_pairs"), (4, "one_per_domain"))


class MLP:
    def __init__(self, hidden, rng):
        self.hidden = hidden
        self.params = [
            (rng.standard_normal((INPUT_DIM, hidden)) * np.sqrt(2 / INPUT_DIM)).astype(np.float32),
            np.zeros(hidden, np.float32),
            (rng.standard_normal((hidden, OUTPUT_DIM)) * np.sqrt(1 / hidden)).astype(np.float32),
            np.zeros(OUTPUT_DIM, np.float32),
        ]
        self.m = [np.zeros_like(v) for v in self.params]
        self.v = [np.zeros_like(v) for v in self.params]
        self.step = 0

    def forward(self, x):
        a = x @ self.params[0] + self.params[1]
        h = np.maximum(a, 0)
        return h @ self.params[2] + self.params[3], h, a

    def gradients(self, x, y):
        logits, h, a = self.forward(x)
        logits = logits - logits.max(axis=1, keepdims=True)
        probs = np.exp(logits)
        probs /= probs.sum(axis=1, keepdims=True)
        loss = -np.log(probs[np.arange(len(y)), y] + 1e-12).mean()
        dz = probs.copy()
        dz[np.arange(len(y)), y] -= 1
        dz /= len(y)
        dh = (dz @ self.params[2].T) * (a > 0)
        grads = [x.T @ dh, dh.sum(axis=0), h.T @ dz, dz.sum(axis=0)]
        return float(loss), grads

    def update(self, x, y, lr=0.006):
        loss, grads = self.gradients(x, y)
        self.step += 1
        for p, m, v, g in zip(self.params, self.m, self.v, grads):
            m *= 0.9
            m += 0.1 * g
            v *= 0.999
            v += 0.001 * g * g
            mhat = m / (1 - 0.9 ** self.step)
            vhat = v / (1 - 0.999 ** self.step)
            p -= lr * mhat / (np.sqrt(vhat) + 1e-8)
        return loss

    def accuracy(self, x, y):
        return float(np.mean(self.forward(x)[0].argmax(axis=1) == y))


def gradient_check():
    """Check actual handwritten backprop against central finite differences."""
    rng = np.random.default_rng(9981)
    net = MLP(7, rng)
    net.params = [p.astype(np.float64) for p in net.params]
    x = rng.normal(size=(8, INPUT_DIM))
    y = rng.integers(0, 2, size=8)
    _, grads = net.gradients(x, y)
    records = []
    for pi, index in ((0, (3, 2)), (0, (12, 5)), (1, (2,)), (2, (4, 1)), (3, (0,))):
        p = net.params[pi]
        old = p[index]
        eps = 1e-5
        p[index] = old + eps
        plus = net.gradients(x, y)[0]
        p[index] = old - eps
        minus = net.gradients(x, y)[0]
        p[index] = old
        numeric = (plus - minus) / (2 * eps)
        analytic = float(grads[pi][index])
        relative_error = abs(numeric - analytic) / max(1e-8, abs(numeric) + abs(analytic))
        records.append({"parameter": pi, "index": index, "relative_error": relative_error})
    assert max(r["relative_error"] for r in records) < 1e-5, records
    return records


def make_data(seed, regime):
    # Both regimes use the same covariates. Labels change only by the stated rule.
    rng = np.random.default_rng(10000 + seed)
    domain_weights = rng.normal(size=(N_DOMAINS, FEATURES - 6))
    domain_weights /= np.linalg.norm(domain_weights, axis=1, keepdims=True)
    signs = np.array([1, -1, 1, -1])
    train, test = [], []
    for d in range(N_DOMAINS):
        z = rng.normal(size=(TRAIN_N + TEST_N, FEATURES)).astype(np.float32)
        shared = (0.9 * z[:, 0] + 0.7 * z[:, 1] - 0.5 * z[:, 2]
                  + 0.4 * z[:, 3] * z[:, 4] - 0.35 * np.sin(2 * z[:, 5])) / 1.35
        private = z[:, 6:] @ domain_weights[d]
        if regime == "shared":
            score = shared + 0.12 * private
        else:
            score = signs[d] * shared + 0.8 * private
        y = (score > 0).astype(np.int64)
        tags = np.zeros((len(z), N_DOMAINS), dtype=np.float32)
        tags[:, d] = 1
        x = np.concatenate([z, tags], axis=1)
        train.append((x[:TRAIN_N], y[:TRAIN_N]))
        test.append((x[TRAIN_N:], y[TRAIN_N:]))
    order = np.random.default_rng(20000 + seed).permutation(N_DOMAINS).tolist()
    return train, test, order


def make_batches(seed, order):
    """Batch selections are independent of architecture, regime, and schedule."""
    rng = np.random.default_rng(30000 + seed)
    memory = {}
    all_stages = []
    for stage, d in enumerate(order):
        current = [(d, rng.integers(0, TRAIN_N, BATCH)) for _ in range(STEPS_PER_STAGE)]
        if stage:
            replay = []
            for _ in range(STEPS_PER_STAGE - CURRENT_STEPS):
                old_d = int(rng.choice(order[:stage]))
                replay.append((old_d, rng.choice(memory[old_d], BATCH)))
            blocked = current[:CURRENT_STEPS] + replay
            interleaved = []
            for k in range(len(replay)):
                interleaved.extend(current[2*k:2*k+2])
                interleaved.append(replay[k])
        else:
            blocked = current
            interleaved = current
        all_stages.append({"no_replay": current, "blocked_replay": blocked,
                           "interleaved_replay": interleaved})
        # Only retain records that every schedule actually trained on. The first
        # 60 current minibatches are common to every schedule, including stage 0.
        observed_by_all = np.unique(np.concatenate([idx for _, idx in current[:CURRENT_STEPS]]))
        memory[d] = rng.choice(observed_by_all, MEMORY_PER_DOMAIN, replace=False)
    return all_stages


def run_one(seed, regime, budget, experts, schedule, data, batches, grouping):
    train, test, order = data
    hidden = int((budget / experts - OUTPUT_DIM) // (INPUT_DIM + OUTPUT_DIM + 1))
    rng = np.random.default_rng(40000 + seed * 31 + experts * 17 + budget)
    nets = [MLP(hidden, rng) for _ in range(experts)]
    # Tags are visible to every network; the parameter-free router groups tags.
    route = ([d % 2 for d in range(N_DOMAINS)] if grouping == "similar_rule_pairs"
             else [d // (N_DOMAINS // experts) for d in range(N_DOMAINS)])

    def evaluate():
        return [nets[route[d]].accuracy(*test[d]) for d in range(N_DOMAINS)]

    start = time.perf_counter()
    accuracy_matrix = [evaluate()]
    probes, immediate, prelearn, exposures_80 = [], [], [], []
    samples_by_domain = [0] * N_DOMAINS
    unique_samples = [set() for _ in range(N_DOMAINS)]
    for stage, domain in enumerate(order):
        prelearn.append(accuracy_matrix[-1][domain])
        stage_probes = []
        for step, (d, idx) in enumerate(batches[stage][schedule], 1):
            x, y = train[d]
            nets[route[d]].update(x[idx], y[idx])
            samples_by_domain[d] += BATCH
            unique_samples[d].update(int(v) for v in idx)
            if step % 30 == 0:
                stage_probes.append({"step": step, "presentations": step * BATCH,
                                     "accuracy": nets[route[domain]].accuracy(*test[domain])})
        probes.append(stage_probes)
        reached = None
        for prev, now in zip(stage_probes, stage_probes[1:]):
            if prev["accuracy"] >= 0.80 and now["accuracy"] >= 0.80:
                reached = now["presentations"]
                break
        exposures_80.append(reached)
        accuracy_matrix.append(evaluate())
        immediate.append(accuracy_matrix[-1][domain])
    elapsed = time.perf_counter() - start
    final = accuracy_matrix[-1]
    acquisition = [None] * N_DOMAINS
    for stage, d in enumerate(order):
        acquisition[d] = accuracy_matrix[stage + 1][d]
    # Signed backward transfer preserves improvements rather than clipping them away.
    backward_transfer = [final[d] - acquisition[d] for d in order[:-1]]
    forgetting = []
    for stage, d in enumerate(order[:-1]):
        forgetting.append(max(row[d] for row in accuracy_matrix[stage+1:]) - final[d])
    forward_transfer = [prelearn[i] - accuracy_matrix[0][d] for i, d in enumerate(order) if i > 0]
    wrong_accuracy = []
    for d in range(N_DOMAINS):
        wrong = [nets[k].accuracy(*test[d]) for k in range(experts) if k != route[d]]
        wrong_accuracy.append(float(np.mean(wrong)) if wrong else final[d])
    routing_sensitivity = {str(p): float(np.mean([(1-p)*a + p*b for a, b in zip(final, wrong_accuracy)]))
                           for p in (0.0, 0.05, 0.10, 0.20)}
    active_params = (INPUT_DIM + OUTPUT_DIM + 1) * hidden + OUTPUT_DIM
    parameter_count = experts * active_params
    presentation_count = N_DOMAINS * STEPS_PER_STAGE * BATCH
    return {
        "seed": seed, "regime": regime, "target_total_parameters": budget,
        "experts": experts, "grouping": grouping, "domain_to_expert": route,
        "schedule": schedule, "order": order,
        "hidden_units_per_expert": hidden, "total_parameters": parameter_count,
        "active_parameters_per_example": active_params,
        "weight_bytes_float32": parameter_count * 4,
        "adam_moment_bytes_float32": parameter_count * 8,
        "replay_capacity_examples": N_DOMAINS * MEMORY_PER_DOMAIN,
        "max_prior_examples_available": (N_DOMAINS - 1) * MEMORY_PER_DOMAIN if schedule != "no_replay" else 0,
        "updates": N_DOMAINS * STEPS_PER_STAGE,
        "optimizer_updates_by_expert": [net.step for net in nets],
        "sample_presentations": presentation_count,
        "sample_presentations_by_domain": samples_by_domain,
        "unique_training_examples_by_domain": [len(s) for s in unique_samples],
        # MACs exclude optimizer, biases, activations, evaluation, and host overhead.
        "estimated_training_matrix_macs": presentation_count * hidden * (2*INPUT_DIM + 3*OUTPUT_DIM),
        "estimated_inference_matrix_macs_per_example": hidden * (INPUT_DIM + OUTPUT_DIM),
        "training_and_evaluation_seconds": elapsed,
        "accuracy_matrix_initial_then_after_each_stage": accuracy_matrix,
        "current_domain_probe_curves": probes,
        "final_accuracy_by_domain": final,
        "final_mean_accuracy": float(np.mean(final)),
        "immediate_after_acquisition_accuracy": float(np.mean(immediate)),
        "new_task_prelearning_accuracy": float(np.mean(prelearn[1:])),
        "forward_transfer_vs_initial_accuracy": float(np.mean(forward_transfer)),
        "signed_backward_transfer": float(np.mean(backward_transfer)),
        "mean_forgetting_from_best_post_acquisition": float(np.mean(forgetting)),
        "presentations_to_two_consecutive_80pct_probes_by_stage": exposures_80,
        "fraction_stages_reaching_two_80pct_probes": float(np.mean([v is not None for v in exposures_80])),
        "routing_error_expected_final_accuracy": routing_sensitivity,
        "wrong_expert_accuracy_by_domain": wrong_accuracy,
    }


def summarize(results, metadata):
    rows = []
    metrics = ("final_mean_accuracy", "immediate_after_acquisition_accuracy",
               "new_task_prelearning_accuracy", "forward_transfer_vs_initial_accuracy",
               "signed_backward_transfer", "mean_forgetting_from_best_post_acquisition",
               "fraction_stages_reaching_two_80pct_probes", "training_and_evaluation_seconds")
    for regime in REGIMES:
        for budget in BUDGETS:
            for experts, grouping in ARCHITECTURES:
                for schedule in SCHEDULES:
                    group = [r for r in results if (r["regime"], r["target_total_parameters"], r["experts"], r["schedule"], r["grouping"])
                             == (regime, budget, experts, schedule, grouping)]
                    if not group:
                        continue
                    row = {k: group[0][k] for k in ("regime", "target_total_parameters", "total_parameters", "experts",
                                                    "hidden_units_per_expert", "active_parameters_per_example", "schedule", "grouping",
                                                    "updates", "sample_presentations", "estimated_training_matrix_macs")}
                    row["n_seeds"] = len(group)
                    for metric in metrics:
                        values = np.array([r[metric] for r in group])
                        sd = float(values.std(ddof=1)) if len(group) > 1 else 0.0
                        row[metric] = {"mean": float(values.mean()), "sd": sd,
                                       "ci95_t_half_width": 2.776 * sd / math.sqrt(len(group)) if len(group) == 5 else None}
                    row["routing_error_expected_final_accuracy"] = {
                        p: float(np.mean([r["routing_error_expected_final_accuracy"][p] for r in group]))
                        for p in ("0.0", "0.05", "0.1", "0.2")}
                    rows.append(row)
    paired = []
    for regime in REGIMES:
        for budget in BUDGETS:
            for schedule in SCHEDULES:
                for experts, grouping in ARCHITECTURES[1:]:
                    a = {r["seed"]: r for r in results if (r["regime"], r["target_total_parameters"], r["schedule"], r["experts"], r["grouping"])
                         == (regime, budget, schedule, experts, grouping)}
                    b = {r["seed"]: r for r in results if (r["regime"], r["target_total_parameters"], r["schedule"], r["experts"])
                         == (regime, budget, schedule, 1)}
                    diffs = [a[s]["final_mean_accuracy"] - b[s]["final_mean_accuracy"] for s in sorted(a.keys() & b.keys())]
                    if diffs:
                        sd = float(np.std(diffs, ddof=1)) if len(diffs) > 1 else 0.0
                        paired.append({"regime": regime, "target_total_parameters": budget, "schedule": schedule,
                                       "experts_vs_1": experts, "grouping": grouping, "n_seeds": len(diffs),
                                       "mean_accuracy_difference": float(np.mean(diffs)),
                                       "ci95_t_half_width": 2.776 * sd / math.sqrt(len(diffs)) if len(diffs) == 5 else None,
                                       "per_seed_difference": diffs})
    return {"metadata": metadata, "groups": rows, "paired_expert_vs_generalist_comparisons": paired}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--pilot", action="store_true", help="One seed and capacity, all architectures and schedules")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    start = time.perf_counter()
    checks = gradient_check()
    results = []
    seeds = (0,) if args.pilot else SEEDS
    budgets = (4096,) if args.pilot else BUDGETS
    for seed in seeds:
        for regime in REGIMES:
            data = make_data(seed, regime)
            batches = make_batches(seed, data[2])
            for budget in budgets:
                for experts, grouping in ARCHITECTURES:
                    for schedule in SCHEDULES:
                        result = run_one(seed, regime, budget, experts, schedule, data, batches, grouping)
                        results.append(result)
            print(json.dumps({"seed": seed, "regime": regime, "runs_done": len(results),
                              "elapsed_seconds": round(time.perf_counter() - start, 2)}), flush=True)
            # Checkpoint after each independent regime/seed, so work is recoverable.
            (args.output_dir / "raw_results.json").write_text(json.dumps(results, indent=2))
    metadata = {
        "experiment": "HIVE tiny-network sequential-learning mechanism study",
        "numpy_version": np.__version__, "run_count": len(results),
        "elapsed_seconds": time.perf_counter() - start,
        "gradient_check": checks, "seeds": list(seeds), "budgets": list(budgets),
        "input_features": FEATURES, "input_including_domain_tags": INPUT_DIM,
        "domains": N_DOMAINS, "train_examples_per_domain": TRAIN_N,
        "held_out_examples_per_domain": TEST_N, "batch_size": BATCH,
        "steps_per_stage": STEPS_PER_STAGE, "current_steps_in_replay_schedules": CURRENT_STEPS,
        "optimizer": "Adam, learning rate 0.006, beta1 0.9, beta2 0.999, epsilon 1e-8",
        "routing": "Parameter-free known-domain tag routing; identical observable one-hot tags also given to generalist",
        "grouping_control": "Two experts compare (0,1)/(2,3) with (0,2)/(1,3); the second pairs same-sign shared rules in the conflict regime. This is an optimistic known-structure control, not learned grouping.",
        "matching": "Approximately matched total parameters; exactly matched optimizer calls and presentations; executed MACs differ",
        "replay_matching": "Interleaved and blocked arms consume identical batch multisets, differing only in order",
        "no_replay_matching": "No replay uses its matching presentation budget on current-domain data",
        "ci_note": "Across-seed Student t intervals, df=4, descriptive and uncorrected for grid selection; not LLM prediction intervals",
    }
    (args.output_dir / "summary.json").write_text(json.dumps(summarize(results, metadata), indent=2))
    print(json.dumps({"complete": True, "runs": len(results), "elapsed_seconds": metadata["elapsed_seconds"]}), flush=True)


if __name__ == "__main__":
    main()
