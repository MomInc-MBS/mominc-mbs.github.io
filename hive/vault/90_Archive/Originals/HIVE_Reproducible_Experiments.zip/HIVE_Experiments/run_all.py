#!/usr/bin/env python3
"""Regenerate the supplied HIVE studies; no network or model downloads."""
import argparse
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plots-only', action='store_true')
    args = parser.parse_args()
    env = os.environ.copy()
    for name in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
        env[name] = '1'
    steps = []
    if not args.plots_only:
        steps += ['learning/learning_sim.py', 'representation/run_representation.py', 'systems/graph_simulation.py']
    steps += ['learning/analyze_results.py', 'representation/analyze_representation.py', 'systems/analyze_graph.py']
    for script in steps:
        print(f'Running {script}', flush=True)
        subprocess.run([sys.executable, str(ROOT/script)], cwd=ROOT, env=env, check=True)
    print('Completed requested HIVE computations.', flush=True)

if __name__ == '__main__':
    main()
