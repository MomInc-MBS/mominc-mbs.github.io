# HIVE runtime v2 reproduction

Python 3.11+ and ffprobe are required.

`python -m tools.hive_engine.audit evidence/state` audits the saved run.

`python -m tools.hive_engine.cycle --out rerun-new` reruns the frozen regression set.

Reports: hive/implementation/runtime-v2/README.md and RESULTS.md.
Vault/source-reference links and documentation-overlay checks require the full repository checkout.
This candidate was rejected; autonomous learning is not established.
