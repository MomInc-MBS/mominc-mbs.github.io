# HIVE recipe search reproduction

Python 3.11+.

`python -m tools.hive_engine.search --audit evidence` rechecks the saved experiment without Optuna.

Read hive/implementation/runtime-v2/LEARNING_ACCELERATION.md for isolated installation and rerun commands.
Vault/source-reference links and documentation-overlay checks require the full repository checkout.
Exposed synthetic regression evidence; no autonomous learning or operational promotion.
