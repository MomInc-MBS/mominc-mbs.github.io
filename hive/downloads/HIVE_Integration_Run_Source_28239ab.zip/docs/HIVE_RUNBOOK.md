# Reproduce the integrated HIVE mission

From `D:/Repos/hive-ai` with Python 3.11+, installed Ollama model
`myr5-hold-local:latest`, and the exact tested source:

```powershell
$env:PYTHONPATH = "$PWD\src"
python -m hive doctor --config configs/integration-20261121.json
python -m hive --store .hive/integration-20261121 integration --manifest experiments/manifests/integration-20261121.json --config configs/integration-20261121.json --output experiments/results/integration-smoke/20261121-run/report.json
python -m hive --store .hive/integration-20261121 status
python -m hive --store .hive/integration-20261121 inspect --run <job-id-from-report>
```

The command runs source-inventory aggregation (Mission A), independent-label
classification of supplied requirements (Mission B), freezes the feedback-derived
candidate, compares it on distinct development inputs against three controls,
and runs a subsequent task under the unchanged incumbent if the candidate loses.
The report records actual routes, outputs, hashes, verdicts and spend. Agreement
with independent labels is narrower than semantic correctness for all texts.

The declared six-request cap is for this mission, not permission to create new
stores repeatedly. No cloud inference, model download, weight training, arbitrary
shell execution or automatic production promotion is part of the mission.

## Restart and STOP/resume

Run the identical integration command in a new process. Completed jobs and the
final report are verified from hashed evidence; a finished run spends no new
model calls. Source, manifest and config changes are refused on an existing store.

```powershell
python -m hive --store .hive/integration-20261121 stop
python -m hive --store .hive/integration-20261121 status
python -m hive --store .hive/integration-20261121 resume
# Repeat the original integration command; resume does not refill budgets.
```

## Restore and inspect policies

The report names `initial_snapshot` and `candidate_snapshot` artifact references.
The experimental option restores only candidate learning state and prints the
unchanged governing hash. It does not mark a candidate approved.

```powershell
python -m hive --store .hive/integration-20261121 rollback --experimental <initial_snapshot>
python -m hive --store .hive/integration-20261121 rollback --experimental <candidate_snapshot>
```

The existing production operation remains
`rollback --checkpoint <independently-approved-checkpoint>`. Unapproved snapshots
are refused. Do not set approval flags as a demonstration shortcut.

## Verification and limits

```powershell
python -m pytest -q
npx e2e run --config e2e.config.mts --output experiments/results/integration-cli-e2e
```

These are CLI/software checks. They do not claim physical-phone testing. The
historical video/finite code-fixture tasks retain their original acceptance
limits. An arbitrary isolated repository execution adapter and broad frontier
gain require further implementation and independent acceptance.
