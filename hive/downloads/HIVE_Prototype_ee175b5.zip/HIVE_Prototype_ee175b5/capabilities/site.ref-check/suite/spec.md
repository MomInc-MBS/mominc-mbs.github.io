Check the local references of a site against its file manifest and report the broken ones.

Fixture author: a conductor-side agent (not Ian). The suite was written independently of any adapter and of any tool; ground truth is by construction.

Input env: {"files":[{"name":NAME,"format":"base64","data":BASE64},...]} with exactly 2 files in arbitrary order. Each `data` is the base64 text of a UTF-8 JSON document (any whitespace). The file names and their order tell you nothing: tell the two documents apart by their "schema" field.
- the TABLE has "schema":"ref-table-v1", "commit":STR, "refs":[{"class":C,"kind":K,"page":P,"raw":R,"target":T},...] (other fields such as "pages" may be present: ignore them). C is one of "local", "external", "scheme", "anchor", "escapes-root". T is a string exactly when C is "local" (a site-root path with no leading slash, or a directory ending in "/", the root being "/"), otherwise null. K, P and R are strings.
- the MANIFEST has "schema":"site-manifest-v1", "commit":STR, "excluded_prefixes":[STR,...], "files":[{"path":P,"bytes":N,"sha256":HEX},...] (other fields may be present: ignore them). File paths are site-root paths (no leading slash), case-sensitive.
Output ERROR (the plain text, not JSON) if the two files are not exactly one table and one manifest, the two "commit" values differ, "refs" is not a list, a table row breaks the rule on C and T above (or K, P or R is not a string), "excluded_prefixes" is not a list of strings, or two manifest files share a path.

Classify every table row, one outcome per row (duplicate rows count once each):
- class "external", "scheme" or "anchor": not local, nothing to check.
- class "escapes-root": broken, reason "escapes-root".
- class "local", target T:
  1. out of scope when, for some excluded prefix X, T starts with X, or T does not end in "/" and T + "/" starts with X (so the prefix "tv/" covers "tv/a.js", "tv/" and "tv"). Plain string prefixes. This is decided first, whether or not a file exists.
  2. otherwise present ("local ok") when T is a manifest path (only when T does not end in "/"), or when D + "/index.html" is a manifest path, where D is T without a final "/" (for the root "/", D is empty and the path is just "index.html"). So a directory reference, with or without the trailing slash, is satisfied by its index.html.
  3. otherwise broken with reason "case-mismatch" when some candidate path from step 2 (T itself if it does not end in "/", and the index.html path) equals a manifest path once both are lower-cased; else broken with reason "missing". Everything else is exact and case-sensitive.

Output: ONE string, a JSON text written with json.dumps(obj, sort_keys=True, separators=(",", ":")):
{"schema":"broken-refs-v1","commit":COMMIT,"broken":[{"kind":K,"page":P,"raw":R,"reason":REASON,"target":T},...],"totals":{"refs":N,"not_local":N,"local_ok":N,"out_of_scope":N,"broken":N}}
- commit is copied from the table.
- broken: one entry per broken row (target is null for "escapes-root"), sorted ascending by (page, target with null taken as the empty string, raw, kind, reason), Python string order (code points).
- totals: refs = number of table rows; not_local, local_ok, out_of_scope and broken count the outcomes above (an "escapes-root" row counts as broken); the four add up to refs.
