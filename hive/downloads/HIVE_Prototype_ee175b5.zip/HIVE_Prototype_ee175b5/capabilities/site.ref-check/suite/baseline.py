"""Scripted baseline for site.ref-check: HAND-WRITTEN, stdlib only, not model output, not learned. Positional (first file = table, second = manifest); a reference is
broken when its target is not an exact manifest path; no directory rule, no case check, no out-of-scope prefixes, no escapes, no errors. Expected to fail acceptance."""
import base64
import json


def run(env):
    tab, man = (json.loads(base64.b64decode(f["data"])) for f in env["files"][:2])
    have = {f["path"] for f in man["files"]}
    broken, tot = [], {"refs": 0, "not_local": 0, "local_ok": 0, "out_of_scope": 0, "broken": 0}
    for r in tab["refs"]:
        tot["refs"] += 1
        if r["target"] is None:
            tot["not_local"] += 1
        elif r["target"] in have:
            tot["local_ok"] += 1
        else:
            tot["broken"] += 1
            broken.append({"kind": r["kind"], "page": r["page"], "raw": r["raw"], "reason": "missing", "target": r["target"]})
    return json.dumps({"schema": "broken-refs-v1", "commit": tab["commit"], "broken": broken, "totals": tot}, sort_keys=True, separators=(",", ":"))
