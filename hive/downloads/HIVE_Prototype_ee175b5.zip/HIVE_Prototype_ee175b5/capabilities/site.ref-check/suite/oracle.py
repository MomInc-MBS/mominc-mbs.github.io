"""Independent oracle for site.ref-check. Needs only the input env. Pure stdlib, shares no code with any candidate.
The two input files are told apart by their "schema" field, never by name or position. Fixture author: a conductor-side agent (Sol-B), not Ian."""
import base64
import json

TABLE, MANIFEST, OUT = "ref-table-v1", "site-manifest-v1", "broken-refs-v1"
CLASSES = {"local", "external", "scheme", "anchor", "escapes-root"}


def render(doc):
    return json.dumps(doc, sort_keys=True, separators=(",", ":"))


def _doc(f):
    try:
        return json.loads(base64.b64decode(f["data"], validate=True).decode("utf-8"))
    except (ValueError, KeyError, TypeError):
        return None


def status(target, paths, lower, prefixes):
    """-> 'ok' | 'out_of_scope' | 'missing' | 'case-mismatch' for a local target path."""
    for p in prefixes:
        if target.startswith(p) or (not target.endswith("/") and (target + "/").startswith(p)):
            return "out_of_scope"
    d = target[:-1] if target.endswith("/") else target
    cands = ([target] if not target.endswith("/") else []) + [(d + "/" if d else "") + "index.html"]
    if any(c in paths for c in cands):
        return "ok"
    if any(c.lower() in lower for c in cands):
        return "case-mismatch"
    return "missing"


def expected(env):
    fs = env["files"]
    docs = [_doc(f) for f in fs]
    ts = [d for d in docs if isinstance(d, dict) and d.get("schema") == TABLE]
    ms = [d for d in docs if isinstance(d, dict) and d.get("schema") == MANIFEST]
    if len(fs) != 2 or len(ts) != 1 or len(ms) != 1:
        return "ERROR"
    t, m = ts[0], ms[0]
    try:
        if not isinstance(t["commit"], str) or t["commit"] != m["commit"] or not isinstance(t["refs"], list):
            return "ERROR"
        prefixes = m["excluded_prefixes"]
        if not isinstance(prefixes, list) or not all(isinstance(p, str) for p in prefixes):
            return "ERROR"
        paths = [f["path"] for f in m["files"]]
        if not all(isinstance(p, str) for p in paths) or len(set(paths)) != len(paths):
            return "ERROR"
        pathset, lower = set(paths), {p.lower() for p in paths}
        tot = {"refs": 0, "not_local": 0, "local_ok": 0, "out_of_scope": 0, "broken": 0}
        broken = []
        for r in t["refs"]:
            cls, tgt = r["class"], r["target"]
            if cls not in CLASSES or not all(isinstance(r[k], str) for k in ("kind", "page", "raw")) or (cls == "local") != isinstance(tgt, str) or (cls != "local" and tgt is not None):
                return "ERROR"
            tot["refs"] += 1
            if cls in ("external", "scheme", "anchor"):
                tot["not_local"] += 1
                continue
            s = "escapes-root" if cls == "escapes-root" else status(tgt, pathset, lower, prefixes)
            if s == "ok":
                tot["local_ok"] += 1
            elif s == "out_of_scope":
                tot["out_of_scope"] += 1
            else:
                tot["broken"] += 1
                broken.append({"kind": r["kind"], "page": r["page"], "raw": r["raw"], "reason": s, "target": tgt})
    except (KeyError, TypeError):
        return "ERROR"
    broken.sort(key=lambda b: (b["page"], b["target"] or "", b["raw"], b["kind"], b["reason"]))
    return render({"schema": OUT, "commit": t["commit"], "broken": broken, "totals": tot})
