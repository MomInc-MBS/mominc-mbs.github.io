"""Public dev cases and the shared deterministic builder for site.ref-check.
Fixture author: a conductor-side agent (Sol-B), NOT Ian. Written independently of any adapter and of any candidate tool. A small synthetic site is built first
(its manifest), then each reference row is generated from a chosen outcome (ok file, ok directory, missing, wrong case, out of scope, escapes root, not local),
so the expected report is known by construction. Every case is also checked against the independent oracle by gen_private and the tests."""
import base64
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oracle  # noqa: E402

DIRS = ["", "docs", "docs/guide", "img", "assets/css", "Play", "a/b"]
NAMES = ["about.html", "logo.png", "Logo.PNG", "app.js", "x.css", "readme.md", "pic 1.jpg", "café.png"]
PREFIXES = ["tv/", "backend/", "tools/gen.js", "download/"]
EXT = ["https://example.com/x.png", "//cdn.example.net/z.css", "mailto:me@example.com", "data:image/png;base64,AAAA", "#top", "?q=1"]
EXT_CLASS = ["external", "external", "scheme", "scheme", "anchor", "anchor"]
PAGES = ["index.html", "docs/index.html", "docs/guide/a.html", "a/b/c.html", "Play/p.html", "assets/css/site.css", "about.html"]
FILE_NAMES = ["manifest.json", "site-manifest.json", "m.json", "table.json", "refs.json", "ref-table.json"]


def sha(rng):
    return "%064x" % rng.getrandbits(256)


def swap(path):
    return path.swapcase()


def build(rng, n, error=None):
    """-> (env, expected). n = number of reference rows is about 4*n. error: None | 'commit-mismatch' | 'two-manifests' | 'duplicate-path' | 'local-null-target' -> 'ERROR'."""
    files = set()
    for d in DIRS:
        if rng.random() < 0.6:
            files.add((d + "/" if d else "") + "index.html")
        for nm in rng.sample(NAMES, rng.choice([1, 2, 3])):
            files.add((d + "/" if d else "") + nm)
    files = sorted(files)
    excluded = sorted(rng.sample(PREFIXES, rng.choice([0, 1, 2, 3])))
    lower = {f.lower() for f in files}
    dirs_with_index = sorted({f[:-len("index.html")].rstrip("/") for f in files if f.endswith("index.html")} - {""})
    dirs_no_index = sorted({f.rsplit("/", 1)[0] for f in files if "/" in f} - set(dirs_with_index))
    commit = "%07x" % rng.getrandbits(28)
    rows, broken, tot = [], [], {"refs": 0, "not_local": 0, "local_ok": 0, "out_of_scope": 0, "broken": 0}
    gone = 0
    for _ in range(4 * n):
        page = rng.choice(PAGES)
        kind = rng.choice(["href", "src", "srcset", "css-url"])
        r = rng.random()
        status = None
        if r < 0.25:
            t = rng.choice(files)
            row, status = ("local", t), "ok"
        elif r < 0.37 and (dirs_with_index or "index.html" in files):
            d = rng.choice(dirs_with_index + (["/"] if "index.html" in files else []))
            t = d if d == "/" else d + rng.choice(["/", "", "/"])
            row, status = ("local", t if t != "" else "/"), "ok"
        elif r < 0.50:
            gone += 1
            t = rng.choice(["", "docs/", "img/", "a/b/"]) + "gone-%d.%s" % (gone, rng.choice(["png", "html", "js"]))
            row, status = ("local", t), "missing"
        elif r < 0.56 and dirs_no_index:
            t = rng.choice(dirs_no_index)
            row, status = ("local", t + "/"), "missing"
        elif r < 0.66:
            t = swap(rng.choice(files))
            if t in files or t.lower() not in lower:
                continue
            row, status = ("local", t), "case-mismatch"
        elif r < 0.72 and dirs_with_index:
            d = swap(rng.choice(dirs_with_index))
            if d in dirs_with_index or (d + "/index.html") in files or d == d.lower():
                continue
            row, status = ("local", d + "/"), "case-mismatch"
        elif r < 0.82 and excluded:
            p = rng.choice(excluded)
            t = p + rng.choice(["", "a.js", "x/y.png"]) if p.endswith("/") else p
            if p.endswith("/") and rng.random() < 0.3:
                t = p[:-1]  # the directory itself, no trailing slash
            row, status = ("local", t), "out_of_scope"
        elif r < 0.88:
            row, status = ("escapes-root", None), "escapes-root"
        else:
            i = rng.randrange(len(EXT))
            row, status = (EXT_CLASS[i], None), "not_local"
            raw = EXT[i]
        cls, t = row
        if status != "not_local":
            raw = rng.choice(["", "./", "../"]) + (t or "x.png") + rng.choice(["", "", "?v=2", "#f"])
        if cls == "escapes-root":
            raw = "../" * 4 + "x.png"
        rows.append({"class": cls, "kind": kind, "page": page, "raw": raw, "target": t if cls == "local" else None})
        copies = 2 if rng.random() < 0.1 else 1  # duplicate references count once each
        rows += [dict(rows[-1])] * (copies - 1)
        for _c in range(copies):
            tot["refs"] += 1
            if status == "not_local":
                tot["not_local"] += 1
            elif status == "ok":
                tot["local_ok"] += 1
            elif status == "out_of_scope":
                tot["out_of_scope"] += 1
            else:
                tot["broken"] += 1
                broken.append({"kind": kind, "page": page, "raw": raw, "reason": status, "target": rows[-1]["target"]})
    broken.sort(key=lambda b: (b["page"], b["target"] or "", b["raw"], b["kind"], b["reason"]))
    expected = oracle.render({"schema": oracle.OUT, "commit": commit, "broken": broken, "totals": tot})
    rng.shuffle(rows)
    manifest = {"schema": oracle.MANIFEST, "commit": commit, "committed_at": "2026-01-02T03:04:05Z", "excluded_prefixes": excluded,
                "files": [{"path": f, "bytes": rng.randint(0, 5000), "sha256": sha(rng)} for f in files]}
    table = {"schema": oracle.TABLE, "commit": commit, "pages": len(PAGES), "refs": rows}
    if error == "commit-mismatch":
        table["commit"] = commit + "x"
    elif error == "duplicate-path":
        manifest["files"].append(dict(manifest["files"][0]))
    elif error == "local-null-target":
        loc = [r for r in rows if r["class"] == "local"]
        if not loc:
            return build(rng, n, error)
        loc[0]["target"] = None

    def f(name, doc):
        text = json.dumps(doc, sort_keys=True, separators=(",", ":")) if rng.random() < 0.6 else json.dumps(doc, indent=rng.randint(1, 3))
        return {"name": name, "format": "base64", "data": base64.b64encode(text.encode("utf-8")).decode("ascii")}

    nt, nm = rng.sample(FILE_NAMES, 2)
    fs = [f(nt, table), f(nm, manifest)]
    if error == "two-manifests":
        fs = [f(nt, manifest), f(nm, manifest)]
    rng.shuffle(fs)
    return {"files": fs}, ("ERROR" if error else expected)


def case(name, rng, n, error=None):
    env, expected = build(rng, n, error)
    return {"name": name, "env": env, "expected": expected}


def cases():
    rng = random.Random(20261130)
    return [case("small-site", rng, 2), case("mixed-outcomes", rng, 6), case("out-of-scope-and-case", rng, 10), case("larger-table", rng, 20),
            case("commit-mismatch-is-an-error", rng, 3, "commit-mismatch"), case("two-manifests-is-an-error", rng, 3, "two-manifests")]
