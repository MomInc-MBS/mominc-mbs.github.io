"""Public dev cases and the shared deterministic image builder for image.asset-match.
Fixture author: a conductor-side agent, NOT Ian. Written independently of any adapter and of any candidate tool; ground truth is by construction
(which variants descend from which base picture), and every case is checked against the independent oracle before it is accepted."""
import base64
import io
import math
import os
import random
import sys

from PIL import Image, ImageDraw, ImageEnhance, ImageOps

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oracle  # noqa: E402

STEMS = ["IMG", "photo", "Scan", "asset", "DSC", "holiday", "Logo final", "banner", "tile", "screenshot"]


def scene(rng, w=112, h=84, cells=None):
    """A synthetic picture: a smooth random colour field (6x5 cells, bicubic) plus 3 large hard-edged shapes. Different seeds differ
    strongly; `cells` reuses another picture's cell colours in a new layout (a same-palette hard negative)."""
    if cells is None:
        cells = [tuple(rng.randint(0, 255) for _ in range(3)) for _ in range(30)]
    c = Image.new("RGB", (6, 5))
    c.putdata(cells)
    im = c.resize((w, h), Image.BICUBIC)
    d = ImageDraw.Draw(im)
    for k in range(3):
        x0, y0 = rng.randint(0, w - 40), rng.randint(0, h - 30)
        (d.rectangle if k % 2 else d.ellipse)([x0, y0, x0 + rng.randint(25, 45), y0 + rng.randint(18, 32)],
                                              fill=tuple(rng.randint(0, 255) for _ in range(3)))
    return im, cells


def variant(rng, base, kind, jpeg=True):
    """kind: exact | rename | resize | size | jpeg | crop | bright | mixed. Returns (image, fmt). Alpha is kept through every transform (jpeg=False: PNG only)."""
    im, fmt = base.copy(), "PNG"
    if kind in ("resize", "mixed"):
        s = rng.uniform(0.6, 1.4)
        im = im.resize((max(24, round(im.width * s)), max(24, round(im.height * s))), Image.BICUBIC)
    if kind in ("crop", "mixed"):
        w, h = im.size
        l, t, r, b = (rng.uniform(0.0, 0.08) for _ in range(4))
        im = im.crop((round(w * l), round(h * t), w - round(w * r), h - round(h * b)))
    if kind == "size":
        s = rng.choice((180, 192, 512))
        im = im.resize((s, s), Image.LANCZOS)
    if kind in ("bright", "mixed"):
        f = rng.uniform(0.85, 1.15)
        if im.mode == "RGBA":  # brightness acts on the colour only: the stock enhancer would also fade the alpha band
            rgb = ImageEnhance.Brightness(im.convert("RGB")).enhance(f)
            im = Image.merge("RGBA", (*rgb.split(), im.getchannel("A")))
        else:
            im = ImageEnhance.Brightness(im).enhance(f)
    if jpeg and kind in ("jpeg", "mixed"):
        fmt = "JPEG"
    return im, fmt


def encode(im, fmt, rng):
    buf = io.BytesIO()
    if fmt == "JPEG":
        im.convert("RGB").save(buf, "JPEG", quality=rng.randint(45, 90))
    else:
        im.save(buf, "PNG")
    return buf.getvalue()


def file_name(rng, fmt, used):
    while True:
        n = f"{rng.choice(STEMS)}_{rng.randint(1, 9999):04d}{rng.choice(['', ' copy', ' - Copy', '-final'])}"
        n += rng.choice([".jpg", ".jpeg", ".JPG"] if fmt == "JPEG" else [".png", ".PNG"])
        if n.lower() not in used:
            used.add(n.lower())
            return n


def build(rng, n_bases, hard=True, size=(112, 84)):
    """-> (env, truth_groups, sizes). Each base gets 1-4 files (exact copy under another name / resize / re-encode / crop / brightness / mixed);
    when hard, extra single files are a mirrored base and a same-colours different-layout picture (both must NOT match their source)."""
    used, files, groups, sizes = set(), [], [], {}
    made = [scene(rng, *size) for _ in range(n_bases)]
    bases = [m[0] for m in made]
    extra = []
    if hard:
        extra.append(ImageOps.mirror(bases[0]))
        cells = list(made[-1][1])
        rng.shuffle(cells)
        extra.append(scene(rng, *size, cells=cells)[0])
    for k, base in enumerate(bases + extra):
        grp = []
        for kind in rng.sample(["exact", "rename", "resize", "jpeg", "crop", "bright", "mixed"], rng.randint(1, 4) if k < len(bases) else 1):
            im, fmt = variant(rng, base, kind)
            raw = encode(im, fmt, rng)
            name = file_name(rng, fmt, used)
            files.append({"name": name, "format": "base64", "data": base64.b64encode(raw).decode("ascii")})
            sizes[name] = len(raw)
            grp.append(name)
        groups.append(grp)
    order = list(range(len(files)))
    rng.shuffle(order)
    return {"files": [files[i] for i in order]}, groups, sizes


# ---------------------------------------------------------------- real-like families (contract 2.0.0): alpha kept through every transform
GLYPHS = ("tri", "bars", "ring", "plus", "slash")


def _col(rng):
    return tuple(rng.randint(0, 255) for _ in range(3))


def figure(rng, p=None, size=192):
    """A sparse opaque silhouette (thick-line figure, off centre so its mirror lands elsewhere) on a TRANSPARENT background. p = pose parameters."""
    p = p or {"c": _col(rng), "cx": rng.uniform(0.3, 0.7), "w": rng.randint(30, 40), "arms": [rng.uniform(0, 360) for _ in range(2)],
              "legs": [rng.uniform(40, 140) for _ in range(2)], "len": rng.uniform(0.2, 0.3)}
    S = size * 4
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    cx, sh, L, fill, w = p["cx"] * S, 0.38 * S, p["len"] * S, p["c"] + (255,), p["w"] * 4
    d.ellipse([cx - 0.06 * S, 0.14 * S, cx + 0.06 * S, 0.26 * S], fill=fill)
    d.line([cx, 0.26 * S, cx, 0.58 * S], fill=fill, width=w)
    for a in p["arms"]:
        d.line([cx, sh, cx + L * math.cos(math.radians(a)), sh + L * math.sin(math.radians(a))], fill=fill, width=w)
    for a in p["legs"]:
        d.line([cx, 0.58 * S, cx + 1.3 * L * math.cos(math.radians(a)), 0.58 * S + 1.3 * L * math.sin(math.radians(a))], fill=fill, width=w)
    return im.resize((size, size), Image.LANCZOS), p


def icon(rng, p=None, size=192, rgba=False):
    """A flat 2-3 colour icon (background plate, one glyph, one dot); rgba=True leaves the plate's corners transparent."""
    p = p or {"bg": _col(rng), "fg": _col(rng), "dot": _col(rng), "glyph": rng.choice(GLYPHS), "k": [rng.uniform(0.25, 0.9) for _ in range(3)]}
    S = size * 4
    im = Image.new("RGBA" if rgba else "RGB", (S, S), (0, 0, 0, 0) if rgba else p["bg"])
    d = ImageDraw.Draw(im)
    d.rounded_rectangle([0, 0, S, S], radius=(0.4 if rgba else 0.18) * S, fill=p["bg"])
    k, fg = p["k"], p["fg"]
    if p["glyph"] == "tri":
        d.polygon([(0.2 * S, 0.8 * S), (0.2 * S + 0.6 * S * k[0], 0.2 * S), (0.8 * S, 0.8 * S * (0.6 + 0.4 * k[1]))], fill=fg)
    elif p["glyph"] == "bars":
        for i in range(3):
            d.rectangle([(0.2 + 0.22 * i) * S, (0.8 - 0.6 * k[i]) * S, (0.36 + 0.22 * i) * S, 0.8 * S], fill=fg)
    elif p["glyph"] == "ring":
        d.ellipse([0.2 * S, 0.2 * S, (0.4 + 0.4 * k[0]) * S, (0.4 + 0.4 * k[1]) * S], outline=fg, width=int(0.08 * S))
    elif p["glyph"] == "plus":
        c, r = (0.3 + 0.4 * k[0]) * S, (0.3 + 0.4 * k[1]) * S
        d.rectangle([c - 0.06 * S, 0.2 * S, c + 0.06 * S, 0.8 * S], fill=fg)
        d.rectangle([0.2 * S, r - 0.06 * S, 0.8 * S, r + 0.06 * S], fill=fg)
    else:
        d.line([0.2 * S, (0.2 + 0.6 * k[0]) * S, 0.8 * S, (0.2 + 0.6 * k[1]) * S], fill=fg, width=int(0.14 * S))
    d.ellipse([0.7 * S, 0.14 * S, 0.84 * S, 0.28 * S], fill=p["dot"])
    return im.resize((size, size), Image.LANCZOS), p


def _sig(im):
    return oracle.signature(encode(im, "PNG", None))


def sparse_icon(rng, p=None, size=192):
    """The real-site failure shape: a thin outline glyph (a few percent of the pixels opaque) on a TRANSPARENT background whose hidden colour is black."""
    p = p or {"c": _col(rng), "glyph": rng.choice(GLYPHS), "k": [rng.uniform(0.25, 0.9) for _ in range(3)]}
    S, w, fill = size * 4, int(0.06 * size * 4), p["c"] + (255,)
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d, k = ImageDraw.Draw(im), p["k"]
    if p["glyph"] == "tri":
        d.polygon([(0.15 * S, 0.85 * S), (0.15 * S + 0.7 * S * k[0], 0.15 * S), (0.85 * S, 0.85 * S * (0.6 + 0.4 * k[1]))], outline=fill, width=w)
    elif p["glyph"] == "bars":
        for i in range(3):
            d.line([(0.2 + 0.28 * i) * S, 0.85 * S, (0.2 + 0.28 * i) * S, (0.85 - 0.7 * k[i]) * S], fill=fill, width=w)
    elif p["glyph"] == "ring":
        d.ellipse([0.15 * S, 0.15 * S, (0.4 + 0.45 * k[0]) * S, (0.4 + 0.45 * k[1]) * S], outline=fill, width=w)
    elif p["glyph"] == "plus":
        c, r = (0.3 + 0.4 * k[0]) * S, (0.3 + 0.4 * k[1]) * S
        d.line([c, 0.15 * S, c, 0.85 * S], fill=fill, width=w)
        d.line([0.15 * S, r, 0.85 * S, r], fill=fill, width=w)
    else:
        d.line([0.15 * S, (0.15 + 0.7 * k[0]) * S, 0.85 * S, (0.15 + 0.7 * k[1]) * S], fill=fill, width=w)
    return im.resize((size, size), Image.LANCZOS), p


SPARSE_KINDS = ["exact", "rename", "resize", "size", "bright"]  # no crop: an 8 percent shift moves a hairline off itself, so no picture-level answer survives it
KINDS = ["exact", "rename", "resize", "size", "crop", "bright", "mixed"]


def build_real(rng, n_bases, hard=True, families=("figure", "icon", "icon_rgba", "sparse")):
    """-> (env, truth_groups, sizes). Real-site-like pictures: sparse silhouettes on transparent backgrounds, flat icons (opaque or with
    transparent corners), square size families (180/192/512), byte-identical copies under new names. Everything stays PNG with its alpha.
    hard adds single files that must NOT match: a mirrored or upside-down silhouette, a same-palette different-glyph icon, a sibling icon
    (same design and colours, different bar heights / glyph geometry). Bases, negatives and transforms are re-drawn until the oracle sees
    them clearly on their side of THRESH; a negative that cannot get clear of its source is dropped. real_case / gen_private then apply
    the whole-case gap rule."""
    used, files, groups, sizes = set(), [], [], {}
    far_d = oracle.THRESH * 1.3
    bases, sigs, extra = [], [], []
    for _ in range(n_bases):
        fam = rng.choice(families)
        for _t in range(30):
            im, p = figure(rng) if fam == "figure" else sparse_icon(rng) if fam == "sparse" else icon(rng, rgba=fam == "icon_rgba")
            s = _sig(im)
            if all(oracle.distance(s, o) > far_d for o in sigs):
                break
        bases.append((fam, (im, p)))
        sigs.append(s)

    def far(im, *makers):
        s0 = _sig(im)
        for mk in makers:
            for _t in range(20):
                c = mk()
                if oracle.distance(s0, _sig(c)) > far_d:
                    return [(fam, c)]
        return []
    if hard:
        for fam, (im, p) in bases[:2]:
            if fam == "figure":
                extra += far(im, lambda: ImageOps.mirror(im)) + far(im, lambda: ImageOps.flip(im))
            elif fam == "sparse":
                extra += far(im, lambda: sparse_icon(rng, dict(p, glyph=rng.choice([g for g in GLYPHS if g != p["glyph"]])))[0])
                extra += far(im, lambda: sparse_icon(rng, dict(p, k=[rng.uniform(0.15, 0.95) for _ in range(3)]))[0], lambda: ImageOps.mirror(im))
            else:
                rg = fam == "icon_rgba"
                extra += far(im, lambda: icon(rng, dict(p, glyph=rng.choice([g for g in GLYPHS if g != p["glyph"]])), rgba=rg)[0])
                extra += far(im, lambda: icon(rng, dict(p, k=[rng.uniform(0.15, 0.95) for _ in range(3)]), rgba=rg)[0])
    for k, (fam, im) in enumerate([(b[0], b[1][0]) for b in bases] + extra):
        grp, mine = [], []
        s0 = _sig(im)
        kinds = SPARSE_KINDS if fam == "sparse" else KINDS
        for kind in rng.sample(kinds, rng.randint(1, 3) if k < len(bases) else 1):
            for _t in range(30):  # re-draw the transform until the oracle sees the same picture clearly
                v, fmt = variant(rng, im, kind, jpeg=False)
                raw = encode(v, fmt, rng)
                if oracle.distance(s0, oracle.signature(raw)) < oracle.THRESH / 1.25 * 0.8:
                    break
            mine.append(raw)
        if k < len(bases) and rng.random() < 0.6:
            mine.append(mine[0])  # a byte-identical copy under another name
        for raw in mine:
            name = file_name(rng, "PNG", used)
            files.append({"name": name, "format": "base64", "data": base64.b64encode(raw).decode("ascii")})
            sizes[name] = len(raw)
            grp.append(name)
        groups.append(grp)
    order = list(range(len(files)))
    rng.shuffle(order)
    return {"files": [files[i] for i in order]}, groups, sizes


def gap(env, groups):
    """(max distance inside a truth group, min distance between pictures of different groups) under the oracle."""
    names = [f["name"] for f in env["files"]]
    sig = [oracle.signature(oracle.decode(f)) for f in env["files"]]
    grp = {n: i for i, g in enumerate(groups) for n in g}
    intra, inter = 0.0, 9e9
    for i in range(len(names)):
        for j in range(i + 1, len(names)):
            d = oracle.distance(sig[i], sig[j])
            if grp[names[i]] == grp[names[j]]:
                intra = max(intra, d)
            else:
                inter = min(inter, d)
    return intra, inter


def within_limits(env):
    """The contract's input limits: 2-20 files, 256 KiB each, 2 MiB in all (decoded)."""
    n = [len(base64.b64decode(f["data"])) for f in env["files"]]
    return 2 <= len(n) <= 20 and max(n) <= 262144 and sum(n) <= 2097152


def wide(env, groups):
    """The generator's acceptance rule: worst same-picture distance < THRESH/1.25 and best different-picture distance > THRESH*1.25."""
    intra, inter = gap(env, groups)
    return intra * 1.25 < oracle.THRESH and inter > oracle.THRESH * 1.25


def real_case(name, rng, n_bases, hard=True, families=("figure", "icon", "icon_rgba", "sparse")):
    while True:
        env, groups, sizes = build_real(rng, n_bases, hard, families)
        if within_limits(env) and wide(env, groups):
            return {"name": name, "env": env, "expected": oracle.render(groups, sizes)}


def case(name, rng, n_bases, hard=True):
    env, groups, sizes = build(rng, n_bases, hard)
    return {"name": name, "env": env, "expected": oracle.render(groups, sizes)}  # truth by construction


def cases():
    rng = random.Random(20261126)
    return [case("two-copies-and-one-other", rng, 2, False), case("three-pictures", rng, 3, False), case("one-picture-and-lookalikes", rng, 1, True),
            case("mirror-is-not-a-match", rng, 2, True), case("many-variants", rng, 4, False), case("mixed-with-distractors", rng, 4, True),
            real_case("real-silhouettes-mirror-sibling", rng, 3, True, ("figure",)),
            real_case("real-flat-icons-size-families", rng, 3, True, ("icon", "icon_rgba")),
            real_case("real-sparse-transparent-icons", rng, 3, True, ("sparse",)),
            real_case("real-mixed-families", rng, 4, True), real_case("real-copies-no-distractors", rng, 3, False)]
