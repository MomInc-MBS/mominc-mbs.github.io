"""Acceptance cases for image.asset-match from a random seed, written ONLY under --out (gitignored) with their answers.
Prints just {"set_sha256","n"}. Every case is accepted only if (1) the independent oracle equals the by-construction truth and
(2) the measured distance gap is wide: worst same-picture distance < THRESH/1.25 and best different-picture distance > THRESH*1.25."""
import argparse
import hashlib
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gen_public  # noqa: E402
import oracle  # noqa: E402


def gap(env, groups):
    return gen_public.gap(env, groups)  # call-time lookup: loaders that exec this file by path may have another suite's gen_public cached


def generate(seed, n=24, report=None):
    rng, cases = random.Random(seed), []
    while len(cases) < n:
        if rng.random() < 0.5:  # real-like families (alpha, flat icons, size families, byte copies) as often as the synthetic scenes
            env, groups, sizes = gen_public.build_real(rng, rng.randint(2, 5), hard=rng.random() < 0.7)
        else:
            env, groups, sizes = gen_public.build(rng, rng.randint(2, 5), hard=rng.random() < 0.6)
        if not gen_public.within_limits(env):
            continue
        intra, inter = gap(env, groups)
        if intra * 1.25 >= oracle.THRESH or inter <= oracle.THRESH * 1.25:
            continue  # ambiguous picture pair: regenerate, never score it
        truth = oracle.render(groups, sizes)
        if oracle.expected(env) != truth:  # a wide gap yet a different answer can only be a bug in the oracle or the builder
            raise SystemExit("oracle disagrees with the by-construction truth: fixture rejected")
        if report is not None:
            report.append((intra, inter))
        cases.append({"name": f"random-{len(cases)}", "env": env, "expected": truth})
    return cases


def set_sha(cases):
    return hashlib.sha256(json.dumps(cases, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int)
    a = ap.parse_args(argv)
    cases = generate(random.SystemRandom().randrange(2**62) if a.seed is None else a.seed)
    sha = set_sha(cases)
    d = os.path.join(a.out, sha)
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "cases.json"), "w", encoding="utf-8", newline="\n") as f:
        json.dump(cases, f, sort_keys=True, separators=(",", ":"))
    print(json.dumps({"set_sha256": sha, "n": len(cases)}))


if __name__ == "__main__":
    main()
