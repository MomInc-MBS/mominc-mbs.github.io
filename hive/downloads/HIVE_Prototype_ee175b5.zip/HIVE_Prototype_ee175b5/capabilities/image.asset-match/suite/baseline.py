"""Scripted baseline for image.asset-match: HAND-WRITTEN, stdlib only, not model output, not learned. Groups files whose bytes are identical
(sha256). It cannot see renamed re-encodes, resizes, crops or brightness changes, so it is expected to fail acceptance."""
import base64
import hashlib
import json


def run(env):
    by, size = {}, {}
    for f in env["files"]:
        raw = base64.b64decode(f["data"])
        by.setdefault(hashlib.sha256(raw).hexdigest(), []).append(f["name"])
        size[f["name"]] = len(raw)
    groups = [sorted(g) for g in by.values() if len(g) > 1]
    groups.sort(key=lambda g: g[0])
    return json.dumps({"schema": "image-match-manifest-v1",
                       "groups": [{"id": "g%03d" % (i + 1), "members": g, "keeper": sorted(g, key=lambda n: (-size[n], n))[0]} for i, g in enumerate(groups)],
                       "singletons": sorted(g[0] for g in by.values() if len(g) == 1)}, sort_keys=True, separators=(",", ":"))
