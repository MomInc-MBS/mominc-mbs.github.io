Match image files that are the same underlying picture, and write a normalised manifest. This is near-duplicate matching (the same picture under the transforms listed below), not semantic similarity: two different pictures of the same kind of thing (two poses of one figure, two icons in one colour scheme) are different pictures.

Fixture author: a conductor-side agent (not Ian). The suite was written independently of any adapter and of any tool; ground truth is by construction.

Input env: {"files":[{"name":NAME,"format":"base64","data":BASE64},...]} with 2 to 20 files, in arbitrary order. Each `data` is the base64 text of a PNG or JPEG file (at most 256 KiB each, 2 MiB in total). `name` is the file name as given (unique, ASCII letters, digits, space, dot, dash, underscore). Each entry also has "path": the same bytes as a read-only file (use it with libraries that take file paths). Names and file formats tell you nothing: the same picture may appear under different names, as PNG and as JPEG.

Two files MATCH when they come from the same base picture after any of: a rename, a resize (about 0.6x to 1.4x), JPEG re-encoding (quality 45-90), a crop of up to 8 percent per border, or a brightness change of up to 15 percent. Transparency counts: judge what a viewer sees. Composite each image over white and over black; two files match only if they are the same picture on both. Square icon size families (for example 180, 192 and 512 pixels) are one picture, and byte-identical files under different names match. Different pictures never match, including a left-right mirror of a picture and a picture built from the same colours in a different layout. Matching is transitive: files that match through a chain are one group.

Output: ONE string, a JSON text written with json.dumps(obj, sort_keys=True, separators=(",", ":")):
{"schema":"image-match-manifest-v1","groups":[{"id":"g001","keeper":NAME,"members":[NAME,...]},...],"singletons":[NAME,...]}
- groups: only sets of 2 or more matching files. `members` sorted ascending by name (Python string order, code points). Groups sorted ascending by their first member, ids "g001", "g002", ... in that order.
- keeper: the member with the LARGEST file size in bytes (decoded data length); ties go to the smaller name.
- singletons: every file that matches no other, sorted ascending by name.
Every input name appears exactly once, in a group or in singletons.
