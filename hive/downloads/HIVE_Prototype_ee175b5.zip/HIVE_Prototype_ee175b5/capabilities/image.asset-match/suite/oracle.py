"""Independent oracle for image.asset-match (contract 2.0.0: transparency counts). Needs only the input env (so it also verifies unseen inputs at run time). Host side, Pillow + stdlib.
Algorithm: a perceptual distance of its own (central 84 percent of the picture, 24x24 grayscale, per-image mean/std normalised, root-mean-square
difference), taken on the picture composited over white AND over black (distance = the larger of the two; opaque pictures give the same
signature twice), and union-find over pairs closer than THRESH. It shares no code with any candidate. THRESH sits inside a measured gap: the
generator refuses to write a case set unless the worst same-picture distance is below THRESH/1.25 and the best different-picture distance is
above THRESH*1.25 (see gen_private.py)."""
import base64
import io
import json

from PIL import Image

THRESH = 0.70
SIDE = 24


def decode(f):
    if f.get("format") != "base64":
        raise ValueError("input files must be base64")
    return base64.b64decode(f["data"], validate=True)


def _sig(im):
    w, h = im.size
    box = (round(w * 0.08), round(h * 0.08), round(w * 0.92), round(h * 0.92))
    px = list(im.convert("L").crop(box).resize((SIDE, SIDE), Image.BOX).tobytes())
    m = sum(px) / len(px)
    sd = (sum((p - m) ** 2 for p in px) / len(px)) ** 0.5
    return [0.0] * len(px) if sd < 1e-6 else [(p - m) / sd for p in px]


def signature(raw):
    """(signature over white, signature over black). What a viewer sees: transparent pixels show the backdrop."""
    im = Image.open(io.BytesIO(raw))
    im.load()
    if im.mode in ("RGBA", "LA", "PA") or "transparency" in im.info:
        im = im.convert("RGBA")
        out = []
        for bg in (255, 0):
            back = Image.new("RGBA", im.size, (bg, bg, bg, 255))
            out.append(_sig(Image.alpha_composite(back, im)))
        return tuple(out)
    s = _sig(im)
    return (s, s)


def distance(a, b):
    """Root-mean-square difference of the z-scored signatures (= sqrt(2 * (1 - correlation))), the larger of the white and black backdrops. The
    v1 mean-absolute difference could not separate sparse silhouettes (generator gap rule met on about 1 case in 7); RMS can."""
    return max((sum((x - y) ** 2 for x, y in zip(u, v)) / len(u)) ** 0.5 for u, v in zip(a, b))


def render(groups, sizes):
    """Canonical manifest text. groups = lists of names (any order); sizes = {name: bytes}. Keeper = largest file, ties by smaller name."""
    gs = [sorted(g) for g in groups if len(g) > 1]
    gs.sort(key=lambda g: g[0])
    single = sorted(g[0] for g in groups if len(g) == 1)
    out = {"schema": "image-match-manifest-v1",
           "groups": [{"id": "g%03d" % (i + 1), "members": g, "keeper": sorted(g, key=lambda n: (-sizes[n], n))[0]} for i, g in enumerate(gs)],
           "singletons": single}
    return json.dumps(out, sort_keys=True, separators=(",", ":"))


def groups_of(env, thresh=THRESH):
    fs = env["files"]
    names = [f["name"] for f in fs]
    if len(set(names)) != len(names):
        raise ValueError("duplicate input names")
    raws = [decode(f) for f in fs]
    sig = [signature(r) for r in raws]
    par = list(range(len(fs)))

    def find(i):
        while par[i] != i:
            par[i] = par[par[i]]
            i = par[i]
        return i
    for i in range(len(fs)):
        for j in range(i + 1, len(fs)):
            if distance(sig[i], sig[j]) < thresh:
                par[find(i)] = find(j)
    by = {}
    for i, n in enumerate(names):
        by.setdefault(find(i), []).append(n)
    return list(by.values()), {n: len(r) for n, r in zip(names, raws)}, sig


def expected(env):
    g, sizes, _ = groups_of(env)
    return render(g, sizes)
