"""Scripted baseline for site.ref-extract: HAND-WRITTEN, stdlib only, not model output, not learned. It greps double-quoted href/src values from every page, ignores
srcset, style, CSS pages, comments and scripts, and never reports an error. Expected to fail acceptance."""
import base64
import json
import re


def run(env):
    doc = json.loads(base64.b64decode(env["files"][0]["data"]))
    rows = []
    for p in sorted(doc["pages"], key=lambda q: q["path"]):
        rows += [{"kind": k, "page": p["path"], "raw": r} for k, r in re.findall(r'(href|src)="([^"]*)"', p["text"])]
    return json.dumps({"schema": "raw-ref-table-v1", "commit": doc["commit"], "pages": len(doc["pages"]), "refs": rows}, sort_keys=True, separators=(",", ":"))
