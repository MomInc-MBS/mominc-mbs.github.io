Extract every raw reference from the pages of a website snapshot (scan only, no resolving).
Fixture author: a conductor-side agent (not Ian); the suite was written independently of any adapter.

Input env: {"files":[{"name":N,"format":"base64","data":B64}]}, exactly 1 file: base64 of UTF-8 JSON {"schema":"site-pages-v1","commit":STR,"pages":[{"path":P,"text":T},...]} (ignore other top-level fields; page order arbitrary).
Output the plain text ERROR if the file count is not 1, the JSON is invalid, "schema" is wrong, "commit" is not a string, "pages" is not a list of {path,text} string pairs, or two pages share a path.

A page whose path ends (any letter case) in .html/.htm is HTML, in .css is CSS; any other page gives no rows.
HTML, rows in source order (case-insensitive):
1. Delete comments `<!-- ... -->` (unterminated: to the end), then the body of each `<script ...>` up to `</script>` (unterminated: to the end); the script start tag stays.
2. A start tag is `<` + letter + text up to the first `>` (values never contain `>`). Text outside tags is never read.
3. In a start tag read only attributes href, src, srcset, style, written name="v" or name='v' (spaces around `=` allowed; the name must follow whitespace, a quote or `/`, so data-src is not src). Trim ASCII whitespace from v; empty v gives no row.
   href -> kind "href"; src -> "src"; srcset -> split on `,`, trim each piece, URL = piece up to its first whitespace (so 2x and 480w are dropped), skip empty, each URL kind "srcset"; style -> each url() (rule below) kind "css-url".
4. The body of `<style ...>` up to `</style>` (unterminated: to the end) is CSS: each url() is a "css-url" row, emitted at the position of its `<style>` tag in the page's source order (before the rows of any later tag, never deferred to the end of the page). The style tag's own attributes are not read.
CSS page: each url() is a "css-url" row.
url() rule: delete `/* ... */` comments (unterminated: to the end), then every `url(` (any case) + optional whitespace + "double", 'single' or unquoted text (no `)`, quote or whitespace) + optional whitespace + `)` is a row, raw = inner text trimmed. Non-matching `url(` or empty text: no row.

Output ONE string: json.dumps(obj, sort_keys=True, separators=(",", ":")) of
{"schema":"raw-ref-table-v1","commit":COMMIT,"pages":N,"refs":[{"kind":K,"page":P,"raw":R},...]}
N = number of input pages; refs: pages in ascending path order, each page's rows in source order, duplicates kept, raw exactly as written (no decoding).
Example: page "a/x.html" with `<a href="../b.png?v=1"><img srcset='s.png 1x, t.png 2x'>` gives (href, ../b.png?v=1), (srcset, s.png), (srcset, t.png).
