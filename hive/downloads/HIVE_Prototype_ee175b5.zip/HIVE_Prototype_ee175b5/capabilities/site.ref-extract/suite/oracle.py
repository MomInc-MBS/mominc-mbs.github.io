"""Independent oracle for site.ref-extract (scan only). Needs only the input env. Pure stdlib, shares no code with any candidate.
Fixture author: a conductor-side agent (Sol-B), not Ian. The grammar is exactly what spec.md tells the proposer."""
import base64
import json
import re

SCHEMA_IN, SCHEMA_OUT = "site-pages-v1", "raw-ref-table-v1"
WS = " \t\n\r\f"
S, I = re.S, re.I
COMMENT = re.compile(r"<!--.*?(?:-->|\Z)", S)
SCRIPT = re.compile(r"(<script\b[^>]*>).*?(?:</script>|\Z)", S | I)
BLOCK = re.compile(r"<style\b[^>]*>(.*?)(?:</style>|\Z)|<[A-Za-z][^>]*>", S | I)
ATTR = re.compile(r"""(?<=[\s"'/])(href|src|srcset|style)\s*=\s*(?:"([^"]*)"|'([^']*)')""", I)
CSSCOMMENT = re.compile(r"/\*.*?(?:\*/|\Z)", S)
CSSURL = re.compile(r"""url\(\s*(?:"([^"]*)"|'([^']*)'|([^)"'\s]*))\s*\)""", I)


def render(doc):
    return json.dumps(doc, sort_keys=True, separators=(",", ":"))


def css_urls(text):
    vals = (next(g for g in m.groups() if g is not None).strip(WS) for m in CSSURL.finditer(CSSCOMMENT.sub("", text)))
    return [("css-url", v) for v in vals if v]


def html_refs(text):
    out = []
    for m in BLOCK.finditer(SCRIPT.sub(r"\1", COMMENT.sub("", text))):
        if m.group(1) is not None:
            out += css_urls(m.group(1))
            continue
        for a in ATTR.finditer(m.group(0)):
            name, val = a.group(1).lower(), (a.group(2) if a.group(2) is not None else a.group(3)).strip(WS)
            if name == "style":
                out += css_urls(val)
            elif name == "srcset":
                out += [("srcset", c.split()[0]) for c in (x.strip(WS) for x in val.split(",")) if c]
            elif val:
                out.append((name, val))
    return out


def expected(env):
    fs = env["files"]
    try:
        doc = json.loads(base64.b64decode(fs[0]["data"], validate=True).decode("utf-8")) if len(fs) == 1 else None
        if not (isinstance(doc, dict) and doc.get("schema") == SCHEMA_IN and isinstance(doc.get("commit"), str) and isinstance(doc.get("pages"), list)):
            return "ERROR"
        seen = set()
        for p in doc["pages"]:
            if not (isinstance(p, dict) and isinstance(p.get("path"), str) and isinstance(p.get("text"), str)) or p["path"] in seen:
                return "ERROR"
            seen.add(p["path"])
    except (ValueError, KeyError, TypeError):
        return "ERROR"
    rows = []
    for p in sorted(doc["pages"], key=lambda q: q["path"]):
        low = p["path"].lower()
        ev = html_refs(p["text"]) if low.endswith((".html", ".htm")) else css_urls(p["text"]) if low.endswith(".css") else []
        rows += [{"kind": k, "page": p["path"], "raw": r} for k, r in ev]
    return render({"schema": SCHEMA_OUT, "commit": doc["commit"], "pages": len(doc["pages"]), "refs": rows})
