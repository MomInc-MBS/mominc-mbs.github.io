"""Public dev cases and the shared deterministic builder for site.ref-extract.
Fixture author: a conductor-side agent (Sol-B), NOT Ian. Written independently of any adapter and of any candidate tool. The expected table is computed by
construction: each raw reference is generated from a known value and then written into a page with a known spelling, so the truth never comes from parsing; every case is also checked against the independent oracle by gen_private and the tests."""
import base64
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oracle  # noqa: E402

DIRS = ["", "a", "a/b", "a/b/c", "docs", "docs/guide", "img", "assets/css", "Play"]
NAMES = ["index.html", "about.html", "logo.png", "Logo.PNG", "app.js", "style.css", "my file.png", "café.png", "50%.png", "a b.html", "data.json", "font.woff2", "pic-1.jpg", "x.svg"]
EXTERNAL = ["https://example.com/x.png", "http://example.org/a/b.html", "HTTPS://CDN.example.com/lib.js", "//cdn.example.net/z.css", "https://fonts.example.com/css?family=A&display=swap"]
SCHEME = ["mailto:me@example.com", "tel:+15551234", "data:image/png;base64,iVBORw0KGgo=", "javascript:void(0)", "blob:https://example.com/1"]
ANCHOR = ["#", "#top", "#a/b", "?q=1", "?a=1#x", "#?x"]
SUFFIX = ["", "", "", "?v=3", "#top", "?a=1&b=2#frag", "?next=../a/b", "#frag?x"]
FILE_NAMES = ["site-pages.json", "pages.json", "input.json", "export.json"]


def pct(s, rng):
    """Percent-encode space and non-ASCII bytes; the hex case varies. A bare % is left alone (it is not followed by two hex digits in NAMES)."""
    up = rng.random() < 0.5
    out = []
    for b in s.encode("utf-8"):
        out.append(("%%%02X" if up else "%%%02x") % b if b > 127 or b == 32 else chr(b))
    return "".join(out)


def rel(d, target):
    """Relative spelling of site path `target` (a file, or a directory ending '/') from the page directory `d` (list of segments)."""
    t = [x for x in target.split("/") if x]
    n = 0
    while n < len(d) and n < len(t) and d[n] == t[n]:
        n += 1
    isdir = target.endswith("/")
    if not isdir and n == len(t):
        n -= 1
    body = "/".join([".."] * (len(d) - n) + t[n:])
    return (body + "/" if body else "./") if isdir else body


def spell_local(rng, page, target):
    """A raw string whose resolution from `page` is `target`."""
    d = page.split("/")[:-1]
    style = rng.choice(["rel", "rel", "root", "dot", "detour", "pct-dots"])
    r = rel(d, target)
    if style == "root":
        raw = "/" + target if target != "/" else "/"
    elif style == "dot" and not r.startswith("."):
        raw = "./" + r
    elif style == "detour":
        k = r.find("/")
        raw = (r[:k + 1] + "zz/../" + r[k + 1:]) if k >= 0 and not r.startswith("..") else "zz/../" + r
    elif style == "pct-dots" and d:
        raw = "%2e%2e/" + rel(d[:-1], target)
    else:
        raw = r
    if rng.random() < 0.7:
        raw = pct(raw, rng)
    return raw + rng.choice(SUFFIX)


def make_ref(rng, page, targets):
    """-> (raw, class, target)."""
    r = rng.random()
    if r < 0.55:
        t = rng.choice(targets)
        return spell_local(rng, page, t), "local", t
    if r < 0.70:
        return rng.choice(EXTERNAL), "external", None
    if r < 0.78:
        return rng.choice(SCHEME), "scheme", None
    if r < 0.88:
        return rng.choice(ANCHOR), "anchor", None
    depth = len(page.split("/")) - 1
    raw = "../" * (depth + 1) + "x.png" if rng.random() < 0.7 else "/../x.png"
    return raw + rng.choice(SUFFIX), "escapes-root", None


def quote(rng, v):
    return "'" + v + "'" if rng.random() < 0.35 else '"' + v + '"'


def attr(rng, name, v, pad=False):
    if rng.random() < 0.15:
        name = name.upper()
    return name + rng.choice(["=", "=", " = "]) + (quote(rng, " " + v + " ") if pad else quote(rng, v))


def ws(rng):
    return rng.choice([" ", " ", "\n  ", "\t"])


def noise(rng):
    return rng.choice(["<!-- <a href=\"ghost.html\"> <img src=ghost.png> -->", "<script>var s = '<a href=\"ghost2.html\">'; var u = 'url(ghost.png)';</script>",
                       "<script type=\"module\">document.write(\"<img src='g.png'>\")</script>", "<p data-src=\"ghost3.png\" poster=\"ghost4.png\" action=\"ghost5\">text href=\"ghost6\" src=\"x\"</p>", "<style>/* url(ghost7.png) */</style>",
                       "<div>a < b and 1<2 </div>", "<!doctype html>", "</a>", "<p>url(ghost.png) in text</p>"])


def css_refs(rng, page, targets, k, quotes):
    """k references that can be written as url(...) with one of `quotes`. -> [(quote, (raw, class, target))]"""
    out = []
    while len(out) < k:
        r = make_ref(rng, page, targets)
        qq = rng.choice(quotes)
        if any(c in r[0] for c in "\"')") or (qq == "" and any(c in r[0] for c in " \t\n")):
            continue
        out.append((qq, r))
    return out


def html_page(rng, page, targets):
    parts, rows = [], []

    def add(kind, r):
        rows.append({"kind": kind, "page": page, "raw": r[0]})

    for _ in range(rng.choice([0, 1, 2, 3, 4, 6])):
        t = rng.random()
        if rng.random() < 0.3:
            parts.append(noise(rng))
        if t < 0.35:
            r = make_ref(rng, page, targets)
            tag = rng.choice(["a", "link", "area"])
            extra = rng.choice(["", " class=\"x\"", " rel=stylesheet"])
            parts.append(f"<{rng.choice([tag, tag.upper()])}{extra}{ws(rng)}{attr(rng, 'href', r[0])}{rng.choice(['>', ' >', ' />'])}")
            add("href", r)
        elif t < 0.6:
            r = make_ref(rng, page, targets)
            tag = rng.choice(["img", "script", "iframe", "source", "audio"])
            parts.append(f"<{tag}{ws(rng)}{attr(rng, 'src', r[0])}{'></script>' if tag == 'script' else rng.choice(['>', ' />', '></' + tag + '>'])}")
            add("src", r)
        elif t < 0.72:
            cands, buf = [], []
            for _k in range(rng.choice([1, 2, 3])):
                r = make_ref(rng, page, targets)
                if any(c in r[0] for c in ", \t\n") or r[1] == "scheme":
                    r = ("/img/fb.png?s=1", "local", "img/fb.png")
                cands.append(r)
                buf.append(r[0] + rng.choice(["", " 1x", " 2x", " 480w", "  800w"]))
            parts.append(f"<img{ws(rng)}{attr(rng, 'srcset', rng.choice([', ', ',', ' , ']).join(buf))}>")
            for r in cands:
                add("srcset", r)
        elif t < 0.84:
            attr_form = rng.random() < 0.5
            refs = css_refs(rng, page, targets, rng.choice([1, 2]), ["", "'"] if attr_form else ["", '"', "'"])
            body = ";".join("background:url(" + qq + r[0] + qq + ")" for qq, r in refs)
            parts.append(f"<div style=\"{body}\">x</div>" if attr_form else f"<style>{rng.choice(['', '/* url(nope.png) */'])}.k{{{body}}}</style>")
            for _, r in refs:
                add("css-url", r)
        else:
            r = make_ref(rng, page, targets)
            parts.append(f"<a{ws(rng)}{attr(rng, 'href', r[0], pad=True)}>dup</a>")
            parts.append(f"<a href=\"{r[0]}\">dup</a>")
            add("href", r)
            add("href", r)
    return ("\n".join(parts) if parts else rng.choice(["", "<html></html>", "plain text"])), rows


def css_page(rng, page, targets):
    parts, rows = [], []
    for i in range(rng.choice([0, 1, 2, 4])):
        (qq, r), = css_refs(rng, page, targets, 1, ["", '"', "'"])
        if rng.random() < 0.25:
            parts.append(f"/* url({r[0]}) */")
        sp = " " if rng.random() < 0.3 else ""
        parts.append(f".c{i}{{background:url({sp}{qq}{r[0]}{qq}{sp})}}")
        rows.append({"kind": "css-url", "page": page, "raw": r[0]})
    return "\n".join(parts), rows


def build(rng, n, error=None):
    """-> (env, expected). n pages. error: None | 'duplicate-path' | 'wrong-schema' | 'two-files' -> expected 'ERROR'."""
    pool = set()
    while len(pool) < 18:
        d = rng.choice(DIRS)
        pool.add((d + "/" if d else "") + rng.choice(NAMES))
    targets = sorted(pool) + ["docs/", "a/b/", "img/", "/", "assets/css/"]
    pages, rows, used = [], [], set()
    while len(pages) < n:
        d = rng.choice(DIRS)
        ext = rng.choice(["html"] * 4 + ["css", "htm", "js", "HTML"])
        p = (d + "/" if d else "") + "p%d.%s" % (len(pages), ext)
        if p in used:
            continue
        used.add(p)
        if ext == "css":
            text, r = css_page(rng, p, targets)
        elif ext == "js":
            text, r = "var a = '<a href=\"ghost.html\">'; var b = 'url(ghost.png)';", []  # other extensions contribute nothing
        else:
            text, r = html_page(rng, p, targets)
        pages.append({"path": p, "text": text})
        rows += r
    rng.shuffle(pages)
    commit = "%07x" % rng.getrandbits(28)
    expected = oracle.render({"schema": oracle.SCHEMA_OUT, "commit": commit, "pages": len(pages), "refs": sorted(rows, key=lambda r: r["page"])})  # sorted() is stable: document order kept
    doc = {"schema": oracle.SCHEMA_IN, "commit": commit, "pages": pages}
    if error == "duplicate-path" and pages:
        pages.append(dict(pages[0]))
    elif error == "wrong-schema":
        doc["schema"] = "site-pages-v2"
    text = json.dumps(doc, sort_keys=True, separators=(",", ":")) if rng.random() < 0.5 else json.dumps(doc, indent=2)
    f = {"name": rng.choice(FILE_NAMES), "format": "base64", "data": base64.b64encode(text.encode("utf-8")).decode("ascii")}
    files = [f, dict(f, name="second.json")] if error == "two-files" else [f]
    return {"files": files}, ("ERROR" if error else expected)


def case(name, rng, n, error=None):
    env, expected = build(rng, n, error)
    return {"name": name, "env": env, "expected": expected}


def tiny(name, pages, refs, commit="c0ffee1"):
    """A hand-written worked case: `pages` as {path: text}, `refs` as [(page, kind, raw)] written out by hand (truth by construction, not by parsing)."""
    doc = {"schema": oracle.SCHEMA_IN, "commit": commit, "pages": [{"path": p, "text": t} for p, t in pages.items()]}
    f = {"name": "site-pages.json", "format": "base64", "data": base64.b64encode(json.dumps(doc).encode("utf-8")).decode("ascii")}
    exp = oracle.render({"schema": oracle.SCHEMA_OUT, "commit": commit, "pages": len(pages), "refs": [{"kind": k, "page": p, "raw": r} for p, k, r in refs]})
    return {"name": name, "env": {"files": [f]}, "expected": exp}


def cases():
    rng = random.Random(20261129)
    tiny1 = tiny("worked-tiny", {
        "docs/b.css": "/* url(no.png) */ a{background:url( 'x.png' )} b{background:url(../y.png)}",
        "docs/a.html": "<A HREF='../i.png?v=1#t'><img srcset=\"s.png 1x, t.png 2x,\" alt=\"x\"><!-- <a href=\"no.html\"> -->\n"
                       "<script>var u='<a href=\"no2.html\">'</script><p data-src=\"no3.png\" style=\"background:url(&quot;z.png&quot;)\">hi</p>",
        "notes.txt": "<a href=\"no4.html\">"},
        [("docs/a.html", "href", "../i.png?v=1#t"), ("docs/a.html", "srcset", "s.png"), ("docs/a.html", "srcset", "t.png"), ("docs/a.html", "css-url", "&quot;z.png&quot;"),
         ("docs/b.css", "css-url", "x.png"), ("docs/b.css", "css-url", "../y.png")])
    style_first = tiny("style-body-before-tag", {"s/p.html": "<style>.a{background:url(bg.png)}</style><a href=\"l.html\"><img src=\"i.png\">"},
                       [("s/p.html", "css-url", "bg.png"), ("s/p.html", "href", "l.html"), ("s/p.html", "src", "i.png")])
    return [tiny1, case("few-pages", rng, 4), case("many-pages", rng, 10), case("empty-and-noise", rng, 6),
            case("duplicate-path-is-an-error", rng, 3, "duplicate-path"), case("wrong-schema-is-an-error", rng, 2, "wrong-schema"),
            case("two-files-is-an-error", rng, 1, "two-files"), style_first]
