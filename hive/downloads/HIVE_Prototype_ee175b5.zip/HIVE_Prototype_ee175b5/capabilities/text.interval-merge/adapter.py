"""Hand-written reference adapter for text.interval-merge (the stub proposer's answer in the G1 gate; not a learned capability).
Sort-and-sweep; json is the only import."""
import json

DIGITS = "0123456789"


def _num(t):
    t = t.strip(" \t")
    body = t[1:] if t.startswith("-") else t
    if not body or any(c not in DIGITS for c in body):
        return None
    return int(t)


def _interval(line):
    for k in range(1, len(line)):
        if line[k] == "-":
            a, b = _num(line[:k]), _num(line[k + 1:])
            if a is not None and b is not None and a <= b:
                return [a, b]
    return None


def run(env):
    ivs = []
    for n, raw in enumerate(env["files"][0]["text"].split("\n"), 1):
        line = raw.strip(" \t\r")
        if not line or line.startswith("#"):
            continue
        iv = _interval(line)
        if iv is None:
            return "ERROR line " + str(n)
        ivs.append(iv)
    ivs.sort()
    out = []
    for a, b in ivs:
        if out and a <= out[-1][1] + 1:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return ",".join(str(a) + "-" + str(b) for a, b in out)
