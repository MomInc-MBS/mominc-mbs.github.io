"""Acceptance cases for text.interval-merge from a random seed, written ONLY under --out (gitignored) with their answers.
Prints just {"set_sha256","n"}: the proposer side learns the hash, never the cases. Includes metamorphic twins (shuffled lines)
and idempotence cases (a merged answer fed back as input)."""
import argparse
import hashlib
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gen_public  # noqa: E402
import oracle  # noqa: E402


def _lines(rng, n, span, wide=0):
    out = []
    for _ in range(n):
        a = rng.randint(-span, span)
        out.append((a, a + rng.randint(0, wide or span // 5 + 1)))
    return out


def _text(rng, ivs, noise):
    rows = []
    for a, b in ivs:
        rows.append(f"{' ' * rng.randint(0, noise)}{a}{' ' * rng.randint(0, noise)}-{' ' * rng.randint(0, noise)}{b}{' ' * rng.randint(0, noise)}")
        if noise and rng.random() < 0.2:
            rows.append(rng.choice(["", "# note", "   "]))
    return "\n".join(rows) + ("\n" if rng.random() < 0.5 else "")


def generate(seed, n=24):
    rng, cases = random.Random(seed), []

    def add(name, text):
        cases.append(gen_public.case(name, text))

    def with_twins(name, ivs, noise=0):
        add(name, _text(rng, ivs, noise))
        merged = cases[-1]["expected"]
        sh = ivs[:]
        rng.shuffle(sh)
        add(name + "-shuffled", _text(rng, sh, noise))
        if merged and not merged.startswith("ERROR"):
            add(name + "-idempotent", merged.replace(",", "\n"))

    with_twins("small-dense", _lines(rng, 60, 40))
    with_twins("huge-coordinates", [(a * 10**9, a * 10**9 + b) for a, b in _lines(rng, 40, 500, 3000)])
    with_twins("negatives-and-noise", _lines(rng, 50, 100), noise=2)
    add("two-hundred-lines", _text(rng, _lines(rng, 200, 400), 1))
    add("all-identical-big", "\n".join(["-1000000000-1000000000"] * 50))
    add("single-line-error", "9-1")
    add("error-after-comments", "# a\n\n# b\n1-5\nx-y\n3-2\n")
    add("error-only-last-line", "1-2\n3-4\n5-6\n7-six")
    add("trailing-blank-lines", "1-2\n\n\n\n")
    add("zero-and-adjacent", "0-0\n1-1\n2-2\n-1--1\n")
    add("leading-zeros", "007-9\n10-0012\n")
    while len(cases) < n:
        k = rng.randint(1, 30)
        add(f"random-{len(cases)}", _text(rng, _lines(rng, k, rng.choice([5, 50, 10**6])), rng.randint(0, 2)))
    return cases


def set_sha(cases):
    return hashlib.sha256(json.dumps(cases, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int)
    a = ap.parse_args(argv)
    cases = generate(random.SystemRandom().randrange(2**62) if a.seed is None else a.seed)
    sha = set_sha(cases)
    d = os.path.join(a.out, sha)
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "cases.json"), "w", encoding="utf-8", newline="\n") as f:
        json.dump(cases, f, sort_keys=True, separators=(",", ":"))
    print(json.dumps({"set_sha256": sha, "n": len(cases)}))


if __name__ == "__main__":
    main()
