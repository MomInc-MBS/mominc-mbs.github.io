"""Independent property oracle for text.interval-merge. Stdlib only; nothing from src/hive and nothing shared with adapter.py.
The answer is derived by COVERAGE (which integers are in some interval), not by sorting and sweeping: a bitmask over the value range
when it is small, coordinate compression with a membership test per elementary segment otherwise. expected() also asserts the
properties every correct answer has: canonical form, shuffle invariance and idempotence (the output, fed back as input, is unchanged)."""
import re

LINE = re.compile(r"[ \t]*(-?[0-9]+)[ \t]*-[ \t]*(-?[0-9]+)[ \t]*")
CANON = re.compile(r"-?[0-9]+--?[0-9]+(,-?[0-9]+--?[0-9]+)*")
SMALL = 200000


def parse(text):
    """([(start, end)], None) or (None, first bad line number)."""
    out = []
    for n, raw in enumerate(text.split("\n"), 1):
        line = raw[:-1] if raw.endswith("\r") else raw
        s = line.strip(" \t")
        if not s or s.startswith("#"):
            continue
        m = LINE.fullmatch(line)
        if m is None or int(m.group(1)) > int(m.group(2)):
            return None, n
        out.append((int(m.group(1)), int(m.group(2))))
    return out, None


def runs(ivs):
    """Maximal runs of covered integers, as (a, b) pairs."""
    lo, hi = min(a for a, _ in ivs), max(b for _, b in ivs)
    if hi - lo < SMALL:
        mask = 0
        for a, b in ivs:
            mask |= ((1 << (b - a + 1)) - 1) << (a - lo)
        bits = bin(mask)[:1:-1]  # least significant bit first
        return [(lo + m.start(), lo + m.end() - 1) for m in re.finditer("1+", bits)]
    pts = sorted({a for a, _ in ivs} | {b + 1 for _, b in ivs})
    out = []
    for x, y in zip(pts, pts[1:]):  # elementary segment [x, y-1] is wholly covered or wholly not
        if any(a <= x and y - 1 <= b for a, b in ivs):
            if out and out[-1][1] == x - 1:
                out[-1] = (out[-1][0], y - 1)
            else:
                out.append((x, y - 1))
    return out


def fmt(rs):
    return ",".join(f"{a}-{b}" for a, b in rs)


def expected(env):
    """env = {"files":[{"format":"text","text":TEXT}]}."""
    (f,) = env["files"]
    assert set(f) == {"format", "text"} and f["format"] == "text"
    ivs, bad = parse(f["text"])
    if bad:
        return f"ERROR line {bad}"
    if not ivs:
        return ""
    out = fmt(runs(ivs))
    assert CANON.fullmatch(out)
    assert fmt(runs(ivs[::-1])) == out  # shuffle invariance
    again, _ = parse(out.replace(",", "\n"))
    assert fmt(runs(again)) == out  # idempotence
    return out
