"""Scripted baseline for text.interval-merge: a straightforward HAND-WRITTEN merge (not model output, not learned)."""
import json


def run(env):
    ivs = []
    for n, raw in enumerate(env["files"][0]["text"].split("\n"), 1):
        s = raw.strip(" \t\r")
        if not s or s[0] == "#":
            continue
        pair = None
        for k in range(1, len(s)):
            if s[k] == "-":
                lo, hi = s[:k].strip(" \t"), s[k + 1:].strip(" \t")
                if all(p.lstrip("-")[:1] and p.lstrip("-").isdigit() and p.count("-") <= 1 and p.isascii() for p in (lo, hi)):
                    pair = [int(lo), int(hi)]
                    break
        if pair is None or pair[0] > pair[1]:
            return "ERROR line " + str(n)
        ivs.append(pair)
    changed = True
    while changed:  # repeat until no two intervals overlap or touch
        changed = False
        for i in range(len(ivs)):
            for j in range(i + 1, len(ivs)):
                if ivs[i][0] <= ivs[j][1] + 1 and ivs[j][0] <= ivs[i][1] + 1:
                    ivs[i] = [min(ivs[i][0], ivs[j][0]), max(ivs[i][1], ivs[j][1])]
                    del ivs[j]
                    changed = True
                    break
            if changed:
                break
    ivs.sort()
    return ",".join(str(a) + "-" + str(b) for a, b in ivs)
