"""Public dev cases for text.interval-merge: deterministic, shown to the proposer. Each case = {"name", "env", "expected"}."""
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oracle  # noqa: E402


def case(name, text):
    env = {"files": [{"format": "text", "text": text}]}
    return {"name": name, "env": env, "expected": oracle.expected(env)}


def cases():
    rng = random.Random(20261125)
    big = [(s, s + rng.randint(0, 30)) for s in (rng.randint(0, 500) for _ in range(200))]
    rng.shuffle(big)
    return [case("empty", ""),
            case("blank-and-comments-only", "# nothing\n\n   \n# more\n"),
            case("single", "5-9\n"),
            case("single-point", "7-7"),
            case("touching", "1-3\n4-6\n"),
            case("gap-of-one-integer", "1-2\n4-5\n"),
            case("nested", "1-10\n3-4\n2-9\n"),
            case("duplicates", "2-5\n2-5\n2-5\n"),
            case("unsorted-overlap", "10-12\n1-3\n2-6\n11-20\n"),
            case("negatives", "-5--2\n-3-4\n10-12\n"),
            case("spaces-comments-crlf", "# header\r\n\r\n  3 - 4  \r\n1-2\r\n"),
            case("reversed-endpoints", "1-2\n5-2\n"),
            case("non-numeric", "1-2\n# ok\nfoo\n"),
            case("200-line-shuffle", "\n".join(f"{a}-{b}" for a, b in big) + "\n")]
