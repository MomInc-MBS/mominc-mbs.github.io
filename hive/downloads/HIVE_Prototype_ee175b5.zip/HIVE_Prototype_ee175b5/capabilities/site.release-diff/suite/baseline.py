"""Scripted baseline for site.release-diff: HAND-WRITTEN, stdlib only, not model output, not learned. Positional (first manifest = older), compares paths only
(a changed file is never reported as modified), no sections or byte deltas worth the name, no errors. Expected to fail acceptance."""
import base64
import json


def run(env):
    a, b = (json.loads(base64.b64decode(f["data"])) for f in env["files"][:2])
    pa, pb = {x["path"] for x in a["files"]}, {x["path"] for x in b["files"]}
    added, removed = sorted(pb - pa), sorted(pa - pb)
    return json.dumps({"schema": "release-changes-v1", "older": {"commit": a["commit"], "committed_at": a["committed_at"]}, "newer": {"commit": b["commit"], "committed_at": b["committed_at"]},
                       "added": added, "removed": removed, "modified": [], "unchanged": len(pa & pb), "sections": [],
                       "totals": {"added": len(added), "bytes_delta": 0, "modified": 0, "removed": len(removed), "unchanged": len(pa & pb)}}, sort_keys=True, separators=(",", ":"))
