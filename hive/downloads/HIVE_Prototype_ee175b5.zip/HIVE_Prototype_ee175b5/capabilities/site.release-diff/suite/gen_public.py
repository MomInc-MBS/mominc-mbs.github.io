"""Public dev cases and the shared deterministic builder for site.release-diff.
Fixture author: a conductor-side agent (Sol-B), NOT Ian. Written independently of any adapter and of any candidate tool. An older site manifest is built, then
the newer one is derived from it by recorded edits (added, removed, modified, unchanged files), so the expected report is known by construction.
Which manifest is older is set by the committed_at field; the files are given in a random order. Every case is also checked against the independent oracle."""
import base64
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oracle  # noqa: E402

SECTIONS = ["", "apps", "play", "docs", "little-boyfriend", "vendor", "a b", "Apps"]
NAMES = ["index.html", "app.js", "style.css", "logo.png", "Logo.png", "data.json", "readme.md", "x.svg", "caf\u00e9.png"]
FILE_NAMES = ["m1.json", "m2.json", "site-manifest-a.json", "site-manifest-b.json", "old.json", "new.json"]


def sha(rng):
    return "%064x" % rng.getrandbits(256)


def stamp(rng, base=1_700_000_000):
    import datetime
    return datetime.datetime.fromtimestamp(base + rng.randint(0, 40_000_000), datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def paths(rng, n):
    out = set()
    while len(out) < n:
        s = rng.choice(SECTIONS)
        sub = rng.choice(["", "", "x/", "x/y/"]) if s else ""
        out.add((s + "/" if s else "") + sub + rng.choice(NAMES) + ("" if rng.random() < 0.7 else ".%d" % rng.randint(1, 9)))
    return sorted(out)


def build(rng, n, error=None):
    """-> (env, expected). n = size of the older site. error: None | 'same-time' | 'bad-stamp' | 'duplicate-path' | 'wrong-schema' | 'one-file' -> 'ERROR'."""
    old_paths = paths(rng, max(n, 1) if error == "duplicate-path" else n)
    old = {p: (rng.choice([0, rng.randint(1, 100), rng.randint(100, 90000)]), sha(rng)) for p in old_paths}
    new, added, removed, modified = {}, [], [], []
    for p, (b, h) in old.items():
        r = rng.random()
        if r < 0.15:
            removed.append(p)
        elif r < 0.40:
            nb = b if rng.random() < 0.3 else rng.choice([0, rng.randint(1, 100), rng.randint(100, 90000)])
            new[p] = (nb, sha(rng))
            modified.append(p)
        else:
            new[p] = (b, h)
    for p in paths(rng, rng.choice([0, 1, 2, max(1, n // 3)])):
        if p not in old:
            new[p] = (rng.choice([0, rng.randint(1, 100), rng.randint(100, 90000)]), sha(rng))
            added.append(p)
    # a case-only rename is a removal plus an addition
    cand = [p for p in old if p in new and p == p.lower() and p.swapcase() not in old and p.swapcase() not in new and p not in modified]
    if cand and rng.random() < 0.5:
        p = rng.choice(cand)
        new[p.swapcase()] = new.pop(p)
        removed.append(p)
        added.append(p.swapcase())
    t_old = stamp(rng)
    t_new = stamp(rng, 1_740_000_000)
    c_old, c_new = "%07x" % rng.getrandbits(28), "%07x" % rng.getrandbits(28)
    sec = {}
    for kind, ps in (("added", added), ("removed", removed), ("modified", modified)):
        for p in ps:
            s = p.split("/", 1)[0] if "/" in p else "(root)"
            e = sec.setdefault(s, {"added": 0, "bytes_delta": 0, "modified": 0, "removed": 0, "section": s})
            e[kind] += 1
            e["bytes_delta"] += new.get(p, (0,))[0] - old.get(p, (0,))[0]
    secs = [sec[k] for k in sorted(sec)]
    kept = len([p for p in old if p in new]) - len(modified)
    expected = oracle.render({"schema": oracle.OUT, "older": {"commit": c_old, "committed_at": t_old}, "newer": {"commit": c_new, "committed_at": t_new},
                              "added": sorted(added), "removed": sorted(removed), "modified": sorted(modified), "unchanged": kept, "sections": secs,
                              "totals": {"added": len(added), "bytes_delta": sum(s["bytes_delta"] for s in secs), "modified": len(modified), "removed": len(removed), "unchanged": kept}})

    def man(c, t, fs):
        return {"schema": oracle.MANIFEST, "commit": c, "committed_at": t, "excluded_prefixes": ["tv/"], "files": [{"path": p, "bytes": b, "sha256": h} for p, (b, h) in sorted(fs.items())]}

    mo, mn = man(c_old, t_old, old), man(c_new, t_new, new)
    if error == "same-time":
        mn["committed_at"] = t_old
    elif error == "bad-stamp":
        mn["committed_at"] = "2026-11-25"
    elif error == "duplicate-path" and mo["files"]:
        mo["files"].append(dict(mo["files"][0]))
    elif error == "wrong-schema":
        mo["schema"] = "site-manifest-v2"

    def f(name, doc):
        text = json.dumps(doc, sort_keys=True, separators=(",", ":")) if rng.random() < 0.6 else json.dumps(doc, indent=rng.randint(1, 3))
        return {"name": name, "format": "base64", "data": base64.b64encode(text.encode("utf-8")).decode("ascii")}

    a, b = rng.sample(FILE_NAMES, 2)
    fs = [f(a, mo), f(b, mn)]
    rng.shuffle(fs)  # the older manifest is not reliably first
    if error == "one-file":
        fs = fs[:1]
    return {"files": fs}, ("ERROR" if error else expected)


def case(name, rng, n, error=None):
    env, expected = build(rng, n, error)
    return {"name": name, "env": env, "expected": expected}


def cases():
    rng = random.Random(20261201)
    return [case("small-release", rng, 5), case("several-sections", rng, 14), case("larger-release", rng, 30), case("small-again", rng, 3),
            case("same-timestamp-is-an-error", rng, 4, "same-time"), case("one-manifest-is-an-error", rng, 4, "one-file")]
