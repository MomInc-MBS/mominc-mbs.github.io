Compare two site manifests (two releases of the same site) and report what changed between the older and the newer.

Fixture author: a conductor-side agent (not Ian). The suite was written independently of any adapter and of any tool; ground truth is by construction.

Input env: {"files":[{"name":NAME,"format":"base64","data":BASE64},...]} with exactly 2 files in arbitrary order. Each `data` is the base64 text of a UTF-8 JSON document (any whitespace) of the form
{"schema":"site-manifest-v1","commit":STR,"committed_at":"YYYY-MM-DDTHH:MM:SSZ","files":[{"path":P,"bytes":N,"sha256":HEX},...],...} (other fields such as "excluded_prefixes" may be present: ignore them). Paths are site-root paths (no leading slash, "/" separated), case-sensitive, unique within a manifest; bytes is a non-negative integer.
The file names and their order tell you nothing. Which manifest is the OLDER one is decided only by "committed_at" (UTC, so the strings compare in time order): the smaller is older.
Output ERROR (the plain text, not JSON) if there are not exactly 2 files, a document is not valid JSON or its "schema" is not "site-manifest-v1", a "commit", "committed_at", path, bytes or sha256 is missing or of the wrong type, a "committed_at" does not have exactly the form above, a path occurs twice in one manifest, or the two "committed_at" values are equal.

Compare the files of the older manifest (OLD) with those of the newer (NEW):
- added: paths only in NEW. removed: paths only in OLD. modified: paths in both whose sha256 differs (the byte count alone decides nothing). unchanged: paths in both with the same sha256. A path that differs only in letter case is a different path (one removed, one added).
- The section of a path is its first segment when the path contains "/", otherwise "(root)".
- Per section, only for sections with at least one added, removed or modified file: the counts of added, removed and modified files, and bytes_delta = the sum of the NEW byte counts of its added and modified files minus the sum of the OLD byte counts of its removed and modified files.

Output: ONE string, a JSON text written with json.dumps(obj, sort_keys=True, separators=(",", ":")) (default ensure_ascii):
{"schema":"release-changes-v1","older":{"commit":C,"committed_at":T},"newer":{"commit":C,"committed_at":T},"added":[P,...],"removed":[P,...],"modified":[P,...],"unchanged":N,"sections":[{"added":N,"bytes_delta":D,"modified":N,"removed":N,"section":S},...],"totals":{"added":N,"bytes_delta":D,"modified":N,"removed":N,"unchanged":N}}
- added, removed, modified: path lists sorted ascending (Python string order, code points). sections: sorted ascending by section name.
- totals: the counts of the three lists, unchanged, and bytes_delta = the sum over all sections (unchanged files contribute nothing).
