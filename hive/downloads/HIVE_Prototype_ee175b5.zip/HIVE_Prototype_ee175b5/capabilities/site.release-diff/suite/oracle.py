"""Independent oracle for site.release-diff. Needs only the input env. Pure stdlib, shares no code with any candidate.
Which manifest is older is decided by the "committed_at" field, never by file name or position. Fixture author: a conductor-side agent (Sol-B), not Ian."""
import base64
import json
import re

MANIFEST, OUT = "site-manifest-v1", "release-changes-v1"
STAMP = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z")


def render(doc):
    return json.dumps(doc, sort_keys=True, separators=(",", ":"))


def section(path):
    return path.split("/", 1)[0] if "/" in path else "(root)"


def _load(f):
    try:
        d = json.loads(base64.b64decode(f["data"], validate=True).decode("utf-8"))
        if not (isinstance(d, dict) and d.get("schema") == MANIFEST and isinstance(d["commit"], str) and isinstance(d["committed_at"], str) and STAMP.fullmatch(d["committed_at"])):
            return None
        files = {}
        for x in d["files"]:
            if not (isinstance(x["path"], str) and type(x["bytes"]) is int and x["bytes"] >= 0 and isinstance(x["sha256"], str)) or x["path"] in files:
                return None
            files[x["path"]] = (x["bytes"], x["sha256"])
        return d["commit"], d["committed_at"], files
    except (ValueError, KeyError, TypeError):
        return None


def expected(env):
    fs = env["files"]
    ms = [_load(f) for f in fs]
    if len(fs) != 2 or None in ms or ms[0][1] == ms[1][1]:
        return "ERROR"
    old, new = sorted(ms, key=lambda m: m[1])
    of, nf = old[2], new[2]
    added = sorted(p for p in nf if p not in of)
    removed = sorted(p for p in of if p not in nf)
    modified = sorted(p for p in nf if p in of and nf[p][1] != of[p][1])
    sec = {}
    for p in sorted(set(of) | set(nf)):
        kind = "added" if p in added else "removed" if p in removed else "modified" if p in modified else None
        if kind is None:
            continue
        s = sec.setdefault(section(p), {"added": 0, "bytes_delta": 0, "modified": 0, "removed": 0, "section": section(p)})
        s[kind] += 1
        s["bytes_delta"] += nf.get(p, (0, ""))[0] - of.get(p, (0, ""))[0]
    secs = [sec[k] for k in sorted(sec)]
    return render({"schema": OUT, "older": {"commit": old[0], "committed_at": old[1]}, "newer": {"commit": new[0], "committed_at": new[1]},
                   "added": added, "removed": removed, "modified": modified, "unchanged": len(set(of) & set(nf)) - len(modified), "sections": secs,
                   "totals": {"added": len(added), "bytes_delta": sum(s["bytes_delta"] for s in secs), "modified": len(modified), "removed": len(removed),
                              "unchanged": len(set(of) & set(nf)) - len(modified)}})
