"""Independent oracle for report.reconcile. Needs only the input env (so it also verifies unseen inputs at run time). Pure stdlib, shares no code with any candidate.
The two input files are told apart by their "schema" field, never by name or position."""
import base64
import json

MANIFEST, TABLE = "image-match-manifest-v1", "asset-properties-v1"


def render(groups, totals):
    return json.dumps({"schema": "asset-reconcile-v1", "groups": groups, "totals": totals}, sort_keys=True, separators=(",", ":"))


def _doc(f):
    try:
        return json.loads(base64.b64decode(f["data"], validate=True).decode("utf-8"))
    except (ValueError, KeyError, TypeError):
        return None


def expected(env):
    fs = env["files"]
    docs = [_doc(f) for f in fs]
    ms = [d for d in docs if isinstance(d, dict) and d.get("schema") == MANIFEST]
    ts = [d for d in docs if isinstance(d, dict) and d.get("schema") == TABLE]
    if len(fs) != 2 or len(ms) != 1 or len(ts) != 1:
        return "ERROR"
    try:
        size = {}
        for a in ts[0]["assets"]:
            if a["name"] in size or not isinstance(a["bytes"], int):
                return "ERROR"
            size[a["name"]] = a["bytes"]
        groups, seen = [], []
        for g in ms[0]["groups"]:
            if g["keeper"] not in g["members"]:
                return "ERROR"
            dups = sorted(m for m in g["members"] if m != g["keeper"])
            groups.append({"id": g["id"], "keeper": g["keeper"], "duplicates": dups, "reclaimable_bytes": sum(size[m] for m in dups)})
            seen += g["members"]
        seen += ms[0]["singletons"]
        if sorted(seen) != sorted(size):
            return "ERROR"
    except (KeyError, TypeError):
        return "ERROR"
    groups.sort(key=lambda g: g["id"])
    return render(groups, {"assets": len(size), "groups": len(groups), "duplicates": sum(len(g["duplicates"]) for g in groups),
                           "reclaimable_bytes": sum(g["reclaimable_bytes"] for g in groups)})
