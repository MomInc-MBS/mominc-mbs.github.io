"""Acceptance cases for report.reconcile from a random seed, written ONLY under --out (gitignored) with their answers.
Prints just {"set_sha256","n"}. Every case is accepted only if the independent oracle equals the by-construction truth."""
import argparse
import hashlib
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gen_public  # noqa: E402
import oracle  # noqa: E402

ERRORS = [None] * 5 + ["missing-from-table", "extra-in-manifest", "two-manifests", "keeper-not-member"]


def generate(seed, n=24):
    rng, cases = random.Random(seed), []
    while len(cases) < n:
        env, truth = gen_public.build(rng, rng.choice([2, 3, 5, 8, 13, 20]), rng.choice(ERRORS))
        if oracle.expected(env) != truth:
            raise SystemExit("oracle disagrees with the by-construction truth: fixture rejected")
        cases.append({"name": f"random-{len(cases)}", "env": env, "expected": truth})
    return cases


def set_sha(cases):
    return hashlib.sha256(json.dumps(cases, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int)
    a = ap.parse_args(argv)
    cases = generate(random.SystemRandom().randrange(2**62) if a.seed is None else a.seed)
    sha = set_sha(cases)
    d = os.path.join(a.out, sha)
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "cases.json"), "w", encoding="utf-8", newline="\n") as f:
        json.dump(cases, f, sort_keys=True, separators=(",", ":"))
    print(json.dumps({"set_sha256": sha, "n": len(cases)}))


if __name__ == "__main__":
    main()
