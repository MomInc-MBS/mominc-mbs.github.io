"""Scripted baseline for report.reconcile: HAND-WRITTEN, stdlib only, not model output, not learned. Positional: it assumes the first file is the
manifest and the second the table and recomputes every keeper as the largest member, and never reports an error. Expected to fail acceptance."""
import base64
import json


def run(env):
    man, tab = (json.loads(base64.b64decode(f["data"])) for f in env["files"][:2])
    size = {a["name"]: a["bytes"] for a in tab["assets"]}
    groups = []
    for g in man["groups"]:
        keeper = sorted(g["members"], key=lambda m: (-size[m], m))[0]
        dups = sorted(m for m in g["members"] if m != keeper)
        groups.append({"id": g["id"], "keeper": keeper, "duplicates": dups, "reclaimable_bytes": sum(size[m] for m in dups)})
    totals = {"assets": len(size), "groups": len(groups), "duplicates": sum(len(g["duplicates"]) for g in groups), "reclaimable_bytes": sum(g["reclaimable_bytes"] for g in groups)}
    return json.dumps({"schema": "asset-reconcile-v1", "groups": groups, "totals": totals}, sort_keys=True, separators=(",", ":"))
