"""Public dev cases and the shared deterministic builder for report.reconcile.
Fixture author: a conductor-side agent, NOT Ian. Written independently of any adapter and of any candidate tool; the expected report is computed
here by construction (which names were generated as copies of which keeper), and every case is checked against the independent oracle."""
import base64
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oracle  # noqa: E402

STEMS = ["IMG", "photo", "Scan", "asset", "DSC", "holiday", "Logo final", "banner", "tile", "screenshot"]
FILE_NAMES = [("manifest.json", "properties.json"), ("s1.json", "s2.json"), ("properties.json", "manifest.json"), ("a.json", "b.json"), ("s2.json", "s1.json")]  # names say nothing


def _names(rng, n):
    out = set()
    while len(out) < n:
        out.add(f"{rng.choice(STEMS)}_{rng.randint(1, 9999):04d}{rng.choice(['', ' copy', '-final'])}{rng.choice(['.png', '.jpg', '.JPG', '.jpeg'])}")
    return sorted(out)


def _file(name, doc, rng):
    text = json.dumps(doc, sort_keys=True, separators=(",", ":")) if rng.random() < 0.6 else json.dumps(doc, sort_keys=True, indent=rng.randint(1, 3))
    return {"name": name, "format": "base64", "data": base64.b64encode(text.encode("utf-8")).decode("ascii")}


def build(rng, n, error=None):
    """-> (env, expected). n assets; groups of 2-4 names (the keeper is usually, not always, the largest: the manifest is trusted as given).
    error: None | 'missing-from-table' | 'extra-in-manifest' | 'two-manifests' | 'keeper-not-member' -> expected 'ERROR'."""
    names = _names(rng, n)
    size = {x: rng.choice([0, rng.randint(1, 50), rng.randint(100, 300000)]) for x in names}
    pool, groups, singles = names[:], [], []
    rng.shuffle(pool)
    while pool:
        k = min(len(pool), rng.choice([1, 1, 2, 2, 3, 4]))
        members, pool = sorted(pool[:k]), pool[k:]
        (groups if k > 1 else singles).append(members)
    groups.sort(key=lambda g: g[0])
    singles = sorted(m[0] for m in singles)
    man_groups, out_groups = [], []
    for i, g in enumerate(groups):
        keeper = max(g, key=lambda m: (size[m], m)) if rng.random() < 0.7 else rng.choice(g)
        gid = "g%03d" % (i + 1)
        dups = sorted(m for m in g if m != keeper)
        man_groups.append({"id": gid, "keeper": keeper, "members": g})
        out_groups.append({"id": gid, "keeper": keeper, "duplicates": dups, "reclaimable_bytes": sum(size[m] for m in dups)})
    manifest = {"schema": oracle.MANIFEST, "groups": man_groups, "singletons": singles}
    table = {"schema": oracle.TABLE, "assets": [{"name": x, "bytes": size[x], "sha256": "%064x" % rng.getrandbits(256), "format": rng.choice(["png", "jpeg", "other"])} for x in names]}
    if error == "missing-from-table":
        table["assets"].pop(rng.randrange(len(table["assets"])))
    elif error == "extra-in-manifest":
        manifest["singletons"] = sorted(manifest["singletons"] + ["zzz_ghost.png"])
    elif error == "keeper-not-member":
        if not man_groups:
            return build(rng, n, error)
        man_groups[0]["keeper"] = "zzz_ghost.png"
    expected = "ERROR" if error in ("missing-from-table", "extra-in-manifest", "keeper-not-member") else oracle.render(out_groups, {
        "assets": len(names), "groups": len(out_groups), "duplicates": sum(len(g["duplicates"]) for g in out_groups), "reclaimable_bytes": sum(g["reclaimable_bytes"] for g in out_groups)})
    nm, nt = rng.choice(FILE_NAMES)
    files = [_file(nm, manifest, rng), _file(nt, table, rng)]
    if error == "two-manifests":
        files = [_file(nm, manifest, rng), _file(nt, manifest, rng)]
        expected = "ERROR"
    rng.shuffle(files)
    return {"files": files}, expected


def case(name, rng, n, error=None):
    env, expected = build(rng, n, error)
    return {"name": name, "env": env, "expected": expected}  # truth by construction


def cases():
    rng = random.Random(20261128)
    return [case("three-assets", rng, 3), case("one-group", rng, 4), case("several-groups", rng, 9), case("keeper-is-taken-as-given", rng, 12),
            case("name-mismatch-is-an-error", rng, 6, "missing-from-table"), case("two-manifests-is-an-error", rng, 5, "two-manifests")]
