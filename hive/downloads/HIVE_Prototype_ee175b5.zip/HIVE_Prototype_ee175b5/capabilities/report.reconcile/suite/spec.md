Reconcile an image match manifest with an asset property table into a reclaimable-space report.

Fixture author: a conductor-side agent (not Ian). The suite was written independently of any adapter and of any tool; ground truth is by construction.

Input env: {"files":[{"name":NAME,"format":"base64","data":BASE64},...]} with exactly 2 files in arbitrary order. Each `data` is the base64 text of a UTF-8 JSON document (any whitespace). The file names and their order tell you nothing: tell the two documents apart by their "schema" field.
- the MANIFEST has "schema":"image-match-manifest-v1", "groups":[{"id":ID,"keeper":NAME,"members":[NAME,...]},...] and "singletons":[NAME,...].
- the TABLE has "schema":"asset-properties-v1" and "assets":[{"name":NAME,"bytes":INT,"sha256":HEX,"format":F},...].

Rules:
- Every name in the manifest (all members of all groups plus all singletons) must appear exactly once there, and the set of those names must equal the set of names in the table (each table name appearing once). Otherwise, or if the two files are not exactly one manifest and one table, or if a group's keeper is not one of its members, the output is the plain text ERROR (not JSON).
- For each manifest group: "id" and "keeper" are copied from the manifest as given (the keeper is NOT recomputed); "duplicates" are the members other than the keeper, sorted ascending by name (Python string order); "reclaimable_bytes" is the sum of the table's "bytes" of the duplicates.
- groups are sorted ascending by id. Singletons do not appear in groups.
- totals: "assets" = number of table assets; "groups" = number of groups; "duplicates" = total number of duplicates over all groups; "reclaimable_bytes" = sum over groups.

Output: ONE string, a JSON text written with json.dumps(obj, sort_keys=True, separators=(",", ":")):
{"schema":"asset-reconcile-v1","groups":[{"duplicates":[NAME,...],"id":ID,"keeper":NAME,"reclaimable_bytes":INT},...],"totals":{"assets":N,"duplicates":N,"groups":N,"reclaimable_bytes":N}}
