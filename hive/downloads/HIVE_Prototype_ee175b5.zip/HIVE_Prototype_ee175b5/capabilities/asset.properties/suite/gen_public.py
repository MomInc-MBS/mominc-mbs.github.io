"""Public dev cases and the shared deterministic file builder for asset.properties.
Fixture author: a conductor-side agent, NOT Ian. Written independently of any adapter and of any candidate tool; the format of every file is known by
construction (which builder made it), the size and digest are computed from the bytes, and every case is checked against the independent oracle."""
import base64
import hashlib
import os
import random
import struct
import sys
import zlib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oracle  # noqa: E402

STEMS = ["IMG", "photo", "Scan", "asset", "DSC", "holiday", "Logo final", "banner", "tile", "screenshot"]
EXTS = [".png", ".PNG", ".jpg", ".jpeg", ".JPG", ".gif", ".bmp", ".webp", ""]


def _chunk(tag, data):
    return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)


def png(rng):
    w, h = rng.randint(2, 40), rng.randint(2, 30)
    rows = b"".join(b"\x00" + bytes(rng.randrange(256) for _ in range(w * 3)) for _ in range(h))
    return oracle.PNG + _chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + _chunk(b"IDAT", zlib.compress(rows)) + _chunk(b"IEND", b"")


def jpeg(rng):
    return oracle.JPEG + b"\xe0\x00\x10JFIF\x00" + bytes(rng.randrange(256) for _ in range(rng.randint(20, 3000))) + b"\xff\xd9"


def other(rng):
    head = rng.choice([b"GIF89a", b"BM", b"RIFF\x24\x00\x00\x00WEBP", b"\x89PNG\r\n\x1a", b"\xff\xd8", b"", b"hello"])  # near misses included
    return head + bytes(rng.randrange(256) for _ in range(rng.randint(0, 900)))


BUILDERS = {"png": png, "jpeg": jpeg, "other": other}


def name_for(rng, used):
    while True:
        n = f"{rng.choice(STEMS)}_{rng.randint(1, 9999):04d}{rng.choice(['', ' copy', ' - Copy', '-final'])}{rng.choice(EXTS)}"  # the extension says nothing about the bytes
        if n.lower() not in used:
            used.add(n.lower())
            return n


def build(rng, n):
    """-> (env, truth rows). n files in arbitrary order; some are exact byte copies under another name (same sha256)."""
    used, made, rows = set(), [], []
    for _ in range(n):
        raw = rng.choice(made) if made and rng.random() < 0.2 else BUILDERS[rng.choice(["png", "jpeg", "other"])](rng)
        made.append(raw)
        rows.append({"name": name_for(rng, used), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "format": oracle.kind(raw), "_raw": raw})
    rng.shuffle(rows)
    env = {"files": [{"name": r["name"], "format": "base64", "data": base64.b64encode(r["_raw"]).decode("ascii")} for r in rows]}
    return env, [{k: v for k, v in r.items() if k != "_raw"} for r in rows]


def case(name, rng, n):
    env, rows = build(rng, n)
    return {"name": name, "env": env, "expected": oracle.render(rows)}  # truth by construction


def cases():
    rng = random.Random(20261127)
    return [case("one-file", rng, 1), case("two-files", rng, 2), case("mixed-formats", rng, 5), case("copies-share-a-digest", rng, 8), case("many-files", rng, 14),
            case("max-files", rng, 20)]
