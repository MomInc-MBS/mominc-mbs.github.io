Write a property table for image files.

Fixture author: a conductor-side agent (not Ian). The suite was written independently of any adapter and of any tool; ground truth is by construction.

Input env: {"files":[{"name":NAME,"format":"base64","data":BASE64},...]} with 1 to 20 files, in arbitrary order. Each `data` is the base64 text of one file (at most 256 KiB each, 2 MiB in total). `name` is the file name as given (unique, ASCII letters, digits, space, dot, dash, underscore; it may have any extension or none). The name and extension tell you nothing about the bytes: a file called x.png may hold JPEG data.

For every file compute, from its decoded bytes:
- "bytes": the decoded length as an integer.
- "sha256": the lowercase hex SHA-256 of the decoded bytes.
- "format": "png" when the bytes start with the 8 bytes 89 50 4E 47 0D 0A 1A 0A; "jpeg" when they start with the 3 bytes FF D8 FF; otherwise "other" (this includes empty files and near misses such as a truncated PNG signature).

Output: ONE string, a JSON text written with json.dumps(obj, sort_keys=True, separators=(",", ":")):
{"schema":"asset-properties-v1","assets":[{"bytes":N,"format":F,"name":NAME,"sha256":HEX},...]}
- assets: one entry per input file, sorted ascending by name (Python string order, code points). Every input name appears exactly once.
