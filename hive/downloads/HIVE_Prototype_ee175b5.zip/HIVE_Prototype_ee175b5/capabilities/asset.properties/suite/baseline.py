"""Scripted baseline for asset.properties: HAND-WRITTEN, stdlib only, not model output, not learned. Takes the format from the file name's
extension (the obvious shortcut), so it is expected to fail acceptance on files whose name misleads."""
import base64
import hashlib
import json


def run(env):
    rows = []
    for f in env["files"]:
        raw = base64.b64decode(f["data"])
        ext = f["name"].lower().rsplit(".", 1)[-1]
        rows.append({"name": f["name"], "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "format": "png" if ext == "png" else "jpeg" if ext in ("jpg", "jpeg") else "other"})
    return json.dumps({"schema": "asset-properties-v1", "assets": sorted(rows, key=lambda r: r["name"])}, sort_keys=True, separators=(",", ":"))
