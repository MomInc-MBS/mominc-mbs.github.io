"""Independent oracle for asset.properties. Needs only the input env (so it also verifies unseen inputs at run time). Pure stdlib, shares no code with any candidate.
Format comes from the file's first bytes, never from its name."""
import base64
import hashlib
import json

PNG = b"\x89PNG\r\n\x1a\n"
JPEG = b"\xff\xd8\xff"


def decode(f):
    if f.get("format") != "base64":
        raise ValueError("input files must be base64")
    return base64.b64decode(f["data"], validate=True)


def kind(raw):
    return "png" if raw[:8] == PNG else "jpeg" if raw[:3] == JPEG else "other"


def render(rows):
    """Canonical table text. rows = dicts with name, bytes, sha256, format (any order)."""
    return json.dumps({"schema": "asset-properties-v1", "assets": sorted(rows, key=lambda r: r["name"])}, sort_keys=True, separators=(",", ":"))


def expected(env):
    names = [f["name"] for f in env["files"]]
    if len(set(names)) != len(names):
        raise ValueError("duplicate input names")
    rows = []
    for f in env["files"]:
        raw = decode(f)
        rows.append({"name": f["name"], "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "format": kind(raw)})
    return render(rows)
