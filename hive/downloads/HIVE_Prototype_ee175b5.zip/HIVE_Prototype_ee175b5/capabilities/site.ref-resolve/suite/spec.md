Classify and resolve raw references of a website into a reference table.
Fixture author: a conductor-side agent (not Ian); the suite was written independently of any adapter.

Input env: {"files":[{"name":N,"format":"base64","data":B64}]}, exactly 1 file: base64 of UTF-8 JSON {"schema":"raw-ref-table-v1","commit":STR,"pages":INT,"refs":[{"kind":K,"page":P,"raw":R},...]} (ignore other top-level fields). P is a site-root page path (no leading slash, "/" separated, case-sensitive); R is a reference exactly as written in the page.
Output the plain text ERROR if the file count is not 1, the JSON is invalid, "schema" is wrong, "commit" is not a string, "pages" is not an integer, or "refs" is not a list of objects whose kind, page and raw are all strings.

For each row, from raw R and page path P, compute a class and a target (null unless local):
- R starts with `#`: "anchor". R starts with `//`: "external".
- R starts with a scheme (a letter, then letters, digits, `+`, `-` or `.`, then `:`): "external" if the scheme is http or https (any case), else "scheme" (mailto, tel, data, javascript, blob ...).
- Otherwise cut R at the first `?` or `#` and keep the part before it (the path part). If it is empty: "anchor".
- Otherwise it is a site path. Percent-decode it (each % followed by two hex digits is one byte; the bytes are UTF-8; a stray % stays as written; undecodable bytes become U+FFFD). Then resolve: if the path starts with `/`, start at the site root, else at the directory of P (P without its last segment). Split on `/`; ignore empty segments and `.`; `..` removes the last segment, and if there is none the class is "escapes-root" (target null). Any other segment is appended. Decoding happens before the split, so `%2e%2e` acts like `..`. Letter case never changes, and every character outside %-escapes (including a literal non-ASCII character) is kept exactly as written.
- Otherwise class "local". If the decoded path ends in `/`, or its last segment is `.` or `..`, the target is the segments joined with `/` plus a final `/` (the site root is "/"); else the segments joined with `/`, no leading or trailing slash.

Output ONE string: json.dumps(obj, sort_keys=True, separators=(",", ":")) of
{"schema":"ref-table-v1","commit":COMMIT,"pages":PAGES,"refs":[{"class":C,"kind":K,"page":P,"raw":R,"target":T},...]}
commit and pages are copied; refs has one row per input row, in the input order, kind, page and raw copied unchanged.
Example: page "docs/a.html", raw "../img/x%20y.png?v=2" gives class "local", target "img/x y.png"; raw "../../up.png" gives "escapes-root", null; raw "sub/" gives "local", "docs/sub/".
