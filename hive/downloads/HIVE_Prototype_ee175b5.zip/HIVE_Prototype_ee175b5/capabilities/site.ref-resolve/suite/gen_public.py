"""Public dev cases and the shared deterministic builder for site.ref-resolve.
Fixture author: a conductor-side agent (Sol-B), NOT Ian. Written independently of any adapter and of any candidate tool. Each raw reference is generated from a known
outcome (a site-root target, or a class such as external) and spelled with a known style (relative, root, ./, detours, %2e%2e, percent-encoding, query/fragment), so the
expected table comes from construction, never from parsing; gen_private and the tests also check every case against the independent oracle."""
import base64
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oracle  # noqa: E402

KINDS = ["href", "src", "srcset", "css-url"]
DIRS = ["", "a", "a/b", "a/b/c", "docs", "docs/guide", "img", "assets/css", "Play"]
NAMES = ["index.html", "about.html", "logo.png", "Logo.PNG", "app.js", "style.css", "my file.png", "café.png", "50%.png", "a b.html", "data.json", "font.woff2", "pic-1.jpg", "x.svg"]
EXTERNAL = ["https://example.com/x.png", "http://example.org/a/b.html", "HTTPS://CDN.example.com/lib.js", "//cdn.example.net/z.css", "https://fonts.example.com/css?family=A&display=swap"]
SCHEME = ["mailto:me@example.com", "tel:+15551234", "data:image/png;base64,iVBORw0KGgo=", "javascript:void(0)", "blob:https://example.com/1"]
ANCHOR = ["#", "#top", "#a/b", "?q=1", "?a=1#x", "#?x"]
SUFFIX = ["", "", "", "?v=3", "#top", "?a=1&b=2#frag", "?next=../a/b", "#frag?x"]
FILE_NAMES = ["raw-refs.json", "refs.json", "input.json", "export.json"]


def pct(s, rng):
    """Percent-encode space and non-ASCII bytes; the hex case varies. A bare % is left alone (it is not followed by two hex digits in NAMES)."""
    up = rng.random() < 0.5
    out = []
    for b in s.encode("utf-8"):
        out.append(("%%%02X" if up else "%%%02x") % b if b > 127 or b == 32 else chr(b))
    return "".join(out)


def rel(d, target):
    """Relative spelling of site path `target` (a file, or a directory ending '/') from the page directory `d` (list of segments)."""
    t = [x for x in target.split("/") if x]
    n = 0
    while n < len(d) and n < len(t) and d[n] == t[n]:
        n += 1
    isdir = target.endswith("/")
    if not isdir and n == len(t):
        n -= 1
    body = "/".join([".."] * (len(d) - n) + t[n:])
    return (body + "/" if body else "./") if isdir else body


def spell_local(rng, page, target):
    """A raw string whose resolution from `page` is `target`."""
    d = page.split("/")[:-1]
    style = rng.choice(["rel", "rel", "root", "dot", "detour", "pct-dots"])
    r = rel(d, target)
    if style == "root":
        raw = "/" + target if target != "/" else "/"
    elif style == "dot" and not r.startswith("."):
        raw = "./" + r
    elif style == "detour":
        k = r.find("/")
        raw = (r[:k + 1] + "zz/../" + r[k + 1:]) if k >= 0 and not r.startswith("..") else "zz/../" + r
    elif style == "pct-dots" and d:
        raw = "%2e%2e/" + rel(d[:-1], target)
    else:
        raw = r
    if rng.random() < 0.7:
        raw = pct(raw, rng)
    return raw + rng.choice(SUFFIX)


def make_ref(rng, page, targets):
    """-> (raw, class, target)."""
    r = rng.random()
    if r < 0.55:
        t = rng.choice(targets)
        return spell_local(rng, page, t), "local", t
    if r < 0.70:
        return rng.choice(EXTERNAL), "external", None
    if r < 0.78:
        return rng.choice(SCHEME), "scheme", None
    if r < 0.88:
        return rng.choice(ANCHOR), "anchor", None
    depth = len(page.split("/")) - 1
    raw = "../" * (depth + 1) + "x.png" if rng.random() < 0.7 else "/../x.png"
    return raw + rng.choice(SUFFIX), "escapes-root", None


def build(rng, n, error=None):
    """-> (env, expected). Up to 12 rows per page over n pages. error: None | 'wrong-schema' | 'two-files' | 'bad-row' | 'pages-not-int' -> expected 'ERROR'."""
    pool = set()
    while len(pool) < 18:
        d = rng.choice(DIRS)
        pool.add((d + "/" if d else "") + rng.choice(NAMES))
    targets = sorted(pool) + ["docs/", "a/b/", "img/", "/", "assets/css/"]
    pages = sorted({(rng.choice(DIRS) + "/" if rng.random() < 0.8 else "").lstrip("/") + "p%d.%s" % (i, rng.choice(["html", "html", "css", "htm"])) for i in range(n)})
    refs, rows = [], []
    for p in pages:
        for _ in range(rng.choice([0, 3, 6, 9, 12])):
            raw, cls, tgt = make_ref(rng, p, targets)
            kind = rng.choice(KINDS)
            refs.append({"kind": kind, "page": p, "raw": raw})
            rows.append({"class": cls, "kind": kind, "page": p, "raw": raw, "target": tgt})
            if rng.random() < 0.1:  # duplicates are kept, one row each
                refs.append(dict(refs[-1]))
                rows.append(dict(rows[-1]))
    commit = "%07x" % rng.getrandbits(28)
    expected = oracle.render({"schema": oracle.SCHEMA_OUT, "commit": commit, "pages": len(pages), "refs": rows})
    doc = {"schema": oracle.SCHEMA_IN, "commit": commit, "pages": len(pages), "refs": refs}
    if error == "wrong-schema":
        doc["schema"] = "ref-table-v1"
    elif error == "pages-not-int":
        doc["pages"] = "3"
    elif error == "bad-row":
        doc["refs"] = refs + [{"kind": "href", "page": "a.html", "raw": 5}]
    text = json.dumps(doc, sort_keys=True, separators=(",", ":")) if rng.random() < 0.5 else json.dumps(doc, indent=2)
    f = {"name": rng.choice(FILE_NAMES), "format": "base64", "data": base64.b64encode(text.encode("utf-8")).decode("ascii")}
    files = [f, dict(f, name="second.json")] if error == "two-files" else [f]
    return {"files": files}, ("ERROR" if error else expected)


def tiny(name, page, raws, commit="c0ffee1"):
    """A hand-written worked case: one page, `raws` as [(raw, class, target)] written out by hand."""
    doc = {"schema": oracle.SCHEMA_IN, "commit": commit, "pages": 1, "refs": [{"kind": "href", "page": page, "raw": r} for r, _, _ in raws]}
    f = {"name": "raw-refs.json", "format": "base64", "data": base64.b64encode(json.dumps(doc).encode("utf-8")).decode("ascii")}
    rows = [{"class": c, "kind": "href", "page": page, "raw": r, "target": t} for r, c, t in raws]
    return {"name": name, "env": {"files": [f]}, "expected": oracle.render({"schema": oracle.SCHEMA_OUT, "commit": commit, "pages": 1, "refs": rows})}


def case(name, rng, n, error=None):
    env, expected = build(rng, n, error)
    return {"name": name, "env": env, "expected": expected}


def cases():
    rng = random.Random(20261201)
    t1 = tiny("worked-tiny", "docs/guide/a.html", [
        ("../img/Logo.png?v=2#x", "local", "docs/img/Logo.png"), ("#top", "anchor", None), ("HTTPS://e.com/a", "external", None), ("mailto:x@y", "scheme", None),
        ("../../../up.html", "escapes-root", None), ("%2e%2e/x%20y.html", "local", "docs/x y.html"), ("./", "local", "docs/guide/"), ("/a/./b/../c.png", "local", "a/c.png"),
        ("?q=1", "anchor", None), ("caf%C3%A9.png", "local", "docs/guide/café.png"), ("50%.png", "local", "docs/guide/50%.png"), ("..", "local", "docs/")])
    t2 = tiny("literal-non-ascii", "docs/a.html", [("café/ñ ü.png?x=é", "local", "docs/café/ñ ü.png"), ("caf%C3%A9/日本.html#é", "local", "docs/café/日本.html")])
    return [t1, case("few-pages", rng, 3), case("many-pages", rng, 8), case("empty-and-dups", rng, 5),
            case("wrong-schema-is-an-error", rng, 2, "wrong-schema"), case("two-files-is-an-error", rng, 2, "two-files"),
            case("bad-row-is-an-error", rng, 1, "bad-row"), case("pages-not-int-is-an-error", rng, 1, "pages-not-int"), t2]
