"""Independent oracle for site.ref-resolve (classify, percent-decode, resolve). Needs only the input env. Pure stdlib, shares no code with any candidate.
Fixture author: a conductor-side agent (Sol-B), not Ian. The grammar is exactly what spec.md tells the proposer."""
import base64
import json
import re
from urllib.parse import unquote

SCHEMA_IN, SCHEMA_OUT = "raw-ref-table-v1", "ref-table-v1"
SCHEME = re.compile(r"[A-Za-z][A-Za-z0-9+.-]*:")


def render(doc):
    return json.dumps(doc, sort_keys=True, separators=(",", ":"))


def resolve(page, raw):
    """-> (class, target). class: local | external | scheme | anchor | escapes-root."""
    if raw.startswith("#"):
        return "anchor", None
    if raw.startswith("//"):
        return "external", None
    m = SCHEME.match(raw)
    if m:
        return ("external" if raw[:m.end() - 1].lower() in ("http", "https") else "scheme"), None
    p = re.split(r"[?#]", raw, 1)[0]
    if p == "":
        return "anchor", None
    p = unquote(p)
    segs = [] if p.startswith("/") else page.split("/")[:-1]
    parts = p.split("/")
    for s in parts:
        if s in ("", "."):
            continue
        if s == "..":
            if not segs:
                return "escapes-root", None
            segs.pop()
        else:
            segs.append(s)
    return "local", "/".join(segs) + ("/" if p.endswith("/") or parts[-1] in (".", "..") else "")


def expected(env):
    fs = env["files"]
    try:
        doc = json.loads(base64.b64decode(fs[0]["data"], validate=True).decode("utf-8")) if len(fs) == 1 else None
        if not (isinstance(doc, dict) and doc.get("schema") == SCHEMA_IN and isinstance(doc.get("commit"), str) and isinstance(doc.get("refs"), list)):
            return "ERROR"
        if type(doc.get("pages")) is not int or not all(isinstance(r, dict) and all(isinstance(r.get(k), str) for k in ("kind", "page", "raw")) for r in doc["refs"]):
            return "ERROR"
    except (ValueError, KeyError, TypeError):
        return "ERROR"
    rows = []
    for r in doc["refs"]:
        cls, tgt = resolve(r["page"], r["raw"])
        rows.append({"class": cls, "kind": r["kind"], "page": r["page"], "raw": r["raw"], "target": tgt})
    return render({"schema": SCHEMA_OUT, "commit": doc["commit"], "pages": doc["pages"], "refs": rows})
