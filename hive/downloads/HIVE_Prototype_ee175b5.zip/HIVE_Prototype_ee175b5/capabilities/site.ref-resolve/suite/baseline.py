"""Scripted baseline for site.ref-resolve: HAND-WRITTEN, stdlib only, not model output, not learned. It marks http values external and everything else local with the raw
value as the target (no query/fragment strip, no decoding, no ../ resolution, no schemes or anchors), and never reports an error. Expected to fail acceptance."""
import base64
import json


def run(env):
    doc = json.loads(base64.b64decode(env["files"][0]["data"]))
    rows = []
    for r in doc["refs"]:
        ext = r["raw"].startswith("http")
        rows.append({"class": "external" if ext else "local", "kind": r["kind"], "page": r["page"], "raw": r["raw"], "target": None if ext else r["raw"]})
    return json.dumps({"schema": "ref-table-v1", "commit": doc["commit"], "pages": doc["pages"], "refs": rows}, sort_keys=True, separators=(",", ":"))
