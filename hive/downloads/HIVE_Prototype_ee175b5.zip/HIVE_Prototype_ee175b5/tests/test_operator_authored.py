"""Operator-authored route: a human body goes through the experiment/evaluator/receipt gates and the signed admission; never counted as learned."""
import json
import sys
from pathlib import Path

import pytest

from hive import capability_registry as CR
from hive import cap_cli as K
from hive import discovery as D
from hive.operator_runtime import Refused
from hive.storage import Store

from test_capability_admission import auth  # noqa: F401  (real ssh-keygen authority fixture)
from test_discovery import CORRECT, env, fake_runs  # noqa: F401

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
GOOD = CORRECT.removeprefix("```python\n").removesuffix("```")
BAD = "import json\ndef run(env):\n    return json.dumps({'v': 1})\n"


def body(tmp_path, text):
    p = tmp_path / "body.py"
    p.write_text(text, encoding="utf-8", newline="\n")
    return p


@pytest.fixture(autouse=True)
def private(env, monkeypatch):
    monkeypatch.setattr(D, "PRIVATE", env[2])


def test_authored_admitted_with_route_and_not_counted_as_learned(env, fake_runs, auth, tmp_path):
    store = env[0]
    before = K.overview(store)["capabilities"]
    out = K.author(store, "inventory-diff", body(tmp_path, GOOD), "ian", auth)
    assert out["version"] == 1 and out["route"] == "operator-authored"
    s = Store(store)
    try:
        st = CR.resolve_discovered(s, "inventory-diff")["statement"]
        assert (st["route"], st["author"]) == ("operator-authored", "ian")
        e = D.experiments(s)[-1]
        assert e["ledger"]["calls"] == 0 and e["ledger"]["proposals"] == 0 and (D.discoveries(s)[-1]["route"] == "operator-authored")
    finally:
        s.close()
    row = [r for r in K.capabilities(store) if r["id"] == "inventory-diff"][0]
    assert row["route"] == "operator-authored" and "operator-authored by ian" in row["provenance"]
    ov = K.overview(store)
    assert ov["capabilities"] == before and ov["operator_authored"] == {"active": 1}
    assert K.acquisitions(store)["experiments"][-1]["route"] == "operator-authored"


def test_failing_body_refused_nothing_admitted(env, fake_runs, auth, tmp_path):
    store = env[0]
    with pytest.raises(Refused, match="hidden acceptance|dev cases"):
        K.author(store, "inventory-diff", body(tmp_path, BAD), "ian", auth)
    s = Store(store)
    try:
        assert CR.cap_ids(s) == [] and D.experiments(s)[-1]["state"] == "NO_QUALIFYING_CANDIDATE"
    finally:
        s.close()
    with pytest.raises(Refused, match="static"):
        K.author(store, "inventory-diff", body(tmp_path, "import os\ndef run(env):\n    return ''\n"), "ian", auth)


def test_receipt_and_signature_tamper_refused(env, fake_runs, auth, tmp_path, monkeypatch):
    import hive_admission as H
    store = env[0]
    s = Store(store)
    try:
        exp = D.open_authored(s, "inventory-diff", "ian", GOOD)["exp_id"]
    finally:
        s.close()
    assert D.run_experiment(store, exp)["state"] == "CANDIDATE_PASSED"
    rp = next((Path(store) / "discovery" / exp).glob("receipt-candidate-*.json"))
    r = json.loads(rp.read_text(encoding="utf-8"))
    r["pass_count"] -= 1
    rp.write_text(json.dumps(r), encoding="utf-8")
    with pytest.raises(Refused):
        H.admit(store, exp, auth)
    s = Store(store)
    try:
        assert CR.cap_ids(s) == ["inventory-diff"] and [e["type"] for e in CR.history(s, "inventory-diff")] == ["rejected"]
    finally:
        s.close()


def test_signed_route_cannot_be_rewritten(env, fake_runs, auth, tmp_path):
    store = env[0]
    K.author(store, "inventory-diff", body(tmp_path, GOOD), "ian", auth)
    s = Store(store)
    try:
        ev = CR.history(s, "inventory-diff")[-1]
        st = s.read_artifact(ev["statement_ref"])
        st["route"] = "learned"
        e = {k: v for k, v in ev.items() if k != "ref"}
        e["statement_ref"] = s.put_artifact(st)
        s.set(CR.CHAIN + "inventory-diff", s.put_artifact(e))
        with pytest.raises(Refused):
            CR.resolve_discovered(s, "inventory-diff")
    finally:
        s.close()
