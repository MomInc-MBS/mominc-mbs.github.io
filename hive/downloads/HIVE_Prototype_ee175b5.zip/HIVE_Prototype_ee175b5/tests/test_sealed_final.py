"""public_feedback_sealed_final_v1: stub LLM and fake containers only (the test_discovery pattern). No model, no network."""
import importlib.util
import json
import os
import re
import sys
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))
sys.path.insert(0, str(ROOT / "scripts"))
from hive import capcontract as CC  # noqa: E402
from hive import discovery as D  # noqa: E402
from hive import m2_model as M  # noqa: E402
from hive import operator_runtime as O  # noqa: E402
from hive.storage import Store  # noqa: E402
from test_coop import PINNED_FROZEN_SHA, _core  # noqa: E402
from test_discovery import CORRECT, GOOD, OTHER, WRONGS, env, fake_runs, get, opened, stub  # noqa: E402,F401
import g3_qualify as Q  # noqa: E402

spec = importlib.util.spec_from_file_location("sealed_final", ROOT / "evaluator" / "coop" / "sealed_final.py")  # by path: the folder also holds coverage.py
SF = importlib.util.module_from_spec(spec)
spec.loader.exec_module(SF)

CAP = "inventory-diff"
SENTINEL, HIDDEN_COUNT = "SEALED-SENTINEL-9c41e7", "HIDDEN_PASS_17_OF_24"
GOAL, INS = "Compare the before and after inventories", [("one.csv", "file", GOOD), ("two.csv", "file", OTHER)]


def body(tag, k):
    """A candidate whose public dev result is controlled by the marker (see fake_dev): k = a pass count or 'all'."""
    return f"```python\nimport json\ndef run(env):\n    return json.dumps({{\"t\": \"{tag}\"}})\n# pass={k}\n```"


@pytest.fixture
def fake_dev(monkeypatch):
    def dev(b, dev, harness, timeout=60, **kw):
        m = re.search(r"# pass=(\w+)", b)
        k = len(dev) if m and m.group(1) == "all" else int(m.group(1)) if m else 0
        return {"n": len(dev), "pass_count": k}, f"case x: expected 1 got 2 (marker {k})"
    monkeypatch.setattr(D, "_dev_run", dev)


@pytest.fixture
def no_hidden(monkeypatch):
    """The runtime must never reach the hidden gate: any evaluator call while armed fails the test. Scoring disarms it."""
    g, real = {"armed": True, "labels": []}, D._evaluate

    def ev(rec, outdir, body_path, label, *a, **k):
        g["labels"].append(label)
        assert not g["armed"], "the runtime ran the hidden gate"
        return real(rec, outdir, body_path, label, *a, **k)
    monkeypatch.setattr(D, "_evaluate", ev)
    return g


def store_at(path):
    s = Store(path)
    O.import_bundle(s)
    s.close()
    return str(path)


def ns(url, private=None, manifest=None, model=None):
    return SimpleNamespace(private=private, model=model, stub_endpoint=url, admit_key=None, manifest=manifest)


def reqs(tmp_path, name="req.jsonl"):
    p = tmp_path / name
    return [json.loads(x) for x in p.read_text(encoding="utf-8").splitlines()] if p.exists() else []


def all_bytes(*roots):
    return b"".join(p.read_bytes() for r in roots for p in (Path(r).rglob("*") if Path(r).is_dir() else [Path(r)]) if p.is_file())


# 1 ------------------------------------------------------------------------------------------------------------------ identity
def test_legacy_identity_unchanged_and_policy_identity_deterministic(env):
    exp = opened(env)
    assert "eval_policy" not in exp["frozen"] and D._sha(D._json(dict(_core(exp["frozen"]), attempt=1))) == PINNED_FROZEN_SHA
    s = Store(env[0])
    ids = []
    for _ in range(2):  # the same protocol twice: identical apart from the attempt counter
        s.set(D.KEY + exp["exp_id"], dict(s.get(D.KEY + exp["exp_id"]), state="NO_QUALIFYING_CANDIDATE"))
        on = D.open_experiment(s, exp["gap_key"], private_dir=env[2], seed=7, policy=D.SEALED, acq_run="idt")
        ids.append(D._sha(D._json(dict(_core(on["frozen"]), attempt=1))))
        assert on["frozen"]["eval_policy"] == D.SEALED_POLICY and on["exp_id"] != exp["exp_id"] and on["frozen"]["acceptance"].get("set_sha256") is None
        exp = on
    assert ids[0] == ids[1] != PINNED_FROZEN_SHA
    with pytest.raises(O.Refused):
        s.set(D.KEY + exp["exp_id"], dict(exp, state="NO_QUALIFYING_CANDIDATE"))
        D.open_experiment(s, exp["gap_key"], policy="some_other_policy")
    with pytest.raises(O.Refused):
        D.open_experiment(s, exp["gap_key"], policy=D.SEALED, coop="sample3")
    s.close()


def test_selector_check_and_backend_cannot_be_swapped_after_freeze(env, fake_runs, tmp_path):
    exp = opened(env, policy=D.SEALED)
    s = Store(env[0])
    rec = s.get(D.KEY + exp["exp_id"])
    rec["frozen"]["eval_policy"] = dict(rec["frozen"]["eval_policy"], selector="highest hidden pass")
    s.set(D.KEY + exp["exp_id"], rec)
    s.close()
    srv, url = stub([CORRECT], tmp_path)
    assert D.run_experiment(env[0], exp["exp_id"], stub_endpoint=url)["state"] == "INTERRUPTED" and srv.counters["total"] == 0
    s = Store(env[0])
    rec = s.get(D.KEY + exp["exp_id"])
    rec["frozen"]["eval_policy"], rec["state"] = D.SEALED_POLICY, "OPEN"
    s.set(D.KEY + exp["exp_id"], rec)
    s.close()
    done = D.run_experiment(env[0], exp["exp_id"], stub_endpoint=url, requested_model="qwen/qwen3.8-27b")  # another backend than the frozen one
    assert done["state"] == "INTERRUPTED" and "frozen backend" in done["reason"] and srv.counters["total"] == 0


# 2 ------------------------------------------------------------------------------------------------------------------ the loop
def test_dev_perfect_ends_as_a_public_candidate_with_no_hidden_anything(env, fake_runs, tmp_path, no_hidden):
    exp = opened(env, policy=D.SEALED)
    srv, url = stub([WRONGS[0], CORRECT, WRONGS[1]], tmp_path)
    done = D.run_experiment(env[0], exp["exp_id"], stub_endpoint=url)
    h = D._sha(D.extract_code(CORRECT))
    assert done["state"] == "PUBLIC_CANDIDATE_FROZEN" and done["candidate_sha256"] == h and done["final"]["sha256"] == h and srv.counters["total"] == 2
    assert no_hidden["labels"] == [] and "receipt" not in done and "report" not in done and all(p["acceptance"] is None for p in done["proposals"])
    assert set(done["baselines"]) == {"unchanged_hive"}  # no hidden-set baseline either
    second = reqs(tmp_path)[1]["messages"][1]["content"]
    assert "dev cases passed" in second and "hidden" not in second.lower() and "withheld" not in second
    assert D.run_experiment(env[0], exp["exp_id"], stub_endpoint=url)["state"] == "PUBLIC_CANDIDATE_FROZEN" and srv.counters["total"] == 2  # terminal: a restart dispatches nothing


def test_experiment_and_campaign_boundaries(env, fake_runs, tmp_path, fake_dev):
    exp = opened(env, policy=D.SEALED, budget=Q.EXP_BUDGET)
    srv, url = stub([body(f"w{i}", 1) for i in range(6)], tmp_path)
    done = D.run_experiment(env[0], exp["exp_id"], stub_endpoint=url)
    assert srv.counters["total"] == 3 == done["ledger"]["calls"] and done["ledger"]["proposals"] == 3 and done["state"] in ("NO_QUALIFYING_CANDIDATE", "BUDGET_EXHAUSTED")  # no 4th call or proposal
    D.run_experiment(env[0], exp["exp_id"], stub_endpoint=url)
    assert srv.counters["total"] == 3  # a restart neither replenishes nor re-dispatches
    # the same gate refuses the 4th call, the 11th container run and an output overflow, before anything is spent
    s = Store(env[0])
    fresh = D.open_experiment(s, exp["gap_key"], private_dir=env[2], budget=dict(Q.EXP_BUDGET), acq_run="boundary", policy=D.SEALED)
    clock = [time.monotonic()]
    for kw in ({"calls": 3}, {"container_runs": 10}, {"out_tokens": 5900}):
        r = s.get(D.KEY + fresh["exp_id"])
        D._spend(s, r, **kw)
        k = next(iter(kw))
        with pytest.raises(D._End, match=k):
            D._gate(s, r, clock, tmp_path / "STOP", **{k: 1 if k != "out_tokens" else 256})
        D._spend(s, r, **{k: -kw[k]})
    # a 4th experiment of one campaign is refused at the campaign boundary
    for _ in range(2):
        s.set(D.KEY + fresh["exp_id"], dict(s.get(D.KEY + fresh["exp_id"]), state="NO_QUALIFYING_CANDIDATE"))
        fresh = D.open_experiment(s, exp["gap_key"], private_dir=env[2], budget=dict(Q.EXP_BUDGET), acq_run="boundary", policy=D.SEALED)
    s.set(D.KEY + fresh["exp_id"], dict(s.get(D.KEY + fresh["exp_id"]), state="NO_QUALIFYING_CANDIDATE"))
    with pytest.raises(O.Refused, match="campaign boundary"):
        D.open_experiment(s, exp["gap_key"], private_dir=env[2], budget=dict(Q.EXP_BUDGET), acq_run="boundary", policy=D.SEALED)
    s.close()


# 3 ------------------------------------------------------------------------------------------------------------------ campaign: containment, retry, resume, carry-best
def test_hidden_data_never_reaches_a_request_store_feedback_or_carry_best(env, fake_runs, tmp_path, fake_dev, no_hidden, monkeypatch):
    store, _, priv = env
    block = SF.prepare("blk-contain", CAP, None, priv)  # real hidden fixtures, built before generation
    cases = next(Path(priv, "blk-contain").glob("*/cases.json"))
    cases.write_text(cases.read_text(encoding="utf-8").replace('"name"', f'"note": "{SENTINEL} {HIDDEN_COUNT}", "name"', 1), encoding="utf-8")  # the sentinel is inside the grading data
    (Path(priv) / "blk-contain" / "answers.txt").write_text(f"{SENTINEL} {HIDDEN_COUNT}", encoding="utf-8")
    replies = [body("p1", 1), body("p2", 2), body("p2b", 2), body("p3", 3), body("pall", "all")]
    srv, url = stub(replies, tmp_path)
    a = ns(url, private=str(priv / "blk-contain"), manifest={"id": block["manifest_id"], "sha256": block["manifest_sha256"]})
    real, n = D._dispatched, {"i": 0}

    def flaky(*x, **k):  # the process dies after the 2nd call of the first experiment was paid for
        n["i"] += 1
        if n["i"] == 2:
            raise OSError("interrupted")
        return real(*x, **k)
    monkeypatch.setattr(D, "_dispatched", flaky)
    first = Q.acquire_gap(a, store, "contain", CAP, GOAL, INS, policy=D.SEALED)
    assert first["state"] == "INCOMPLETE" and not Q.receipt_path(store, CAP).exists()  # no final, so nothing can be scored
    monkeypatch.setattr(D, "_dispatched", real)
    out = Q.acquire_gap(a, store, "contain", CAP, GOAL, INS, policy=D.SEALED)  # restart: same experiment resumes, same ledger
    r = json.loads(Q.receipt_path(store, CAP).read_text(encoding="utf-8"))
    final = D._sha(D.extract_code(replies[4]))
    assert out["state"] == r["state"] == "PUBLIC_CANDIDATE_FROZEN" and r["final_sha256"] == final and len(r["experiments"]) == 2
    assert [x["ledger"]["calls"] for x in out["attempts"]] == [3, 2] and srv.counters["total"] == 5 == r["ledger"]["calls"]  # 3 + 2: the resume did not replenish
    assert r["backend"]["returned_models"] == ["openai/gpt-oss-20b"] and r["manifest"]["sha256"] == block["manifest_sha256"] and len(r["calls"]) == 5 and r["body_path"].endswith(f"cand-{final}.py")
    again = Q.acquire_gap(a, store, "contain", CAP, GOAL, INS, policy=D.SEALED)  # a second restart: the receipt stands, nothing is dispatched
    assert again.get("resumed") and srv.counters["total"] == 5 and again["final_receipt"]["sha256"] == r["receipt_sha256"]
    # carry-best saw only public dev results
    rq = reqs(tmp_path)
    assert len(rq) == 5 and "Your best previous candidate (dev 2 of" in rq[3]["messages"][1]["content"] and "# pass=2" in rq[3]["messages"][1]["content"]
    assert no_hidden["labels"] == []
    # containment: the sentinel and any hidden count are in no request, store record, feedback, carry-best, reply, receipt or log (before and after the restart)
    blob = all_bytes(store, tmp_path / "req.jsonl")
    assert SENTINEL.encode() not in blob and HIDDEN_COUNT.encode() not in blob and b"hidden acceptance" not in blob and b"withheld" not in blob
    for e in D.experiments(Store(store)):
        assert all(p["acceptance"] is None for p in e["proposals"]) and "receipt" not in e and "hidden" not in (e.get("feedback") or "").lower()
        assert "hidden" not in json.dumps(e.get("best_feedback")).lower()


# 4 ------------------------------------------------------------------------------------------------------------------ finalization order and scoring
def test_final_receipt_precedes_scoring_which_never_generates_or_replaces(env, fake_runs, tmp_path, no_hidden):
    store_a, priv = str(env[0]), env[2]
    store_b, store_c = store_at(tmp_path / "b"), store_at(tmp_path / "c")
    block = SF.prepare("blk1", CAP, None, priv)
    man = {"id": block["manifest_id"], "sha256": block["manifest_sha256"]}
    assert block["manifest_sha256"] == SF.prepare("blk1", CAP, None, priv)["manifest_sha256"]  # one manifest per block, never regenerated
    (tmp_path / "la").mkdir(), (tmp_path / "lb").mkdir()
    srv_a, url_a = stub([WRONGS[0], CORRECT], tmp_path / "la")
    srv_b, url_b = stub(["no code in this reply"], tmp_path / "lb")
    ra = Q.acquire_gap(ns(url_a, manifest=man), store_a, "A", CAP, GOAL, INS, policy=D.SEALED)
    rb = Q.acquire_gap(ns(url_b, manifest=man), store_b, "B", CAP, GOAL, INS, policy=D.SEALED)
    assert ra["state"] == "PUBLIC_CANDIDATE_FROZEN" and rb["state"] == "UNRESOLVED" and srv_b.counters["total"] == 9  # nothing usable: UNRESOLVED, never fabricated
    assert "admission" not in ra and json.loads(Q.receipt_path(store_b, CAP).read_text(encoding="utf-8"))["final_sha256"] is None
    batch = {"batch_id": "t", "campaigns": [
        {"campaign_id": "A", "block_id": "blk1", "cap": CAP, "backend": "local", "store": store_a, "receipt_sha256": ra["final_receipt"]["sha256"], "status": "done"},
        {"campaign_id": "B", "block_id": "blk1", "cap": CAP, "backend": "hosted", "store": store_b, "receipt_sha256": rb["final_receipt"]["sha256"], "status": "done"},
        {"campaign_id": "C", "block_id": "blk1", "cap": CAP, "backend": "hosted", "store": store_c, "receipt_sha256": None, "status": "done"}]}
    bp, pub = tmp_path / "batch.json", tmp_path / "pub" / "public.json"
    bp.write_text(json.dumps(batch), encoding="utf-8")
    before = (srv_a.counters["total"], srv_b.counters["total"], Q.receipt_path(store_a, CAP).read_bytes())
    with pytest.raises(SystemExit, match="C: no frozen final receipt"):  # one campaign has no final receipt: nothing is scored at all
        SF.score(bp, priv, pub)
    assert not (priv / "_results").exists() and no_hidden["labels"] == []
    batch["campaigns"][2]["status"] = "incomplete"  # recorded as an incomplete pair instead
    bp.write_text(json.dumps(batch), encoding="utf-8")
    no_hidden["armed"] = False
    m_receipt = Q.receipt_path(store_a, CAP).stat().st_mtime_ns
    res = SF.score(bp, priv, pub)
    fin = json.loads((priv / "_results" / "A" / "final.json").read_text(encoding="utf-8"))
    assert fin["outcome"] == "PASS" and fin["receipt_sha256"] == ra["final_receipt"]["sha256"] and m_receipt < (priv / "_results" / "A" / "final.json").stat().st_mtime_ns
    assert (srv_a.counters["total"], srv_b.counters["total"], Q.receipt_path(store_a, CAP).read_bytes()) == before  # scoring called no model and replaced nothing
    assert [x for x in no_hidden["labels"] if x == "sealed_final"] == ["sealed_final"]  # ONE final scored (B was UNRESOLVED, C incomplete)
    cov = [json.loads(x) for x in (priv / "_results" / "coverage.jsonl").read_text(encoding="utf-8").splitlines()]
    cand_files = {p.stem[5:] for st in (store_a, store_b) for p in Path(st, "discovery").glob("*/cand-*.py")}
    assert {c["sha256"] for c in cov} == cand_files and all(c.get("pass_count") is not None for c in cov)  # every distinct candidate judged, privately
    text = pub.read_text(encoding="utf-8")
    assert res["by_backend"] == {"local": {"pass": 1, "fail": 0, "incomplete": 0}, "hosted": {"pass": 0, "fail": 1, "incomplete": 1}}
    assert res["blocks"][0]["manifest_sha256"] == block["manifest_sha256"] and "pass_count" not in text and SENTINEL not in text
    n = len(no_hidden["labels"])
    SF.score(bp, priv, pub)  # scoring again re-scores no final
    assert [x for x in no_hidden["labels"][n:] if x == "sealed_final"] == []


def test_manifest_seed_is_outside_every_pilot_range_and_the_public_identity_is_opaque(env):
    _, _, priv = env
    seed = SF.derive_seed("blkX", CAP)
    assert SF.SEED_FLOOR <= seed < 2 ** 62 and seed > 2026300000 + 100 * 3 + 10000 * 1000  # above every proposer seed and pilot seed_base
    with pytest.raises(SystemExit, match="seed must be in"):
        SF.prepare("blkY", CAP, 2026300001, priv)
    pub = SF.prepare("blkX", CAP, None, priv)
    assert set(pub) == {"manifest_id", "manifest_sha256", "block_id", "cap"} and not re.search(r"d-[0-9a-f]{20}", json.dumps(pub))


# 5 ------------------------------------------------------------------------------------------------------------------ backend_screen --dry-run, end to end on the stub
INPUTS = Path("D:/HIVE-operator-inputs/mom-site/exports")


@pytest.fixture(scope="module")
def screen(tmp_path_factory):
    if not (INPUTS / "2633d9b").is_dir():
        pytest.skip("the site export inputs are not on this machine")
    import backend_screen as BS
    mp = pytest.MonkeyPatch()
    mp.setattr(D, "_dev_run", lambda b, dev, h, timeout=60, **kw: ({"n": len(dev), "pass_count": 0}, "case x: wrong"))  # no containers: the dry run is about the protocol
    root = tmp_path_factory.mktemp("screen")
    argv = ["--out", str(root / "out"), "--private-root", str(root / "private"), "--inputs", str(INPUTS), "--dry-run"]
    assert BS.main(argv) == 0
    yield SimpleNamespace(BS=BS, out=root / "out", private=root / "private", argv=argv, first=json.loads((root / "out" / "screen-summary.json").read_text(encoding="utf-8")))
    mp.undo()


def test_screen_dry_run_is_8_campaigns_72_calls_and_pairs_share_a_manifest(screen):
    out, m = screen.out, json.loads((screen.out / "screen-manifest.json").read_text(encoding="utf-8"))
    assert screen.first["campaigns"] == 8 and screen.first["calls"] == 72 <= screen.BS.LIMITS["calls"] and screen.first["stopped"] is None
    assert [b["order"][0] for b in m["blocks"]] == ["local", "hosted", "local", "hosted"] and m["temperature"] == 0.2 and m["policy"] == D.SEALED
    assert [(b["cap"], b["repeat"]) for b in m["blocks"]] == [("site.ref-extract", 1), ("site.ref-extract", 2), ("site.ref-resolve", 1), ("site.ref-resolve", 2)]
    assert len({b["manifest"]["sha256"] for b in m["blocks"]}) == 4 and len({b["seed_base"] for b in m["blocks"]}) == 4
    batch = json.loads((out / "batch.json").read_text(encoding="utf-8"))
    assert len(batch["campaigns"]) == 8
    for b in m["blocks"]:
        rs = {c["backend"]: json.loads(Q.receipt_path(c["store"], c["cap"]).read_text(encoding="utf-8")) for c in batch["campaigns"] if c["block_id"] == b["block_id"]}
        assert set(rs) == {"local", "hosted"} and {r["manifest"]["sha256"] for r in rs.values()} == {b["manifest"]["sha256"]}  # one identical manifest per pair ...
        assert not set(rs["local"]["experiments"]) & set(rs["hosted"]["experiments"])  # ... but different experiments (frozen backend)
        assert rs["local"]["backend"]["returned_models"] == [m["backends"]["local"]["model"]] and rs["hosted"]["backend"]["returned_models"] == [m["backends"]["hosted"]["model"]]
        assert rs["local"]["seed_base"] == rs["hosted"]["seed_base"] == b["seed_base"] and all(r["ledger"]["calls"] <= 9 for r in rs.values())
    assert not any(Path(c["store"]).resolve().is_relative_to(screen.private.resolve()) for c in batch["campaigns"])


def test_screen_restart_neither_replenishes_nor_dispatches_again(screen):
    n = sum(len((screen.out / f).read_text(encoding="utf-8").splitlines()) for f in os.listdir(screen.out) if f.startswith("stub-requests-"))
    led = (screen.out / "screen-ledger.json").read_bytes()
    assert screen.BS.main(screen.argv) == 0
    assert sum(len((screen.out / f).read_text(encoding="utf-8").splitlines()) for f in os.listdir(screen.out) if f.startswith("stub-requests-")) == n == 72
    assert (screen.out / "screen-ledger.json").read_bytes() == led
    st = json.loads(led.decode("utf-8"))
    assert sum(b["reserved"]["calls"] for b in st["blocks"].values()) == 72 and all(c["status"] == "final" for c in st["campaigns"].values())


def test_screen_stops_cleanly_when_a_block_does_not_fit_and_a_started_campaign_is_never_rerun(screen, tmp_path, monkeypatch):
    BS = screen.BS
    cfg = json.loads(json.dumps(M._dispatch_cfg()))
    cfg["budget"]["remaining_usd"] = 0.5  # below one block's hosted worst case
    monkeypatch.setattr(M, "_dispatch_cfg", lambda c=None: c if isinstance(c, dict) else cfg)
    argv = ["--out", str(tmp_path / "o2"), "--private-root", str(tmp_path / "p2"), "--inputs", str(INPUTS), "--dry-run"]
    assert BS.main(argv) == 0
    s = json.loads((tmp_path / "o2" / "screen-summary.json").read_text(encoding="utf-8"))
    assert s["campaigns"] == 0 and s["calls"] == 0 and "hosted budget" in s["stopped"]
    st = json.loads((tmp_path / "o2" / "screen-ledger.json").read_text(encoding="utf-8"))
    assert st["blocks"] == {} and not (tmp_path / "o2" / "stores").exists()
    # a campaign that was started and has no final receipt stays an incomplete pair: its partner is not run, and nothing is re-dispatched
    m = json.loads((screen.out / "screen-manifest.json").read_text(encoding="utf-8"))
    b0 = m["blocks"][0]
    BS.save(SimpleNamespace(out=str(tmp_path / "o2")), m, lambda st: (st["blocks"].update({b0["block_id"]: {"status": "reserved", "reserved": dict(BS.PER_BLOCK, usd=0)}}),
                                                                       st["campaigns"].update({f"{b0['block_id']}.{x}": {"block_id": b0["block_id"], "backend": x, "status": "started" if x == "local" else "pending"} for x in b0["order"]})))
    assert BS.main(argv) == 0  # the reserved block needs no new reservation; the next block does not fit: stop
    st = json.loads((tmp_path / "o2" / "screen-ledger.json").read_text(encoding="utf-8"))
    assert st["campaigns"][f"{b0['block_id']}.local"]["status"] == "incomplete" and st["campaigns"][f"{b0['block_id']}.hosted"]["status"] == "not_run"
    assert not list((tmp_path / "o2").glob(f"stub-requests-{b0['block_id']}.*")) and BS.LIMITS["calls"] == 72
