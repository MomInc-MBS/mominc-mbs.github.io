"""Two raw site releases (folder + site-scope file each) plan as pack-manifest x2 -> release-diff, in the order given; one pair is unchanged."""
from __future__ import annotations

import json

import pytest

from hive import capability_registry as CR
from hive import capcontract as CC
from hive import goal_runner as G
from hive import operator_runtime as O
from hive.storage import Store

DIFF, GOAL = "site.release-diff", "Compare these two site releases: list the changed files."


@pytest.fixture
def store(tmp_path, monkeypatch):
    s = Store(tmp_path / "s")
    O.import_bundle(s)
    monkeypatch.setattr(CR, "cap_ids", lambda st: [DIFF, "site.ref-extract", "site.ref-resolve", "site.ref-check"])
    monkeypatch.setattr(CR, "resolve_discovered", lambda st, cid: {"cap_id": cid, "version": 1, "statement": {"schema": CC.V3, "cap_id": cid, "version": 1, "contract": CC.get(cid)},
                                                                    "statement_sha": "sha", "event_ref": "ev"})
    yield s
    s.close()


def release(tmp_path, name):
    d = tmp_path / name
    d.mkdir()
    (d / "index.html").write_bytes(name.encode())
    return (name, "folder", d), (name + ".scope.json", "file", json.dumps({"schema": "site-scope-v1", "commit": name, "committed_at": "2026-01-01T00:00:00Z"}).encode())


def contract(tmp_path, *names, deliverable="release_change_report"):
    ins = [x for n in names for x in release(tmp_path, n)]
    return G.make_contract(GOAL, [(n, k, v) for n, k, v in ins], deliverable=deliverable)


def test_two_releases_plan_pack_pack_diff_in_given_order(store, tmp_path):
    c = contract(tmp_path, "olda", "newb")
    assert [i["type"] for i in c["inputs"]] == ["folder", "site_scope"] * 2
    plan = G.plan_goal(store, c)
    assert [(s["op"], s["inputs"]) for s in plan["steps"]] == [("site.pack-manifest", ["input:0", "input:1"]), ("site.pack-manifest", ["input:2", "input:3"]),
                                                              (DIFF, ["step:s1", "step:s2"])]
    assert G.validate_plan(store, c, plan) == []


def test_single_release_plan_is_unchanged(store, tmp_path):
    c = contract(tmp_path, "only", deliverable="broken_ref_report")
    assert [i["type"] for i in c["inputs"]] == ["folder", "site_scope"]
    assert [s["op"] for s in G.plan_goal(store, c)["steps"]] == ["site.pack-manifest", "site.pack-pages", "site.ref-extract", "site.ref-resolve", "site.ref-check"]


def test_folder_without_scope_has_no_plan(store, tmp_path):
    (n, k, v), _ = release(tmp_path, "olda")
    (m, k2, v2), s2 = release(tmp_path, "newb")
    c = G.make_contract(GOAL, [(n, k, v), (m, k2, v2), s2], deliverable="release_change_report")
    assert G.plan_goal(store, c)["steps"] == []
