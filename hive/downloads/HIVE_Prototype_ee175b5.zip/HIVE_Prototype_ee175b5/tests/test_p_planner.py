"""P-A: same-contract alternatives, bounded runtime fallback, per-capability history, stored-plan execution, duplicate detection.
Docker-free: two real signed admissions of the SAME interface under different capability_ids (a contract copy with its own capability_id), run through the
real goal_runner with in-process stand-ins for the container."""
from __future__ import annotations

import copy
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import hive_admission as H  # noqa: E402
from hive import cap_history as CH  # noqa: E402
from hive import capability_registry as CR  # noqa: E402
from hive import capcontract as CC  # noqa: E402
from hive import experiment_compare as EC  # noqa: E402
from hive import goal_runner as G  # noqa: E402
from hive import operator_runtime as O  # noqa: E402
from hive.operator_runtime import _sha  # noqa: E402
from hive.storage import Store  # noqa: E402

pytestmark = pytest.mark.skipif(not CR.keygen(), reason="ssh-keygen unavailable")
BASE = "text.interval-merge"
GOAL = "Merge the overlapping ranges in this file"
FIRST, SECOND = "cap-z-first", "cap-a-second"  # the preferred one sorts LAST by name: ranking, not op-name order, must pick it
BODY = (ROOT / "capabilities" / BASE / "adapter.py").read_text(encoding="utf-8")
RANGES = [("ranges.txt", "file", b"1-3\n5-8\n10-20\n15-30\n")]


def contract_for(cap):
    c = copy.deepcopy(CC.get(BASE))
    c["capability_id"] = cap
    return c


def admit(store, key, cap, body=BODY, *, passed=10, n=10, version=1):
    c = contract_for(cap)
    st = {"schema": CR.SCHEMA, "cap_id": cap, "version": version, "contract": c, "contract_sha256": CC.sha(c), "impl_sha256": _sha(body), "body": body,
          "harness_sha256": CC.harness_sha(c), "pin": CC.pin(c), "evaluation": {"pass_count": passed, "n": n}, "lineage": {}, "authority": {}, "admitted_at": "t"}
    s = Store(store)
    try:
        CR.append(s, cap, "admit", statement=st, statement_sha=_sha(CR.canon(st)), signature=CR.sign(CR.canon(st), key), exp_id="direct")
    finally:
        s.close()


@pytest.fixture
def rig(tmp_path, monkeypatch):
    info = H.init(str(tmp_path / "keys"), str(tmp_path / "signers"))
    monkeypatch.setattr(CR, "SIGNERS", Path(info["signers"]))
    calls = []

    def run(src, text, checks=None, timeout=None, max_out=None, *, backend="container", operator_class="generated", **kw):
        calls.append(src)
        if "BOOM" in src:
            raise RuntimeError("container failed")
        if "WRONG" in src:
            return json.dumps(["not the answer"])
        ns = {}
        exec(compile(src, "<genome>", "exec"), ns)
        return ns["apply"](text, checks)
    monkeypatch.setattr(EC, "run_isolated", run)
    store = tmp_path / "store"
    s = Store(store)
    O.import_bundle(s)
    s.close()
    return SimpleNamespace(store=store, key=Path(info["key"]), calls=calls, tmp=tmp_path)


def two(rig, first_body=BODY, **kw):
    admit(rig.store, rig.key, FIRST, first_body, passed=10, n=10)
    admit(rig.store, rig.key, SECOND, passed=9, n=10)


def goal(rig, **kw):
    return G.run_goal(rig.store, G.make_contract(GOAL, RANGES, deliverable="merged_intervals", **kw), RANGES)


def plan_of(rig):
    s = Store(rig.store)
    try:
        return G.plan_goal(s, G.make_contract(GOAL, RANGES, deliverable="merged_intervals"))
    finally:
        s.close()


def test_same_contract_caps_are_ranked_by_hidden_pass_ratio_not_name(rig):
    two(rig)
    step = plan_of(rig)["steps"][0]
    alts = step["ranking"]["alternatives"]
    assert step["op"] == FIRST and [a["op"] for a in alts] == [FIRST, SECOND]
    assert alts[0]["reason"] == "best by the rank key" and alts[1]["reason"].startswith("pass_ratio 0.9 vs 1.0")
    assert alts[0]["rank"]["pass_ratio"] == 1.0 and set(alts[0]["rank"]) == {"pass_ratio", "success_rate", "median_ms", "cost", "version"}
    assert len(CC.contracts_for_gap({"in": "interval_text", "arity": 1, "out": "merged_intervals"})) >= 1


def test_history_decides_when_the_receipts_tie(rig):
    admit(rig.store, rig.key, FIRST)
    admit(rig.store, rig.key, SECOND)  # identical receipts
    assert plan_of(rig)["steps"][0]["op"] == SECOND  # a full tie ends at capability_id
    s = Store(rig.store)
    for _ in range(3):
        CH.record(s, SECOND, 1, "g-x", "FAILED", 50, 0, "EXECUTION")
        CH.record(s, FIRST, 1, "g-x", "OK", 80, 0, "NONE")
    s.close()
    step = plan_of(rig)["steps"][0]
    assert step["op"] == FIRST and step["ranking"]["alternatives"][1]["reason"].startswith("success_rate 0.0 vs 1.0")


def test_history_stores_only_numbers_and_enums(rig):
    s = Store(rig.store)
    CH.record(s, "c", 1, "g-1", "OK", 12, 0, "NONE")
    for bad in (dict(status="the model said hi"), dict(failure_class="free text"), dict(cap_id="a b; drop"), dict(elapsed_ms=-1), dict(version=True)):
        args = dict(cap_id="c", version=1, goal_id="g-1", status="OK", elapsed_ms=1, model_calls=0, failure_class="NONE") | bad
        with pytest.raises(ValueError):
            CH.record(s, **args)
    assert CH.stats(s, "c") == {"n": 1, "success_rate": 1.0, "median_ms": 12}
    assert set(CH.rows(s, "c")[0]) == {"v", "goal", "status", "ms", "model_calls", "fail", "at"}
    s.close()


def test_single_capability_plans_are_unchanged(rig):
    admit(rig.store, rig.key, FIRST)
    step = plan_of(rig)["steps"][0]
    assert step["op"] == FIRST and "ranking" not in step


@pytest.mark.parametrize("bad", ["BOOM", "WRONG"])
def test_preferred_fails_at_runtime_then_second_is_used_and_verified(rig, bad):
    two(rig, BODY + f"\n# {bad}\n")
    r = goal(rig)
    assert r["state"] == "VERIFIED", r["reason"]
    assert r["steps"][-1]["capability"]["cap_id"] == SECOND and r["steps"][-1]["op"] == SECOND
    assert [f["from"] for f in r["fallbacks"]] == [FIRST] and r["fallbacks"][0]["to"] == SECOND
    assert r["fallbacks"][0]["reason"] == ("EXECUTION" if bad == "BOOM" else "OUTPUT_REJECTED")
    assert r["steps"][-1]["attempts"][0]["op"] == FIRST and r["usage"]["container_runs"] == 2 and r["usage"]["model_calls"] == 0
    s = Store(rig.store)
    assert CH.stats(s, FIRST)["success_rate"] == 0.0 and CH.stats(s, SECOND)["success_rate"] == 1.0
    s.close()


def test_preferred_revoked_then_plan_picks_the_second(rig):
    two(rig)
    H.revoke(rig.store, FIRST, 1, "bad", rig.key)
    r = goal(rig)
    assert r["state"] == "VERIFIED" and r["plan"]["steps"][0]["op"] == SECOND and r["fallbacks"] == []


def test_tampered_preferred_fails_closed_with_no_fallback(rig, monkeypatch):
    two(rig)
    real = G.validate_plan

    def tamper_after_validation(store, contract, plan):
        out = real(store, contract, plan)
        ev = CR.history(store, FIRST)[-1]
        f = Path(rig.store) / ev["statement_ref"]
        f.write_bytes(f.read_bytes() + b" ")  # the plan was valid; the statement is altered before the step loads it
        return out
    monkeypatch.setattr(G, "validate_plan", tamper_after_validation)
    r = goal(rig)
    assert r["state"] == "STEP_FAILED" and r["fallbacks"] == [] and r["integrity_failure"]["op"] == FIRST
    assert not rig.calls and r["usage"]["container_runs"] == 0 and not r.get("deliverable")


def test_fallback_also_fails_is_a_bounded_failure_not_success(rig):
    admit(rig.store, rig.key, FIRST, BODY + "\n# BOOM\n", passed=10, n=10)
    admit(rig.store, rig.key, SECOND, BODY + "\n# BOOM\n", passed=9, n=10)
    r = goal(rig)
    assert r["state"] == "STEP_FAILED" and not r.get("deliverable") and len(r["fallbacks"]) == 1 and r["usage"]["container_runs"] == 2


def test_fallbacks_are_capped_per_goal(rig, monkeypatch):
    monkeypatch.setattr(G, "MAX_FALLBACKS", 0)
    two(rig, BODY + "\n# BOOM\n")
    r = goal(rig)
    assert r["state"] == "STEP_FAILED" and r["fallbacks"] == [] and "fallback budget exhausted" in r["reason"]


def test_fallback_counts_against_the_container_budget(rig):
    two(rig, BODY + "\n# BOOM\n")
    r = goal(rig, budget={"container_runs": 1})
    assert r["state"] == "STEP_FAILED" and r["fallbacks"] == [] and r["usage"]["container_runs"] == 1


def test_plan_then_run_plan_runs_the_stored_plan_with_zero_model_calls(rig, monkeypatch):
    admit(rig.store, rig.key, FIRST)
    root = rig.tmp / "in"
    root.mkdir()
    (root / "ranges.txt").write_bytes(RANGES[0][2])
    contract, _ = G.prepare(rig.store, root, GOAL, ["ranges.txt"], "merged_intervals")
    planned = G.plan_only(rig.store, contract, ["ranges.txt"])
    assert planned["state"] == "PLANNED" and not rig.calls and planned["plan"]["steps"][0]["op"] == FIRST
    monkeypatch.setattr(G, "plan_goal", lambda *a, **k: pytest.fail("run-plan must not replan"))
    r = G.run_plan(rig.store, contract["contract_id"], root)
    assert r["state"] == "VERIFIED" and r["stored_plan"] == {"replanned": False, "substitutions": 0, "model_calls": 0}
    assert r["usage"]["model_calls"] == 0 and r["usage"]["proposal_calls"] == 0
    with pytest.raises(O.Refused, match="no stored plan"):
        G.run_plan(rig.store, "g-nope", root)


def test_run_plan_revoked_preferred_takes_the_alternative_or_refuses(rig, monkeypatch):
    two(rig)
    root = rig.tmp / "in"
    root.mkdir()
    (root / "ranges.txt").write_bytes(RANGES[0][2])
    contract, _ = G.prepare(rig.store, root, GOAL, ["ranges.txt"], "merged_intervals")
    G.plan_only(rig.store, contract, ["ranges.txt"])
    H.revoke(rig.store, FIRST, 1, "bad", rig.key)
    r = G.run_plan(rig.store, contract["contract_id"], root)
    assert r["state"] == "VERIFIED" and r["steps"][-1]["op"] == SECOND and r["fallbacks"][0]["phase"] == "run-plan" and r["stored_plan"]["substitutions"] == 1
    # no alternative left: refused, nothing run, never replanned
    G.plan_only(rig.store, contract, ["ranges.txt"])  # replans the only remaining capability (no alternatives)
    H.revoke(rig.store, SECOND, 1, "bad", rig.key)
    n = len(rig.calls)
    r = G.run_plan(rig.store, contract["contract_id"], root)
    assert r["state"] == "PLAN_INVALID" and len(rig.calls) == n and r["usage"]["model_calls"] == 0


def test_cli_has_plan_and_run_plan():
    from hive import cli
    ap = cli.parser()
    ns = ap.parse_args(["operator", "plan", "g", "a.txt", "--allowed-root", "r"])
    assert ns.op_command == "plan" and ns.sources == ["a.txt"]
    ns = ap.parse_args(["operator", "run-plan", "g-1", "--allowed-root", "r"])
    assert ns.op_command == "run-plan" and ns.goal_id == "g-1"


def test_duplicate_contract_reuses_instead_of_acquiring(rig, monkeypatch):
    admit(rig.store, rig.key, BASE)  # contract identical to the repo contract of the gap below
    s = Store(rig.store)
    c = CC.get(BASE)
    dup = CR.find_duplicate(s, contract_sha256=CC.sha(c))
    assert dup["cap_id"] == BASE and dup["match"] == "contract_sha256" and CR.find_duplicate(s, contract_sha256="0" * 64) is None
    s.close()
    from hive import acquire as A
    monkeypatch.setattr(A, "open_run", lambda *a, **k: pytest.fail("a duplicate must not trigger acquisition"))
    gap = ({"in": "interval_text", "arity": 1, "ordered": True, "out": "merged_intervals"}, [])
    monkeypatch.setattr(G, "plan_goal", lambda store, contract: {"schema": G.PLAN_SCHEMA, "steps": [], "excluded": []})
    monkeypatch.setattr(G, "missing_step", lambda store, contract: gap)
    r = goal(rig, allow_acquisition=True)
    assert r["state"] == "DUPLICATE" and r["duplicate"]["cap_id"] == BASE and r.get("acquisition_run") is None


def test_no_duplicate_still_acquires(rig, monkeypatch):
    from hive import acquire as A
    monkeypatch.setattr(A, "open_run", lambda s, gap: {"run_id": "a-1"})
    gap = ({"in": "interval_text", "arity": 1, "ordered": True, "out": "merged_intervals"}, [])
    monkeypatch.setattr(G, "plan_goal", lambda store, contract: {"schema": G.PLAN_SCHEMA, "steps": [], "excluded": []})
    monkeypatch.setattr(G, "missing_step", lambda store, contract: gap)
    r = goal(rig, allow_acquisition=True)
    assert r["state"] == "ACQUISITION_QUEUED" and r["acquisition_run"] == "a-1"


def test_duplicate_provenance_needs_repo_revision_and_tree(rig):
    admit(rig.store, rig.key, FIRST)
    s = Store(rig.store)
    assert CR.find_duplicate(s, provenance={"repo": "o/r", "revision": "abc", "tree_sha256": None}) is None
    s.close()
