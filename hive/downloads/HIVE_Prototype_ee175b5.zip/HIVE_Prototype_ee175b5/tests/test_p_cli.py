"""CLI views and signed lifecycle on a temp store: `hive operator cap list|show|revoke|rollback`, `acquisitions`, `receipt`, `overview`.
Same fixture as the admission tests (copy of the committed C3 store, test key, in-process containers)."""
import json
import shutil
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "tests"))
import hive_admission as H  # noqa: E402
import test_capability_admission as TA  # noqa: E402  (module import only)
from hive import capability_registry as CR  # noqa: E402
from hive import cap_cli as K  # noqa: E402
from hive import cli  # noqa: E402
from hive import experiment_compare as EC  # noqa: E402
from hive.storage import Store  # noqa: E402

pytestmark = pytest.mark.skipif(not TA.SRC.exists() or not CR.keygen(), reason="C3 store or ssh-keygen unavailable")


@pytest.fixture
def auth(tmp_path, monkeypatch):
    info = H.init(str(tmp_path / "keys"), str(tmp_path / "signers"))
    monkeypatch.setattr(CR, "SIGNERS", Path(info["signers"]))
    return Path(info["key"])


@pytest.fixture
def store(tmp_path, monkeypatch, auth):
    def fake(src, text, checks=None, timeout=None, max_out=None, *, backend, operator_class, **kw):
        ns = {}
        exec(compile(src, "<genome>", "exec"), ns)
        return ns["apply"](text, checks)
    monkeypatch.setattr(EC, "run_isolated", fake)
    root = tmp_path / "store"
    shutil.copytree(TA.SRC, root)
    return root


def hive(capsys, store, *argv):
    rc = cli.main(["--store", str(store), "operator", *argv])
    cap = capsys.readouterr()
    return rc, cap.out, cap.err


def js(capsys, store, *argv):
    rc, out, err = hive(capsys, store, *argv, "--json")
    assert rc == 0, err
    return json.loads(out)


def admit_v1(store, auth):
    return H.admit(store, TA.EXP, auth, rerun=TA.rerun_fake(store))


def test_list_shows_candidate_then_active_with_provenance_and_receipt(capsys, store, auth):
    rows = js(capsys, store, "cap", "list")
    cand = [r for r in rows if r["id"] == "inventory-diff"]
    assert [r["lifecycle"] for r in cand] == ["candidate"] and cand[0]["version"] is None and cand[0]["receipt"]
    assert {r["id"] for r in rows if r["kind"] == "m2"} >= {"convert", "merge"}
    admit_v1(store, auth)
    row = [r for r in js(capsys, store, "cap", "list") if r["id"] == "inventory-diff"]
    assert len(row) == 1 and row[0]["lifecycle"] == "active" and row[0]["version"] == 1 and row[0]["admitted_at"] and len(row[0]["receipt"]) == 12 and "model" in row[0]["provenance"]
    rc, out, _ = hive(capsys, store, "cap", "list")  # the human view
    assert rc == 0 and "inventory-diff" in out and "active" in out and not out.lstrip().startswith("[")


def test_show_history_is_the_verified_signed_chain(capsys, store, auth):
    admit_v1(store, auth)
    TA.v2_fixture(store, auth)
    h = js(capsys, store, "cap", "show", "inventory-diff")
    assert h["chain_ok"] and [(e["type"], e.get("version")) for e in h["events"]] == [("admit", 1), ("admit", 2)] and all(e["signed"] for e in h["events"])
    rc, out, _ = hive(capsys, store, "cap", "show", "inventory-diff")
    assert "chain OK" in out
    TA.forge(store, lambda st: st.update(version=2, body=st["body"] + "\n# tampered\n"))  # replace the head admit with an altered statement
    assert js(capsys, store, "cap", "show", "inventory-diff")["chain_ok"] is False
    rc, _, err = hive(capsys, store, "cap", "show", "nothing-here", "--json")
    assert rc == 2 and "no chain" in err


def test_rollback_then_revoke_through_the_signed_authority(capsys, store, auth):
    admit_v1(store, auth)
    TA.v2_fixture(store, auth)
    out = js(capsys, store, "cap", "rollback", "inventory-diff", "--key", str(auth))
    assert (out["from_version"], out["to_version"]) == (2, 1)
    life = {r["version"]: r["lifecycle"] for r in js(capsys, store, "cap", "list") if r["id"] == "inventory-diff"}
    assert life == {1: "active", 2: "superseded"}
    out = js(capsys, store, "cap", "revoke", "inventory-diff", "--reason", "test", "--version", "2", "--key", str(auth))
    assert out["type"] == "revoke" and out["version"] == 2
    life = {r["version"]: r["lifecycle"] for r in js(capsys, store, "cap", "list") if r["id"] == "inventory-diff"}
    assert life == {1: "active", 2: "revoked"}
    out = js(capsys, store, "cap", "revoke", "inventory-diff", "--reason", "test v1", "--key", str(auth))  # default: the active version
    assert out["version"] == 1
    s = Store(store)
    with pytest.raises(CR.Unavailable):
        CR.resolve_discovered(s, "inventory-diff")
    s.close()


def test_lifecycle_commands_cannot_bypass_signing_or_key_rules(capsys, store, auth, tmp_path):
    admit_v1(store, auth)
    rc, _, err = hive(capsys, store, "cap", "revoke", "inventory-diff", "--reason", "x", "--key", str(Path(store) / "k"))  # key inside the store
    assert rc == 2 and "must not be inside" in err
    rc, _, err = hive(capsys, store, "cap", "rollback", "inventory-diff", "--key", str(auth))  # only one version
    assert rc == 2 and "no earlier admitted" in err
    rc, _, err = hive(capsys, store, "cap", "revoke", "inventory-diff", "--reason", "x", "--key", str(tmp_path / "missing_key"))
    assert rc == 2
    life = [r["lifecycle"] for r in js(capsys, store, "cap", "list") if r["id"] == "inventory-diff"]
    assert life == ["active"]  # nothing changed on any refusal
    src = (ROOT / "src" / "hive" / "cap_cli.py").read_text(encoding="utf-8")
    assert "CR.sign" not in src and "CR.append" not in src and "ssh-keygen" not in src  # the CLI module has no signing path of its own


def test_acquisitions_receipt_overview(capsys, store, auth):
    admit_v1(store, auth)
    a = js(capsys, store, "acquisitions")
    exp = next(e for e in a["experiments"] if e["exp_id"] == TA.EXP)
    assert exp["state"] == "CANDIDATE_PASSED" and exp["phase"] == "admitted" and exp["kind"] == "discovery" and a["runs"] == []
    ins = [("before.csv", "file", TA.BEFORE), ("after.csv", "file", TA.AFTER)]
    g = TA.G.run_goal(store, TA.G.make_contract("compare before and after", ins, deliverable="inventory_diff"), ins)
    assert g["state"] == "VERIFIED"
    r = js(capsys, store, "receipt", g["goal_id"][:14])  # a unique prefix is enough
    assert r["goal_id"] == g["goal_id"] and r["verdict"] == "VERIFIED" and r["versions_used"] == {"inventory-diff": 1}
    assert r["model_calls"] == 0 and r["proposal_calls"] == 0 and r["elapsed_s"] is not None and "diff.json" in r["artifacts"]
    assert r["plan"] == [x["op"] + "(" + ",".join(x["inputs"]) + ")" for x in g["plan"]["steps"]]
    rc, out, _ = hive(capsys, store, "receipt", g["goal_id"])
    assert rc == 0 and "VERIFIED" in out and "inventory-diff" in out
    assert hive(capsys, store, "receipt", "no-such-goal")[0] == 2
    o = js(capsys, store, "overview")
    assert o["capabilities"]["active"] >= 3 and o["goals"] >= 2 and o["last_goals"][0]["goal_id"] == g["goal_id"] and o["ledger"]["counters"]["model_calls"] == 0
    rc, out, _ = hive(capsys, store, "overview")
    assert rc == 0 and "capabilities:" in out and "ledger:" in out


def test_objective_parser_and_command_surface(capsys):
    assert K.parse_objective("failure_class:wrong_output") == {"kind": "failure_class", "value": "wrong_output"}
    assert K.parse_objective("latency_ms:250") == {"kind": "latency_ms", "value": "250"}  # parsed, then refused by the improve path (no latency objective)
    with pytest.raises(SystemExit):
        cli.parser().parse_args(["operator", "cap", "improve", "x"])  # --objective is required
