"""P-B: the site.* capability contracts and their independent suites (site.ref-extract, site.ref-resolve, site.ref-check, site.release-diff, plus the same-interface site.ref-check-alt),
the type rows that map ordinary goals to them, and the export script. Fixture author: a conductor-side agent (Sol-B), not Ian.
No adapter is written here: the oracles are checked on hand-computed cases and against the by-construction truth of the generators."""
from __future__ import annotations

import base64
import hashlib
import importlib.util
import json
import re
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
from hive import capcontract as CC  # noqa: E402
from hive import goal_runner as G  # noqa: E402

CAPS = ["site.ref-extract", "site.ref-resolve", "site.ref-check", "site.release-diff"]


def mods(cap):
    c = CC.get(cap)
    return c, {m: CC.load_module(m, c) for m in ("oracle", "gen_public", "gen_private", "baseline", "harness")}


def b64(doc):
    return {"name": "x.json", "format": "base64", "data": base64.b64encode(json.dumps(doc).encode()).decode()}


# ---------------------------------------------------------------- contracts
@pytest.mark.parametrize("cap", CAPS + ["site.ref-check-alt"])
def test_contract_is_valid_v2_pinned_stdlib_and_names_no_adapter(cap):
    c = CC.get(cap)
    assert CC.is_v2(c) and c["execution"]["adapter_ref"] is None and c["execution"]["environment_ref"]["kind"] == "pinned"
    assert c["inputs"]["envelope"] == "files-v2" and c["permissions"]["imports"]["staged"] is False and c["permissions"]["network"] is False
    assert set(c["permissions"]["imports"]["stdlib"]) <= {"json", "base64", "re"}
    assert "fixture author" in (ROOT / c["proposer"]["behaviour_spec_ref"]).read_text(encoding="utf-8").lower()
    assert not list((ROOT / "capabilities" / cap).glob("adapter*")), "the repo ships no adapter"
    assert len(CC.pin(c)) == 64 and c["inputs"]["limits"]["max_total_bytes"] <= 2 * 1024 * 1024


def test_contract_interfaces():
    e, r, k, d = (CC.get(c) for c in CAPS)
    assert (e["inputs"]["types"], e["inputs"]["arity"], e["outputs"]["type"]) == (["site_pages"], [1, 1], "raw_reference_table")
    assert (r["inputs"]["types"], r["inputs"]["arity"], r["outputs"]["type"]) == (["raw_reference_table"], [1, 1], "reference_table")
    assert (k["inputs"]["types"], k["inputs"]["arity"], k["outputs"]["type"]) == (["reference_table", "site_manifest"], [2, 2], "broken_ref_report")
    assert (d["inputs"]["types"], d["inputs"]["arity"], d["outputs"]["type"]) == (["site_manifest"], [2, 2], "release_change_report")
    assert set(e["permissions"]["imports"]["stdlib"]) == set(r["permissions"]["imports"]["stdlib"]) == {"json", "base64", "re"}  # the schema allows only these of the stdlib the task needs
    produced = {c["outputs"]["type"] for c in CC.contracts() if not c["capability_id"].startswith("site.")}
    assert not produced & {"raw_reference_table", "reference_table", "broken_ref_report", "release_change_report"}, "each site output type is a genuine gap"
    assert len({CC.get(c)["outputs"]["artifact_name"] for c in CAPS + ["site.ref-check-alt"]}) == 5


def test_alt_contract_has_the_identical_interface_and_the_same_suite():
    a, k = CC.get("site.ref-check-alt"), CC.get("site.ref-check")
    assert a["capability_id"] != k["capability_id"]
    for f in ("types", "arity", "envelope", "format", "limits"):
        assert a["inputs"][f] == k["inputs"][f]
    assert a["outputs"]["type"] == k["outputs"]["type"] and a["outputs"]["canonical_form"] == k["outputs"]["canonical_form"]
    assert a["verification"] == k["verification"] and a["execution"] == k["execution"] and a["permissions"] == k["permissions"]
    assert CC.pin(a) == CC.pin(k)
    sig = {"in": "reference_table", "ins": ["reference_table", "site_manifest"], "arity": 2, "out": "broken_ref_report"}
    assert CC.contract_for_gap(sig)["capability_id"] == "site.ref-check"  # first by id; the planner test sees both


@pytest.mark.parametrize("cap", CAPS)
def test_evaluator_pin_in_the_contract_equals_the_evaluators_own_pin(cap):
    spec = importlib.util.spec_from_file_location("g2_evaluate", ROOT / "evaluator" / "g2" / "evaluate.py")
    ev = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ev)
    c = CC.get(cap)
    assert ev.pin(str(ROOT / c["verification"]["suite_ref"])) == CC.pin(c)  # the receipt's evaluator pin and the admitted statement's pin agree


# ---------------------------------------------------------------- suites
@pytest.mark.parametrize("cap", CAPS)
def test_public_cases_are_deterministic_and_match_the_oracle(cap):
    _, m = mods(cap)
    a, b = m["gen_public"].cases(), m["gen_public"].cases()
    assert a == b and len(a) >= 6 and any(c["expected"] == "ERROR" for c in a) and any(c["expected"] != "ERROR" for c in a)
    for c in a:
        assert m["oracle"].expected(c["env"]) == c["expected"], c["name"]


@pytest.mark.parametrize("cap", CAPS)
def test_private_generation_is_seeded_bounded_and_oracle_consistent(cap):
    c, m = mods(cap)
    g = m["gen_private"]
    a, b, d = g.generate(5, 12), g.generate(5, 12), g.generate(6, 12)
    assert a == b and g.set_sha(a) == g.set_sha(b) and g.set_sha(a) != g.set_sha(d)
    lim = c["inputs"]["limits"]
    names = re.compile(r"[A-Za-z0-9._ -]{1,128}")
    for case in g.generate(21, 24):
        fs = case["env"]["files"]
        assert case["expected"] == "ERROR" or c["inputs"]["arity"][0] <= len(fs) <= c["inputs"]["arity"][1]  # a wrong file count is only ever an ERROR case
        assert len({f["name"].lower() for f in fs}) == len(fs)
        assert all(len(base64.b64decode(f["data"])) <= lim["max_file_bytes"] and names.fullmatch(f["name"]) and f["format"] == "base64" for f in fs)
        assert sum(len(base64.b64decode(f["data"])) for f in fs) <= lim["max_total_bytes"]
        assert m["oracle"].expected(case["env"]) == case["expected"]
    exp = [x["expected"] for x in g.generate(5, 24)]
    assert 0 < sum(e == "ERROR" for e in exp) < len(exp)


@pytest.mark.parametrize("cap", CAPS)
def test_the_oracle_agrees_with_the_by_construction_truth_over_many_seeds(cap):
    import random
    _, m = mods(cap)
    for seed in range(60):
        rng = random.Random(seed)
        env, truth = m["gen_public"].build(rng, rng.choice([1, 3, 6, 12]), rng.choice(m["gen_private"].ERRORS))
        assert m["oracle"].expected(env) == truth, seed


@pytest.mark.parametrize("cap", CAPS)
def test_cli_writes_only_under_out_and_prints_hash_only(cap, tmp_path):
    suite = ROOT / "capabilities" / cap / "suite"
    r = subprocess.run([sys.executable, "-I", str(suite / "gen_private.py"), "--out", str(tmp_path), "--seed", "3"], capture_output=True, text=True, timeout=120)
    assert r.returncode == 0, r.stderr
    got = json.loads(r.stdout.strip().splitlines()[-1])
    assert set(got) == {"set_sha256", "n"} and got["n"] == 24 and "expected" not in r.stdout and "base64" not in r.stdout
    cases = json.loads((tmp_path / got["set_sha256"] / "cases.json").read_text(encoding="utf-8"))
    assert hashlib.sha256(json.dumps(cases, sort_keys=True, separators=(",", ":")).encode()).hexdigest() == got["set_sha256"]
    assert not list(suite.glob("cases*"))


@pytest.mark.parametrize("cap", CAPS)
def test_scripted_baseline_fails_acceptance(cap):
    _, m = mods(cap)
    cases = m["gen_private"].generate(2, 24)

    def ok(case):
        try:
            return m["baseline"].run(case["env"]) == case["expected"]
        except Exception:
            return False
    assert sum(map(ok, cases)) < len(cases)


@pytest.mark.parametrize("cap", CAPS)
def test_proposer_spec_is_present_and_has_no_hidden_answers(cap):
    spec = (ROOT / CC.get(cap)["proposer"]["behaviour_spec_ref"]).read_text(encoding="utf-8")
    assert "json.dumps(obj, sort_keys=True" in spec and "ERROR" in spec
    assert not re.search(r"[0-9a-f]{40,}", spec), "no hashes or answers in the spec"


@pytest.mark.parametrize("cap", ["site.ref-extract", "site.ref-resolve"])
def test_split_capabilities_fit_one_small_proposal(cap):
    """The first ref-extract did not fit one 2,000-token local answer (spec 5.6 KB, a full tokenizer). Each half now has a spec of at most about 2.5 KB and a small oracle."""
    spec = (ROOT / CC.get(cap)["proposer"]["behaviour_spec_ref"]).read_text(encoding="utf-8")
    assert len(spec) <= 2700, len(spec)  # was 2600; contract v2 (a57d38e) added the two rules the P1 audit found missing, and the live screen froze these exact bytes
    core = [ln for ln in (ROOT / "capabilities" / cap / "suite" / "oracle.py").read_text(encoding="utf-8").splitlines() if ln.strip() and not ln.strip().startswith(("#", '"""'))]
    assert len(core) <= 80, len(core)


# ---------------------------------------------------------------- oracles on hand-computed cases
def pages_env(pages, commit="abc"):
    return {"files": [b64({"schema": "site-pages-v1", "commit": commit, "subset": {}, "pages": [{"path": p, "text": t} for p, t in pages]})]}


def test_ref_extract_oracle_hand_cases():
    _, m = mods("site.ref-extract")
    html = ("<A HREF=\"../img/Logo.png?v=2#x\"><img SRCSET='a.png 1x, /b.png 2x,'>\n<!-- <a href=\"ghost\"> --><script src=\"app.js\">x='<a href=\"g2\">'</script>\n"
            "<link href='#top'><a href=\"mailto:x@y\"><a href = \" ../up.html \"><a data-src=\"no\" href=\"\" title='a'>\n"
            "<div style=\"background:url('p/q.png')\"></div><a href=\"./\"><a href=\"HTTP://e.com/a\">"
            "<style>/* url(no.png) */ i{background:url( \"s.png\" ) , url(data:x,y)}</style><a href=\"a%zz/\u00e9.png\"><p>url(no2.png) href=\"no3\"</p><a href=x.html>")
    css = "/* url(no.png) */ a{background:url( \"../img/b.png\" )} b{background:url(//c.net/f.woff)} c{background:url(\"\")}"
    P = "docs/guide/a.html"
    got = json.loads(m["oracle"].expected(pages_env([(P, html), ("assets/s.css", css), ("x.js", "<a href=\"no\">")])))
    row = lambda page, kind, raw: {"kind": kind, "page": page, "raw": raw}
    assert got["schema"] == "raw-ref-table-v1" and got["commit"] == "abc" and got["pages"] == 3
    assert got["refs"] == [row("assets/s.css", "css-url", "../img/b.png"), row("assets/s.css", "css-url", "//c.net/f.woff"),
                           row(P, "href", "../img/Logo.png?v=2#x"), row(P, "srcset", "a.png"), row(P, "srcset", "/b.png"), row(P, "src", "app.js"), row(P, "href", "#top"),
                           row(P, "href", "mailto:x@y"), row(P, "href", "../up.html"), row(P, "css-url", "p/q.png"), row(P, "href", "./"), row(P, "href", "HTTP://e.com/a"),
                           row(P, "css-url", "s.png"), row(P, "css-url", "data:x,y"), row(P, "href", "a%zz/\u00e9.png")]  # unquoted attribute values are outside the grammar
    assert m["oracle"].expected(pages_env([("a.html", "<img src=\"x.png\">")] * 2)) == "ERROR"
    assert m["oracle"].expected({"files": [b64({"schema": "site-pages-v1", "commit": "c", "pages": []})] * 2}) == "ERROR"
    assert json.loads(m["oracle"].expected(pages_env([("e.html", "")])))["refs"] == []


def test_ref_extract_unterminated_and_edge_cases():
    _, m = mods("site.ref-extract")
    pages = [("a/b.html", "<a href=\"x.html\"><!-- never closed <a href=\"y.html\">"), ("s.htm", "<script>never closed <a href=\"z.html\">"),
             ("u.HTM", "<STYLE>a{b:url(k.png)} never closed"), ("c.CSS", "a{b:url(  ' sp.png ' )} /* never closed url(no.png)"),
             ("r.html", "<a\nhref='/'\n>< a href=\"no\"><a href=\"A\" HREF='B'><img srcset=\" , a.png,,b.png 480w\">")]
    got = json.loads(m["oracle"].expected(pages_env(pages)))["refs"]
    assert [(r["page"], r["kind"], r["raw"]) for r in got] == [("a/b.html", "href", "x.html"), ("c.CSS", "css-url", "sp.png"), ("r.html", "href", "/"), ("r.html", "href", "A"),
                                                              ("r.html", "href", "B"), ("r.html", "srcset", "a.png"), ("r.html", "srcset", "b.png"), ("u.HTM", "css-url", "k.png")]


def test_ref_resolve_oracle_hand_cases():
    _, m = mods("site.ref-resolve")
    P = "docs/guide/a.html"
    want = [("../img/Logo.png?v=2#x", "local", "docs/img/Logo.png"), ("#top", "anchor", None), ("HTTPS://e.com/a", "external", None), ("//cdn.x/z.css", "external", None),
            ("mailto:x@y", "scheme", None), ("data:image/png;base64,AAAA", "scheme", None), ("../../../up.html", "escapes-root", None), ("/../x.png", "escapes-root", None),
            ("%2e%2e/x%20y.html", "local", "docs/x y.html"), ("./", "local", "docs/guide/"), (".", "local", "docs/guide/"), ("..", "local", "docs/"), ("../..", "local", "/"),
            ("/", "local", "/"), ("a/./b/../c.png", "local", "docs/guide/a/c.png"), ("?q=1#f", "anchor", None), ("caf%c3%a9.png", "local", "docs/guide/caf\u00e9.png"),
            ("50%.png", "local", "docs/guide/50%.png"), ("a%zz", "local", "docs/guide/a%zz"), ("Up/Case.PNG#?x", "local", "docs/guide/Up/Case.PNG"), ("sub//dir/", "local", "docs/guide/sub/dir/"),
            ("c:/windows", "scheme", None), ("1abc:x", "local", "docs/guide/1abc:x"), ("", "anchor", None)]
    doc = {"schema": "raw-ref-table-v1", "commit": "c1", "pages": 7, "extra": 1, "refs": [{"kind": "src", "page": P, "raw": r} for r, _, _ in want]}
    got = json.loads(m["oracle"].expected({"files": [b64(doc)]}))
    assert got["schema"] == "ref-table-v1" and got["commit"] == "c1" and got["pages"] == 7
    assert [(r["raw"], r["class"], r["target"]) for r in got["refs"]] == want and all(r["kind"] == "src" and r["page"] == P for r in got["refs"])
    root = json.loads(m["oracle"].expected({"files": [b64(dict(doc, refs=[{"kind": "href", "page": "top.html", "raw": "../x.png"}, {"kind": "href", "page": "top.html", "raw": "a.png"}]))]}))
    assert [(r["class"], r["target"]) for r in root["refs"]] == [("escapes-root", None), ("local", "a.png")]
    ok = dict(doc, refs=[])
    bad = [{"files": []}, {"files": [b64(ok)] * 2}, {"files": [b64(dict(ok, schema="ref-table-v1"))]}, {"files": [b64(dict(ok, commit=3))]}, {"files": [b64(dict(ok, pages="7"))]},
           {"files": [b64(dict(ok, pages=True))]}, {"files": [b64(dict(ok, refs="x"))]}, {"files": [b64(dict(ok, refs=[{"kind": "href", "page": "a", "raw": 1}]))]},
           {"files": [b64(dict(ok, refs=[{"kind": "href", "page": "a"}]))]}, {"files": [{"name": "x", "format": "base64", "data": "!!"}]}]
    assert [m["oracle"].expected(e) for e in bad] == ["ERROR"] * len(bad)


def test_extract_then_resolve_gives_the_table_the_ref_check_oracle_reads():
    _, e = mods("site.ref-extract")
    _, r = mods("site.ref-resolve")
    _, k = mods("site.ref-check")
    pages = [("docs/a.html", "<a href=\"../img/logo.png\"><img src=\"gone.png\"><a href=\"https://x.org/\"><a href=\"../../esc.png\">"), ("img/s.css", "a{b:url(logo.png)}")]
    raw = e["oracle"].expected(pages_env(pages, "c1"))
    tab = r["oracle"].expected({"files": [{"name": "x", "format": "base64", "data": base64.b64encode(raw.encode()).decode()}]})
    assert json.loads(tab)["schema"] == "ref-table-v1" and json.loads(tab)["pages"] == 2
    man = {"schema": "site-manifest-v1", "commit": "c1", "excluded_prefixes": [], "files": [{"path": "img/logo.png", "bytes": 1, "sha256": "0" * 64}]}
    got = json.loads(k["oracle"].expected({"files": [{"name": "t", "format": "base64", "data": base64.b64encode(tab.encode()).decode()}, b64(man)]}))
    assert got["totals"] == {"refs": 5, "not_local": 1, "local_ok": 2, "out_of_scope": 0, "broken": 2}
    assert [(b["page"], b["reason"]) for b in got["broken"]] == [("docs/a.html", "escapes-root"), ("docs/a.html", "missing")]


def test_ref_check_oracle_hand_cases():
    _, m = mods("site.ref-check")
    man = {"schema": "site-manifest-v1", "commit": "c1", "excluded_prefixes": ["tv/"], "files": [{"path": p, "bytes": 1, "sha256": "0" * 64} for p in ("index.html", "docs/index.html", "img/a.png")]}
    row = lambda cls, tgt, raw="r", page="p.html", kind="href": {"class": cls, "kind": kind, "page": page, "raw": raw, "target": tgt}
    rows = [row("local", "img/a.png"), row("local", "docs/"), row("local", "docs"), row("local", "/"), row("local", "img/", "i"), row("local", "IMG/a.png", "c"),
            row("local", "tv/x.js"), row("local", "tv"), row("local", "tvx/a.js", "t"), row("escapes-root", None, "e"), row("external", None), row("local", "img/", "i"),
            row("local", "DOCS/", "d")]
    tab = {"schema": "ref-table-v1", "commit": "c1", "refs": rows}
    want = {"schema": "broken-refs-v1", "commit": "c1", "totals": {"refs": 13, "not_local": 1, "local_ok": 4, "out_of_scope": 2, "broken": 6}, "broken": [
        {"kind": "href", "page": "p.html", "raw": "e", "reason": "escapes-root", "target": None}, {"kind": "href", "page": "p.html", "raw": "d", "reason": "case-mismatch", "target": "DOCS/"},
        {"kind": "href", "page": "p.html", "raw": "c", "reason": "case-mismatch", "target": "IMG/a.png"},
        {"kind": "href", "page": "p.html", "raw": "i", "reason": "missing", "target": "img/"}, {"kind": "href", "page": "p.html", "raw": "i", "reason": "missing", "target": "img/"},
        {"kind": "href", "page": "p.html", "raw": "t", "reason": "missing", "target": "tvx/a.js"}]}
    for env in ({"files": [b64(tab), b64(man)]}, {"files": [b64(man), b64(tab)]}):  # order and name decide nothing
        assert json.loads(m["oracle"].expected(env)) == want
    bad = [{"files": [b64(tab)]}, {"files": [b64(tab), b64(dict(man, commit="c2"))]}, {"files": [b64(man), b64(man)]},
           {"files": [b64(tab), b64(dict(man, files=man["files"] + man["files"][:1]))]}, {"files": [b64(dict(tab, refs=[row("local", None)])), b64(man)]},
           {"files": [b64(dict(tab, refs=[row("external", "x")])), b64(man)]}, {"files": [b64(tab), b64(dict(man, excluded_prefixes="tv/"))]}]
    assert [m["oracle"].expected(e) for e in bad] == ["ERROR"] * 7


def test_ref_check_root_without_index_and_exact_file_prefix():
    _, m = mods("site.ref-check")
    man = {"schema": "site-manifest-v1", "commit": "c", "excluded_prefixes": ["big/file.js"], "files": [{"path": "a/index.html", "bytes": 1, "sha256": "0"}]}
    rows = [{"class": "local", "kind": "src", "page": "p", "raw": r, "target": t} for r, t in (("/", "/"), ("a", "a"), ("a/", "a/"), ("big/file.js", "big/file.js"), ("big/file.json", "big/file.json"))]
    got = json.loads(m["oracle"].expected({"files": [b64({"schema": "ref-table-v1", "commit": "c", "refs": rows}), b64(man)]}))
    assert got["totals"] == {"refs": 5, "not_local": 0, "local_ok": 2, "out_of_scope": 2, "broken": 1} and got["broken"][0]["target"] == "/"  # plain string prefix: .json is covered too


def test_release_diff_oracle_hand_case():
    _, m = mods("site.release-diff")
    f = lambda p, b, h: {"path": p, "bytes": b, "sha256": h * 64}
    old = {"schema": "site-manifest-v1", "commit": "o", "committed_at": "2026-01-01T00:00:00Z", "files": [f("a.txt", 10, "1"), f("docs/x", 5, "2"), f("docs/y", 7, "3"), f("Z/q", 1, "4")]}
    new = {"schema": "site-manifest-v1", "commit": "n", "committed_at": "2026-02-01T00:00:00Z", "files": [f("a.txt", 10, "9"), f("docs/x", 5, "2"), f("docs/z", 3, "5"), f("z/q", 1, "6")]}
    sec = lambda s, a, r, mo, d: {"added": a, "bytes_delta": d, "modified": mo, "removed": r, "section": s}
    want = {"schema": "release-changes-v1", "older": {"commit": "o", "committed_at": "2026-01-01T00:00:00Z"}, "newer": {"commit": "n", "committed_at": "2026-02-01T00:00:00Z"},
            "added": ["docs/z", "z/q"], "removed": ["Z/q", "docs/y"], "modified": ["a.txt"], "unchanged": 1,
            "sections": [sec("(root)", 0, 0, 1, 0), sec("Z", 0, 1, 0, -1), sec("docs", 1, 1, 0, -4), sec("z", 1, 0, 0, 1)],
            "totals": {"added": 2, "bytes_delta": -4, "modified": 1, "removed": 2, "unchanged": 1}}
    for env in ({"files": [b64(new), b64(old)]}, {"files": [b64(old), b64(new)]}):  # the newer manifest may come first
        assert json.loads(m["oracle"].expected(env)) == want
    bad = [{"files": [b64(old)]}, {"files": [b64(old), b64(dict(new, committed_at=old["committed_at"]))]}, {"files": [b64(old), b64(dict(new, committed_at="2026-02-01"))]},
           {"files": [b64(old), b64(dict(new, files=new["files"] + new["files"][:1]))]}, {"files": [b64(old), b64(dict(new, schema="x"))]},
           {"files": [b64(old), b64(dict(new, files=[dict(f("q", 1, "1"), bytes=-1)]))]}]
    assert [m["oracle"].expected(e) for e in bad] == ["ERROR"] * 6


def test_release_diff_same_bytes_different_hash_is_modified_with_zero_delta():
    _, m = mods("site.release-diff")
    mk = lambda c, t, h: {"schema": "site-manifest-v1", "commit": c, "committed_at": t, "files": [{"path": "p", "bytes": 4, "sha256": h * 64}]}
    got = json.loads(m["oracle"].expected({"files": [b64(mk("a", "2026-01-01T00:00:00Z", "1")), b64(mk("b", "2026-01-02T00:00:00Z", "2"))]}))
    assert got["modified"] == ["p"] and got["totals"]["bytes_delta"] == 0 and got["sections"] == [{"added": 0, "bytes_delta": 0, "modified": 1, "removed": 0, "section": "(root)"}]
    empty = json.loads(m["oracle"].expected({"files": [b64(dict(mk("a", "2026-01-01T00:00:00Z", "1"), files=[])), b64(dict(mk("b", "2026-01-02T00:00:00Z", "1"), files=[]))]}))
    assert empty["sections"] == [] and empty["totals"] == {"added": 0, "bytes_delta": 0, "modified": 0, "removed": 0, "unchanged": 0}


# ---------------------------------------------------------------- export script
def test_export_script_is_deterministic_and_typed(tmp_path):
    snap = tmp_path / "snap"
    (snap / "docs").mkdir(parents=True)
    (snap / "index.html").write_text("<a href=\"docs/\"><img src=\"a.png\">", encoding="utf-8")
    (snap / "docs" / "index.html").write_text("<link href=\"../s.css\">", encoding="utf-8")
    (snap / "s.css").write_text("a{background:url(i.png)}", encoding="utf-8")
    (snap / "a.png").write_bytes(b"\x89PNG")
    (snap / "bad.html").write_bytes(b"\xff\xfe<a>")
    scope = tmp_path / "scope.json"
    scope.write_text(json.dumps({"commit": "abc1234", "excluded_top_level": ["tv"], "excluded_files_over_5MB": [{"path": "big/x.glb", "bytes": 9}]}))
    outs = []
    for n in (1, 2):
        out = tmp_path / f"o{n}"
        r = subprocess.run([sys.executable, str(ROOT / "scripts" / "export_site_inputs.py"), str(snap), str(scope), str(out), "--committed-at", "2026-11-25T13:42:32-08:00", "--derive"],
                           capture_output=True, text=True, timeout=120)
        assert r.returncode == 0, r.stderr
        outs.append({p.name: p.read_bytes() for p in out.iterdir()})
    assert outs[0] == outs[1] and sorted(outs[0]) == ["raw-reference-table-abc1234.json", "reference-table-abc1234.json", "site-manifest-abc1234.json", "site-pages-abc1234.json"]
    man = json.loads(outs[0]["site-manifest-abc1234.json"])
    pages = json.loads(outs[0]["site-pages-abc1234.json"])
    assert man["schema"] == "site-manifest-v1" and man["committed_at"] == "2026-11-25T21:42:32Z" and man["excluded_prefixes"] == ["big/x.glb", "tv/"]
    assert [f["path"] for f in man["files"]] == ["a.png", "bad.html", "docs/index.html", "index.html", "s.css"]
    assert man["files"][0] == {"path": "a.png", "bytes": 4, "sha256": hashlib.sha256(b"\x89PNG").hexdigest()}
    assert pages["schema"] == "site-pages-v1" and [p["path"] for p in pages["pages"]] == ["docs/index.html", "index.html", "s.css"] and pages["subset"]["undecodable"] == ["bad.html"]
    assert json.loads(outs[0]["reference-table-abc1234.json"])["refs"][0]["target"] == "s.css"
    assert not outs[0]["site-manifest-abc1234.json"].count(b"\r")
    _, m = mods("site.ref-extract")
    _, rs = mods("site.ref-resolve")
    f = lambda data: {"files": [{"name": "p.json", "format": "base64", "data": base64.b64encode(data).decode()}]}
    raw = m["oracle"].expected(f(outs[0]["site-pages-abc1234.json"]))
    assert raw == outs[0]["raw-reference-table-abc1234.json"].decode() and json.loads(raw)["schema"] == "raw-ref-table-v1"
    assert rs["oracle"].expected(f(raw.encode())) == outs[0]["reference-table-abc1234.json"].decode()


def test_export_script_drops_whole_sections_only_when_over_the_limit(tmp_path):
    spec = importlib.util.spec_from_file_location("export_site_inputs", ROOT / "scripts" / "export_site_inputs.py")
    ex = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ex)
    snap = tmp_path / "s"
    for sec, n in (("big", 400), ("small", 10)):
        (snap / sec).mkdir(parents=True)
        (snap / sec / "i.html").write_text("x" * n, encoding="utf-8")
    scope = tmp_path / "sc.json"
    scope.write_text(json.dumps({"commit": "c"}))
    ex.LIMIT = 300
    _, pages = ex.export(str(snap), str(scope))
    assert [p["path"] for p in pages["pages"]] == ["small/i.html"] and pages["subset"]["dropped_sections"] == ["big"]
    ex.LIMIT = 10**6
    assert len(ex.export(str(snap), str(scope))[1]["pages"]) == 2


# ---------------------------------------------------------------- type rows and goal mapping
LEARN = [("Scan the pages of this site for every raw reference.", "raw_reference_table", ["site_pages"]),
         ("Resolve these scanned page references into a reference table.", "reference_table", ["raw_reference_table"]),
         ("Check these references against the site manifest and list the broken links.", "broken_ref_report", ["reference_table", "site_manifest"]),
         ("Produce the release change report for these two site manifests.", "release_change_report", ["site_manifest", "site_manifest"])]
HELD = [("Check the references in these site pages against the site manifest and list the broken links.", "broken_ref_report", ["site_pages", "site_manifest"])]
FILES = {"site_pages": b'{"schema":"site-pages-v1","pages":[]}', "site_manifest": b'{"schema":"site-manifest-v1","files":[]}', "reference_table": b'{"schema":"ref-table-v1","refs":[]}',
         "raw_reference_table": b'{"schema":"raw-ref-table-v1","refs":[]}'}


@pytest.mark.parametrize("goal,deliverable,ins", LEARN + HELD)
def test_goal_sentences_map_to_exactly_one_new_deliverable_and_type_their_inputs(goal, deliverable, ins):
    c = G.make_contract(goal, [(f"in{i}.json", "file", FILES[t]) for i, t in enumerate(ins)])
    assert c.get("deliverable") == deliverable, c
    assert [i["type"] for i in c["inputs"]] == ins


def test_new_types_are_in_the_table_and_do_not_disturb_existing_mapping():
    T = G.types()
    assert {"raw_reference_table", "reference_table", "broken_ref_report", "release_change_report"} <= set(T["deliverables"])
    for t, tag in (("site_pages", "site-pages-v1"), ("site_manifest", "site-manifest-v1"), ("raw_reference_table", "raw-ref-table-v1"), ("reference_table", "ref-table-v1"), ("broken_ref_report", "broken-refs-v1"), ("release_change_report", "release-changes-v1")):
        assert T["types"][t]["schema_tag"] == tag
    existing = [("Convert this to canonical JSON", "canonical_rows"), ("Merge these into a summary", "group_summary"), ("Compare these two inventories and show what was added", "inventory_diff"),
                ("Merge intervals in this file", "merged_intervals"), ("Find the duplicate images", "image_match_manifest"), ("Write a property table for these pictures", "asset_property_table"),
                ("Write a reconciliation report: which of these pictures are copies, and how much space can I reclaim?", "reconciliation_report")]
    for goal, want in existing:
        assert G.make_contract(goal, [("a.csv", "file", b"id,group,bytes\na,g,1\n")]).get("deliverable") == want, goal
    for goal in ("do something nice", "merge and convert everything", "merge or added everything", "hello"):
        assert G.make_contract(goal, [("a.csv", "file", b"id,group,bytes\na,g,1\n")])["state"] == "NEEDS_CLARIFICATION"


def test_site_keywords_do_not_match_any_other_deliverables_sample_goals():
    T = G.types()
    for d in ("raw_reference_table", "reference_table", "broken_ref_report", "release_change_report"):
        pat = re.compile(T["types"][d]["keywords"])
        for goal, other, _ in LEARN + HELD:
            assert bool(pat.search(goal.lower())) == (other == d), (d, goal)
    assert not G.make_contract("Write a reconciliation report using these two files", [("a.csv", "file", b"id,group,bytes\na,g,1\n")]).get("state")
    for dd in T["deliverables"]:
        if dd not in ("raw_reference_table", "reference_table", "broken_ref_report", "release_change_report", "inventory_diff", "group_summary", "canonical_rows"):
            assert not re.search(T["types"][dd].get("keywords") or "(?!)", "check these references and list the broken links")
