"""T18 (selectable model backends) and T19 (spend gate on the proposer path). Stub endpoint only, except ONE opt-in live qwen smoke call
(HIVE_LIVE_MODEL=1; temporary approval written under tmp_path, never activating the owner's draft)."""
from __future__ import annotations

import copy
import hashlib
import json
import os
import shutil
import sys
import urllib.request
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import m2_stub_server as STUB  # noqa: E402
from hive import discovery as D, m2_model as M, m2_workflow as W  # noqa: E402

QWEN = "qwen/qwen3.8-27b"
GPT = "openai/gpt-oss-20b"
DRAFT = ROOT / "build" / "prototype" / "approvals" / "qwen3.8-27b.approval.DRAFT.json"
MSGS = [{"role": "system", "content": "s"}, {"role": "user", "content": "Target type: Source\nreply"}]


def stub(tmp_path, replies=None):
    srv, url = STUB.serve_thread({"R": replies or [["identity"]]}, log=str(tmp_path / "req.jsonl"))
    return srv, url


# ---------------------------------------------------------------- T18: selectable backends
def test_backend_list_default_and_pins():
    cfg = json.loads((ROOT / "configs" / "model_dispatch.json").read_text(encoding="utf-8"))
    assert M.list_backends() == [GPT, QWEN, "nvidia/nemotron-3.5-super-vl-120b-a12b", "moonshotai/kimi-k3.1-pro"] and cfg["backends"]["default"] == W.load_policy()["model"]["id"] == GPT
    p = W.load_policy()
    q = M.apply_backend(p, QWEN)
    m = q["model"]
    assert m["id"] == QWEN and m["endpoint"] == "http://127.0.0.1:1234/v1" and len(m["sha256"]) == 64 and m["bytes"] > 10**9 and m["file"].endswith(".gguf")
    assert q["approval_path"] == "build/prototype/approvals/qwen3.8-27b.approval.json" and not (ROOT / q["approval_path"]).exists()  # the owner activates it
    assert q["approval_caps"] == p["approval_caps"] and q["sampling"] == p["sampling"] and q["max_model_calls"] == p["max_model_calls"]  # same caps, nothing relaxed
    assert p["model"]["id"] == GPT and M.apply_backend(p) is p and M.apply_backend(p, GPT)["model"] == p["model"]  # caller's policy untouched; gpt-oss default
    assert M.apply_backend(p, GPT)["approval_path"] == p["approval_path"]


def test_unknown_incomplete_and_non_loopback_backends_are_refused():
    p = W.load_policy()
    with pytest.raises(M.Refused, match="not a qualified backend"):
        M.apply_backend(p, "some/other-model")
    base = {"backends": {"default": GPT, "list": [{"id": GPT}, {"id": "x/y", "endpoint": "http://127.0.0.1:1234/v1"}]}}
    with pytest.raises(M.Refused, match="missing pins"):
        M.apply_backend(p, "x/y", base)
    bad = {"backends": {"default": GPT, "list": [{"id": "x/y", "endpoint": "http://example.com/v1", "file": "f", "bytes": 1, "sha256": "a" * 64, "context": 1}]}}
    with pytest.raises(M.Invalidated, match="loopback"):
        M.apply_backend(p, "x/y", bad)
    with pytest.raises(M.Refused, match="not a qualified backend"):
        M.Model(Path("."), stub=True, endpoint="http://127.0.0.1:9/v1", backend="some/other-model")


def test_non_default_backend_is_refused_until_its_approval_is_activated(tmp_path):
    with pytest.raises(M.Refused, match="approval file missing"):
        M.Model(tmp_path / "o", backend=QWEN)  # non-stub: the backend's own approval file is required (draft is not active)


def test_draft_approval_is_well_formed_but_not_active():
    a = json.loads(DRAFT.read_text(encoding="utf-8"))
    q = M.apply_backend(D.pol(), QWEN)  # the discovery (c3-proposal) policy: its caps are what the approval must carry (N4)
    assert set(M.approval_problems(DRAFT, q)) == {"approval is a DRAFT", "status is not active", "status must be 'active'", "approval sha256 not bound in the backend config"}  # only the draft/activation gates refuse; every pin check passes (F3 L4)
    assert a["model_id"] == QWEN and a["model_file_sha256"] == q["model"]["sha256"] and a["caps"] == D.APPROVAL_CAPS
    assert M.approval_problems(DRAFT, W.load_policy())  # and it does not approve gpt-oss (model id / sha / endpoint differ)
    assert "DRAFT" in a["statement"] and a.get("status") == "DRAFT"


def test_weights_pin_is_per_backend(tmp_path):
    w = tmp_path / "w.gguf"
    w.write_bytes(b"weights")
    good = {"backends": {"default": GPT, "list": [{"id": "x/y", "endpoint": "http://127.0.0.1:1/v1", "file": str(w), "bytes": 7, "sha256": hashlib.sha256(b"weights").hexdigest(), "context": 4096}]}, "pricing": {}}
    m = M.Model(tmp_path / "o", stub=True, endpoint="http://127.0.0.1:1/v1", backend="x/y", dispatch_cfg=good, weights_path=w)
    assert m.check_weights("t") == hashlib.sha256(b"weights").hexdigest()
    w.write_bytes(b"tampered")
    with pytest.raises(M.Invalidated, match="weight sha mismatch"):
        m.check_weights("t2")


@pytest.mark.parametrize("backend", [None, GPT, QWEN])
def test_adapter_contract_through_stub(tmp_path, backend):
    srv, url = stub(tmp_path)
    m = M.Model(tmp_path / "o", stub=True, endpoint=url, backend=backend)
    want = backend or GPT
    r = m.call("propose", MSGS, 7)
    assert r["status"] == "ok" and M.parse_reply(r["content"]) == ["identity"] and r["usage"]["prompt_tokens"] > 0
    body = json.loads((tmp_path / "req.jsonl").read_text(encoding="utf-8").splitlines()[0])
    s = W.load_policy()["sampling"]
    assert body["model"] == want and body["seed"] == 7 and body["temperature"] == s["temperature"] and body["max_tokens"] == s["max_tokens"] and body["stream"] is False
    row = m.ledger()[0]
    assert row["model"] == want and row["status"] == "ok" and row["endpoint"] == url


def test_reply_with_wrong_model_id_is_invalidated(tmp_path, monkeypatch):
    srv, url = stub(tmp_path)
    m = M.Model(tmp_path / "o", stub=True, endpoint=url, backend=QWEN)
    real = urllib.request.urlopen

    class R:
        def __init__(self, r): self.r = r
        def __enter__(self): return self
        def __exit__(self, *a): return False
        def read(self): return self.r.read().replace(QWEN.encode(), b"other/model")
    monkeypatch.setattr(urllib.request, "urlopen", lambda req, timeout=None: R(real(req, timeout=timeout)))
    with pytest.raises(M.Invalidated, match="unexpected model id"):
        m.call("propose", MSGS, 1)


# ---------------------------------------------------------------- T19: spend gate before the request
PRICED = {GPT: {"fresh_input": 1000.0, "cached_read": 0.0, "cache_write": 0.0, "output": 1000.0}}  # USD per 1M tokens: deliberately dear


def test_priced_policy_refuses_over_budget_request_with_zero_requests_and_a_ledger_row(tmp_path):
    srv, url = stub(tmp_path)
    m = M.Model(tmp_path / "o", stub=True, endpoint=url, pricing=PRICED, budget_usd=0.001)
    with pytest.raises(M.BudgetRefused, match="budget refused"):
        m.call("propose", MSGS, 1)
    assert srv.counters["total"] == 0 and not (tmp_path / "req.jsonl").exists()  # refused before any HTTP request
    led = [json.loads(l) for l in (tmp_path / "o" / "usage-ledger.jsonl").read_text(encoding="utf-8").splitlines()]
    assert len(led) == 1 and led[0]["source"].startswith("refusal: budget refused") and led[0]["cost_usd"] == 0.0 and led[0]["model"] == GPT
    assert m.ledger()[0]["status"] == "budget_refused" and m.totals() == {"calls": 1, "tokens": 0}  # the model-call log records the refusal too


def test_reserve_then_reconcile_then_refuse_when_remaining_is_short(tmp_path):
    srv, url = stub(tmp_path)
    pol = W.load_policy()
    pol["sampling"]["max_tokens"] = 100
    m = M.Model(tmp_path / "o", stub=True, endpoint=url, pol=pol, pricing=PRICED, budget_usd=0.5)  # worst case ~ (len+256+100) tokens at $1/1k = about $0.5
    worst = (len(json.dumps(m.body(MSGS, 1), sort_keys=True, ensure_ascii=True).encode()) + 256 + 100) * 1000 / 1e6
    m.budget_usd = worst * 1.001
    r = m.call("propose", MSGS, 1)
    assert r["status"] == "ok" and srv.counters["total"] == 1
    led = [json.loads(l) for l in (tmp_path / "o" / "usage-ledger.jsonl").read_text(encoding="utf-8").splitlines()]
    kinds = [x.get("kind", "usage") for x in led]
    assert kinds == ["reservation", "usage"] and led[1]["reservation_id"] == led[0]["reservation_id"] and led[1]["measured"] is True
    assert led[1]["fresh_input_tokens"] == r["usage"]["prompt_tokens"] and led[1]["cost_usd"] < led[0]["cost_usd"]  # reconciled to actual, below the reserved worst case
    with pytest.raises(M.BudgetRefused):  # actual spend + a second worst case exceeds the remainder
        m.call("propose", MSGS, 2)
    assert srv.counters["total"] == 1  # the second request never left the process


def test_local_models_are_priced_zero_but_the_gate_still_runs(tmp_path):
    srv, url = stub(tmp_path)
    m = M.Model(tmp_path / "o", stub=True, endpoint=url, backend=QWEN, budget_usd=0.0)
    assert m.call("propose", MSGS, 1)["status"] == "ok"
    led = [json.loads(l) for l in (tmp_path / "o" / "usage-ledger.jsonl").read_text(encoding="utf-8").splitlines()]
    assert [x.get("kind", "usage") for x in led] == ["reservation", "usage"] and all(x["cost_usd"] == 0.0 for x in led) and led[0]["model"] == QWEN


def test_unpriced_model_outside_stub_fails_closed(tmp_path):
    srv, url = stub(tmp_path)
    m = M.Model(tmp_path / "o", stub=True, endpoint=url, pricing={})
    m.stub = False  # a real (non-loopback-stub) path with no price entry: billing data unavailable
    with pytest.raises(M.BudgetRefused, match="no price"):
        m.call("propose", MSGS, 1)
    assert srv.counters["total"] == 0


def test_unreadable_ledger_fails_closed(tmp_path):
    srv, url = stub(tmp_path)
    bad = tmp_path / "led.jsonl"
    bad.write_bytes(b'{"torn":')  # torn last line: never dispatch unaccounted
    m = M.Model(tmp_path / "o", stub=True, endpoint=url, ledger_path=bad, pricing=PRICED, budget_usd=100.0)
    with pytest.raises(M.BudgetRefused):
        m.call("propose", MSGS, 1)
    assert srv.counters["total"] == 0


def test_existing_call_cap_still_applies_first(tmp_path):
    srv, url = stub(tmp_path)
    pol = W.load_policy()
    pol["max_model_calls"] = 1
    m = M.Model(tmp_path / "o", stub=True, endpoint=url, pol=pol)
    m.call("propose", MSGS, 1)
    with pytest.raises(M.CapReached, match="model call cap"):
        m.call("propose", MSGS, 2)
    assert srv.counters["total"] == 1


# ---------------------------------------------------------------- one live smoke call to qwen (opt-in)
def _qwen_listed():
    try:
        with urllib.request.urlopen("http://127.0.0.1:1234/v1/models", timeout=5) as r:
            return QWEN in [d["id"] for d in json.loads(r.read())["data"]]
    except OSError:
        return False


@pytest.mark.skipif(os.environ.get("HIVE_LIVE_MODEL") != "1" or not _qwen_listed(), reason="opt-in: HIVE_LIVE_MODEL=1 and qwen listed by LM Studio (one real call)")
def test_live_qwen_smoke_through_the_adapter(tmp_path):
    """Through the REAL (non-stub) path: the backend's own pins, a temporary approval (the DRAFT's content copied under tmp_path, so the owner's
    DRAFT is never activated), the spend gate, identity check on the reply. One call, 48 tokens."""
    approval = tmp_path / "qwen.approval.json"
    shutil.copy(DRAFT, approval)
    pol = copy.deepcopy(W.load_policy())
    pol["sampling"]["max_tokens"] = 48
    pol["call_timeout_s"], pol["transport_retries"] = 900, 0  # a cold JIT load of a 27B model may take minutes
    m = M.Model(tmp_path / "o", backend=QWEN, pol=pol, approval_path=approval)
    assert m.pol["model"]["id"] == QWEN and m.endpoint == "http://127.0.0.1:1234/v1"
    r = m.call("smoke", [{"role": "user", "content": "Reply with the single word: ok"}], 2026119001)
    assert r["status"] == "ok" and r["usage"].get("total_tokens", 0) > 0
    assert m.ledger()[0]["response_model"] == QWEN and m.totals()["calls"] == 1
