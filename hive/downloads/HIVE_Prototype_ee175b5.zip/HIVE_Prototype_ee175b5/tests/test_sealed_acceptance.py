"""Sealed-final acceptance route: a campaign's frozen final goes through the STANDARD gates (fresh hidden set, baseline, dev, separate-process hidden gate); never a model call."""
import json
import sys
from pathlib import Path

import pytest

from hive import capability_registry as CR
from hive import discovery as D
from hive.operator_runtime import Refused, _sha
from hive.storage import Store

from test_capability_admission import auth  # noqa: F401
from test_discovery import CORRECT, env, fake_runs, submit  # noqa: F401

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
GOOD = CORRECT.removeprefix("```python\n").removesuffix("```")
BAD = "import json\ndef run(env):\n    return json.dumps({'v': 1})\n"
CAP = "inventory-diff"


@pytest.fixture(autouse=True)
def private(env, monkeypatch):
    monkeypatch.setattr(D, "PRIVATE", env[2])

    def never(*a, **k):
        raise AssertionError("a model was constructed or dispatched")
    monkeypatch.setattr(D.M, "Model", never)
    monkeypatch.setattr(D.MD, "plan", never)
    monkeypatch.setattr(D.MD, "record", never)


def campaign(env, tmp_path, body=GOOD, policy=D.SEALED, **over):
    """A finished-looking sealed campaign store (experiment record + body file + final receipt); nothing is run."""
    root = tmp_path / "camp"
    from hive import operator_runtime as O
    s = Store(root)
    O.import_bundle(s)
    s.close()
    gap = submit((root, env[1], env[2]))["gap_ref"]
    s = Store(root)
    try:
        rec = D.open_experiment(s, gap, policy=D.SEALED if policy else None, **({} if policy else {"private_dir": env[2], "seed": 7}))
    finally:
        s.close()
    h = _sha(body)
    D._write_lf(root / "discovery" / rec["exp_id"] / f"cand-{h}.py", body)
    r = {"schema": "hive-sealed-final-receipt-v1", "policy": D.SEALED, "capability": CAP, "state": "PUBLIC_CANDIDATE_FROZEN", "final_sha256": h, "exp_id": rec["exp_id"],
         "frozen_sha": rec["frozen_sha"], "body_path": f"discovery/{rec['exp_id']}/cand-{h}.py"}
    r.update(over)
    r["receipt_sha256"] = _sha(json.dumps(r, sort_keys=True, separators=(",", ":")))
    rp = root / "campaign" / CAP / "final-receipt.json"
    rp.parent.mkdir(parents=True)
    rp.write_text(json.dumps(r), encoding="utf-8")
    return root, rp, r


def opened(env, root, rp):
    s = Store(env[0])
    try:
        return D.open_sealed_acceptance(s, root, rp)
    finally:
        s.close()


def nothing_opened(env, calls):
    s = Store(env[0])
    try:
        assert D.experiments(s) == [] and calls == []
    finally:
        s.close()


def test_refused_before_any_run(env, fake_runs, tmp_path):
    root, rp, r = campaign(env, tmp_path)
    t = dict(r, final_dev_pass=1)  # tampered receipt: its sha no longer recomputes
    rp.write_text(json.dumps(t), encoding="utf-8")
    with pytest.raises(Refused, match="recompute"):
        opened(env, root, rp)
    rp.write_text(json.dumps(r), encoding="utf-8")
    body = root / r["body_path"]
    body.write_bytes(body.read_bytes() + b"\n# edited\n")  # wrong body sha
    with pytest.raises(Refused, match="final_sha256"):
        opened(env, root, rp)
    nothing_opened(env, fake_runs)


def test_missing_or_unsealed_campaign_experiment_refused(env, fake_runs, tmp_path):
    root, rp, _ = campaign(env, tmp_path, exp_id="d-" + "0" * 20, body_path="discovery/x/y.py")
    with pytest.raises(Refused, match="unreadable"):
        opened(env, root, rp)
    root, rp, r = campaign(env, tmp_path / "b")  # sealed experiment, then a receipt that names it with another frozen_sha
    t = dict(r, frozen_sha="1" * 64)
    t["receipt_sha256"] = _sha(json.dumps({k: v for k, v in t.items() if k != "receipt_sha256"}, sort_keys=True, separators=(",", ":")))
    rp.write_text(json.dumps(t), encoding="utf-8")
    with pytest.raises(Refused, match="frozen_sha"):
        opened(env, root, rp)
    root, rp, _ = campaign(env, tmp_path / "c", policy=None)  # a STANDARD (non-sealed) campaign experiment is not a sealed final
    with pytest.raises(Refused, match="not sealed-policy"):
        opened(env, root, rp)
    nothing_opened(env, fake_runs)


def test_accepted_runs_standard_gates_and_admits_as_learned(env, fake_runs, auth, tmp_path):
    import hive_admission as H
    root, rp, r = campaign(env, tmp_path)
    before = (root / "hive.sqlite3").read_bytes()
    rec = opened(env, root, rp)
    fz = rec["frozen"]
    assert "eval_policy" not in fz and fz["budget"]["calls"] == 0 and fz["acceptance"]["set_sha256"]  # standard path: a fresh hidden set exists
    assert fz["sealed_final"]["receipt_sha256"] == r["receipt_sha256"] and fz["proposer"]["model"] == fz["sealed_final"]["proposer_model"]
    d = D.run_experiment(env[0], rec["exp_id"])
    assert d["state"] == "CANDIDATE_PASSED" and d["ledger"]["calls"] == 0 and d["ledger"]["proposals"] == 0 and d["calls"] == []
    out = H.admit(env[0], rec["exp_id"], auth)
    assert out["route"] == "learned" and out["version"] == 1
    s = Store(env[0])
    try:
        st = CR.resolve_discovered(s, CAP)["statement"]
        assert st.get("route") is None and st["sealed_final"] == fz["sealed_final"] and st["lineage"]["proposer_model"] == fz["sealed_final"]["proposer_model"]
        assert D.discoveries(s)[-1]["route"] == "learned"
    finally:
        s.close()
    assert (root / "hive.sqlite3").read_bytes() == before and not list(root.glob("hive.sqlite3-*"))  # the campaign store is never modified


def test_body_failing_fresh_hidden_gate_not_admitted(env, fake_runs, auth, tmp_path):
    import hive_admission as H
    root, rp, _ = campaign(env, tmp_path, body=BAD)
    rec = opened(env, root, rp)
    assert D.run_experiment(env[0], rec["exp_id"])["state"] == "NO_QUALIFYING_CANDIDATE"
    with pytest.raises(Refused):
        H.admit(env[0], rec["exp_id"], auth)
    s = Store(env[0])
    try:
        assert [e["type"] for e in CR.history(s, CAP)] == ["rejected"]
    finally:
        s.close()
