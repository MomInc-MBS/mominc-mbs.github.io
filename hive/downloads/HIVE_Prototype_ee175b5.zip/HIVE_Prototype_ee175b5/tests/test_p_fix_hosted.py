"""REVIEW_P4 F1-F6 regressions for the hosted NIM backend (each fails on 97503b1). Loopback stubs only; the host allowlist is patched only here, inside the tests."""
from __future__ import annotations

import http.client
import json
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import m2_stub_server as STUB  # noqa: E402
from test_discovery import WRONGS, env, fake_runs, opened  # noqa: E402,F401
from test_p_hosted_backend import DRAFT, Hosted, KEY, MSGS, NIM, ROOT, _manifest, active, cfg_for, init_ledger, live_model, patched  # noqa: E402,F401
from hive import acquire as A, discovery as D, m2_model as M  # noqa: E402
from hive.storage import Store  # noqa: E402
from hive.usage_ledger import HostedLedger, UsageLedger, UsageRecord  # noqa: E402


class Raw:
    """One-shot loopback server: POST answers (code, body); body may be bytes or f(authorization) -> bytes."""

    def __init__(self, code, body, trickle=0.0):
        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass

            def do_POST(self):
                self.rfile.read(int(self.headers.get("Content-Length") or 0))
                b = body(self.headers.get("Authorization") or "") if callable(body) else body
                self.send_response(code); self.send_header("Content-Length", str(len(b))); self.end_headers()
                try:
                    if trickle:
                        for i in range(0, len(b), 4):
                            self.wfile.write(b[i:i + 4]); self.wfile.flush(); time.sleep(trickle)
                    else:
                        self.wfile.write(b)
                except OSError: pass
        self.srv = HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.url = f"http://127.0.0.1:{self.srv.server_port}/v1"


def _worst(m):
    price, mt = m.pricing[NIM], m.pol["sampling"]["max_tokens"]
    raw = json.dumps(m.body(MSGS, 1), sort_keys=True, ensure_ascii=True).encode()
    return ((len(raw) + 256) * price["fresh_input"] + mt * price["output"]) / 1e6


def _rows(p): return [json.loads(x) for x in Path(p).read_text(encoding="utf-8").splitlines() if x.strip()]


def _forge(env, exp, **fz):
    s = Store(env[0]); key = D.KEY + exp["exp_id"]; rec = s.get(key)
    for k, v in fz.items():
        tgt = rec["frozen"]
        *path, last = k.split("__")
        for q in path: tgt = tgt[q]
        tgt[last] = v
    s.set(key, rec); s.close()


def _stub(tmp_path):
    srv = STUB.make_server({"R": WRONGS}, 0, str(tmp_path / "req.jsonl"), model_id=NIM)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{srv.server_port}/v1"


# ---------------------------------------------------------------- F1: the spend ledger
def _two_calls_then_budget_stop(tmp_path):
    srv = Hosted("no_usage")  # every call is charged its worst case
    led = tmp_path / "ledger.jsonl"
    m = live_model(tmp_path, srv, ledger_path=led, budget_usd=None)
    m.budget_usd = _worst(m) * 1.5
    assert m.call("propose", MSGS, 1)["status"] == "ok"
    with pytest.raises(M.BudgetRefused):
        m.call("propose", MSGS, 2)
    return srv, m, led


@pytest.mark.parametrize("how", ["emptied", "deleted", "truncated_to_genesis", "tail_cut", "torn", "negative_line", "edited_line", "head_deleted"])
def test_f1_a_tampered_hosted_ledger_fails_closed(tmp_path, patched, how):
    srv, m, led = _two_calls_then_budget_stop(tmp_path)
    n = len(srv.posts())
    raw = led.read_bytes(); lines = raw.splitlines(keepends=True)
    if how == "emptied": led.write_bytes(b"")
    elif how == "deleted": led.unlink()
    elif how == "truncated_to_genesis": led.write_bytes(lines[0])
    elif how == "tail_cut": led.write_bytes(b"".join(lines[:-1]))
    elif how == "torn": led.write_bytes(raw + b'{"cost_usd": 1')
    elif how == "negative_line":
        forged = {"run_id": "x", "task_id": "x", "model": NIM, "fresh_input_tokens": 0, "cached_read_tokens": 0, "cache_write_tokens": 0, "output_tokens": 0,
                  "wall_seconds": 0, "measured": True, "source": "endpoint_usage", "cost_usd": -1000.0, "prev_sha256": "", "seq": 99}
        led.write_bytes(raw + (json.dumps(forged) + "\n").encode())
    elif how == "edited_line": led.write_bytes(raw.replace(b'"genesis"', b'"genesiz"', 1))
    elif how == "head_deleted": led.with_name(led.name + ".head").unlink()
    with pytest.raises(M.BudgetRefused):
        m.call("propose", MSGS, 3)
    assert len(srv.posts()) == n  # zero further requests


def test_f1_hosted_ledger_must_be_initialised_first(tmp_path, patched):
    srv = Hosted()
    p = tmp_path / "never-initialised.jsonl"
    ap, sha = active(tmp_path, srv.url)
    m = M.Model(tmp_path / "o", backend=NIM, pol=D.pol(), dispatch_cfg=cfg_for(srv.url, sha), approval_path=ap, budget_usd=5.0, ledger_path=p)
    with pytest.raises(M.BudgetRefused, match="missing or empty"):
        m.call("propose", MSGS, 1)
    assert not srv.posts()
    init_ledger(p)
    with pytest.raises(ValueError):  # an existing ledger is never re-initialised
        HostedLedger(p, {}).init()


@pytest.mark.parametrize("mt", [-10_000_000, 0, 1.5, True, "4096", 10 ** 9])
def test_f1_bad_max_tokens_is_refused_before_any_request(tmp_path, patched, mt):
    srv = Hosted("no_usage")
    led = tmp_path / "ledger.jsonl"
    m = live_model(tmp_path, srv, ledger_path=led)
    m.pol["sampling"]["max_tokens"] = mt
    with pytest.raises(M.BudgetRefused):
        m.call("propose", MSGS, 1)
    assert not srv.posts() and all(r.get("cost_usd", 0) >= 0 for r in _rows(led))


def test_f1_forged_negative_max_tokens_in_a_record_never_reaches_the_ledger(env, fake_runs, tmp_path):
    c = cfg_for("https://integrate.api.nvidia.com/v1", measured=True)
    exp = opened(env, proposer_model=NIM)
    _forge(env, exp, budget__max_tokens_per_call=-10_000_000)
    srv, url = _stub(tmp_path)
    D.run_experiment(env[0], exp["exp_id"], stub_endpoint=url, private_dir=env[2], requested_model=NIM, dispatch_cfg=c)
    assert srv.counters["total"] == 0
    led = env[0] / "discovery" / exp["exp_id"] / "model" / "usage-ledger.jsonl"
    assert all(r.get("cost_usd", 0) >= 0 for r in _rows(led)) if led.exists() else True


def test_f1_ledger_arithmetic_refuses_negative_and_non_integer_counts():
    price = {"fresh_input": 1.0, "cached_read": 1.0, "cache_write": 1.0, "output": 1.0}
    L = UsageLedger(Path("unused.jsonl"), {"m": price})
    for bad in (-1, 1.5, True, "3"):
        with pytest.raises(ValueError):
            L.cost_usd(UsageRecord("r", None, "t", "m", 0, 0, 0, bad, 0.0, False, "x"))
    for bad in (-1.0, float("nan"), float("inf"), "1"):
        with pytest.raises(ValueError):
            L.reserve("r", "t", "m", bad)
    with pytest.raises(ValueError):
        UsageLedger(Path("unused.jsonl"), {"m": dict(price, fresh_input=-4.0)}).cost_usd(UsageRecord("r", None, "t", "m", 1, 0, 0, 1, 0.0, False, "x"))


def test_f1_ledger_location_comes_from_configs_and_is_outside_the_store(tmp_path, patched):
    cfg = json.loads((ROOT / "configs" / "model_dispatch.json").read_text(encoding="utf-8"))
    home = Path(os.path.expanduser("~")).resolve()
    assert (ROOT / os.path.expandvars(os.path.expanduser(cfg["budget"]["ledger"]))).resolve() == home / ".hive-spend" / "hosted-ledger.jsonl"
    srv = Hosted()
    ap, sha = active(tmp_path, srv.url)
    c = cfg_for(srv.url, sha)
    c["budget"]["ledger"] = str(tmp_path / "cfg-ledger.jsonl")
    m = M.Model(tmp_path / "o", backend=NIM, pol=D.pol(), dispatch_cfg=c, approval_path=ap)  # no ledger_path: the configs entry decides
    assert Path(m.ledger_path) == tmp_path / "cfg-ledger.jsonl"


def test_f1_stub_runs_keep_a_temp_ledger_not_the_project_one(tmp_path):
    srv, url = STUB.serve_thread(None)
    m = M.Model(tmp_path / "o", stub=True, endpoint=url, pol=M.apply_backend(D.pol(), NIM), budget_usd=5.0)
    assert Path(m.ledger_path) == tmp_path / "o" / "usage-ledger.jsonl"


def test_f1_init_script_imports_the_smoke_spend(tmp_path, monkeypatch):
    import init_hosted_ledger as IH
    cfgp = json.loads((ROOT / "configs" / "model_dispatch.json").read_text(encoding="utf-8"))
    target = tmp_path / "led.jsonl"
    real = json.loads

    def patched_loads(s, *a, **k):
        d = real(s, *a, **k)
        if isinstance(d, dict) and "budget" in d: d["budget"]["ledger"] = str(target)
        return d
    monkeypatch.setattr(IH.json, "loads", patched_loads)
    IH.main(["--import-receipt", str(ROOT / "build" / "prototype" / "approvals" / "nim-smoke-receipt.json")])
    L = HostedLedger(target, cfgp["pricing"]); L.check()
    assert round(L.totals()["usd_measured"], 6) == 0.004624
    row = _rows(target)[-1]
    assert row["source"] == "smoke_receipt_import" and row["model"] == NIM
    with pytest.raises(ValueError):
        IH.main([])


# ---------------------------------------------------------------- F2: the record cannot pick the backend or write the prompt
def test_f2_forged_record_cannot_route_an_operator_run_to_the_hosted_backend(env, fake_runs, tmp_path):
    c = cfg_for("https://integrate.api.nvidia.com/v1", measured=True)
    exp = opened(env)
    _forge(env, exp, proposer__model=NIM)
    srv, url = _stub(tmp_path)
    done = D.run_experiment(env[0], exp["exp_id"], stub_endpoint=url, private_dir=env[2], dispatch_cfg=c)  # no explicit request, as cli.py / console.py
    assert srv.counters["total"] == 0 and done["state"] == "INTERRUPTED" and "hosted" in done["reason"]


def test_f2_hosted_request_needs_a_frozen_hosted_backend(env, fake_runs, tmp_path):
    c = cfg_for("https://integrate.api.nvidia.com/v1", measured=True)
    exp = opened(env)  # honest gpt-oss record
    srv, url = _stub(tmp_path)
    done = D.run_experiment(env[0], exp["exp_id"], stub_endpoint=url, private_dir=env[2], requested_model=NIM, dispatch_cfg=c)
    assert srv.counters["total"] == 0 and done["state"] == "INTERRUPTED"
    assert exp["frozen"]["proposer"]["model"] == "openai/gpt-oss-20b"


def test_f2_frozen_backend_is_recorded_only_for_a_hosted_request(env, fake_runs):
    assert opened(env, proposer_model="qwen/qwen3.8-27b")["frozen"]["proposer"]["model"] == "openai/gpt-oss-20b"


def test_f2_prompt_text_comes_from_the_repo_spec_not_the_record(env, fake_runs, tmp_path):
    exp = opened(env)
    _forge(env, exp, behaviour_spec="ATTACKER-CHOSEN TEXT sent under the owner's key")
    srv, url = STUB.serve_thread({"R": WRONGS}, log=str(tmp_path / "req.jsonl"))
    D.run_experiment(env[0], exp["exp_id"], stub_endpoint=url, private_dir=env[2])
    bodies = [json.loads(x) for x in (tmp_path / "req.jsonl").read_text(encoding="utf-8").splitlines()]
    assert bodies and all("ATTACKER-CHOSEN" not in b["messages"][1]["content"] for b in bodies)


# ---------------------------------------------------------------- F3
def test_f3_key_fragment_at_the_error_body_cut_is_scrubbed(tmp_path, patched):
    srv = Raw(401, lambda auth: b"x" * 480 + auth.encode())  # the provider echoes the header near byte 500
    m = live_model(tmp_path, srv)
    assert m.call("propose", MSGS, 1)["status"] == "transport_failure"
    log = (tmp_path / "o" / "model_calls.jsonl").read_text(encoding="utf-8")
    assert KEY[:13] not in log


# ---------------------------------------------------------------- F4
def test_f4_draft_states_exactly_what_is_enforced():
    d = json.loads(DRAFT.read_text(encoding="utf-8"))
    assert "refuses prompts with real input data" not in d["context"] and "heuristic" in d["context"] and "512" in d["context"]


def test_f4_cli_input_file_reaches_the_probe_guard():
    src = (ROOT / "src" / "hive" / "cli.py").read_text(encoding="utf-8")
    assert "--input-file" in src and "private_blobs=" in src


# ---------------------------------------------------------------- F5
def test_f5_report_prices_a_hosted_run_instead_of_claiming_local_zero():
    disp = [{"called": True, "executed_model": NIM, "tokens_in": 1000, "tokens_out": 500}]
    out = A._cost([{"frozen": {"proposer": {"model": NIM}}, "dispatches": disp}])
    assert out["cost_usd"] == round((4.0 * 1000 + 20.0 * 500) / 1e6, 6) and "local" not in out["cost_note"] and out["model"] == NIM and out["cost_complete"] is True
    unk = A._cost([{"frozen": {"proposer": {"model": NIM}}, "dispatches": [{"called": True, "executed_model": NIM, "tokens_in": None, "tokens_out": None}]}])
    assert unk["cost_complete"] is False
    loc = A._cost([{"frozen": {"proposer": {"model": "openai/gpt-oss-20b"}}, "dispatches": [{"called": True, "executed_model": "openai/gpt-oss-20b"}]}])
    assert loc["cost_usd"] == 0.0 and "local" in loc["cost_note"]


# ---------------------------------------------------------------- F6
@pytest.mark.parametrize("usage", [[1], "x", 5])
def test_f6_usage_of_the_wrong_shape_is_charged_the_worst_case_not_an_exception(tmp_path, patched, usage):
    body = json.dumps({"model": NIM, "choices": [{"message": {"content": "x"}}], "usage": usage}).encode()
    led = tmp_path / "ledger.jsonl"
    m = live_model(tmp_path, Raw(200, body), ledger_path=led)
    assert m.call("propose", MSGS, 1)["status"] == "ok"
    assert [r.get("source") for r in _rows(led) if r.get("source")] == ["estimate"]


def test_f6_message_of_the_wrong_shape_is_a_clean_model_error(tmp_path, patched):
    body = json.dumps({"model": NIM, "choices": [{"message": ["not", "a", "dict"]}]}).encode()
    m = live_model(tmp_path, Raw(200, body))
    assert m.call("propose", MSGS, 1)["status"] == "transport_failure"


def test_f6_incomplete_read_is_a_clean_model_error(tmp_path, patched, monkeypatch):
    m = live_model(tmp_path, Hosted())

    def boom(self, req, timeout): raise http.client.IncompleteRead(b"par")
    monkeypatch.setattr(M.Model, "_fetch", boom)
    assert m.call("propose", MSGS, 1)["status"] == "transport_failure"


def test_f6_a_trickling_reply_hits_a_total_wall_time_limit(tmp_path, patched):
    body = json.dumps({"model": NIM, "choices": [{"message": {"content": "x" * 40}}], "usage": {"prompt_tokens": 1, "completion_tokens": 1}}).encode()
    m = live_model(tmp_path, Raw(200, body, trickle=0.2), timeout=1.0)  # ~30 chunks x 0.2 s: every socket read is fast, the total is not
    m.pol["transport_retries"] = 0
    t0 = time.time()
    assert m.call("propose", MSGS, 1)["status"] == "transport_failure"
    assert time.time() - t0 < 4
    assert "in total" in (tmp_path / "o" / "model_calls.jsonl").read_text(encoding="utf-8")


# ---------------------------------------------------------------- request timeout and cancellation: explicit status, charged the reservation, no retry, no other backend
def _ledger_rows(p): return [r for r in _rows(p) if r.get("kind") != "genesis"]


def test_request_timeout_is_an_explicit_status_charged_the_worst_case_and_not_retried(tmp_path, patched):
    led = tmp_path / "ledger.jsonl"
    slow = Raw(200, lambda auth: (time.sleep(1.5), b"{}")[1])
    m = live_model(tmp_path, slow, ledger_path=led, timeout=0.4)
    m.pol["transport_retries"] = 0
    assert m.call("propose", MSGS, 1)["status"] == "transport_failure"
    assert [r["status"] for r in m.ledger()] == ["timeout"]  # one attempt, its own status (not a generic transport_error)
    rows = _ledger_rows(led)
    assert [r.get("kind", "usage") for r in rows] == ["reservation", "usage"] and rows[1]["source"] == "estimate" and abs(rows[1]["cost_usd"] - _worst(m)) < 1e-12
    assert m.pol["model"]["id"] == NIM  # still the same backend: nothing else was tried


def test_cancel_mid_request_is_recorded_charged_the_worst_case_and_never_retried(tmp_path, patched, monkeypatch):
    srv = Hosted()
    led = tmp_path / "ledger.jsonl"
    m = live_model(tmp_path, srv, ledger_path=led)
    m.pol["transport_retries"] = 3  # even with retries allowed a cancel is final

    def interrupted(self, req, timeout): raise KeyboardInterrupt
    monkeypatch.setattr(M.Model, "_fetch", interrupted)
    with pytest.raises(KeyboardInterrupt):
        m.call("propose", MSGS, 1)
    assert [r["status"] for r in m.ledger()] == ["cancelled"] and srv.posts() == []
    rows = _ledger_rows(led)
    assert [r.get("kind", "usage") for r in rows] == ["reservation", "usage"] and rows[1]["source"] == "estimate" and abs(rows[1]["cost_usd"] - _worst(m)) < 1e-12
    assert HostedLedger(led, m.pricing).outstanding_reserved_usd() == 0  # the reservation was settled, not left dangling
