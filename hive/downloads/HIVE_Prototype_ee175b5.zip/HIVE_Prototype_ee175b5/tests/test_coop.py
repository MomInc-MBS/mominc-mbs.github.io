"""Cooperative round ("coop"): stub LLM only, faked containers (the test_discovery pattern). Off by default; on = 3 independent samples, one hidden gate."""
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))
from hive import capcontract as CC  # noqa: E402
from hive import coop as CP  # noqa: E402
from hive import discovery as D  # noqa: E402
from hive import m2_model as M  # noqa: E402
from hive.storage import Store  # noqa: E402
from test_discovery import CORRECT, WRONGS, env, fake_runs, get, opened, run, stub  # noqa: E402,F401

VARIANT = CORRECT.replace("```python\n", "```python\n# variant\n", 1)  # same behaviour, different sha
MARK = "DIFFMARK-7f3a"
# sha256 of the frozen protocol of opened(env) with coop=None, computed on the pre-change code. The hidden set hash varies per run (generator), so it is left out.
PINNED_FROZEN_SHA = "1ff95153a0ab3daf1dcc0ed2f187cca46b09acab4ccf3b2eb257046b210137b8"


def sha_of(reply):
    return D._sha(D.extract_code(reply))


@pytest.fixture
def diff(monkeypatch):
    """The c3 inventory generator has no case(name, rng, n): stand in with marked copies of two public dev envs (the real generator is covered by coop_pilot)."""
    envs = []

    def fake(gen_public, seed, k):
        dev = gen_public.cases()
        envs[:] = [dict(dev[i % len(dev)]["env"], marker=MARK) for i in range(3)]
        return list(envs)
    monkeypatch.setattr(CP, "diff_envs", fake)
    return envs


def requests(tmp_path):
    return [json.loads(x) for x in (tmp_path / "req.jsonl").read_text(encoding="utf-8").splitlines()]


def text_of(body):
    return "\n".join(m["content"] for m in body["messages"])


def hidden_spy(monkeypatch):
    seen = []
    real = D._evaluate
    monkeypatch.setattr(D, "_evaluate", lambda rec, outdir, body_path, label, *a, **k: (seen.append((label, Path(body_path).name)), real(rec, outdir, body_path, label, *a, **k))[1])
    return seen


# 1 ------------------------------------------------------------------------------------------------------------------ off by default
def _core(frozen):
    return {k: ({a: b for a, b in v.items() if a != "set_sha256"} if k == "acceptance" else v) for k, v in frozen.items() if k not in ("coop", "attempt")}


def test_off_by_default_is_byte_identical(env):
    exp = opened(env)
    assert "coop" not in exp["frozen"] and "seed_base" not in exp["frozen"]
    assert D._sha(D._json(dict(_core(exp["frozen"]), attempt=1))) == PINNED_FROZEN_SHA  # the frozen dict is exactly what the pre-coop code produced
    assert exp["exp_id"] == "d-" + exp["frozen_sha"][:20] and exp["frozen_sha"] == D._sha(D._json(exp["frozen"]))
    s = Store(env[0])
    s.set(D.KEY + exp["exp_id"], dict(exp, state="NO_QUALIFYING_CANDIDATE"))  # free the gap, then open the coop twin
    on = D.open_experiment(s, exp["gap_key"], private_dir=env[2], seed=7, coop="sample3")
    s.close()
    assert on["frozen"]["coop"] == {"recipe": "sample3", "branches": 3, "temperature": 0.7, "instructions": None, "select": "dev>agree>dev_ms>sha", "diff_seed": CP.DIFF_SEED, "diff_inputs": 8}
    assert on["exp_id"] != exp["exp_id"] and _core(on["frozen"]) == _core(exp["frozen"])  # only the coop key (and the attempt counter) differ
    assert D.proposer_seed({"attempt": 1}, 1) == 2026300001 and D.proposer_seed({"attempt": 1, "seed_base": 10000}, 1) == 2026310001  # a campaign repeat shifts every seed


# 2 ------------------------------------------------------------------------------------------------------------------ independence
def test_three_calls_and_no_branch_sees_another(env, fake_runs, tmp_path, diff):
    exp = opened(env, coop="diverse3")
    replies = [WRONGS[0], CORRECT, VARIANT]
    srv, url = stub(replies, tmp_path)
    done = run(env, exp, url)
    reqs = requests(tmp_path)
    assert srv.counters["total"] == 3 == done["ledger"]["calls"] and len(reqs) == 3
    codes = [D.extract_code(r) for r in replies]
    for q in reqs:
        t = text_of(q)
        assert not any(c in t or c.strip() in t for c in codes) and q["temperature"] == 0.7
    assert len({q["seed"] for q in reqs}) == 3  # distinct seeds
    base = [m["content"] for m in reqs[0]["messages"]][:2]
    assert all([m["content"] for m in q["messages"]][:2] == base for q in reqs)  # identical messages, built once
    assert [q["messages"][-1]["content"] for q in reqs] == CP.RECIPES["diverse3"] and all(len(q["messages"]) == 3 for q in reqs)
    assert [c["branch"] for c in done["calls"]] == [0, 1, 2] and all(c["recipe_id"] == "diverse3" and c["temperature"] == 0.7 for c in done["calls"])


def test_sample3_messages_identical_and_temperature_stays_local(env, fake_runs, tmp_path, diff):
    exp = opened(env, coop="sample3")
    srv, url = stub(WRONGS, tmp_path)
    run(env, exp, url)
    reqs = requests(tmp_path)
    assert len({json.dumps(q["messages"]) for q in reqs}) == 1 and {q["temperature"] for q in reqs} == {0.7}
    assert D.pol()["sampling"]["temperature"] == 0.2  # the per-call override never leaks into the shared policy


# 3 ------------------------------------------------------------------------------------------------------------------ hidden gate once
def test_hidden_gate_once_for_the_selected_only(env, fake_runs, tmp_path, diff, monkeypatch):
    spy = hidden_spy(monkeypatch)
    exp = opened(env, coop="sample3")
    srv, url = stub([CORRECT, VARIANT, WRONGS[0]], tmp_path)
    done = run(env, exp, url)
    cand = [x for x in spy if x[0] == "candidate"]
    assert done["state"] == "CANDIDATE_PASSED" and len(cand) == 1 and cand[0][1] == f"cand-{done['candidate_sha256']}.py"
    sel = [p for p in done["proposals"] if p["selected"]]
    assert len(sel) == 1 and sel[0]["sha256"] == done["candidate_sha256"] and done["coop"]["selected"] == sel[0]["sha256"]
    assert [p["acceptance"] is not None for p in done["proposals"]] == [p["selected"] for p in done["proposals"]]


def test_no_hidden_gate_when_nothing_is_dev_perfect(env, fake_runs, tmp_path, diff, monkeypatch):
    spy = hidden_spy(monkeypatch)
    exp = opened(env, coop="sample3")
    srv, url = stub(WRONGS, tmp_path)
    done = run(env, exp, url)
    assert done["state"] == "NO_QUALIFYING_CANDIDATE" and not [x for x in spy if x[0] == "candidate"]
    assert all(p["acceptance"] is None and p["failure_category"] == "dev_fail" for p in done["proposals"])
    assert done["coop"]["selected"] is not None and done["coop"]["diff_inputs_sha"] is None  # best dev partial is still picked for carry-best, never gated


# 4 ------------------------------------------------------------------------------------------------------------------ selection is pure
class NoHidden(dict):
    def __getitem__(self, k):
        assert k != "acceptance", "select must not read acceptance"
        return super().__getitem__(k)

    def get(self, k, d=None):
        assert k != "acceptance", "select must not read acceptance"
        return super().get(k, d)


def test_select_ignores_acceptance_and_prefers_dev_then_agreement():
    good_dev = NoHidden(sha="b", dev_pass=6, agreement=0, dev_ms=50.0, acceptance={"pass_count": 0})
    better_hidden = NoHidden(sha="a", dev_pass=5, agreement=9, dev_ms=1.0, acceptance={"pass_count": 24})
    assert CP.select([better_hidden, good_dev]) is good_dev
    agree_dev_fail = NoHidden(sha="c", dev_pass=3, agreement=99, dev_ms=1.0)
    assert CP.select([agree_dev_fail, good_dev]) is good_dev  # a dev-failing candidate with top agreement never beats a dev-perfect one
    x, y = dict(sha="x", dev_pass=6, agreement=2, dev_ms=9.0), dict(sha="y", dev_pass=6, agreement=3, dev_ms=99.0)
    assert CP.select([x, y]) is y  # agreement before speed
    z = dict(sha="z", dev_pass=6, agreement=3, dev_ms=10.0)
    assert CP.select([y, z]) is z and CP.select([dict(z, sha="zz"), z]) is z and CP.select([]) is None  # then dev_ms, then sha
    assert CP.select([dict(x, agreement="skipped-cap"), dict(y, agreement=None)])["sha"] == "x"  # a skipped agreement counts 0, falls to dev_ms


def test_agreement_counts_other_distinct_candidates_per_input():
    outs = {"a": ["1", "2", "3"], "b": ["1", "2", "9"], "c": ["1", "x", "9"], "d": None}
    assert CP.agreement(outs) == {"a": 3, "b": 4, "c": 3, "d": 0}


def test_diff_envs_use_public_generator_without_answers():
    from hive import capcontract as CC
    c = CC.get("site.ref-extract")
    gp = D._load("gen_public", c)
    envs = CP.diff_envs(gp, CP.DIFF_SEED, 8)
    assert len(envs) == 8 and all(set(e) == {"files"} for e in envs) and CP.digest(envs) == CP.digest(CP.diff_envs(gp, CP.DIFF_SEED, 8))
    assert CP.digest(envs) != CP.digest(CP.diff_envs(gp, CP.DIFF_SEED + 100, 8))
    dev_env = {json.dumps(k["env"], sort_keys=True) for k in gp.cases()}
    assert not dev_env & {json.dumps(e, sort_keys=True) for e in envs}  # fresh inputs, not the public dev cases


# 5 ------------------------------------------------------------------------------------------------------------------ duplicates
def test_duplicate_is_recorded_and_not_a_voter(env, fake_runs, tmp_path, diff):
    exp = opened(env, coop="sample3")
    srv, url = stub([CORRECT, CORRECT, VARIANT], tmp_path)
    done = run(env, exp, url)
    dup = done["calls"][1]
    assert dup["duplicate_of"] == sha_of(CORRECT) and dup["failure_category"] == "duplicate"
    assert done["ledger"]["calls"] == 3 and done["ledger"]["proposals"] == 2 and len(done["proposals"]) == 2  # no proposal charged for the duplicate
    assert [p["agreement"] for p in done["proposals"]] == [len(diff)] * 2  # each has ONE other voter (not two): the copy does not count
    assert done["coop"]["candidates"] == [sha_of(CORRECT), sha_of(VARIANT)] and done["coop"]["diff_inputs_sha"] == CP.digest(diff)


def test_agreement_skipped_when_container_allowance_cannot_cover_it(env, fake_runs, tmp_path, diff):
    exp = opened(env, coop="sample3", budget={"container_runs": 5})  # baseline 1 + 2 dev = 3; agreement (2) + hidden (1) would need 6
    srv, url = stub([CORRECT, VARIANT, WRONGS[0]], tmp_path)
    done = run(env, exp, url)
    perfect = [p for p in done["proposals"] if p["failure_category"] == "dev_pass"]
    assert [p["agreement"] for p in perfect] == ["skipped-cap"] * 2 and done["coop"]["diff_inputs_sha"] is None
    assert done["ledger"]["container_runs"] <= 5


# 6 ------------------------------------------------------------------------------------------------------------------ ledger
def test_each_call_is_gated_and_charged_before_dispatch(env, fake_runs, tmp_path, diff, monkeypatch):
    ev = []
    g, sp, call = D._gate, D._spend, M.Model.call
    monkeypatch.setattr(D, "_gate", lambda s, rec, clock, stop, **need: (ev.append(("gate", need.get("calls"))), g(s, rec, clock, stop, **need))[1])
    monkeypatch.setattr(D, "_spend", lambda s, rec, **kw: (ev.append(("spend", kw.get("calls"))), sp(s, rec, **kw))[1])
    monkeypatch.setattr(M.Model, "call", lambda self, *a, **k: (ev.append(("call", None)), call(self, *a, **k))[1])
    exp = opened(env, coop="sample3")
    srv, url = stub(WRONGS, tmp_path)
    run(env, exp, url)
    flat = [e for e in ev if e in (("gate", 1), ("spend", 1), ("call", None))]
    assert flat == [("gate", 1), ("spend", 1), ("call", None)] * 3


def test_calls_running_out_mid_round_ends_cleanly(env, fake_runs, tmp_path, diff):
    exp = opened(env, coop="sample3", budget={"calls": 2})
    srv, url = stub(WRONGS, tmp_path)
    done = run(env, exp, url)
    assert done["state"] == "BUDGET_EXHAUSTED" and done["reason"].startswith("calls exhausted") and srv.counters["total"] == 2 == done["ledger"]["calls"]
    assert len(done["proposals"]) == 2 and done["coop"]["candidates"] == [p["sha256"] for p in done["proposals"]]  # the records are kept and judged


def test_a_pass_before_the_cap_still_wins(env, fake_runs, tmp_path, diff):
    exp = opened(env, coop="sample3", budget={"calls": 2})
    srv, url = stub([CORRECT, WRONGS[0]], tmp_path)
    assert run(env, exp, url)["state"] == "CANDIDATE_PASSED"


# 7 ------------------------------------------------------------------------------------------------------------------ differential inputs stay private to the selector
def test_diff_inputs_never_reach_the_proposer(env, fake_runs, tmp_path, diff):
    exp = opened(env, coop="diverse3")
    srv, url = stub([CORRECT, VARIANT, WRONGS[0]], tmp_path)
    done = run(env, exp, url)
    assert done["coop"]["diff_inputs_sha"] == CP.digest(diff) and diff
    blob = "\n".join(text_of(q) for q in requests(tmp_path))
    assert MARK not in blob and CP.digest(diff) not in blob
    assert MARK not in json.dumps(done["proposals"]) and MARK not in done["feedback"]


# 5 ------------------------------------------------------------------------------------------------------------------ masking arms (C3)
def dumb_tag(words):  # stand-in tagger (HIVE never imports nltk): long words are "nouns"
    return ["NN" if len(w) > 4 else "DT" for w in words]


def spec_of(cap):
    return CC.text_ref(CC.get(cap)["proposer"]["behaviour_spec_ref"])


class NS:
    def __init__(self, **kw):
        self.__dict__.update(kw)


@pytest.fixture
def masks(tmp_path, monkeypatch):
    """A mask (dumb tagger) for the capability the test gap resolves to, in a temp mask dir."""
    cap = CC.default()["capability_id"]
    spec = spec_of(cap)
    d = tmp_path / "masks"
    d.mkdir()
    m = CP.build_mask(cap, spec, dumb_tag)
    (d / f"{cap}.json").write_bytes(CP.mask_bytes(m))
    monkeypatch.setattr(CP, "MASK_DIR", d)
    return NS(cap=cap, spec=spec, mask=m, path=d / f"{cap}.json")


def free(env, exp):
    s = Store(env[0])
    s.set(D.KEY + exp["exp_id"], dict(exp, state="NO_QUALIFYING_CANDIDATE"))
    s.close()


def user_of(q):
    return [m for m in q["messages"] if m["role"] == "user"][0]["content"]


def test_mask_recipes_frozen_and_unmasked_recipes_unchanged(env, masks):
    assert CP.frozen("sample3") == {"recipe": "sample3", "branches": 3, "temperature": 0.7, "instructions": None, "select": "dev>agree>dev_ms>sha", "diff_seed": CP.DIFF_SEED, "diff_inputs": 8}
    assert CP.frozen("diverse3")["instructions"] == CP.RECIPES["diverse3"] and "view" not in CP.frozen("diverse3")
    fz = opened(env, coop="maskpos3")["frozen"]["coop"]
    assert fz == dict(CP.frozen("sample3"), recipe="maskpos3", masks_sha256=CP.load_mask(masks.cap, masks.spec)[1], view="spec-mask") and fz["instructions"] is None


def test_maskpos3_requests(env, fake_runs, tmp_path, diff, masks):
    exp = opened(env, coop="maskpos3")
    base = D.prompt(exp, D._load("gen_public", D.contract_of(exp)).cases())  # exactly what sample3's every branch sends (built from the same record, before the run)
    srv, url = stub(WRONGS, tmp_path)
    done = run(env, exp, url)
    reqs = requests(tmp_path)
    assert len(reqs) == 3 and {r["temperature"] for r in reqs} == {0.7}
    assert reqs[0]["messages"] == base  # branch 0 is input-identical to sample3's branch 0
    u0 = user_of(reqs[0])
    assert u0.startswith(masks.spec)
    for q in reqs[1:]:
        u = user_of(q)
        assert "___" in u and masks.spec not in u and u.endswith(u0[len(masks.spec):])  # only the spec prefix differs, byte for byte
        assert [m for m in q["messages"] if m["role"] != "user"] == [m for m in reqs[0]["messages"] if m["role"] != "user"]
    assert user_of(reqs[1]) != user_of(reqs[2])
    rows = done["calls"]
    A, B = masks.mask["maskpos"]["1"], masks.mask["maskpos"]["2"]
    assert [r["view"] for r in rows] == ["intact", "maskpos-A", "maskpos-B"] and [r["masked_words"] for r in rows] == [0, len(A), len(B)]
    assert rows[0]["mask_rate"] == 0.0 and rows[1]["mask_rate"] == masks.mask["realized"]["maskpos-A"]["rate"]
    assert [p["view"] for p in done["proposals"]] == ["intact", "maskpos-A", "maskpos-B"]


def check_mask(spec, m):
    a, b, ra, rb = (set(m[k][i]) for k in ("maskpos", "maskrand") for i in "12")
    assert not a & b and a | b == set(m["eligible_nv"]) and not ra & rb
    assert (len(ra), len(rb)) == (len(a), len(b)) and (ra | rb) <= set(m["eligible_any"])
    assert not (a | b | ra | rb) & set(m["protected"])
    words = CP.split_words(spec)
    assert [w[:3] for w in m["words"]] == [list(w) for w in words]
    keep = [w for _, _, w in words if w.lower() in CP.STOP or any(ch.isdigit() for ch in w)]  # not/never/every/only/... and every digit-bearing token
    for recipe, key in (("maskpos3", "maskpos"), ("maskrand3", "maskrand")):
        for br in (1, 2):
            out = CP.render_spec(m, recipe, br, spec)
            ow = [w for _, _, w in CP.split_words(out)]
            assert ow.count("___") == len(m[key][str(br)]) and len(ow) == len(words)
            assert [w for w in ow if w.lower() in CP.STOP or any(ch.isdigit() for ch in w)] == keep
    return keep


def test_masks_disjoint_cover_and_protect(masks):
    assert check_mask(masks.spec, masks.mask)


@pytest.mark.parametrize("cap", ["site.ref-extract", "site.ref-resolve", "site.ref-check"])
def test_committed_masks_structure(cap):
    spec = spec_of(cap)
    m, sha = CP.load_mask(cap, spec)  # also proves spec_sha256 matches the live spec
    assert m["schema"] == "coop-mask-v1" and m["cap"] == cap and m["tagger"] == "nltk 3.9.1 averaged_perceptron_tagger_eng" and len(sha) == 64
    assert set(m) >= {"spec_sha256", "seed", "words", "protected", "eligible_nv", "eligible_any", "maskpos", "maskrand", "realized"} and len(m["eligible_nv"]) >= 10
    assert check_mask(spec, m)


def test_spec_sha_mismatch_refused_before_any_model_call(env, fake_runs, tmp_path, diff, masks):
    bad = dict(masks.mask, spec_sha256="0" * 64)
    masks.path.unlink()
    with pytest.raises(D.Refused, match="no mask file"):
        opened(env, coop="maskpos3")
    masks.path.write_bytes(CP.mask_bytes(bad))
    with pytest.raises(D.Refused, match="spec_sha256 mismatch"):
        opened(env, coop="maskpos3")
    masks.path.write_bytes(CP.mask_bytes(masks.mask))
    exp = opened(env, coop="maskrand3")
    masks.path.write_bytes(CP.mask_bytes(bad))  # the file changes after the freeze
    srv, url = stub(WRONGS, tmp_path)
    done = run(env, exp, url)
    assert srv.counters["total"] == 0 and done["ledger"]["calls"] == 0 and done["state"] == "INTERRUPTED" and "mask" in json.dumps(done)


def test_masking_refuses_when_spec_is_not_the_prefix(masks):
    with pytest.raises(ValueError, match="exact prefix"):
        CP.render_user(masks.mask, "maskpos3", 1, masks.spec, "Preamble\n" + masks.spec)


def test_maskrand3_rows_and_counts(env, fake_runs, tmp_path, diff, masks):
    exp = opened(env, coop="maskrand3")
    srv, url = stub(WRONGS, tmp_path)
    done = run(env, exp, url)
    reqs = requests(tmp_path)
    assert [r["view"] for r in done["calls"]] == ["intact", "maskrand-A", "maskrand-B"]
    assert [r["masked_words"] for r in done["calls"][1:]] == [len(masks.mask["maskpos"]["1"]), len(masks.mask["maskpos"]["2"])]
    assert "___" not in user_of(reqs[0]) and all("___" in user_of(q) for q in reqs[1:])


def test_mask_json_deterministic():
    spec = spec_of("site.ref-extract")
    assert CP.mask_bytes(CP.build_mask("site.ref-extract", spec, dumb_tag)) == CP.mask_bytes(CP.build_mask("site.ref-extract", spec, dumb_tag))


def test_mask_builder_with_nltk_is_deterministic_and_matches_committed():
    pytest.importorskip("nltk")
    sys.path.insert(0, str(ROOT / "scripts"))
    import coop_masks as CM
    tag, spec = CM.nltk_tagger(), spec_of("site.ref-extract")
    a, b = (CP.mask_bytes(CP.build_mask("site.ref-extract", spec, tag)) for _ in range(2))
    assert a == b == (CP.MASK_DIR / "site.ref-extract.json").read_bytes().replace(b"\r\n", b"\n")
