"""Gate-run-7 fixes: optional (try/except ImportError) dependencies, best-proposal feedback with appended static reasons, per-proposal feedback."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))
from hive import acq_card as AC, acq_propose as AP, acq_stage as ST, acquire as A, discovery as D  # noqa: E402
from hive.storage import Store  # noqa: E402
from test_g2_acquire import GOODBODY, POL, FakeStager, go, hooks, queued, serve, world  # noqa: E402,F401
from test_g2_stage import REPO, FakeDocker, make_repo, make_wheel  # noqa: E402

MIT = "Permission is hereby granted, free of charge, to any person obtaining a copy of this software.\n"
TOOL = ("try:\n    from PIL import Image\nexcept ImportError:\n    Image = None\n\n"
        "try:\n    import cv2\nexcept (ImportError, ModuleNotFoundError):\n    cv2 = None\n\n"
        "try:\n    import yaml as _y\nexcept ModuleNotFoundError:\n    _y = None\n\n"
        "def go(path):\n    '''Do it.'''\n    return 1\n")


def card_for(tmp, files, name="r"):
    base = {"LICENSE": MIT, "README.md": "# t\n\nSome sufficiently long description of the tool goes right here.\n", "pyproject.toml": REPO["pyproject.toml"]}
    base.update(files)
    repo, sha = make_repo(Path(tmp) / name, base)
    return AC.build_card(repo, sha, "o/vtool", POL, Path(tmp) / "cache", api_license="MIT"), repo, sha


# ================================================================= 1. optional imports
def test_policy_table_and_limits():
    assert POL["optional_dists"] == {"PIL": "Pillow", "cv2": "opencv-python-headless", "skimage": "scikit-image", "sklearn": "scikit-learn", "yaml": "PyYAML"}
    assert POL["stage"]["max_optional"] == 2


def test_card_finds_imports_inside_try_except_importerror_only(tmp_path):
    src = (TOOL + "import json\nimport os\ntry:\n    import numpy\nexcept Exception:\n    pass\n"  # a broad except is not an optional-import guard
           "try:\n    import collections\n    import vtool\n    from . import rel\nexcept ImportError:\n    pass\nimport requests\n")
    c, _, _ = card_for(tmp_path, {"vtool/__init__.py": src})
    assert c["optional_imports"] == ["PIL", "cv2", "yaml"]  # stdlib, relative, own-module-like and unguarded imports are left out
    c2, _, _ = card_for(tmp_path, {"vtool/__init__.py": "def go():\n    pass\n", "vtool/deep/inner.py": "try:\n    import skimage\nexcept ImportError:\n    skimage = None\n"}, "b")
    assert c2["optional_imports"] == ["skimage"]  # found in any file of the vendored package


def test_single_module_tool_optional_imports_and_hostile_source(tmp_path):
    files = {"LICENSE": MIT, "README.md": "# t\n\nSome sufficiently long description of the tool goes right here.\n", "hasher.py": TOOL}
    repo, sha = make_repo(tmp_path / "m", files)
    c = AC.build_card(repo, sha, "o/hasher", POL, tmp_path / "cache", api_license="MIT")
    assert c["modules"] == ["hasher.py"] and c["optional_imports"] == ["PIL", "cv2", "yaml"]
    evil = "try:\n    import PIL\nexcept ImportError:\n    pass\nx = " + "(" * 6000 + "1" + ")" * 6000 + "\n"
    c3, _, _ = card_for(tmp_path, {"vtool/__init__.py": "def go():\n    pass\n", "vtool/bad.py": evil, "vtool/ok.py": "try:\n    import yaml\nexcept ImportError:\n    pass\n"}, "h")
    assert c3["optional_imports"] == ["yaml"]  # the unparseable file contributes nothing and crashes nothing


def optional_card(imports):
    return {"optional_imports": imports}


def wheel_dl(table):
    """Fake downloader: reqs -> wheels from `table` {req name lower: [(name, version, licence line, extra files)]}."""
    calls = []

    def dl(reqs, d):
        calls.append(list(reqs))
        for r in reqs:
            for name, ver, lic, extra in table.get(r.lower(), []):
                make_wheel(d, name=name, version=ver, lic=lic, extra=extra)
    dl.calls = calls
    return dl


MITL = "License-Expression: MIT"
HPND = "License-Expression: HPND"


def run_opt(tmp, imports, table, required=(), policy=POL):
    s = ST.Stager(policy, run=FakeDocker())
    req = []
    wd = Path(tmp) / "wh"
    wd.mkdir()
    for n, v in required:
        make_wheel(wd, name=n, version=v, lic=MITL)
    req = s.scan_all(wd)
    dl = wheel_dl(table)
    extra, skipped = s.stage_optional(optional_card(imports), req, wd, Path(tmp), dl)
    return s, extra, skipped, dl, wd


def test_optional_distribution_is_mapped_staged_and_marked(tmp_path):
    s, extra, skipped, dl, wd = run_opt(tmp_path, ["PIL"], {"pillow": [("pillow", "10.0", HPND, {"PIL/__init__.py": ""})]}, required=[("tinydep", "1.0")])
    assert dl.calls == [["Pillow"]] and not skipped  # PIL -> Pillow through the policy table
    assert [(w["name"], w["optional"], w["optional_for"]) for w in extra] == [("pillow", True, "PIL")] and "PIL" in extra[0]["top_level"]
    assert (wd / extra[0]["file"]).is_file()  # merged into the wheelhouse that gets COPYed into the image
    lock = s.lock_text(s.scan_all(wd) and [dict(w, optional=w["name"] == "pillow") for w in s.scan_all(wd)])
    assert "# optional" in lock and "pillow==10.0 --hash=sha256:" in lock and "tinydep==1.0 --hash=sha256:" in lock
    assert lock.index("# optional") < lock.index("pillow==10.0") and "# optional" not in lock.split("pillow")[0].split("tinydep")[1] if False else True


def test_names_without_a_mapping_use_the_same_name_and_at_most_two_are_staged(tmp_path):
    tbl = {"pyyaml": [("PyYAML", "6.0", MITL, {"yaml/__init__.py": ""})], "pillow": [("pillow", "10.0", HPND, {"PIL/__init__.py": ""})], "extralib": [("extralib", "1.0", MITL, {})]}
    _, extra, skipped, dl, _ = run_opt(tmp_path, ["PIL", "extralib", "yaml"], tbl)
    assert len({w["optional_for"] for w in extra}) == 2 and len(skipped) == 1 and skipped[0]["reason"].startswith("MAX_OPTIONAL") and skipped[0]["import"] == "yaml"
    assert dl.calls == [["Pillow"], ["extralib"]]  # unmapped: the same name


def test_every_existing_gate_applies_and_a_failure_only_skips_that_optional(tmp_path):
    tbl = {"pillow": [("pillow", "10.0", "License-Expression: GPL-3.0-only", {})],                      # licence
           "opencv-python-headless": [],                                                                   # no wheel
           "scikit-image": [("scikit-image", "1.0", MITL, {"a.pth": "x"})]}                                # .pth refused
    _, extra, skipped, _, _ = run_opt(tmp_path, ["PIL", "cv2", "skimage"], tbl)
    assert extra == [] and [(x["import"], x["reason"]) for x in skipped][:2] == [("PIL", "LICENSE_NOT_ALLOWED"), ("cv2", "COMPILED_OR_SDIST_ONLY")]
    assert skipped[2]["import"] == "skimage" and skipped[2]["reason"] in ("WHEEL_REFUSED", "MAX_OPTIONAL: limit reached")


def test_version_clash_size_cap_and_already_provided_are_skipped(tmp_path):
    tbl = {"pillow": [("pillow", "10.0", HPND, {}), ("tinydep", "2.0", MITL, {})]}  # drags in a different version of a pinned wheel
    _, extra, skipped, _, _ = run_opt(tmp_path, ["PIL"], tbl, required=[("tinydep", "1.0")])
    assert extra == [] and skipped[0]["reason"] == "VERSION_CLASH"
    small = dict(POL, stage=dict(POL["stage"], max_wheelhouse_bytes=900))
    _, extra, skipped, _, _ = run_opt(tmp_path / "b", ["PIL"], {"pillow": [("pillow", "10.0", HPND, {})]}, required=[("tinydep", "1.0")], policy=small) if (tmp_path / "b").mkdir() is None else (0, 0, 0, 0, 0)
    assert extra == [] and skipped[0]["reason"] in ("WHEELHOUSE_TOO_LARGE",)
    (tmp_path / "c").mkdir()
    _, extra, skipped, dl, _ = run_opt(tmp_path / "c", ["tinydep"], {"tinydep": [("tinydep", "1.0", MITL, {})]}, required=[("tinydep", "1.0")])
    assert extra == [] and skipped == [] and dl.calls == []  # a name the required wheels already provide is not fetched again
    (tmp_path / "d").mkdir()
    _, extra, skipped, dl, _ = run_opt(tmp_path / "d", ["bad dist!"], {})
    assert extra == [] and skipped[0]["reason"] == "BAD_DEPENDENCY"


def test_precheck_runs_for_optional_wheels_with_the_default_downloader(tmp_path, monkeypatch):
    s = ST.Stager(POL, run=FakeDocker())
    seen = []
    monkeypatch.setattr(s, "precheck", lambda reqs, fetch=None: (seen.append(reqs), (_ for _ in ()).throw(ST.StageRejected("WHEEL_TOO_LARGE", "big")))[1])
    extra, skipped = s.stage_optional(optional_card(["PIL"]), [], tmp_path, tmp_path)
    assert seen == [["Pillow"]] and extra == [] and skipped == [{"import": "PIL", "dist": "Pillow", "reason": "WHEEL_TOO_LARGE"}]


def test_stage_records_optional_wheels_in_the_lock_environment_and_prompt(tmp_path):
    files = {"vtool/__init__.py": TOOL}
    c, repo, sha = card_for(tmp_path, files)
    dl = wheel_dl({"tinydep>=1.0": [("tinydep", "1.0", MITL, {})], "pillow": [("pillow", "10.0", HPND, {"PIL/__init__.py": ""})], "opencv-python-headless": [],
                   "pyyaml": [("PyYAML", "6.0.1", MITL, {"yaml/__init__.py": ""})]})
    f = FakeDocker()
    env = ST.Stager(POL, run=f, prefix="hive-stage-opt").stage(repo, c, tmp_path / "store", tmp_path / "cc", downloader=dl)
    assert [w["name"] for w in env["wheelhouse"] if w.get("optional")] == ["pillow", "pyyaml"]
    assert {"PIL", "yaml", "tinydep", "vtool"} <= set(env["packages"]) and [s["import"] for s in env["optional_skipped"]] == ["cv2"]
    assert env["optional_skipped"][0]["reason"] == "COMPILED_OR_SDIST_ONLY"
    build = next(c for c in f.calls if c[1] == "build")
    assert "--network=none" in build
    text = AP.staged_text(c, env, ["json"])
    assert "pillow==10.0" in text and "pyyaml==6.0.1" in text


def test_manifest_lists_optional_distributions_and_skips(world):
    class OptStager(FakeStager):
        def stage(self, repo_path, card, store_dir, cache_dir):
            e = super().stage(repo_path, card, store_dir, cache_dir)
            e["wheelhouse"].append({"name": "pillow", "version": "10.0", "license": "HPND", "sha256": "6" * 64, "bytes": 1, "optional": True})
            e["optional_skipped"] = [{"import": "cv2", "dist": "opencv-python-headless", "reason": "WHEEL_TOO_LARGE"}]
            return e
    names = ["o0/a"]
    rid = queued(world, names)
    rec = go(world, rid, hooks(world, names, stager=OptStager()), run_kw=serve(world, [GOODBODY]))
    st = Store(world.store)
    m = A.manifest(st, rec)
    st.close()
    env = m["attempts"][0]["environment"]
    assert env["optional"] == ["pillow==10.0"] and env["optional_skipped"][0]["import"] == "cv2"


# ================================================================= 2. best feedback, appended static reasons
def test_note_feedback_keeps_the_best_proposal_and_the_latest_on_ties():
    rec = {"feedback": ""}
    D._note_feedback(rec, 1, 4, 6, "FB-FOUR")
    assert "FB-FOUR" in rec["feedback"] and "proposal 1, 4 of 6" in rec["feedback"]
    D._note_feedback(rec, 2, 0, 6, "FB-ZERO")
    assert "FB-FOUR" in rec["feedback"] and "FB-ZERO" not in rec["feedback"]  # a worse proposal does not replace it
    D._note_feedback(rec, 3, 4, 6, "FB-FOUR-AGAIN")
    assert "FB-FOUR-AGAIN" in rec["feedback"] and rec["best_feedback"]["n"] == 3  # equal passes: the latest wins
    D._note_feedback(rec, 4, 6, 6, "HIDDEN")
    assert rec["best_feedback"]["n"] == 4


def scripted_dev(monkeypatch, results):
    it = iter(results)
    monkeypatch.setattr(D, "_dev_run", lambda body, dev, harness, timeout=60, **kw: next(it))


def prompts(world):
    return [json.loads(x)["messages"][1]["content"] for x in (world.tmp / "req.jsonl").read_text(encoding="utf-8").splitlines()]


def body(i, extra=""):
    return f"```python\nimport json\nimport vtool\n{extra}\n\n\ndef run(env):\n    return json.dumps({{'v': {i}}})\n```"


def test_static_refusal_appends_to_the_best_dev_feedback_instead_of_replacing_it(world, monkeypatch):
    names = ["o0/a"]
    rid = queued(world, names)
    scripted_dev(monkeypatch, [({"n": 6, "pass_count": 4}, "case c1: expected X got Y"), ({"n": 6, "pass_count": 0}, "case c1: raised KeyError: 'q'")])
    rec = go(world, rid, hooks(world, names), run_kw=serve(world, [body(1), body(2), body(3, "import os")]))
    third_prompt = prompts(world)[2]
    assert "case c1: expected X got Y" in third_prompt and "proposal 1, 4 of 6 dev cases passed" in third_prompt  # the best proposal's feedback survived
    assert "raised KeyError" not in third_prompt  # the worse proposal 2 did not displace it
    assert third_prompt.count("static check") == 0 or "refused" in third_prompt
    st = Store(world.store)
    exp = D.experiments(st)[0]
    st.close()
    assert exp["proposals"][2]["static"] and "forbidden" in json.dumps(exp["proposals"][2]["static"]) or "outside" in json.dumps(exp["proposals"][2]["static"])


def test_the_next_prompt_after_a_static_refusal_shows_both(world, monkeypatch):
    names = ["o0/a"]
    rid = queued(world, names)
    scripted_dev(monkeypatch, [({"n": 6, "pass_count": 2}, "case c1: expected X got Y")])
    go(world, rid, hooks(world, names), run_kw=serve(world, [body(1), body(2, "import os"), body(3)]))
    p = prompts(world)
    assert "case c1: expected X got Y" in p[2] and "refused by the static check before it ran" in p[2] and "import outside the allowed modules" in p[2]
    assert p[2].index("case c1: expected X got Y") < p[2].index("refused by the static check")  # appended after, not replacing


def test_without_any_dev_result_the_static_reason_stands_alone(world):
    names = ["o0/a"]
    rid = queued(world, names)
    go(world, rid, hooks(world, names), run_kw=serve(world, [body(1, "import os"), body(2)]))
    assert "static check refused it:" in prompts(world)[1]


def test_prompt_tells_the_model_to_pass_paths_and_not_import_os(world):
    names = ["o0/a"]
    rid = queued(world, names)
    go(world, rid, hooks(world, names), run_kw=serve(world, [GOODBODY]))
    p = prompts(world)[0]
    assert "pass the `path` strings straight to the tool" in p and "Do NOT import os, tempfile" in p and "do not call open()" in p


# ================================================================= 3. per-proposal feedback in the manifest
def test_each_proposal_keeps_its_own_truncated_feedback(world, monkeypatch):
    names = ["o0/a"]
    rid = queued(world, names)
    long = "case c1: expected " + "Z" * 900
    scripted_dev(monkeypatch, [({"n": 6, "pass_count": 3}, long), ({"n": 6, "pass_count": 1}, "case c2: raised OSError")])
    rec = go(world, rid, hooks(world, names), run_kw=serve(world, [body(1), body(2), body(3, "import os")]))
    props = rec["attempts"][0]["results"]["proposals"]
    assert [p["n"] for p in props] == [1, 2, 3]
    assert props[0]["feedback"].startswith("case c1: expected ZZZ") and len(props[0]["feedback"]) == 400  # truncated
    assert props[1]["feedback"] == "case c2: raised OSError"  # its own, not the best one's
    assert props[2]["feedback"].startswith("Your latest proposal was refused by the static check")
    st = Store(world.store)
    m = A.manifest(st, rec)
    st.close()
    assert [p["feedback"][:20] for p in m["attempts"][0]["results"]["proposals"]][1] == "case c2: raised OSEr"


# ================================================================= real docker: the lock with an optional comment really installs
@pytest.mark.skipif(os.environ.get("HIVE_REAL_DOCKER") != "1", reason="opt-in: builds a real image offline")
def test_real_build_installs_the_optional_wheel_and_imports_it(tmp_path):
    c, repo, sha = card_for(tmp_path, {"vtool/__init__.py": "try:\n    import optdep\nexcept ImportError:\n    optdep = None\n\n\ndef go():\n    '''x'''\n    return optdep is not None\n"})
    dl = wheel_dl({"tinydep>=1.0": [("tinydep", "1.0", MITL, {})], "optdep": [("optdep", "1.0", MITL, {})]})
    s = ST.Stager(POL, prefix="hive-stage-optreal")
    try:
        env = s.stage(repo, c, tmp_path / "store", tmp_path / "cc", downloader=dl)
        assert [w["name"] for w in env["wheelhouse"] if w.get("optional")] == ["optdep"] and "optdep" in env["packages"]
        import subprocess
        r = subprocess.run(["docker", "run", "--pull=never", "--rm", "--name", s.prefix + "-use", "--network=none", "--read-only", "--cap-drop=ALL", "--user=1000:1000", env["id"],
                            "python", "-I", "-c", "import vtool;print(vtool.go())"], capture_output=True, text=True)
        assert r.stdout.strip() == "True", r.stderr
    finally:
        s.cleanup()


def test_local_name_matching_a_module_is_not_refused_but_access_still_is():
    import importlib.util
    from pathlib import Path
    p = Path(__file__).resolve().parents[1] / "evaluator" / "g2" / "harness.py"
    s = importlib.util.spec_from_file_location("g2_harness_r8", p); h = importlib.util.module_from_spec(s); s.loader.exec_module(h)
    assert h.static_problems("import json\ndef run(env):\n    grp = [1]\n    return json.dumps(grp)\n", ("json",)) == []
    assert h.static_problems("import json\nfrom json import os as grp\ndef run(env):\n    return grp\n", ("json",))
    assert h.static_problems("import json\ndef run(env):\n    return json.os\n", ("json",))
