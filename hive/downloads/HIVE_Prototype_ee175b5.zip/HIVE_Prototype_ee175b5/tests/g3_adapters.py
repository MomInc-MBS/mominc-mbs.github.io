"""Hand-written stand-in adapters for the two G3 capabilities (test fixtures only: the repo ships NO adapter for them; a candidate comes from the model)."""

PROPS = '''import base64
import hashlib
import json


def run(env):
    rows = []
    for f in env["files"]:
        raw = base64.b64decode(f["data"])
        fmt = "png" if raw[:8] == b"\\x89PNG\\r\\n\\x1a\\n" else "jpeg" if raw[:3] == b"\\xff\\xd8\\xff" else "other"
        rows.append({"name": f["name"], "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "format": fmt})
    rows.sort(key=lambda r: r["name"])
    return json.dumps({"schema": "asset-properties-v1", "assets": rows}, sort_keys=True, separators=(",", ":"))
'''

RECON = '''import base64
import json


def run(env):
    docs = []
    for f in env["files"]:
        try:
            docs.append(json.loads(base64.b64decode(f["data"]).decode("utf-8")))
        except ValueError:
            docs.append(None)
    man = [d for d in docs if isinstance(d, dict) and d.get("schema") == "image-match-manifest-v1"]
    tab = [d for d in docs if isinstance(d, dict) and d.get("schema") == "asset-properties-v1"]
    if len(docs) != 2 or len(man) != 1 or len(tab) != 1:
        return "ERROR"
    try:
        size = {}
        for a in tab[0]["assets"]:
            if a["name"] in size:
                return "ERROR"
            size[a["name"]] = a["bytes"]
        groups, seen = [], []
        for g in man[0]["groups"]:
            if g["keeper"] not in g["members"]:
                return "ERROR"
            dups = sorted(m for m in g["members"] if m != g["keeper"])
            groups.append({"id": g["id"], "keeper": g["keeper"], "duplicates": dups, "reclaimable_bytes": sum(size[m] for m in dups)})
            seen += g["members"]
        seen += man[0]["singletons"]
    except (KeyError, TypeError):
        return "ERROR"
    if sorted(seen) != sorted(size):
        return "ERROR"
    groups.sort(key=lambda g: g["id"])
    totals = {"assets": len(size), "groups": len(groups), "duplicates": sum(len(g["duplicates"]) for g in groups),
              "reclaimable_bytes": sum(g["reclaimable_bytes"] for g in groups)}
    return json.dumps({"schema": "asset-reconcile-v1", "groups": groups, "totals": totals}, sort_keys=True, separators=(",", ":"))
'''
