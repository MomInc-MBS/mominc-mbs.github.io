"""Offline coop selector replay variants S0-S3: fixtures only (no containers, no network, no model)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from hive import coop as CP  # noqa: E402

N, INP = 3, "i" * 64


def cand(sha, dev_pass=6, dev_ms=100.0, agreement=None, **kw):
    return dict(sha=sha, static=False, dev_pass=dev_pass, dev_n=6, dev_ms=dev_ms, agreement=agreement, **kw)


def rcpt(sha, outs, expected=("x", "x", "x"), failure=None):
    raw = None if failure else {"out": list(outs), "err": [None if isinstance(o, str) else "E" for o in outs]}
    return CP.receipt(sha, INP, raw, list(expected), failure)


def sel(v, cands, rs=()):
    return CP.pool_select(v, cands, {r["cand"]: r for r in rs}, INP, N)


def test_s0_reproduces_recorded_selection_from_stored_dev_ms():
    cs = [cand("b", agreement=4, dev_ms=900.0), cand("a", agreement=4, dev_ms=874.0), cand("c", dev_pass=3, agreement=None)]
    r = sel("S0", cs)
    recorded = CP.select([{"sha": c["sha"], "dev_pass": c["dev_pass"], "agreement": c["agreement"], "dev_ms": c["dev_ms"]} for c in cs])
    assert r["selected"] == recorded["sha"] == "a" and r["key"] == CP.key(recorded) and r["voters"] == ["a", "b"]


def test_two_voter_equal_agreement_tie_needs_no_hidden_score():
    # the known loss shape: two dev-passing voters agree equally, dev_ms (not a label) picks; S1 with the same two voters keeps the tie
    cs = [cand("a", agreement=8, dev_ms=50.0), cand("b", agreement=8, dev_ms=60.0)]
    rs = [rcpt("a", ["x", "x", "x"]), rcpt("b", ["x", "y", "x"])]
    assert sel("S0", cs)["selected"] == "a" and sel("S1", cs, rs)["selected"] == "a"


def test_voter_poisoning():
    # 3rd voter fails dev: it votes in S1 but can never win while a dev-passing candidate exists
    cs = [cand("a", dev_ms=10.0), cand("b", dev_ms=20.0), cand("z", dev_pass=2, dev_ms=1.0)]
    rs = [rcpt("a", ["p", "p", "p"]), rcpt("b", ["q", "q", "q"]), rcpt("z", ["q", "q", "q"])]
    r = sel("S1", cs, rs)
    assert r["selected"] == "b" and "z" in r["voters"]  # z's vote lifts b (more voters, more agreement) but z cannot win
    assert r["selected"] != "z"
    # a verified construct-check failure cannot be outvoted by a wrong majority: b agrees with z but fails the public check
    exp = ["p", "p", "p"]
    assert sel("S3", cs, [rcpt("a", ["p"] * 3, exp), rcpt("b", ["q"] * 3, exp), rcpt("z", ["q"] * 3, exp)])["selected"] == "a"
    assert sel("S1", cs, rs)["selected"] == "b"


def test_duplicate_lineage_adds_no_votes():
    cs = [cand("a"), cand("b"), cand("a"), cand("d", duplicate_of="a")]
    rs = [rcpt("a", ["x"] * 3), rcpt("b", ["x"] * 3), rcpt("d", ["x"] * 3)]
    r = sel("S1", cs, rs)
    assert r["voters"] == ["a", "b"]  # one vote per distinct genuine body; a duplicate_of entry adds none
    assert CP.agreement_v1({"a": ["h"] * 3, "b": ["h"] * 3}) == {"a": 3, "b": 3}


def test_timeouts_and_errors_abstain_and_two_votes_keep_the_tie():
    cs = [cand("a", dev_ms=5.0), cand("b", dev_ms=9.0), cand("t", dev_ms=1.0)]
    rs = [rcpt("a", ["x", "x", "x"]), rcpt("b", ["x", "x", "x"]), rcpt("t", [], failure="timeout")]
    r = sel("S1", cs, rs)
    assert r["voters"] == ["a", "b"] and r["selected"] == "a"  # t casts no vote and earns none; the two survivors keep their tie, broken by dev_ms
    assert CP.agreement_v1({"a": ["h", None, "h"], "b": ["h", "h", None]}) == {"a": 1, "b": 1}  # abstentions give and receive nothing


def test_receipt_invalid_on_wrong_candidate_input_or_checker():
    good = rcpt("a", ["x"] * 3)
    assert CP.receipt_ok(good, "a", INP, N)
    assert not CP.receipt_ok(good, "b", INP, N)
    assert not CP.receipt_ok(good, "a", "j" * 64, N)
    assert not CP.receipt_ok(dict(good, checker="coop-construct-check-v0"), "a", INP, N)
    assert not CP.receipt_ok(rcpt("a", [], failure="timeout"), "a", INP, N)
    # a stale receipt is ignored: S2 falls back to neutral (no check penalty), so the decision is S0's
    cs = [cand("a", agreement=1, dev_ms=1.0), cand("b", agreement=1, dev_ms=2.0)]
    assert sel("S2", cs, [dict(rcpt("a", ["q"] * 3, ["x"] * 3), cand="zz")])["selected"] == "a"


def test_construct_check_outranks_agreement_but_not_dev():
    cs = [cand("a", agreement=9, dev_ms=1.0), cand("b", agreement=0, dev_ms=9.0), cand("c", dev_pass=2, agreement=None, dev_ms=0.5)]
    rs = [rcpt("a", ["bad"] * 3, ["x"] * 3), rcpt("b", ["x"] * 3, ["x"] * 3), rcpt("c", ["x"] * 3, ["x"] * 3)]
    assert sel("S0", cs)["selected"] == "a" and sel("S2", cs, rs)["selected"] == "b"
    assert sel("S2", cs, rs)["key"][:2] == [-6, -3]


def test_candidate_order_and_branch_labels_do_not_change_decisions():
    cs = [cand("a", agreement=2, branch=0), cand("b", agreement=2, branch=1, dev_ms=50.0), cand("c", agreement=1, branch=2)]
    rs = [rcpt("a", ["x"] * 3, ["x"] * 3), rcpt("b", ["x"] * 3, ["x"] * 3), rcpt("c", ["y"] * 3, ["x"] * 3)]
    for v in CP.VARIANTS:
        base = sel(v, cs, rs)
        assert sel(v, cs[::-1], rs[::-1]) == base
        assert sel(v, [dict(c, branch=2 - (c["branch"] or 0)) for c in cs], rs) == base
