"""F1: regression tests for REVIEW_P1 H1, H2, M1, M2, L1. Each one fails on a62f671 (the exploit works) and passes after the fix.
Docker-free; reuses the rig of test_p_planner."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_p_planner import rig, admit, contract_for, two, goal, plan_of, BODY, RANGES, GOAL, FIRST, SECOND  # noqa: E402,F401
from hive import cap_history as CH, capability_registry as CR, capcontract as CC, experiment_compare as EC, goal_runner as G  # noqa: E402
from hive.operator_runtime import Refused, _json, _sha  # noqa: E402
from hive.storage import Store  # noqa: E402

pytestmark = pytest.mark.skipif(not CR.keygen(), reason="ssh-keygen unavailable")
EVIL = b"attacker bytes\n"


def _admit_contract(store_root, key, cap, c, body):
    st = {"schema": CR.SCHEMA, "cap_id": cap, "version": 1, "contract": c, "contract_sha256": CC.sha(c), "impl_sha256": _sha(body), "body": body,
          "harness_sha256": CC.harness_sha(c), "pin": CC.pin(c), "evaluation": {"pass_count": 10, "n": 10}, "lineage": {}, "authority": {}, "admitted_at": "t"}
    s = Store(store_root)
    try:
        CR.append(s, cap, "admit", statement=st, statement_sha=_sha(CR.canon(st)), signature=CR.sign(CR.canon(st), key), exp_id="direct")
    finally:
        s.close()


def _planned(rig):
    root = rig.tmp / "in"
    root.mkdir(exist_ok=True)
    (root / "ranges.txt").write_bytes(RANGES[0][2])
    contract, _ = G.prepare(rig.store, root, GOAL, ["ranges.txt"], "merged_intervals")
    assert G.plan_only(rig.store, contract, ["ranges.txt"])["state"] == "PLANNED"
    return root, contract


def _stored(rig, edit):
    root, contract = _planned(rig)
    s = Store(rig.store)
    key = "operator/goal/" + contract["contract_id"]
    rec = s.get(key)
    edit(s, rec)
    s.set(key, rec)
    s.close()
    return G.run_plan(rig.store, contract["contract_id"], root)


def _escaped(rig, name):
    return (rig.tmp / "outside" / name).exists()


def _capuse(rig):
    s = Store(rig.store)
    try:
        k = s.db.execute("SELECT key FROM kv WHERE key LIKE 'operator/capuse/%'").fetchone()["key"]
        return k, s.get(k)
    finally:
        s.close()


# ------------------------------------------------------------------ H1
def test_h1_stored_report_name_cannot_escape(rig):
    admit(rig.store, rig.key, FIRST)
    r = _stored(rig, lambda s, rec: rec["plan"]["steps"][0].update(report_name="../../../../outside/admission_signers"))
    assert r["state"] == "VERIFIED" and not _escaped(rig, "admission_signers")
    assert r["plan"]["steps"][0].get("report_name", "report.json") == "report.json"


@pytest.mark.parametrize("val", ["../../../../outside/s1", "s1/../../x"])
def test_h1_stored_step_id_is_refused(rig, val):
    admit(rig.store, rig.key, FIRST)
    r = _stored(rig, lambda s, rec: rec["plan"]["steps"][0].update(step_id=val))
    assert r["state"] == "PLAN_INVALID" and not rig.calls and not _escaped(rig, "s1.csv")


def test_h1_stored_kind_allowance_and_ranking_are_rederived(rig):
    admit(rig.store, rig.key, FIRST)

    def edit(s, rec):
        rec["plan"]["steps"][0].update(kind="builtin_adapter", adapter="whatever", allowance={"container_runs": 99, "timeout_s": 10 ** 9},
                                       expected_output="x", ranking={"alternatives": [{"op": "../../x"}]})
    r = _stored(rig, edit)
    st = r["plan"]["steps"][0]
    assert r["state"] == "VERIFIED" and st["kind"] == "discovered" and "adapter" not in st and st["expected_output"] == "merged_intervals"
    assert st["allowance"]["container_runs"] == 1 and st["allowance"]["timeout_s"] < 10 ** 6 and "ranking" not in st


def test_h1_stored_contract_is_rechecked(rig):
    admit(rig.store, rig.key, FIRST)

    def edit(s, rec):
        c = dict(s.read_artifact(rec["contract_ref"]))
        c["budget"] = dict(c["budget"], max_steps=500)
        rec["contract_ref"] = s.put_artifact(c)  # same contract_id, different content
    with pytest.raises(Refused):
        _stored(rig, edit)


def test_h1_stored_malformed_step_is_refused_not_a_crash(rig):
    admit(rig.store, rig.key, FIRST)
    r = _stored(rig, lambda s, rec: rec["plan"]["steps"].__setitem__(0, {"step_id": "s1", "op": FIRST, "inputs": "input:0"}))
    assert r["state"] == "PLAN_INVALID"


# ------------------------------------------------------------------ H2
def _forge(rig, name, ref="evil.bin"):
    s = Store(rig.store)
    r = CR.resolve_discovered(s, FIRST)
    tid = "u-" + _sha(_json({"cap": r["statement_sha"], "pin": CC.pin(CC.normalize(r["statement"])), "inputs": [_sha(RANGES[0][2])]}))[:20]
    (rig.store / "evil.bin").write_bytes(EVIL)
    s.set("operator/capuse/" + tid, {"artifacts": [{"name": name, "ref": ref, "sha256": _sha(EVIL)}],
                                     "verification": {"verdict": "PASS"}, "statement_sha": r["statement_sha"], "at": "t"})
    s.close()


def test_h2_forged_saved_result_is_not_verified_and_cannot_escape(rig):
    admit(rig.store, rig.key, FIRST)
    _forge(rig, "../../../../outside/pwn.txt")
    out = goal(rig)
    assert not _escaped(rig, "pwn.txt")
    assert out["state"] == "VERIFIED" and rig.calls and out["usage"]["container_runs"] == 1  # re-executed, independently verified
    assert out["steps"][-1]["mode"] == "retained_capability_execution"
    assert (rig.store / out["deliverable"][0]["ref"]).read_bytes() != EVIL


def test_h2_forged_ref_outside_output_is_ignored(rig):
    admit(rig.store, rig.key, FIRST)
    an = CC.normalize(CR.resolve_discovered(Store(rig.store), FIRST)["statement"])["outputs"]["artifact_name"]
    _forge(rig, an, ref="../evil.bin")
    out = goal(rig)
    assert out["state"] == "VERIFIED" and out["steps"][-1]["mode"] == "retained_capability_execution" and rig.calls


def test_h2_forged_bytes_under_output_with_matching_hash_are_reexecuted(rig):
    admit(rig.store, rig.key, FIRST)
    assert goal(rig)["state"] == "VERIFIED"
    k, rec = _capuse(rig)
    for a in rec["artifacts"]:
        (rig.store / a["ref"]).write_bytes(EVIL)
        a["sha256"] = _sha(EVIL)
    s = Store(rig.store)
    s.set(k, rec)
    s.close()
    n = len(rig.calls)
    out = goal(rig)
    assert out["state"] == "VERIFIED" and len(rig.calls) == n + 1 and out["steps"][-1]["mode"] == "retained_capability_execution"
    assert (rig.store / out["deliverable"][0]["ref"]).read_bytes() != EVIL


def test_h2_real_replay_is_still_independently_checked(rig, monkeypatch):
    admit(rig.store, rig.key, FIRST)
    assert goal(rig)["state"] == "VERIFIED"
    n = len(rig.calls)
    seen = []
    real = CC.verify
    monkeypatch.setattr(CC, "verify", lambda *a, **k: seen.append(1) or real(*a, **k))
    out = goal(rig)
    assert out["state"] == "VERIFIED" and len(rig.calls) == n and out["usage"]["container_runs"] == 0 and seen
    assert out["steps"][-1]["mode"] == "saved_result_replay"


# ------------------------------------------------------------------ M1
def _other_interface(rig):
    other = "cap-other-interface"
    c = contract_for(other)
    c["outputs"]["type"] = "group_summary"
    _admit_contract(rig.store, rig.key, other, c, BODY)
    return other


def test_m1_stored_ranking_cannot_swap_in_other_interface(rig):
    admit(rig.store, rig.key, FIRST, BODY + "\n# BOOM\n")
    other = _other_interface(rig)

    def edit(s, rec):
        o = CR.resolve_discovered(s, other)
        rec["plan"]["steps"][0]["ranking"] = {"alternatives": [{"op": FIRST}, {"op": other, "version": o["version"], "statement_sha": o["statement_sha"]}]}
    r = _stored(rig, edit)
    assert r["state"] == "STEP_FAILED" and r["fallbacks"] == [] and all(x["op"] != other for x in r["steps"])


def test_m1_runtime_fallback_uses_only_same_interface_group(rig):
    two(rig, BODY + "\n# BOOM\n")
    _other_interface(rig)
    r = goal(rig)
    assert r["state"] == "VERIFIED" and r["steps"][-1]["op"] == SECOND and [f["to"] for f in r["fallbacks"]] == [SECOND]


# ------------------------------------------------------------------ M2
def test_m2_sandbox_integrity_failure_never_falls_back(rig, monkeypatch):
    from hive.adapters.isolation import SandboxUnavailable
    two(rig, BODY + "\n# SANDBOXFAIL\n")
    inner = EC.run_isolated

    def run(src, *a, **k):
        if "SANDBOXFAIL" in src:
            raise SandboxUnavailable("BLOCKED_SANDBOX: daemon or exact image ID could not be verified")
        return inner(src, *a, **k)
    monkeypatch.setattr(EC, "run_isolated", run)
    r = goal(rig)
    assert r["state"] == "STEP_FAILED" and r["fallbacks"] == [] and r["integrity_failure"]["op"] == FIRST and r["usage"]["container_runs"] == 1


def test_m2_unknown_exception_class_fails_closed(rig, monkeypatch):
    two(rig, BODY + "\n# ODD\n")
    inner = EC.run_isolated

    def run(src, *a, **k):
        if "ODD" in src:
            raise KeyError("unexpected")
        return inner(src, *a, **k)
    monkeypatch.setattr(EC, "run_isolated", run)
    r = goal(rig)
    assert r["state"] == "STEP_FAILED" and r["fallbacks"] == [] and "integrity_failure" in r


def test_m2_run_plan_tampered_primary_fails_closed(rig):
    two(rig)
    root, contract = _planned(rig)
    s = Store(rig.store)
    ev = CR.history(s, FIRST)[-1]
    s.close()
    f = Path(rig.store) / ev["statement_ref"]
    f.write_bytes(f.read_bytes() + b" ")
    r = G.run_plan(rig.store, contract["contract_id"], root)
    assert r["state"] == "PLAN_INVALID" and r["fallbacks"] == [] and r["integrity_failure"]["op"] == FIRST and not rig.calls


def test_m2_run_plan_deleted_chain_head_fails_closed(rig):
    two(rig)
    root, contract = _planned(rig)
    s = Store(rig.store)
    s.db.execute("DELETE FROM kv WHERE key LIKE ?", ("%" + FIRST + "%",))
    s.db.commit()
    s.close()
    r = G.run_plan(rig.store, contract["contract_id"], root)
    assert r["state"] == "PLAN_INVALID" and r["fallbacks"] == [] and not rig.calls


# ------------------------------------------------------------------ L1
def test_l1_malformed_history_rows_are_ignored(rig):
    two(rig)
    bad = [{"v": 1, "status": "OK", "ms": "slow"}, {"v": True, "status": "OK", "ms": 1}, {"v": 1, "status": "x", "ms": 1}, "junk", None, {"v": 1},
           {"v": 1, "status": "OK", "ms": -5, "model_calls": 0, "fail": "NONE"}]
    good = {"v": 1, "goal": "g-1", "status": "OK", "ms": 7, "model_calls": 0, "fail": "NONE", "at": "t"}
    s = Store(rig.store)
    s.set("operator/caphist/" + FIRST, bad + [good])
    s.set("operator/caphist/" + SECOND, "not a list")
    s.close()
    s = Store(rig.store)
    assert CH.rows(s, FIRST) == [good] and CH.stats(s, FIRST) == {"n": 1, "success_rate": 1.0, "median_ms": 7} and CH.stats(s, SECOND)["n"] == 0
    s.close()
    assert plan_of(rig)["steps"][0]["op"] == FIRST
