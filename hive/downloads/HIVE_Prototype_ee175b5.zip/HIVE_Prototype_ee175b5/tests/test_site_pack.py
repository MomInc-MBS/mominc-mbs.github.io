"""G1: raw site folder -> site_pages / site_manifest inside the goal (packing only), byte-identical to the evaluator-side exports. Fixture author: worker w2."""
from __future__ import annotations

import json
import os
from pathlib import Path

import pytest

from hive import capability_registry as CR
from hive import capcontract as CC
from hive import goal_runner as G
from hive import operator_runtime as O
from hive.storage import Store

MS = Path("D:/HIVE-operator-inputs/mom-site")
COMMITS = {"2633d9b": "2026-11-25T21:42:32Z", "0b3854a": "2026-11-26T07:25:30Z"}  # committed_at: git log of the site repo, as in PROTOTYPE_DOMAIN.md
GOAL = "Check the references in this site folder against its manifest and list the broken links."
EXTRACT, RESOLVE, CHECK = "site.ref-extract", "site.ref-resolve", "site.ref-check"


def scope_bytes(commit, committed_at=None):
    sc = json.loads((MS / f"{commit}.SCOPE.json").read_text(encoding="utf-8"))
    sc["schema"] = "site-scope-v1"
    if committed_at:
        sc["committed_at"] = committed_at
    return json.dumps(sc).encode()


@pytest.fixture
def store(tmp_path):
    s = Store(tmp_path / "s")
    O.import_bundle(s)
    yield s
    s.close()


@pytest.fixture
def held(monkeypatch):
    caps = {}

    def resolve(store, cid):
        st = {"schema": CC.V3, "cap_id": cid, "version": 1, "contract": caps[cid]}
        return {"cap_id": cid, "version": 1, "statement": st, "statement_sha": "sha-" + cid, "event_ref": "ev"}
    monkeypatch.setattr(CR, "cap_ids", lambda store: sorted(caps))
    monkeypatch.setattr(CR, "resolve_discovered", resolve)
    for i in (EXTRACT, RESOLVE, CHECK):
        caps[i] = CC.get(i)
    return caps


def tiny(tmp_path):
    d = tmp_path / "snap"
    (d / "a").mkdir(parents=True)
    (d / "index.html").write_text('<a href="a/x.html">x</a>', encoding="utf-8")
    (d / "a" / "x.html").write_text("x", encoding="utf-8")
    sc = json.dumps({"schema": "site-scope-v1", "commit": "t1", "excluded_top_level": [], "excluded_files_over_5MB": []}).encode()
    return d, sc


def test_planner_finds_the_full_chain_from_folder_and_scope(store, held, tmp_path):
    d, sc = tiny(tmp_path)
    c = G.make_contract(GOAL, [("snap", "folder", d), ("scope.json", "file", sc)])
    assert [i["type"] for i in c["inputs"]] == ["folder", "site_scope"]
    plan = G.plan_goal(store, c)
    ops = [s["op"] for s in plan["steps"]]
    assert sorted(ops[:2]) == ["site.pack-manifest", "site.pack-pages"] and ops[2:] == [EXTRACT, RESOLVE, CHECK] and plan["dag"] is True
    byop = {s["op"]: s for s in plan["steps"]}
    pages, man = byop["site.pack-pages"]["step_id"], byop["site.pack-manifest"]["step_id"]
    assert byop[EXTRACT]["inputs"] == ["step:" + pages] and sorted(byop[CHECK]["inputs"]) == sorted(["step:" + byop[RESOLVE]["step_id"], "step:" + man])
    assert G.validate_plan(store, c, plan) == []


def test_missing_committed_at_fails_closed_and_symlinks_are_not_followed(store, tmp_path):
    d, sc = tiny(tmp_path)
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "secret.html").write_text("s", encoding="utf-8")
    try:
        os.symlink(outside, d / "link", target_is_directory=True)
    except OSError:
        pass  # symlinks need privilege on Windows; the walk still checks realpath
    c = G.make_contract(GOAL, [("snap", "folder", d), ("scope.json", "file", sc)])
    inputs = [("snap", "folder", d), ("scope.json", "file", sc)]
    step = lambda out: {"step_id": "s1", "inputs": ["input:0", "input:1"], "expected_output": out}
    rec = {}
    assert G._step_site_pack(store.root, c, inputs, step("site_manifest"), rec) is None and "committed_at" in rec["reason"]
    name, data = G._step_site_pack(store.root, c, inputs, step("site_pages"), {})
    assert [p["path"] for p in json.loads(data)["pages"]] == ["a/x.html", "index.html"]
    (d / "extra.html").write_text("changed", encoding="utf-8")
    assert G._step_site_pack(store.root, c, inputs, step("site_pages"), rec := {}) is None and "changed" in rec["reason"]


@pytest.mark.skipif(not MS.exists(), reason="owner inputs not present")
@pytest.mark.parametrize("commit", COMMITS)
def test_in_goal_packing_is_byte_identical_to_the_evaluator_exports(store, held, monkeypatch, commit):
    inputs = [(commit, "folder", MS / commit), (commit + ".scope.json", "file", scope_bytes(commit, COMMITS[commit]))]
    c = G.make_contract(GOAL, inputs)
    seen = {}

    def fake(s, store_root, contract, step, files, sr, stop_path, left=None, rec=None, c0=None):  # the three learned steps are stubs; packing runs for real
        seen[step["op"]] = files
        sr.update(state=G.STEP_OK, verdict="PASS", artifacts=[{"name": "x"}])
        return step["step_id"] + ".json", b"{}"
    monkeypatch.setattr(G, "_discovered", fake)
    rec = G.run_goal(store.root, c, inputs)
    packed = {s["op"]: (store.root / s["artifacts"][0]["ref"]).read_bytes() for s in rec["steps"] if s["kind"] == "builtin_adapter"}
    ex = MS / "exports" / commit
    assert packed["site.pack-pages"] == (ex / f"site-pages-{commit}.json").read_bytes()
    assert packed["site.pack-manifest"] == (ex / f"site-manifest-{commit}.json").read_bytes()
    assert rec["state"] == "VERIFIED" and EXTRACT in seen and seen[EXTRACT][0][1] == packed["site.pack-pages"]
