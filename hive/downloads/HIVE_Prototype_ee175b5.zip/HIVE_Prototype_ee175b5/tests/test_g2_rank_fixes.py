"""Gate-run-6 fixes: licence-metadata skip before inspection, a stronger size penalty in the pre-inspection score, deterministic query suggestion."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))
from hive import acq_github as AG, acquire as A  # noqa: E402
from hive.storage import Store  # noqa: E402
from test_g2_acquire import GOODBODY, POL, go, hooks, items, queued, serve, world  # noqa: E402,F401
from test_g2_gate_fixes import TERMS, repo  # noqa: E402

LIC = POL["licenses"]


def names(ranked):
    return [r["full_name"] for r, _ in ranked]


# ================================================================= 1. licence metadata skip
def test_missing_or_unlisted_search_metadata_licences_are_skipped_before_inspection():
    hits = [repo("o/none", [("q", 0)], license_spdx=None), repo("o/gpl", [("q", 0)], license_spdx="GPL-3.0"), repo("o/unl", [("q", 0)], license_spdx="Unlicense"),
            repo("o/na", [("q", 0)], license_spdx="NOASSERTION"), repo("o/mit", [("q", 1)], license_spdx="MIT"), repo("o/apache", [("q", 2)], license_spdx="Apache-2.0"),
            repo("o/bsd", [("q", 3)], license_spdx="BSD-3-Clause")]
    ranked, skipped = AG.rank_hits(hits, TERMS, 51200, LIC)
    assert sorted(names(ranked)) == ["o/apache", "o/bsd", "o/mit"]
    assert {r["full_name"]: why for r, why, _ in skipped}.keys() == {"o/none", "o/gpl", "o/unl", "o/na"}
    assert all(why.startswith("SKIPPED_LICENSE_METADATA") for _, why, _ in skipped)
    assert "no licence" in dict((r["full_name"], why) for r, why, _ in skipped)["o/none"] and "GPL-3.0" in dict((r["full_name"], why) for r, why, _ in skipped)["o/gpl"]
    assert all(bd["license_spdx"] is None or isinstance(bd["license_spdx"], str) for _, _, bd in skipped)


def test_without_an_allowlist_nothing_is_skipped_for_licence():
    ranked, skipped = AG.rank_hits([repo("o/none", [("q", 0)], license_spdx=None)], TERMS, 51200)
    assert names(ranked) == ["o/none"] and not skipped


def test_search_metadata_normalises_noassertion_to_none(tmp_path):
    it = items("o/a")
    it[0]["license"] = {"spdx_id": "NOASSERTION"}
    gh = AG.GitHubSearch(tmp_path / "c", POL, lambda u, h: (200, {}, json.dumps({"items": it}).encode()))
    assert gh.search("q words")[0]["license_spdx"] is None


def test_skipped_licence_hits_never_use_an_inspection_and_the_small_mit_hit_is_reached(world):
    ns = [f"o{i}/lic{i}" for i in range(9)] + ["o9/small"]
    rid = queued(world, ns)
    its = [dict(items(n)[0]) for n in ns]
    for i, it in enumerate(its[:9]):
        it["license"] = None if i % 2 == 0 else {"spdx_id": "GPL-3.0"}
        it["size"] = 5  # tiny and first in every result list: they would eat the whole inspection budget
    its[9]["size"] = 300
    tr = lambda u, hd: (200, {}, json.dumps({"items": its}).encode())
    rec = go(world, rid, hooks(world, ns, transport=tr), run_kw=serve(world, [GOODBODY]))
    assert [i["repo"] for i in rec["inspected"]] == ["o9/small"] and rec["state"] == "AWAITING_ADMISSION"
    sk = {x["repo"]: x for x in rec["skipped"]}
    assert len(sk) == 9 and all(x["reason"].startswith("SKIPPED_LICENSE_METADATA") for x in sk.values())
    st = Store(world.store)
    m = A.manifest(st, rec)
    st.close()
    assert len(m["skipped_before_inspection"]) == 9 and m["skipped_before_inspection"][0]["pre_score"]["license_spdx"] in (None, "GPL-3.0")


def test_the_card_remains_the_authority_for_licences_that_pass_the_metadata_filter(world):
    from test_g2_stage import REPO
    ns = ["o0/a"]
    rid = queued(world, ns, files=dict(REPO, LICENSE="GNU GENERAL PUBLIC LICENSE Version 3\n"))  # metadata says MIT, the file says GPL
    rec = go(world, rid, hooks(world, ns))
    assert rec["state"] == "NO_CANDIDATE" and rec["inspected"][0]["rejection"].startswith("LICENSE_NOT_ALLOWED") and not rec["skipped"]


# ================================================================= 2. size penalty
def test_size_penalty_is_log_scaled_and_monotonic():
    p = [AG.size_penalty(kb) for kb in (0, 100, 1024, 10240, 25600, 51200)]
    assert p == sorted(p) and p[0] == 0 and 0.7 < p[2] < 0.9 and p[4] > 3.5 and p[5] < 5


def test_an_equally_relevant_large_repo_ranks_below_a_small_one_and_a_bit_more_relevance_does_not_save_it():
    small = repo("o/small", [("q1", 0), ("q2", 0)], desc="image duplicate", size=400)
    big = repo("o/big", [("q1", 0), ("q2", 0)], desc="image duplicate", size=28 * 1024)
    assert names(AG.rank_hits([big, small], TERMS, 51200, LIC)[0]) == ["o/small", "o/big"]
    bigger = repo("o/bigger", [("q1", 0), ("q2", 0), ("q3", 1)], desc="image duplicate", size=28 * 1024)  # one more query is not enough to offset ~28 MB
    assert names(AG.rank_hits([bigger, small], TERMS, 51200, LIC)[0]) == ["o/small", "o/bigger"]


def test_much_more_relevance_still_beats_size_and_the_other_terms_are_kept():
    many = repo("o/many", [(f"q{i}", 0) for i in range(5)], desc="image duplicate manifest", size=20 * 1024)
    one = repo("o/one", [("q0", 3)], desc="", size=200)
    assert names(AG.rank_hits([one, many], TERMS, 51200, LIC)[0]) == ["o/many", "o/one"]
    a, b = repo("o/a", [("q", 0)], size=100), repo("o/b", [("q", 2)], size=100)
    assert names(AG.rank_hits([b, a], TERMS, 51200, LIC)[0]) == ["o/a", "o/b"]  # position still counts
    ov, no = repo("o/ov", [("q", 1)], desc="duplicate image"), repo("o/no", [("q", 1)], desc="other")
    assert names(AG.rank_hits([no, ov], TERMS, 51200, LIC)[0]) == ["o/ov", "o/no"]  # overlap still counts
    new, old = repo("o/new", [("q", 1)], pushed="2026-05-01"), repo("o/old", [("q", 1)], pushed="2020-05-01")
    assert names(AG.rank_hits([old, new], TERMS, 51200, LIC)[0]) == ["o/new", "o/old"]  # recency then stars then name break exact ties


def test_breakdown_records_relevance_penalty_and_score():
    ranked, _ = AG.rank_hits([repo("o/x", [("q1", 0), ("q2", 1)], desc="duplicate image", size=2048)], TERMS, 51200, LIC)
    bd = ranked[0][1]
    assert bd["relevance"] == round(2 * 2 + (1 + 0.5) + 0.5 * 2, 4) and bd["size_penalty"] == round(AG.size_penalty(2048), 4) and bd["score"] == round(bd["relevance"] - bd["size_penalty"], 4)
    assert bd["rank"] == 0


# ================================================================= 3. deterministic query suggestion
def test_suggestion_parameters_are_fixed_and_the_proposal_settings_are_not_touched(world):
    assert A.SUGGEST_PARAMS == {"temperature": 0, "seed": 2026400001, "max_tokens": 200}
    ns = ["o0/a"]
    rid = queued(world, ns)
    kw = serve(world, ["near duplicate pictures\nsecond query here", GOODBODY])
    h = hooks(world, ns)
    h["suggest"] = A.make_suggest(world.store, kw)
    rec = go(world, rid, h, run_kw=kw)
    reqs = [json.loads(x) for x in (world.tmp / "req.jsonl").read_text(encoding="utf-8").splitlines()]
    sug, prop = reqs[0], reqs[1]
    assert sug["temperature"] == 0 and sug["seed"] == 2026400001 and sug["max_tokens"] == 200  # deterministic
    assert prop["temperature"] == 0.2 and prop["seed"] != 2026400001 and prop["max_tokens"] != 200  # proposals keep their settings
    q = rec["search"]["query_sources"]
    assert q["model_params"] == {"temperature": 0, "seed": 2026400001, "max_tokens": 200, "model": "openai/gpt-oss-20b"} and q["model"][0] == "near duplicate pictures"
    st = Store(world.store)
    m = A.manifest(st, rec)
    st.close()
    assert m["search"]["query_sources"]["model_params"]["temperature"] == 0


def test_the_same_suggestion_request_is_byte_identical_across_calls(tmp_path):
    import m2_stub_server as STUB
    from hive import acq_propose as AP
    srv, url = STUB.serve_thread({"R": ["a b c"]}, log=str(tmp_path / "req.jsonl"))
    view = {"purpose": "p", "behaviour_spec": "b", "inputs": ["x"], "output": "o", "media_type": "m"}
    for _ in range(2):
        A.make_suggest(tmp_path, {"stub_endpoint": url})(AP.query_messages(view))
    a, b = [json.loads(x) for x in (tmp_path / "req.jsonl").read_text(encoding="utf-8").splitlines()]
    assert a == b and a["temperature"] == 0 and a["seed"] == 2026400001


def test_manifest_records_no_params_when_the_hook_has_none(world):
    ns = ["o0/a"]
    rid = queued(world, ns)
    h = hooks(world, ns)
    h["suggest"] = lambda msgs: ("some query words", {})
    rec = go(world, rid, h, run_kw=serve(world, [GOODBODY]))
    assert rec["search"]["query_sources"]["model_params"] is None and rec["search"]["query_sources"]["model"] == ["some query words"]
