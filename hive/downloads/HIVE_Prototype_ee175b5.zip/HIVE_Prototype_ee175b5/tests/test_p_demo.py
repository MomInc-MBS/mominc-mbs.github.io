"""scripts/prototype_demo.py without a live model, Docker or network: argument handling, phase preconditions, receipt shape, report aggregation."""
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import prototype_demo as P  # noqa: E402

RECEIPT_KEYS = {"test_id", "baseline_commit", "candidate_commit", "fixture_id", "registry_snapshot", "expected", "observed", "status", "elapsed_ms", "model_calls", "input_tokens",
                "cached_input_tokens", "output_tokens", "cost_usd", "evidence_path"}


def args(tmp_path, phase, *extra):
    return P.parser().parse_args(["--store", str(tmp_path / "s"), "--out", str(tmp_path / "o"), "--phase", phase, *extra])


def run(tmp_path, phase, capsys, *extra):
    rc = P.main(["--store", str(tmp_path / "s"), "--out", str(tmp_path / "o"), "--phase", phase, *extra])
    cap = capsys.readouterr()
    return rc, cap.out, cap.err


def test_arguments(tmp_path):
    a = args(tmp_path, "learn-a")
    assert a.phase == "learn-a" and a.baseline_commit and a.require_new_external is True and a.force is False
    assert args(tmp_path, "alt", "--backend", "qwen/qwen3.8-27b").backend == "qwen/qwen3.8-27b"
    assert args(tmp_path, "learn-c", "--no-require-new-external").require_new_external is False
    with pytest.raises(SystemExit):
        args(tmp_path, "nonsense")
    with pytest.raises(SystemExit):
        P.parser().parse_args(["--phase", "init"])  # --store and --out are required


def test_phases_are_in_the_documented_order():
    assert P.PHASES == ("init", "learn-a", "goal-a", "goal-b", "learn-c", "goal-c", "restart", "alt", "improve", "report")
    assert set(P.RUN) == set(P.PHASES)


def test_phase_before_init_is_refused_and_changes_nothing(tmp_path, capsys):
    rc, out, err = run(tmp_path, "learn-a", capsys)
    assert rc == 2 and "run --phase init first" in err
    assert not (tmp_path / "s").exists()


def test_init_refuses_nonempty_store_and_missing_key(tmp_path, capsys):
    (tmp_path / "s").mkdir()
    (tmp_path / "s" / "x").write_text("x")
    rc, _, err = run(tmp_path, "init", capsys, "--admit-key", str(tmp_path / "nokey"))
    assert rc == 2 and "not empty" in err
    (tmp_path / "s" / "x").unlink()
    rc, _, err = run(tmp_path, "init", capsys, "--inputs", str(tmp_path), "--admit-key", str(tmp_path / "nokey"))
    assert rc == 2 and "admission key" in err


def test_phase_order_and_no_silent_retry(tmp_path, capsys):
    d = P.Demo(args(tmp_path, "goal-a"))
    st = d.load()
    st["phases"]["init"] = {"status": "done"}
    d.save(st)
    rc, _, err = run(tmp_path, "goal-a", capsys)  # learn-a has no record
    assert rc == 2 and "'learn-a' has not been run" in err
    st["phases"]["learn-a"] = {"status": "failed"}
    d.save(st)
    rc, _, err = run(tmp_path, "learn-a", capsys)  # a recorded phase is not retried silently
    assert rc == 2 and "already ran (failed)" in err and "--force" in err


def test_receipt_has_the_minimum_format_and_keeps_unknown_metrics_null(tmp_path):
    d = P.Demo(args(tmp_path, "learn-a"))
    d.phase = "learn-a"
    r = d.receipt("T02", "fx", "exp", "obs", "pass", 12, calls=3, tin=100, tout=50, cost=0.0, evidence="evidence/x", snap="abc")
    assert RECEIPT_KEYS <= set(r)
    assert r["cached_input_tokens"] is None and r["model_calls"] == 3 and r["registry_snapshot"] == "abc"
    assert json.loads((tmp_path / "o" / "receipts" / "learn-a-T02.json").read_text()) == r
    r2 = d.receipt("T11", "fx", "e", "o", "skip", 0, snap="abc")  # nothing measured: null, not an invented 0
    assert r2["model_calls"] is None and r2["input_tokens"] is None and r2["cost_usd"] is None
    with pytest.raises(AssertionError):
        d.receipt("T11", "fx", "e", "o", "maybe", 0, snap="abc")


def test_goal_ok_requires_verified_pass_and_zero_model_calls(tmp_path):
    d = P.Demo(args(tmp_path, "goal-a"))
    g = {"state": "VERIFIED", "steps": [{"kind": "discovered", "verdict": "PASS"}], "usage": {"model_calls": 0, "proposal_calls": 0}, "plan_ops": ["a", "b"]}
    assert d.goal_ok(g, ["a", "b"]) and not d.goal_ok(g, ["b", "a"])
    assert not d.goal_ok(dict(g, usage={"model_calls": 1, "proposal_calls": 0}))
    assert not d.goal_ok(dict(g, steps=[{"kind": "discovered", "verdict": "FAIL"}]))
    assert not d.goal_ok(dict(g, state="STEP_FAILED"))
    assert not d.goal_ok(dict(g, usage={}))  # unknown model calls are not zero
    assert not d.goal_ok(dict(g, usage={"model_calls": None, "proposal_calls": 0}))


def test_domain_sentences_and_h1_chain():
    assert P.TEXT["L1"] == "Scan the pages of this site for every raw reference."
    assert P.TEXT["L1b"] == "Resolve these scanned page references into a reference table."
    assert P.H1_OPS == ["site.ref-extract", "site.ref-resolve", "site.ref-check"]
    assert P.RAW("2633d9b") == "2633d9b/raw-reference-table-2633d9b.json" and P.H3_TABLE == "asset-properties-images-19.json"


def _fake_acq(calls):
    def acquire_local(label, cap, text, rels, *, direct=None):
        calls.append((label, cap, text, rels))
        if cap == P.CHECK:  # admitted earlier: production acquire_gap returns this without touching the model
            return {"label": label, "capability": cap, "goal": text, "state": "ALREADY_RETAINED", "inputs": [], "retained": {"version": 1}}
        return {"label": label, "capability": cap, "goal": text, "state": "NO_QUALIFYING_CANDIDATE", "inputs": [], "goal_state": "ACQUISITION_QUEUED",
                "attempts": [{"exp_id": "e1", "state": "NO_QUALIFYING_CANDIDATE", "reason": "dev 3/6", "best_dev_pass": 3, "receipt": None}],
                "cost": {"calls": 3, "in_tokens": 10, "out_tokens": 20, "wall_s": 2.0}}
    return acquire_local


def test_learn_a_acquires_l1_l1b_reuses_l2_and_reports_real_states(tmp_path):
    d = P.Demo(args(tmp_path, "learn-a"))
    d.phase = "learn-a"
    calls = []
    d.acquire_local = _fake_acq(calls)
    d.snapshot = lambda: ([], "snap")
    st = {"phases": {"init": {"status": "done"}}, "goals": {}, "receipts": []}
    assert P.ph_learn_a(d, st) is True  # the phase passes when L2 is admitted; the failed L1/L1b stay failed in the T02 receipt
    assert [(c[0], c[1], c[3]) for c in calls] == [("L1", P.EXTRACT, ["2633d9b/site-pages-2633d9b.json"]), ("L1b", P.RESOLVE, ["2633d9b/raw-reference-table-2633d9b.json"]),
                                                  ("L2", P.CHECK, ["2633d9b/reference-table-2633d9b.json", "2633d9b/site-manifest-2633d9b.json"])]
    r = json.loads((tmp_path / "o" / "receipts" / "learn-a-T02.json").read_text())
    assert r["status"] == "fail" and r["model_calls"] == 6 and "L2 site.ref-check: ALREADY_RETAINED" in r["observed"] and "NO_QUALIFYING_CANDIDATE (dev 3/6)" in r["observed"]
    assert st["goals"]["L2"]["state"] == "ALREADY_RETAINED" and st["goals"]["L1"]["state"] == "NO_QUALIFYING_CANDIDATE"


def test_learn_a_skip_flag_blocks_t02_and_copies_negative_evidence(tmp_path):
    neg = tmp_path / "o3" / "evidence" / "learn-a"
    neg.mkdir(parents=True)
    (neg / "acquire.json").write_text("{}")
    d = P.Demo(args(tmp_path, "learn-a", "--skip-unlearnable", "site.ref-extract,site.ref-resolve", "--negative-evidence", str(neg)))
    d.phase = "learn-a"
    calls = []
    d.acquire_local = _fake_acq(calls)
    d.snapshot = lambda: ([], "snap")
    st = {"phases": {"init": {"status": "done"}}, "goals": {}, "receipts": []}
    assert P.ph_learn_a(d, st) is True
    assert [c[1] for c in calls] == [P.CHECK]  # the skipped attempts never run
    r = json.loads((tmp_path / "o" / "receipts" / "learn-a-T02.json").read_text())
    assert r["status"] == "blocked" and r["details"]["admitted"] == [P.CHECK]  # T02 never passes on, nor counts, the blocked capabilities
    assert "L1 site.ref-extract: BLOCKED (skipped: not learnable by available models (evidence: " + str(neg) in r["observed"] and "L1b site.ref-resolve: BLOCKED" in r["observed"]
    assert st["goals"]["L1"]["state"] == "blocked" and st["rescope"]["blocked"].keys() == {P.EXTRACT, P.RESOLVE}
    assert (tmp_path / "o" / "evidence" / "negative" / "o3-evidence-learn-a" / "acquire.json").is_file()
    with pytest.raises(P.Refuse, match="not found"):
        d.a.negative_evidence = str(tmp_path / "nope")
        P.ph_learn_a(d, st)


def test_blocked_with_a_failed_attempt_is_fail_not_blocked(tmp_path):
    d = P.Demo(args(tmp_path, "learn-a"))
    d.phase = "learn-a"
    d.acquire_local = _fake_acq([])
    d.snapshot = lambda: ([], "snap")
    outs, r, ok = d.run_acq("T02", "fx", [("L1", P.EXTRACT, "t", [], None)], "e", blocked=[("L1b", P.RESOLVE, "why")])
    assert r["status"] == "fail" and not ok and r["details"]["admitted"] == []


def _goal_stubs(d, tmp_path, active, doc):
    d.phase = "goal-a"
    d.active = lambda: {c: 1 for c in active}
    d.snapshot = lambda: ([], "snap")
    d.meter = lambda: {}
    d.spent = lambda a, b: {"model_calls": 0, "new_experiments": 0, "new_acquisition_runs": 0}
    d.file_info = lambda r: {"path": r}
    seen = []
    out = d.store / "output" / "goal" / "g-1"
    out.mkdir(parents=True)
    (out / "broken.json").write_text(json.dumps(doc))
    rec = {"goal_id": "g-1", "state": "VERIFIED", "steps": [{"op": P.CHECK, "kind": "discovered", "mode": "retained", "verdict": "PASS"}], "usage": {"model_calls": 0, "proposal_calls": 0},
           "plan": {"steps": [{"op": P.CHECK, "inputs": ["input:0", "input:1"]}]}, "deliverable": [{"name": "broken.json", "ref": "output/goal/g-1/broken.json"}]}
    d.goal = lambda label, text, rels: (seen.append((label, text, rels)) or rec, 1, "ev")
    d.cli = lambda *a, **k: (0, {"ok": 1}, 1, "ev")
    return seen


def test_goal_a_without_the_chain_runs_the_l2_sentence_on_the_exports_and_marks_h1_blocked(tmp_path):
    d = P.Demo(args(tmp_path, "goal-a"))
    seen = _goal_stubs(d, tmp_path, [P.CHECK], {"broken": [{"page": "a", "raw": "x"}, {"page": "b", "raw": "y"}], "totals": {"broken": 2}})
    st = {"phases": {"learn-a": {}}, "goals": {}, "rescope": {"blocked": {P.EXTRACT: "why"}, "evidence": ["evidence/negative/x"]}}
    assert P.ph_goal_a(d, st) is True
    assert seen == [("BL-2633d9b", "Check these references against the site manifest and list the broken links.", [P.TABLE("2633d9b"), P.MANIFEST("2633d9b")])]
    t20 = json.loads((tmp_path / "o" / "receipts" / "goal-a-T20.json").read_text())
    assert t20["status"] == "pass" and "broken links: 2" in t20["observed"] and "evaluator-side export" in t20["observed"] and t20["details"]["broken_count"] == 2
    h1 = json.loads((tmp_path / "o" / "receipts" / "goal-a-H1.json").read_text())
    assert h1["status"] == "blocked" and "not admitted" in h1["observed"]
    assert st["goals"]["A"]["result"]["broken_count"] == 2


def test_goal_b_without_the_chain_reuses_check_on_the_new_release_and_diffs_the_manifests(tmp_path):
    d = P.Demo(args(tmp_path, "goal-b"))
    seen = _goal_stubs(d, tmp_path, [P.CHECK], {"broken": [], "totals": {"added": 3, "removed": 1, "modified": 2}})
    d.phase = "goal-b"
    d.plan = lambda *a: ({"state": "UNRESOLVED", "reason": "gap"}, 1, "ev")
    d.run_acq = lambda *a, **k: ([{"inputs": [], "attempts": [], "cost": None, "state": "ADMITTED", "capability": P.DIFF}], {}, True)
    st = {"phases": {"goal-a": {}}, "goals": {}}
    assert P.ph_goal_b(d, st) is False  # the L3 run stub reports PLAN [CHECK], not [DIFF]: ok_run must be strict
    assert seen[0] == ("BL-0b3854a", P.TEXT["L2"], [P.TABLE("0b3854a"), P.MANIFEST("0b3854a")])
    assert seen[1][0] == "L3-run" and seen[1][2] == [P.MANIFEST("2633d9b"), P.MANIFEST("0b3854a")]
    t20 = json.loads((tmp_path / "o" / "receipts" / "goal-b-T20.json").read_text())
    assert t20["status"] == "pass" and t20["model_calls"] == 0


def test_h3_inputs_are_19_pictures_plus_the_property_table(tmp_path):
    src = tmp_path / "src"
    src.mkdir()
    (src / P.H3_TABLE).write_text("{}")
    d = P.Demo(args(tmp_path, "goal-c", "--inputs", str(src)))
    d.phase = "goal-c"
    imgs = [f"images/p{i:02d}.png" for i in range(19)] + ["images/" + P.H3_SKIP]
    rels = P.h3_inputs(d, imgs)
    assert len(rels) == 20 and rels[-1] == P.H3_TABLE and not any(r.endswith(P.H3_SKIP) for r in rels) and (d.inputs / P.H3_TABLE).is_file()


def test_improve_refuses_a_latency_objective(tmp_path):
    d = P.Demo(args(tmp_path, "improve", "--objective", "latency_ms:100"))
    d.phase = "improve"
    d.active = lambda: {P.EXTRACT: 1}
    with pytest.raises(P.Refuse, match="no latency objective"):
        P.ph_improve(d, {"phases": {"alt": {}}, "goals": {}})


def test_report_aggregates_receipts_and_marks_unrun_tests(tmp_path):
    d = P.Demo(args(tmp_path, "report"))
    d.phase = "learn-a"
    d.receipt("T02", "a", "e", "o", "pass", 1, calls=1, tin=1, tout=1, cost=0.0, snap="s")
    d.phase = "goal-b"
    d.receipt("T02", "b", "e", "o", "fail", 1, snap="s")
    d.phase = "restart"
    d.receipt("T10", "c", "e", "o", "pass", 1, calls=0, tin=0, tout=0, cost=0.0, snap="s")
    d.caps = lambda: []
    d.phase = "report"
    st = {"phases": {"init": {"status": "done"}}, "goals": {"A": {"label": "Goal A", "text": "t"}}, "receipts": []}
    assert P.ph_report(d, st)
    s = json.loads((tmp_path / "o" / "SUMMARY.json").read_text())
    assert s["tests"]["T02"]["status"] == "fail" and s["tests"]["T10"]["status"] == "pass" and s["tests"]["T06"]["status"].startswith("skip")
    assert "model_calls" in s["totals"]["metrics_unknown_in_some_receipts"]  # the goal-b receipt measured nothing
    md = (tmp_path / "o" / "REPORT.md").read_text()
    assert "| T02 |" in md and "Goal A" in md


def test_open_experiment_can_name_a_same_interface_alternative(tmp_path):
    """The entry point site.ref-check-alt acquisition needs: a second contract for a gap whose first contract already has a passed experiment."""
    from hive import discovery as D
    from hive.storage import Store
    sig = {"in": "reference_table", "ins": ["reference_table", "site_manifest"], "arity": 2, "out": "broken_ref_report"}
    s = Store(tmp_path / "st")
    try:
        s.set("operator/gap/x", {"missing_step": sig, "partial_plan": []})
        first = D.open_experiment(s, "operator/gap/x", private_dir=tmp_path / "priv")
        assert first["frozen"]["contract"]["capability_id"] == P.CHECK
        first["state"] = "CANDIDATE_PASSED"
        s.set(D.KEY + first["exp_id"], first)
        with pytest.raises(Exception, match="open or passed"):
            D.open_experiment(s, "operator/gap/x", private_dir=tmp_path / "priv")  # default behaviour unchanged
        alt = D.open_experiment(s, "operator/gap/x", private_dir=tmp_path / "priv", capability_id=P.ALT)
        assert alt["frozen"]["contract"]["capability_id"] == P.ALT and alt["exp_id"] != first["exp_id"]
        with pytest.raises(Exception, match="open or passed"):
            D.open_experiment(s, "operator/gap/x", private_dir=tmp_path / "priv", capability_id=P.ALT)  # its own open experiment still blocks a second one
    finally:
        s.close()
