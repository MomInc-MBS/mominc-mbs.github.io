"""G2 S1 kernel: contract v2 (derived environment, binary envelope, limits), staged-image plumbing, statement v3 and its per-use recheck.
No test here starts a container: Docker and the staged-image check are faked; the single real-Docker test is opt-in (HIVE_REAL_DOCKER=1)."""
from __future__ import annotations

import base64
import copy
import json
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "tests"))
import hive_admission as H  # noqa: E402
from hive import acq_stage as ST  # noqa: E402
from hive import capability_registry as CR  # noqa: E402
from hive import capcontract as CC  # noqa: E402
from hive import discovery as D  # noqa: E402
from hive import experiment_compare as EC  # noqa: E402
from hive.adapters import isolation as ISO  # noqa: E402
from hive.operator_runtime import Refused, _sha  # noqa: E402
from hive.storage import Store  # noqa: E402

CAP = "image.asset-match"
IID = "sha256:" + "c" * 64
needs_ssh = pytest.mark.skipif(not CR.keygen(), reason="ssh-keygen unavailable")


def contract():
    return copy.deepcopy(CC.get(CAP))


def env_rec(**kw):
    return dict({"id": IID, "base": dict(ISO.PINNED_IMAGE), "lock_sha256": "1" * 64, "wheelhouse_manifest_sha256": "2" * 64, "image_tar_sha256": "3" * 64,
                 "tar_name": "cccc.tar", "packages": ["tinytool"], "vendored_tree_sha256": "4" * 64}, **kw)


BODY = "import json\nimport tinytool\n\n\ndef run(env):\n    return json.dumps({\"n\": len(env[\"files\"])})\n"


# ---------------------------------------------------------------- contract v2 validation
def test_v2_contract_loads_and_v1_contracts_still_do():
    ids = [c["capability_id"] for c in CC.contracts()]
    assert {"image.asset-match", "inventory-diff", "text.interval-merge"} <= set(ids) and CC._scan()[1] == {}
    c = CC.get(CAP)
    assert CC.is_v2(c) and not CC.is_v2(CC.get("inventory-diff")) and CC.base_image(c)["digest"] == ISO.PINNED_IMAGE["digest"]
    assert CC.base_image(CC.get("inventory-diff"))["image"] == ISO.PINNED_IMAGE["reference"]
    assert CC.default()["capability_id"] == "inventory-diff"  # callers naming no contract keep the legacy one


@pytest.mark.parametrize("edit,why", [
    (lambda c: c["permissions"].update(network=True), "network"),
    (lambda c: c["execution"]["resources"].update(memory_mb=1024), "memory"),
    (lambda c: c["execution"]["resources"].update(cpus=3), "cpus"),
    (lambda c: c["execution"]["resources"].update(tmpfs_mb=512), "tmpfs"),
    (lambda c: c["execution"]["environment_ref"].update(kind="floating"), "kind"),
    (lambda c: c["execution"]["environment_ref"].update(image="x", digest="sha256:" + "0" * 64), "derived+pinned fields"),
    (lambda c: c["execution"]["environment_ref"].pop("stage_policy"), "no stage policy"),
    (lambda c: c["execution"]["environment_ref"].update(stage_policy="configs/nope.json"), "stage policy missing"),
    (lambda c: c["execution"]["environment_ref"]["base"].update(digest="sha256:" + "0" * 64), "base not the pinned image"),
    (lambda c: c["inputs"].pop("limits"), "files-v2 without limits"),
    (lambda c: c["inputs"].update(format="text"), "files-v2 text format"),
    (lambda c: c["inputs"]["limits"].update(max_files=1), "arity beyond max_files"),
    (lambda c: c["inputs"]["limits"].update(max_total_bytes=10**9), "limit over engine ceiling"),
    (lambda c: c["inputs"].update(envelope="files-v3"), "unknown envelope"),
    (lambda c: c["permissions"]["imports"].update(stdlib=["os"]), "os not in the stdlib allowlist"),
    (lambda c: c["permissions"]["imports"].update(extra=1), "unknown field"),
    (lambda c: c["permissions"].update(imports=["json"]), "v1 style imports"),
    (lambda c: c.update(schema="hive-capability-contract-v3"), "unknown schema"),
])
def test_v2_contract_refusals(edit, why):
    c = contract()
    edit(c)
    with pytest.raises(Refused):
        CC.validate(c)


def test_v2_pinned_environment_and_staged_rules():
    c = contract()
    c["execution"]["environment_ref"] = {"kind": "pinned", "image": ISO.PINNED_IMAGE["reference"], "digest": ISO.PINNED_IMAGE["digest"]}
    with pytest.raises(Refused, match="staged imports"):
        CC.validate(c)
    c["permissions"]["imports"]["staged"] = False
    assert CC.validate(c) is c
    c["execution"]["environment_ref"]["base"] = {"image": "x", "digest": "sha256:" + "0" * 64}
    with pytest.raises(Refused):
        CC.validate(c)
    d = CC.get("inventory-diff")
    d["inputs"]["limits"] = {"max_files": 1, "max_file_bytes": 1, "max_total_bytes": 1}
    with pytest.raises(Refused):  # v1 contracts cannot grow v2 fields
        CC.validate(d)


# ---------------------------------------------------------------- envelope, import policy, run arguments
def test_v2_envelope_base64_limits_and_names():
    c = contract()
    env = CC.build_env(c, [("a.png", b"\x89PNG\x00\xff"), ("b.jpg", b"\xff\xd8\x00")])
    assert env == {"files": [{"name": "a.png", "format": "base64", "data": base64.b64encode(b"\x89PNG\x00\xff").decode()},
                             {"name": "b.jpg", "format": "base64", "data": base64.b64encode(b"\xff\xd8\x00").decode()}]}
    assert "NAME" in CC.envelope_text(c) and "2 to 20" in CC.envelope_text(c)
    for bad in ([("a.png", b"x")], [("a", b"x")] * 2, [("a", b"x" * 262145), ("b", b"y")], [(f"f{i}", b"x") for i in range(21)], [("a", "text"), ("b", b"y")]):
        with pytest.raises(Refused):
            CC.build_env(c, bad)
    c["inputs"]["limits"]["max_total_bytes"] = 100
    with pytest.raises(Refused):
        CC.build_env(c, [("a", b"x" * 60), ("b", b"y" * 60)])


def test_v1_envelope_unchanged_and_accepts_pairs():
    d = CC.get("inventory-diff")
    assert CC.build_env(d, ["x", "y"]) == CC.build_env(d, [("a", b"x"), ("b", b"y")]) == {"files": [{"format": d["inputs"]["format"], "text": "x"}, {"format": d["inputs"]["format"], "text": "y"}]}
    assert "INPUT_0" in CC.envelope_text(d)


def test_import_policy_and_exec_args():
    c, d = contract(), CC.get("inventory-diff")
    assert CC.import_policy(d, ["x"]) == ["json"]
    assert "tinytool" in CC.import_policy(c, ["tinytool"]) and "json" in CC.import_policy(c, ["tinytool"]) and "os" not in CC.import_policy(c, ["tinytool"])
    c["permissions"]["imports"]["staged"] = False
    assert "tinytool" not in CC.import_policy(c, ["tinytool"])
    assert CC.exec_args(d) == {} and CC.exec_args(d, {"id": IID}) == {}
    kw = CC.exec_args(contract(), {"id": IID})
    assert kw == {"limits": {"memory_mb": 512, "cpu_count": 2, "pids": 64, "tmpfs_mb": 64}, "image": {"id": IID}, "inputs": "read-only"}


def test_environment_record_validation():
    c = contract()
    CC.check_environment(env_rec())
    for bad in (None, {}, env_rec(id="nope"), env_rec(tar_name="../x.tar"), env_rec(packages=["a b"]), env_rec(base={"reference": "x", "digest": "y"}),
                dict(env_rec(), extra=1), env_rec(packages="tinytool")):
        with pytest.raises(Refused):
            CC.check_environment(bad)
    rec = CC.env_record(dict(env_rec(), tar_path="C:/somewhere/deep/cccc.tar", tag="t", wheelhouse=[]))
    assert rec == env_rec() and c


# ---------------------------------------------------------------- isolation plumbing (fake docker, nothing started)
class _P:
    def __init__(self, out="", rc=0):
        self.stdout, self.returncode, self.stderr = out, rc, ""


def test_local_image_inspect_binds_the_exact_id(monkeypatch):
    calls = []

    def run(argv, **kw):
        calls.append(argv)
        return _P("27.0" if argv[1] == "info" else IID)
    monkeypatch.setattr(ISO.subprocess, "run", run)
    ctl = ISO.DockerIsolation("docker").inspect({"id": IID})
    assert ctl["image_digest"] == IID and ctl["network"] == "none" and ["docker", "image", "inspect", IID, "--format", "{{.Id}}"] in calls
    monkeypatch.setattr(ISO.subprocess, "run", lambda argv, **kw: _P("27.0" if argv[1] == "info" else "sha256:" + "d" * 64))
    with pytest.raises(ISO.SandboxUnavailable):
        ISO.DockerIsolation("docker").inspect({"id": IID})
    for bad in ("short", None, "md5:" + "0" * 67):
        with pytest.raises(ISO.SandboxUnavailable):
            ISO.DockerIsolation("docker").inspect({"id": bad})


def test_execute_runs_the_local_id_with_contract_limits(monkeypatch, tmp_path):
    seen = {}
    monkeypatch.setattr(ISO.DockerIsolation, "_inspect_local", lambda self, i: {"engine": "docker", "image_digest": i})
    monkeypatch.setattr(ISO, "_bounded_process", lambda argv, **kw: (seen.update(argv=argv, kw=kw) or (0, b"{}", b"", False, False)))
    r = ISO.DockerIsolation("docker").execute({"repo_copy": tmp_path, "image": {"id": IID}, "command": ["python", "-c", "pass"],
                                               "limits": {"memory_mb": 512, "cpu_count": 2, "pids": 64, "tmpfs_mb": 64, "timeout_s": 9, "output_bytes": 100}})
    a = seen["argv"]
    assert IID in a and "--network=none" in a and "--memory=512m" in a and "--cpus=2" in a and "--pids-limit=64" in a and "--user=1000:1000" in a
    assert "--tmpfs=/tmp:rw,noexec,nosuid,size=64m" in a and "--read-only" in a and "--cap-drop=ALL" in a and r.state == "passed"
    seen.clear()
    ISO.DockerIsolation("docker").execute({"repo_copy": tmp_path, "image": {"id": IID}, "command": ["x"], "limits": {"memory_mb": 128, "cpu_count": 1, "pids": 32, "timeout_s": 5, "output_bytes": 9}})
    assert "--tmpfs=/tmp:rw,noexec,nosuid,size=16m" in seen["argv"]  # default tmpfs unchanged


def test_run_isolated_passes_image_and_limits_and_defaults_are_unchanged(monkeypatch):
    reqs = []

    class Fake:
        def execute(self, request):
            reqs.append(request)
            return ISO.IsolationResult("passed", {"stdout": '{"out": "ok"}', "timed_out_or_output_capped": False, "exit_code": 0})
    monkeypatch.setattr(ISO, "DockerIsolation", Fake)
    assert EC.run_isolated("def apply(t, c): return 'ok'", "t", {}, backend="container", operator_class="generated") == "ok"
    assert reqs[0]["image"] == ISO.PINNED_IMAGE and reqs[0]["limits"] == {"memory_mb": 128, "cpu_count": 1, "pids": 32, "timeout_s": 10, "output_bytes": (1 << 20) + 64}
    EC.run_isolated("s", "t", {}, backend="container", operator_class="generated", image={"id": IID}, limits={"memory_mb": 512, "tmpfs_mb": 64})
    assert reqs[1]["image"] == {"id": IID} and reqs[1]["limits"]["memory_mb"] == 512 and reqs[1]["limits"]["pids"] == 32 and reqs[1]["limits"]["tmpfs_mb"] == 64
    with pytest.raises(RuntimeError, match="container backend"):
        EC.run_isolated("s", "t", {}, backend="process", image={"id": IID})


# ---------------------------------------------------------------- statement v3 + registry
def statement(c=None, body=BODY, env=None, version=1):
    c = c or contract()
    st = {"schema": CC.V3, "cap_id": c["capability_id"], "version": version, "contract": c, "contract_sha256": CC.sha(c), "impl_sha256": _sha(body), "body": body,
          "harness_sha256": CC.harness_sha(c), "pin": CC.pin(c)}
    if env is not False:
        st["environment"] = env or env_rec()
    return st


@pytest.fixture
def images(monkeypatch):
    seen = []
    monkeypatch.setattr(CC, "ensure_image", lambda env, d: (seen.append((env["id"], str(d))), IID)[1])
    return seen


def test_recheck_v3_ok_and_each_tamper_is_refused(images, tmp_path):
    CC.recheck(statement(), tmp_path)
    assert images == [(IID, str(tmp_path))]
    for bad, msg in ((lambda s: s.update(body=BODY + "#x"), "implementation body"),
                     (lambda s: s["contract"].update(version="9.9.9"), "contract differs"),
                     (lambda s: s.update(harness_sha256="0" * 64), "harness"),
                     (lambda s: s.update(pin="0" * 64), "pin"),
                     (lambda s: s.pop("environment"), "malformed"),
                     (lambda s: s["environment"].update(id="sha256:" + "d" * 64), "image ID"),
                     (lambda s: s["environment"].update(packages=["other"]), "static check"),
                     (lambda s: s.update(schema=CC.V2), "versions disagree")):
        st = statement()
        bad(st)
        if msg in ("implementation body", "static check"):
            st["impl_sha256"] = _sha(st["body"]) if msg == "static check" else st["impl_sha256"]
        with pytest.raises(Refused, match=msg):
            CC.recheck(st, tmp_path)
    with pytest.raises(Refused, match="image store"):
        CC.recheck(statement(), None)


def test_recheck_v3_static_policy_follows_the_staged_packages(images, tmp_path):
    for body in ("import os\ndef run(env):\n    return ''\n", "from tinytool import *\ndef run(env):\n    return ''\n", "import json\ndef run(env):\n    return open('x')\n",
                 "import PIL\ndef run(env):\n    return ''\n"):
        with pytest.raises(Refused, match="static check"):
            CC.recheck(statement(body=body), tmp_path)
    CC.recheck(statement(body="import json, io, base64\nimport tinytool\nfrom tinytool import thing\ndef run(env):\n    return ''\n"), tmp_path)


def test_recheck_pinned_v2_contract_with_v3_statement(tmp_path, images):
    c = contract()
    c["execution"]["environment_ref"] = {"kind": "pinned", "image": ISO.PINNED_IMAGE["reference"], "digest": ISO.PINNED_IMAGE["digest"]}
    c["permissions"]["imports"]["staged"] = False
    body = "import json\ndef run(env):\n    return ''\n"
    CC.recheck(statement(c, body, env=False), tmp_path)
    assert not images  # nothing staged, nothing looked up
    with pytest.raises(Refused, match="pinned environment"):
        CC.recheck(statement(c, body, env=env_rec()), tmp_path)


def test_ensure_image_wraps_stage_failures(monkeypatch, tmp_path):
    def boom(self, env):
        raise ST.StageRejected("IMAGE_MISSING", "gone")
    monkeypatch.setattr(ST.Stager, "ensure", boom)
    with pytest.raises(Refused, match="IMAGE_MISSING"):
        CC.ensure_image(env_rec(), tmp_path)
    seen = {}
    monkeypatch.setattr(ST.Stager, "ensure", lambda self, env: (seen.update(env), env["id"])[1])
    assert CC.ensure_image(env_rec(), tmp_path) == IID and seen["tar_path"] == str(tmp_path / "cccc.tar")


def _frozen(c):
    return {"schema": D.SCHEMA, "contract": {"capability_id": c["capability_id"], "sha256": CC.sha(c)}, "environment": env_rec(),
            "evaluator": {"path": c["verification"]["evaluator"]["path"], "suite": c["verification"]["suite_ref"], "pin": CC.pin(c)}}


def test_check_frozen_demands_an_environment_exactly_when_derived(tmp_path):
    c = contract()
    D.check_frozen({"frozen": _frozen(c)}, c)
    f = _frozen(c)
    f.pop("environment")
    with pytest.raises(Refused, match="environment kind"):
        D.check_frozen({"frozen": f}, c)
    f = _frozen(c)
    f["environment"]["tar_name"] = "../x"
    with pytest.raises(Refused, match="malformed"):
        D.check_frozen({"frozen": f}, c)
    v1 = CC.get("inventory-diff")
    f = {"schema": D.SCHEMA, "contract": {"capability_id": v1["capability_id"], "sha256": CC.sha(v1)}, "environment": env_rec(),
         "evaluator": {"path": v1["verification"]["evaluator"]["path"], "pin": CC.pin(v1)}}
    with pytest.raises(Refused, match="environment kind"):
        D.check_frozen({"frozen": f}, v1)


def test_receipt_problems_binds_the_environment_id():
    c = contract()
    rec = {"exp_id": "d-1", "frozen_sha": "f" * 64, "frozen": dict(_frozen(c), acceptance={"set_sha256": "s", "n": 1})}
    r = {"schema": D.RECEIPT_SCHEMA, "label": "candidate", "exp_id": "d-1", "frozen_sha": "f" * 64, "candidate_sha256": "c", "acceptance_set_sha256": "s", "n": 1,
         "evaluator": {"pin": CC.pin(c)}, "pass_count": 1, "verdict": "PASS", "environment_id": IID}
    r["receipt_sha256"] = _sha(json.dumps({k: v for k, v in r.items() if k != "receipt_sha256"}, sort_keys=True, separators=(",", ":")))
    assert D.receipt_problems(rec, r, "c", "candidate") == []
    r2 = dict(r, environment_id="sha256:" + "e" * 64)
    r2["receipt_sha256"] = _sha(json.dumps({k: v for k, v in r2.items() if k != "receipt_sha256"}, sort_keys=True, separators=(",", ":")))
    assert D.receipt_problems(rec, r2, "c", "candidate") == ["environment id"]


# ---------------------------------------------------------------- admission builds v3 and the registry serves it
@needs_ssh
def test_admit_signs_v3_with_environment_and_registry_serves_it(monkeypatch, tmp_path, images):
    info = H.init(str(tmp_path / "keys"), str(tmp_path / "signers"))
    monkeypatch.setattr(CR, "SIGNERS", Path(info["signers"]))
    c = contract()
    fz = _frozen(c)
    fz["proposer"] = {"model": "openai/gpt-oss-20b"}
    fz["tool"] = {"repo": "a/b", "revision": "0" * 40}
    rec = {"exp_id": "d-" + "a" * 20, "frozen_sha": "a" * 64, "frozen": fz, "gap_key": "gap/x", "state": "CANDIDATE_PASSED"}
    rcpt = {"receipt_sha256": "r" * 64, "pass_count": 24, "n": 24, "case_result_sha256": ["x"], "verdict": "PASS"}
    monkeypatch.setattr(D, "experiments", lambda s: [rec])
    monkeypatch.setattr(D, "contract_of", lambda r: c)
    monkeypatch.setattr(H, "_recheck", lambda sr, r, cc, rerun: (BODY, rcpt, rcpt, rcpt, None))
    store = tmp_path / "store"
    out = H.admit(str(store), rec["exp_id"], str(info["key"]))
    assert out["cap_id"] == CAP and out["version"] == 1
    s = Store(store)
    try:
        r = CR.resolve_discovered(s, CAP)
        st = r["statement"]
        assert st["schema"] == CC.V3 and st["environment"] == env_rec() and st["tool"]["repo"] == "a/b" and st["contract_sha256"] == CC.sha(c)
        assert images and images[-1][1] == str(store / "acquisition" / "images")  # the registry looks for tars in the store's images dir
        ok, ex = CR.eligible_discovered(s)
        assert ok[CAP]["in"] == "image_file" and ok[CAP]["out"] == "image_match_manifest" and ok[CAP]["arity"] == [2, 20] and not ex
        monkeypatch.setattr(CC, "ensure_image", lambda env, d: "sha256:" + "9" * 64)  # the image on disk no longer has the admitted ID
        with pytest.raises(CR.Refused, match="image ID"):
            CR.resolve_discovered(s, CAP)
    finally:
        s.close()


# ---------------------------------------------------------------- g2 harness / evaluator
def _mod(path):
    """Load a suite/evaluator file by path. Its bare sibling imports (gen_public, oracle, ...) must resolve to ITS folder, not to another
    family's module already cached under the same name (full-suite order bug at 9caa093), and must not leak into later tests."""
    import importlib.util
    bare = {p.stem for p in path.parent.glob("*.py")}
    saved, sp = {n: sys.modules.pop(n) for n in bare if n in sys.modules}, list(sys.path)
    sys.path.insert(0, str(path.parent))
    try:
        spec = importlib.util.spec_from_file_location("g2m_" + path.stem, path)
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        return m
    finally:
        for n in bare:
            sys.modules.pop(n, None)
        sys.modules.update(saved)
        sys.path[:] = sp


def test_g2_harness_import_policy_and_wrap():
    h = _mod(ROOT / "evaluator" / "g2" / "harness.py")
    assert h.static_problems(BODY, ["json", "tinytool"]) == [] and h.static_problems(BODY) == ["import outside the allowed modules"]
    for body in ("from x import *\ndef run(e): pass", "import os\ndef run(e): pass", "def run(e):\n    return e.__class__", "def run(e):\n    return eval('1')", "x = 1"):
        assert h.static_problems(body, ["x", "os"]), body
    ns = {}
    exec(h.wrap("def run(env):\n    return 'a'\n"), ns)
    assert json.loads(ns["apply"](json.dumps([{}, {}]), {})) == ["a", "a"]


def test_g2_evaluator_in_process_records_environment_and_scores_by_the_oracle(tmp_path):
    ev = _mod(ROOT / "evaluator" / "g2" / "evaluate.py")
    c = contract()
    suite = ROOT / c["verification"]["suite_ref"]
    pub = _mod(suite / "gen_private.py")
    priv = tmp_path / "priv"
    cases = pub.generate(4, 3)
    sha = pub.set_sha(cases)
    (priv / sha).mkdir(parents=True)
    (priv / sha / "cases.json").write_text(json.dumps(cases), encoding="utf-8")
    cand = tmp_path / "cand.py"
    cand.write_text(BODY, encoding="utf-8", newline="\n")
    orc = _mod(suite / "oracle.py")

    def container(src, text, perfect=True):
        envs = json.loads(text)
        return json.dumps([orc.expected(e) if perfect else None for e in envs])
    base = ["--suite", str(suite), "--exp", "d-1", "--frozen-sha", "f", "--candidate-file", str(cand), "--candidate-sha", _sha(BODY), "--private", str(priv), "--set", sha,
            "--label", "candidate", "--image-id", IID, "--imports", "json,tinytool", "--memory-mb", "512", "--cpus", "2", "--pids", "64", "--tmpfs-mb", "64"]
    with CC.scope(c):  # in-process main() imports the suite's bare modules at call time
        ev.main(base + ["--out", str(tmp_path / "r1.json")], run_container=lambda s, t: container(s, t))
        r = json.loads((tmp_path / "r1.json").read_text(encoding="utf-8"))
        assert r["verdict"] == "PASS" and r["n"] == 3 and r["environment_id"] == IID and r["imports"] == ["json", "tinytool"] and r["evaluator"]["pin"] == CC.pin(c)
        assert r["evaluator"]["path"] == "evaluator/g2/evaluate.py"
        ev.main(base + ["--out", str(tmp_path / "r2.json")], run_container=lambda s, t: container(s, t, False))
        assert json.loads((tmp_path / "r2.json").read_text(encoding="utf-8"))["verdict"] == "FAIL"
        with pytest.raises(SystemExit):  # an import outside the staged policy never runs
            ev.main(base[:base.index("--imports")] + ["--imports", "json", "--out", str(tmp_path / "r3.json")], run_container=lambda s, t: container(s, t))


# ---------------------------------------------------------------- discovery: derived environment frozen, prompt, evaluator args
def _gap(s, c):
    s.set("gap/x", {"missing_step": {"in": "image_file", "arity": 3, "out": "image_match_manifest", "ordered": True}, "partial_plan": []})
    return "gap/x"


def test_open_experiment_freezes_environment_prompt_and_evaluator_args(tmp_path, monkeypatch):
    c = contract()
    s = Store(tmp_path / "store")
    try:
        gap = _gap(s, c)
        with pytest.raises(Refused, match="staged environment"):
            D.open_experiment(s, gap, private_dir=tmp_path / "p1")
        with pytest.raises(Refused, match="malformed"):
            D.open_experiment(s, gap, private_dir=tmp_path / "p1", environment={"id": "x"})
        rec = D.open_experiment(s, gap, private_dir=tmp_path / "p1", seed=1, environment=env_rec(), card_excerpt="=== UNTRUSTED REPOSITORY DATA ===\ntinytool\n")
    finally:
        s.close()
    fz = rec["frozen"]
    assert fz["environment"] == env_rec() and fz["io_envelope"]["input"].startswith("env {\"files\":[{\"name\"") and fz["evaluator"]["suite"] == c["verification"]["suite_ref"]
    D.check_frozen(rec, c)
    dev = D._load("gen_public", c).cases()
    msgs = D.prompt(rec, dev)
    assert "tinytool" in msgs[0]["content"] and "os, " not in msgs[0]["content"] and "UNTRUSTED REPOSITORY DATA" in msgs[1]["content"]
    assert "<base64" in msgs[1]["content"] and len(msgs[1]["content"]) < 16000  # pixels are never inlined (the 8000-token prompt limit is asserted in test_g2_acquire)
    assert D.prompt(dict(rec, frozen=dict(fz, card_excerpt="")), dev)[1]["content"].count("UNTRUSTED") == 0
    h = D._load("harness", c)
    assert D._static(h, c, rec, BODY) == [] and D._static(h, c, rec, "import PIL\ndef run(e): return ''") != []
    got = {}
    monkeypatch.setattr(D, "_launch", lambda args, evaluator: got.update(args=args, ev=evaluator) or __import__("types").SimpleNamespace(returncode=1, stdout=b"", stderr=b"", timed_out=False))
    body = tmp_path / "cand.py"
    body.write_text(BODY, encoding="utf-8", newline="\n")
    with pytest.raises(RuntimeError, match="no receipt"):
        D._evaluate(rec, tmp_path, body, "candidate", tmp_path / "p1")
    a = got["args"]
    assert got["ev"] == "evaluator/g2/evaluate.py" and a[a.index("--image-id") + 1] == IID and a[a.index("--memory-mb") + 1] == "512"
    assert a[a.index("--imports") + 1] == ",".join(CC.import_policy(c, ["tinytool"])) and a[a.index("--suite") + 1].endswith("suite")
    seen = {}
    monkeypatch.setattr(D.EC, "run_isolated", lambda *a, **k: (seen.update(k), json.dumps(["x"] * len(dev)))[1])
    D._dev_run(BODY, dev, h, 30, **CC.exec_args(c, fz["environment"]))
    assert seen["image"] == {"id": IID} and seen["limits"]["memory_mb"] == 512 and seen["backend"] == "container"


def test_open_experiment_refuses_an_environment_for_a_non_derived_contract(tmp_path):
    s = Store(tmp_path / "store")
    try:
        s.set("gap/y", {"missing_step": {"in": "interval_text", "arity": 1, "out": "merged_intervals", "ordered": True}, "partial_plan": []})
        with pytest.raises(Refused, match="staged environment"):
            D.open_experiment(s, "gap/y", private_dir=tmp_path / "p", environment=env_rec())
    finally:
        s.close()


def test_core_modules_name_no_task():
    banned = ("image.asset", "image_match", "image_file", "imagehash", "pillow", "perceptual", "asset-match")
    for n in ("capcontract.py", "discovery.py", "capability_registry.py", "goal_runner.py", "acq_stage.py", "acq_card.py", "acq_github.py"):
        t = (ROOT / "src" / "hive" / n).read_text(encoding="utf-8").lower()
        assert not [w for w in banned if w in t], (n, [w for w in banned if w in t])
    t = (ROOT / "scripts" / "hive_admission.py").read_text(encoding="utf-8").lower()
    assert not [w for w in banned if w in t]
    for n in ("evaluate.py", "harness.py"):
        t = (ROOT / "evaluator" / "g2" / n).read_text(encoding="utf-8").lower()
        assert not [w for w in banned if w in t]


# ---------------------------------------------------------------- opt-in: one real container in a staged image (names hive-code-*; run only when told)
@pytest.mark.skipif(os.environ.get("HIVE_REAL_DOCKER") != "1", reason="opt-in: starts a real hive-code-* container (set HIVE_REAL_DOCKER=1)")
def test_real_container_runs_in_the_staged_image_with_contract_limits(tmp_path):
    from test_g2_stage import REPO, card_for, make_repo, make_wheel, POL
    repo, sha = make_repo(tmp_path, REPO)
    st = ST.Stager(POL)
    try:
        env = st.stage(repo, card_for(repo, sha), tmp_path / "images", tmp_path / "cc", downloader=lambda r, d: make_wheel(d))
        src = ("import json\nimport vtool\n\n\ndef apply(t, c):\n    return json.dumps([vtool.go()])\n")
        out = EC.run_isolated(src, "[]", {}, timeout=60, backend="container", operator_class="generated", **CC.exec_args(contract(), {"id": env["id"]}))
        assert json.loads(out) == [7]
    finally:
        st.cleanup()
