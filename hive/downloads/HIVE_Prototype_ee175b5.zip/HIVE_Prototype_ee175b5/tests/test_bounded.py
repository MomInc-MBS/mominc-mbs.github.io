"""G1 slice 3: deadlines (tree-kill bounded runs, wall-budget clamping) and the planner's input-choice enumeration."""
import copy
import json
import subprocess
import sys
import time
from collections import deque
from pathlib import Path
from types import SimpleNamespace

import pytest

from hive import capcontract as CC
from hive import experiment_compare as EC
from hive import goal_runner as G
from hive.adapters.isolation import DockerIsolation, PINNED_IMAGE
from hive.bounded import run_bounded
from hive.storage import Store

sys.path.insert(0, str(Path(__file__).resolve().parent))
import test_capability_admission as TA  # noqa: E402
from test_capability_admission import auth, store  # noqa: E402,F401  (fixtures)
from test_goal_runner import env  # noqa: E402,F401  (fixture)

needs_store = TA.pytestmark


def _spawner(marker, delay=5):
    child = f"import time;time.sleep({delay});open({str(marker)!r},'w').write('x')"
    return f"import subprocess, sys, time\nsubprocess.Popen([sys.executable, '-c', {child!r}], stdout=1, stderr=2)\n"


# ---------------------------------------------------------------- 1. bounded runner
def test_bounded_kills_grandchild_tree(tmp_path):
    late = tmp_path / "late.txt"
    t0 = time.time()
    rc, out, err, timed_out = run_bounded([sys.executable, "-c", _spawner(late) + "time.sleep(60)\n"], timeout=1, cwd=tmp_path)
    assert timed_out and time.time() - t0 < 4
    time.sleep(7)
    assert not late.exists()  # the grandchild died with the tree


def test_bounded_returns_output_and_exit_code(tmp_path):
    rc, out, err, timed_out = run_bounded([sys.executable, "-c", "import sys;print('hi');sys.stderr.write('e');sys.exit(3)"], timeout=20, cwd=tmp_path)
    assert (rc, out.strip(), err, timed_out) == (3, "hi", "e", False)
    assert run_bounded([sys.executable, "-c", "print(open(0).read())"], timeout=20, input="abc")[1].strip() == "abc"
    assert len(run_bounded([sys.executable, "-c", "print('x' * 5000)"], timeout=20, max_out=100)[1]) == 100


# ---------------------------------------------------------------- 2. verifier hang
def test_verifier_hang_is_unverifiable_and_tree_killed(tmp_path, monkeypatch):
    late = tmp_path / "late.txt"
    (tmp_path / "hang_oracle.py").write_text(f"def expected(env):\n    exec({_spawner(late, 4)!r})\n    while True:\n        pass\n", encoding="utf-8", newline="\n")
    c = copy.deepcopy(CC.default())
    c["verification"]["oracle"] = "hang_oracle.py#expected"
    monkeypatch.setattr(CC, "ROOT", tmp_path)
    monkeypatch.setattr(CC, "pin", lambda c: "0" * 64)
    t0 = time.time()
    v = CC.verify(c, {"files": []}, "x", timeout=1)
    assert v["verdict"] == "UNVERIFIABLE" and "timed out" in v["reason"] and time.time() - t0 < 4
    time.sleep(6)
    assert not late.exists()


# ---------------------------------------------------------------- 3. container deadline (real Docker)
def _docker_ok():
    try:
        DockerIsolation().inspect(PINNED_IMAGE)
        return True
    except Exception:
        return False


@pytest.mark.skipif(not _docker_ok(), reason="Docker/pinned image unavailable")
def test_container_deadline_kills_forked_child_and_removes_container():
    src = "import os, time\ndef apply(t, c):\n    if os.fork() == 0:\n        time.sleep(60)\n        os._exit(0)\n    while True:\n        pass\n"
    t0 = time.time()
    with pytest.raises(RuntimeError, match="timed out"):
        EC.run_isolated(src, "x", {}, timeout=2, backend="container", operator_class="generated")
    assert time.time() - t0 < 20
    assert subprocess.run(["docker", "ps", "-aq", "--filter", "name=hive-code-"], capture_output=True, text=True).stdout.split() == []


# ---------------------------------------------------------------- 4. wall-budget clamp
def _clock(monkeypatch, after):
    """goal_runner's clock: 0 at the start of run_goal, `after` seconds from then on."""
    n = [0]

    def mono():
        n[0] += 1
        return 0.0 if n[0] == 1 else after
    monkeypatch.setattr(G, "time", SimpleNamespace(monotonic=mono))


def _diff_goal(store, wall):
    ins = [("before.csv", "file", TA.BEFORE), ("after.csv", "file", TA.AFTER)]
    return G.run_goal(store, G.make_contract("compare before and after", ins, deliverable="inventory_diff", budget={"wall_s": wall}), ins)


@needs_store
def test_step_timeout_clamped_to_remaining_wall(auth, store, monkeypatch):
    seen = []

    def fake(src, text, checks, timeout=None, max_out=None, *, backend, operator_class):
        seen.append(timeout)
        ns = {}
        exec(compile(src, "<genome>", "exec"), ns)
        return ns["apply"](text, checks)
    monkeypatch.setattr(EC, "run_isolated", fake)
    TA.admit(store, auth)
    assert CC.get("inventory-diff")["execution"]["timeout_seconds"] == 120
    _clock(monkeypatch, 8.0)  # 10 s wall, 8 s already spent
    r = _diff_goal(store, 10)
    assert r["state"] == "VERIFIED" and r["steps"][-1]["mode"] == "retained_capability_execution"
    assert seen[-1] <= 2  # the retained execution (contract timeout 120) was clamped
    seen.clear()
    _clock(monkeypatch, 11.0)  # wall already over
    r = _diff_goal(store, 10)
    assert r["state"] == "BUDGET_EXHAUSTED" and r["steps"] == [] and seen == []  # no run was started


# ---------------------------------------------------------------- 5. planner enumeration
def _old_plan(store, contract):
    """The pre-G1 planner (first match only), kept here as the byte-identity reference."""
    T, (ok, ex) = G.types(), G.eligible_caps(store)
    goal, maxs = contract["deliverable"], contract["budget"]["max_steps"]
    start = tuple((i["type"], f"input:{n}") for n, i in enumerate(contract["inputs"]))
    steps, queue = [], deque([(start, ())])
    while queue:
        items, path = queue.popleft()
        if path and len(items) == 1 and items[0][0] == goal:
            steps = list(path)
            break
        if len(path) >= maxs:
            continue
        for op in sorted(ok):
            c = ok[op]
            lo, hi = c["arity"]
            match = [x for x in items if G._sub(T, x[0], c["in"])]
            take = match[:1] if hi == 1 else match[:hi]
            if len(take) < lo:
                continue
            sid = f"s{len(path) + 1}"
            step = {"step_id": sid, "op": op, "kind": c["kind"], "capability": op, "inputs": [x[1] for x in take],
                    "expected_output": c["out"], "verifier": c["verifier"],
                    "allowance": {"container_runs": 1 if c["kind"] in ("registry", "discovered") else 0, "timeout_s": G.O.load_policy()["container_timeout_s"]},
                    "after": [x[1][5:] for x in take if x[1].startswith("step:")]}
            step.update({"adapter": c["adapter"]} if c["kind"] == "builtin_adapter" else {"genome": c["genome"]})
            if c["kind"] == "discovered":
                step.update(version=c["version"], statement_sha=c["statement_sha"])
            queue.append((tuple(x for x in items if x not in take) + ((c["out"], "step:" + sid),), path + (step,)))
    return {"schema": G.PLAN_SCHEMA, "steps": steps, "excluded": ex}


def test_planner_explores_second_match(monkeypatch):
    T = {"types": {"T": {"subtype_of": None}, "X": {"subtype_of": "T"}, "P": {"subtype_of": "T"}, "Q": {"subtype_of": "X"}, "Z": {"subtype_of": "X"}, "D": {"subtype_of": None}}}
    caps = {"f": {"kind": "builtin_adapter", "adapter": "a", "in": "T", "arity": [1, 1], "out": "Z", "verifier": "v"},
            "h": {"kind": "builtin_adapter", "adapter": "b", "in": "X", "arity": [2, 2], "out": "D", "verifier": "v"}}
    monkeypatch.setattr(G, "types", lambda: T)
    monkeypatch.setattr(G, "eligible_caps", lambda store: (caps, []))
    # Q first: the old planner converts Q (useless), then needs a second f step for P: three steps. The shortest plan converts P and merges with Q.
    c = {"deliverable": "D", "budget": {"max_steps": 2}, "inputs": [{"type": "Q"}, {"type": "P"}]}
    assert _old_plan(None, c)["steps"] == []
    new = G.plan_goal(None, c)["steps"]
    assert [(s["op"], s["inputs"]) for s in new] == [("f", ["input:1"]), ("h", ["input:0", "step:s1"])]
    c["budget"]["max_steps"] = 3  # with room the old first-match plan exists, so it is kept as is (cached replays must still match)
    assert G.plan_goal(None, c)["steps"] == _old_plan(None, c)["steps"] and len(G.plan_goal(None, c)["steps"]) == 3


@needs_store
def test_existing_plans_byte_identical(env, auth, store):
    goal_store, allowed = env
    s = Store(goal_store)
    try:
        for goal, srcs in [("merge", ["one.csv", "two.csv", "three.json"]), ("convert", ["one.csv"]), ("merge", ["A", "B"]), ("convert", ["A"])]:
            c, _ = G.prepare(goal_store, allowed, goal, srcs)
            assert json.dumps(G.plan_goal(s, c), sort_keys=True) == json.dumps(_old_plan(s, c), sort_keys=True)
    finally:
        s.close()
    TA.admit(store, auth)  # convert, convert, inventory-diff
    s = Store(store)
    try:
        ins = [("b.csv", "file", TA.BEFORE), ("a.csv", "file", TA.AFTER)]
        c = G.make_contract("compare", ins, deliverable="inventory_diff")
        plan = G.plan_goal(s, c)
        assert [x["op"] for x in plan["steps"]] == ["convert", "convert", "inventory-diff"]
        assert json.dumps(plan, sort_keys=True) == json.dumps(_old_plan(s, c), sort_keys=True)
    finally:
        s.close()


# ---------------------------------------------------------------- follow-ups
def test_longest_keyword_wins_and_real_tie_asks(env):
    store, allowed = env
    c, _ = G.prepare(store, allowed, "merge intervals in this file", ["one.csv"])
    assert c["deliverable"] == "merged_intervals"  # "merge intervals" beats group_summary's "merge"
    c, _ = G.prepare(store, allowed, "merge the batch", ["one.csv"])
    assert c["deliverable"] == "group_summary"
    assert G.prepare(store, allowed, "merge or added", ["one.csv"])[0]["state"] == "NEEDS_CLARIFICATION"  # equal length: a real tie


def test_registry_step_timeout_clamped_to_remaining_wall(env, monkeypatch):
    store, allowed = env
    seen = []

    def fake(src, text, checks, timeout=None, max_out=None, *, backend, operator_class):
        seen.append(timeout)
        ns = {}
        exec(compile(src, "<genome>", "exec"), ns)
        return ns["apply"](text, checks)
    monkeypatch.setattr(EC, "run_isolated", fake)
    c, ins = G.prepare(store, allowed, "convert", ["one.csv"], budget={"wall_s": 10})
    _clock(monkeypatch, 8.0)
    r = G.run_goal(store, c, ins)
    assert r["state"] == "VERIFIED" and seen and seen[-1] <= 2
    seen.clear()
    c, ins = G.prepare(store, allowed, "convert", ["two.csv"], budget={"wall_s": 10})
    _clock(monkeypatch, 11.0)
    r = G.run_goal(store, c, ins)
    assert r["state"] == "BUDGET_EXHAUSTED" and r["steps"] == [] and seen == []
