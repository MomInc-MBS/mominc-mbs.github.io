import base64
import hashlib
import json
import struct
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import resource_profile as RP  # noqa: E402


def reader(b):
    i = [0]

    def recv(n):
        r = b[i[0]:i[0] + n]
        i[0] += n
        return r
    return recv


@pytest.mark.parametrize("n", [0, 5, 125, 126, 300, 65535, 65536, 70000])
def test_frame_round_trip_masked(n):
    data = bytes(range(256)) * (n // 256 + 1)
    data = data[:n]
    f = RP.ws_encode(data, 1, key=b"\x01\x02\x03\x04")
    assert f[1] & 0x80  # masked
    assert f[1] & 0x7F == (n if n < 126 else 126 if n < 65536 else 127)
    if n:
        assert data not in f  # payload really is masked
    assert RP.ws_read(reader(f)) == (1, data)


def test_unmasked_server_frame_and_fragments():
    assert RP.ws_read(reader(b"\x81\x02hi")) == (1, b"hi")
    assert RP.ws_read(reader(b"\x01\x01a\x80\x01b")) == (1, b"ab")
    assert RP.ws_read(reader(b"\x89\x01x")) == (9, b"x")


def test_auth_vector_by_hand():
    pw, salt, ch = "supersecretpassword", "saltsalt", "challengechallenge"
    s = base64.b64encode(hashlib.sha256(b"supersecretpasswordsaltsalt").digest())
    want = base64.b64encode(hashlib.sha256(s + b"challengechallenge").digest()).decode()
    assert RP.auth_string(pw, salt, ch) == want


class Fake:
    def __init__(self, inbound=b""):
        self.sent, self.inb = [], inbound

    def sendall(self, b):
        self.sent.append(b)

    def recv(self, n):
        r, self.inb = self.inb[:n], self.inb[n:]
        return r


def srv(o):
    d = json.dumps(o).encode()
    return bytes([0x81, len(d)]) + d if len(d) < 126 else bytes([0x81, 126]) + struct.pack(">H", len(d)) + d


def test_password_never_in_repr_or_sent_in_clear(tmp_path, monkeypatch):
    cfg = tmp_path / "c.json"
    cfg.write_text(json.dumps({"server_port": 4455, "server_password": "TOPSECRET"}))
    monkeypatch.setattr(RP, "CONFIG", str(cfg))
    assert RP.read_config() == (4455, "TOPSECRET")
    f = Fake(srv({"op": 0, "d": {"authentication": {"salt": "s", "challenge": "c"}}}) + srv({"op": 2, "d": {}}))
    o = RP.Obs(f)
    o.identify("TOPSECRET")
    assert "TOPSECRET" not in repr(o) + str(o) + str(vars(o))
    ident = RP.ws_read(reader(f.sent[0]))[1]
    d = json.loads(ident)["d"]
    assert d["rpcVersion"] == 1 and d["eventSubscriptions"] == 0 and d["authentication"] == RP.auth_string("TOPSECRET", "s", "c")
    assert b"TOPSECRET" not in b"".join(f.sent)


def test_start_stream_refused_with_zero_bytes_sent():
    f = Fake()
    o = RP.Obs(f)
    for t in ("StartStream", "ToggleStream"):
        with pytest.raises(PermissionError):
            o.request(t)
    assert f.sent == []


P = {"min_free_vram_mib": 2000, "max_vram_used_mib": 14000, "max_render_skip_pct": 1, "max_output_skip_pct": 1, "max_obs_cpu_pct": 50,
     "min_ram_available_mib": 4000, "max_encoder_latency_us": 5000}


def S(**k):
    s = {"gpu_mem_used_mib": 10000, "gpu_mem_total_mib": 16000, "renderSkippedFrames": 0, "renderTotalFrames": 100, "outputSkippedFrames": 0, "outputTotalFrames": 100,
         "cpuUsage": 10, "ram_avail_mib": 8000, "enc_latency_us": 1000}
    s.update(k)
    return s


def s1(**k):
    return S(renderTotalFrames=1100, outputTotalFrames=1100, **k)


def test_admission_pass():
    assert RP.admission(P, S(), s1()) == (True, [])


@pytest.mark.parametrize("k,v", [("gpu_mem_used_mib", 15000), ("cpuUsage", 60), ("ram_avail_mib", 100), ("enc_latency_us", 9000), ("renderSkippedFrames", 50), ("outputSkippedFrames", 50)])
def test_admission_each_breach(k, v):
    ok, why = RP.admission(P, S(), s1(**{k: v}))
    assert not ok and why
    if k == "gpu_mem_used_mib":  # 15000 used breaches both the used cap and the free floor
        assert len(why) == 2


@pytest.mark.parametrize("k", ["gpu_mem_used_mib", "cpuUsage", "ram_avail_mib", "enc_latency_us", "renderTotalFrames", "outputSkippedFrames"])
def test_admission_unknown_is_a_stop(k):
    b = s1()
    b[k] = None
    a = S()
    a[k] = None
    ok, why = RP.admission(P, a, b)
    assert not ok and any(w.startswith("unknown:") for w in why)
    assert RP.admission({"made_up": 1}, S(), s1()) == (False, ["unknown:made_up"])


def test_summarize_synthetic(tmp_path):
    rows = [S(ts=1, renderTotalFrames=0, renderSkippedFrames=0, outputTotalFrames=0, outputSkippedFrames=0, gpu_util_pct=10, enc_latency_us=100),
            S(ts=2, renderTotalFrames=1000, renderSkippedFrames=10, outputTotalFrames=500, outputSkippedFrames=5, gpu_mem_used_mib=12000, gpu_util_pct=90, enc_latency_us=400)]
    p = tmp_path / "s.jsonl"
    p.write_text("\n".join(map(json.dumps, rows)) + "\n")
    out = RP.summarize([json.loads(x) for x in p.read_text().splitlines()])
    assert out["render_frames"] == 1000 and out["render_skipped"] == 10 and out["render_skip_pct"] == 1.0
    assert out["output_skip_pct"] == 1.0
    assert out["peak_vram_used_mib"] == 12000 and out["min_free_vram_mib"] == 4000
    assert out["peak_gpu_util_pct"] == 90 and out["max_encoder_latency_us"] == 400
    assert out["fields"]["gpu_util_pct"] == {"min": 10, "max": 90, "mean": 50.0}


def test_sample_without_obs_is_null_not_crash():
    s = RP.sample(None)
    assert s["obs"] == "unavailable" and s["cpuUsage"] is None and "ram_avail_mib" in s
