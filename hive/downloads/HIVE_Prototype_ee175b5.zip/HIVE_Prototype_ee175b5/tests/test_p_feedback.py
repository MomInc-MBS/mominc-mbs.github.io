import json

from hive import discovery as D


def test_first_diff_lines():
    a = json.dumps({"refs": [{"raw": "x"}, {"raw": "a.png"}]})
    b = json.dumps({"refs": [{"raw": "x"}, {"raw": "a.png?v=1"}]})
    assert D._first_diff(a, b) == 'at refs[1] expected {"raw": "a.png"} got {"raw": "a.png?v=1"}'  # the whole wrong row
    assert "expected length 2 got length 1, first differing index 1" in D._first_diff("[1,2]", "[1]")
    assert "missing keys ['b']" in D._first_diff('{"a":1,"b":2}', '{"a":1}')
    t = D._first_diff("hello world", "hello there")
    assert "char 6" in t and "'hello world'" in t and "'hello there'" in t


class _H:
    wrap = staticmethod(lambda body: body)


def _dev(monkeypatch, out, expected):
    monkeypatch.setattr(D.EC, "run_isolated", lambda *a, **k: json.dumps(out))
    return [{"name": f"c{i}", "env": {}, "expected": e} for i, e in enumerate(expected)]


def test_stub_gets_a_leading_line(monkeypatch):
    dev = _dev(monkeypatch, ["ERROR"] * 3, ["a", "b", "c"])
    ok, text = D._dev_run("x", dev, _H())
    assert ok["pass_count"] == 0
    first, rest = text.split("\n", 1)
    assert first.startswith("your function returned the same value 'ERROR' for every case: it is a stub. Write the full implementation of the spec;")
    assert rest.count("case c") == 3  # the usual per-case lines (cap 3) are kept


def test_no_stub_line_when_outputs_differ_or_expected_same(monkeypatch):
    dev = _dev(monkeypatch, ["x", "y"], ["a", "b"])
    assert "stub" not in D._dev_run("x", dev, _H())[1]
    dev = _dev(monkeypatch, ["x", "x"], ["a", "a"])
    assert "stub" not in D._dev_run("x", dev, _H())[1]


from test_g2_acquire import go, hooks, queued, serve, world  # noqa: E402,F401
from test_g2_proposal_fixes import distinct  # noqa: E402


def test_repeat_proposal_feedback_line(world):
    names = ["o0/a"]
    rid = queued(world, names)
    world.mode["v"] = "wrong"
    go(world, rid, hooks(world, names), run_kw=serve(world, [distinct(1)]))  # the stub model repeats the same reply
    from hive.storage import Store
    st = Store(world.store)
    exp = D.experiments(st)[0]
    st.close()
    assert any("duplicate_of" in c for c in exp["calls"])
    assert exp["feedback"].startswith("your reply repeated an earlier proposal exactly; write different code that fixes the failures listed")
