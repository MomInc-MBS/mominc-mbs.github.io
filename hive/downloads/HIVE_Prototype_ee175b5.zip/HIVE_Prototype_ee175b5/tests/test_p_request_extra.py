"""Hosted request_extra: config-only, allowlisted (chat_template_kwargs.enable_thinking bool); anything else refused."""
import pytest
from hive import m2_model as M


@pytest.mark.parametrize("bad", [None, {}, {"chat_template_kwargs": {"enable_thinking": "no"}}, {"chat_template_kwargs": {"enable_thinking": False, "x": 1}},
                                 {"chat_template_kwargs": {"enable_thinking": False}, "headers": {"X": "1"}}, {"tools": []}, [1]])
def test_request_extra_refuses_anything_but_the_thinking_switch(bad):
    with pytest.raises(M.Refused):
        M.request_extra(bad)


def test_request_extra_passes_the_thinking_switch_only():
    assert M.request_extra({"chat_template_kwargs": {"enable_thinking": False}}) == {"chat_template_kwargs": {"enable_thinking": False}}


def test_nemotron_backend_is_hosted_with_thinking_off():
    from hive import discovery as D
    pol = M.apply_backend(D.pol(), "nvidia/nemotron-3.5-super-vl-120b-a12b")
    assert pol["model"]["hosted"] and pol["model"]["request_extra"] == {"chat_template_kwargs": {"enable_thinking": False}}
    assert M.approval_problems(M.ROOT / "build/prototype/approvals/nim-nemotron-3.5-super.approval.json", pol) == [] if hasattr(M, "ROOT") else True


def test_hosted_reply_alias_is_config_only_and_local_backends_stay_exact():
    from hive import discovery as D
    pol = M.apply_backend(D.pol(), "nvidia/nemotron-3.5-super-vl-120b-a12b")
    assert pol["model"]["reply_model_ids"] == ["private/nvidia/nemotron-3.5-super-120b-a12b"]
    assert "reply_model_ids" not in D.pol()["model"]  # gpt-oss (local) still demands its exact id
