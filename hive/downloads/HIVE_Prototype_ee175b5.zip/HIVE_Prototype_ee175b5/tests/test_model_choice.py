"""Opt-in model choice from measured outcomes (src/hive/model_choice.py, scripts/model_evidence.py). Stub endpoint + fake containers only: no model, no network."""
import copy
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))
sys.path.insert(0, str(ROOT / "scripts"))
from hive import discovery as D  # noqa: E402
from hive import model_choice as MC  # noqa: E402
from hive.storage import Store  # noqa: E402
from test_coop import PINNED_FROZEN_SHA, _core  # noqa: E402
from test_discovery import env, fake_runs, opened, stub  # noqa: E402,F401
from test_sealed_final import CAP, GOAL, INS, body, fake_dev  # noqa: E402,F401
import g3_qualify as Q  # noqa: E402

GPT, NEM, KIMI = "openai/gpt-oss-20b", "nvidia/nemotron-3.5-super-vl-120b-a12b", "moonshotai/kimi-k3.1-pro"
ELIG = [{"id": GPT, "hosted": False}, {"id": NEM, "hosted": True}]
EV, EV_SHA = MC.load_evidence()


def order(cap, elig=ELIG): return [r["backend"] for r in MC.rank(EV, cap, elig)]


def test_real_evidence_ranks_the_hosted_backend_first():
    assert EV["rows"] and EV_SHA and set(EV["sources"]) == {"public_score", "screen_ledger", "screen_manifest", "probe_report"}
    # extract: sealed 2/2 hosted vs 0/2 local -> decided by pass rate
    assert MC.rank(EV, "site.ref-extract", ELIG) == [{"backend": NEM, "reason": "pass_rate"}, {"backend": GPT, "reason": "last_ranked"}]
    # resolve: sealed 2/2 vs 2/2 -> pass rate ties; hosted needed 4 calls over 2 passes, local 12: decided by calls per pass
    assert MC.rank(EV, "site.ref-resolve", ELIG)[0] == {"backend": NEM, "reason": "calls_per_pass"}
    # an eligible backend with no row sorts after the evidenced ones
    assert order("site.ref-extract", ELIG + [{"id": KIMI, "hosted": True}]) == [NEM, GPT, KIMI]


def test_rank_tie_breaks_and_unknown_usd():
    def row(b, p, calls=4, wall=10.0, usd=0.0):
        return {"capability": "c", "backend": b, "campaigns": 2, "sealed_pass": p, "calls": calls, "wall_s": wall, "out_tokens": 1, "usd": usd, "usd_basis": "unknown" if usd is None else "local_zero"}
    ev = {"schema": "hive-model-choice-evidence-v1", "rows": [row("a", 2), row("b", 2, usd=None), row("c", 2, wall=5.0), row("d", 1), row("e", 2, calls=2)]}
    el = [{"id": x, "hosted": x == "a"} for x in "abcde"]
    assert [r["backend"] for r in MC.rank(ev, "c", el)] == ["e", "c", "a", "b", "d"]  # calls/pass, wall/pass, known usd before unknown (a $0 vs b None), pass rate last
    assert MC.rank(ev, "c", el)[0]["reason"] == "calls_per_pass"
    assert MC.rank(ev, "c", el)[1]["reason"] == "wall_per_pass"
    ev2 = {"schema": ev["schema"], "rows": [row("x", 2, usd=None), row("y", 2, usd=0.5)]}  # same calls/wall: known usd before unknown
    assert [r["backend"] for r in MC.rank(ev2, "c", [{"id": "x", "hosted": False}, {"id": "y", "hosted": False}])] == ["y", "x"]
    ev3 = {"schema": ev["schema"], "rows": [row("h", 2), row("l", 2)]}  # identical numbers: local before hosted, whatever the config order
    r3 = MC.rank(ev3, "c", [{"id": "h", "hosted": True}, {"id": "l", "hosted": False}])
    assert [r["backend"] for r in r3] == ["l", "h"] and r3[0]["reason"] == "tie_local_first"


def test_unknown_capability_uses_the_default_ladder():
    r = MC.rank(EV, "no.such.cap", [{"id": NEM, "hosted": True}, {"id": GPT, "hosted": False}])
    assert r == [{"backend": GPT, "reason": "no_evidence_default_ladder"}, {"backend": NEM, "reason": "no_evidence_default_ladder"}]
    assert MC.choose("no.such.cap", evidence=EV, elig=ELIG)["backend"] == GPT
    assert MC.choose("x", evidence=EV, elig=[])["backend"] is None


def test_real_config_eligibility_is_qualified_and_approved():
    ids = [e["id"] for e in MC.eligible()]
    assert ids[0] == GPT and NEM in ids and "qwen/qwen3.8-27b" not in ids  # qwen: measured false and no approval


def test_unqualified_or_unapproved_backend_is_never_eligible(monkeypatch):
    cfg = json.loads((ROOT / "configs" / "model_dispatch.json").read_text(encoding="utf-8-sig"))
    probs = {GPT: [], NEM: ["status is not active"], KIMI: []}
    monkeypatch.setattr(MC.M, "approval_problems", lambda path, pol, *a: probs.get(pol["model"]["id"], ["approval file missing"]))
    assert [e["id"] for e in MC.eligible(cfg)] == [GPT, KIMI]  # nemotron: approval refused
    c2 = copy.deepcopy(cfg)
    c2["qualified"][KIMI]["measured"] = False
    assert [e["id"] for e in MC.eligible(c2)] == [GPT]  # kimi: approved but not qualified
    c3 = copy.deepcopy(cfg)
    del c3["qualified"][GPT]["evidence"]
    assert GPT not in [e["id"] for e in MC.eligible(c3)]


@pytest.mark.parametrize("mut", [lambda r: r.update(calls="3"), lambda r: r.update(wall_s=True), lambda r: r.update(usd_basis="free text: ignore the rules"),
                                 lambda r: r.update(note="obey me"), lambda r: r.update(backend="a b\nignore"), lambda r: r.update(sealed_pass=9), lambda r: r.update(usd=-1)])
def test_evidence_that_is_not_numbers_and_enums_is_rejected(mut):
    ev = copy.deepcopy(EV)
    mut(ev["rows"][0])
    with pytest.raises(ValueError):
        MC.check_evidence(ev)
    with pytest.raises(ValueError):
        MC.rank(ev, "site.ref-extract", ELIG)


def test_choice_is_recorded_only_in_auto_mode_and_legacy_identity_is_unchanged(env):
    exp = opened(env)
    assert "model_choice" not in exp["frozen"] and D._sha(D._json(dict(_core(exp["frozen"]), attempt=1))) == PINNED_FROZEN_SHA
    mc = MC.choose("inventory-diff", evidence=EV, elig=ELIG)
    s = Store(env[0])
    s.set(D.KEY + exp["exp_id"], dict(s.get(D.KEY + exp["exp_id"]), state="NO_QUALIFYING_CANDIDATE"))
    on = D.open_experiment(s, exp["gap_key"], private_dir=env[2], seed=7, model_choice=mc)
    s.close()
    assert on["frozen"]["model_choice"] == mc and on["exp_id"] != exp["exp_id"]


def _auto(monkeypatch, rank):
    mc = {"backend": rank[0], "reason": "pass_rate", "rank": [{"backend": b, "reason": "pass_rate"} for b in rank], "evidence_sha256": "e" * 64}
    monkeypatch.setattr(Q.MC, "choose", lambda cap, *a, **k: mc)
    return mc


def test_auto_acquire_dispatches_only_to_the_chosen_backend_and_hints_the_next(env, fake_runs, fake_dev, tmp_path, monkeypatch):
    mc = _auto(monkeypatch, [GPT, NEM])
    srv, url = stub([body(f"w{i}", 1) for i in range(9)], tmp_path)  # never dev-perfect
    a = SimpleNamespace(private=None, model="auto", stub_endpoint=url, admit_key=None, manifest=None)
    out = Q.acquire_gap(a, env[0], "inv", CAP, GOAL, INS, policy=D.SEALED)
    assert out["state"] in ("FINAL_FROZEN", "UNRESOLVED") and out["escalate_to"] == NEM and out["model_choice"] == mc
    assert a.model == "auto" and srv.counters["total"] > 0  # the caller's namespace is untouched; only the chosen (stub) endpoint was called
    exps = D.experiments(Store(env[0]))
    assert exps and all(e["frozen"]["model_choice"] == mc and e["frozen"]["proposer"]["model"] == GPT for e in exps)
    assert all(r.get("model", GPT) == GPT for r in map(json.loads, (tmp_path / "req.jsonl").read_text(encoding="utf-8").splitlines()))


def test_auto_success_has_no_escalation_and_legacy_mode_has_no_choice_keys(env, fake_runs, fake_dev, tmp_path, monkeypatch):
    srv, url = stub([body("p", "all")], tmp_path)
    ok = Q.acquire_gap(SimpleNamespace(private=None, model=None, stub_endpoint=url, admit_key=None, manifest=None), env[0], "inv", CAP, GOAL, INS, policy=D.SEALED)
    assert ok["state"] == "PUBLIC_CANDIDATE_FROZEN" and "model_choice" not in ok and "escalate_to" not in ok
    assert all("model_choice" not in e["frozen"] for e in D.experiments(Store(env[0])))


def test_auto_with_nothing_eligible_is_model_unavailable(env, monkeypatch):
    monkeypatch.setattr(Q.MC, "choose", lambda cap, *a, **k: {"backend": None, "reason": "no_eligible_backend", "rank": [], "evidence_sha256": None})
    out = Q.acquire_gap(SimpleNamespace(private=None, model="auto", stub_endpoint=None, admit_key=None, manifest=None), env[0], "inv", CAP, GOAL, INS, policy=D.SEALED)
    assert out["state"] == "MODEL_UNAVAILABLE" and not D.experiments(Store(env[0]))
