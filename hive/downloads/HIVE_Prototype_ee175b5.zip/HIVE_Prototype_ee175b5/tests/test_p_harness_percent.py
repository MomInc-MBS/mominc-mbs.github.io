"""evaluator/g2 harness: a candidate whose source contains % characters must run (wrap_dev used to %-format the source into its header)."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "evaluator" / "g2"))
import harness as H  # noqa: E402

BODY = "def run(env):\n    s = '%41%zz'\n    return s.replace('%41', 'A') + ' %d' % 7\n\ndef bad(env):\n    raise ValueError('x')\n"


def _apply(src, envs):
    g = {"__name__": "candidate"}
    exec(compile(src, "candidate", "exec"), g)
    return json.loads(g["apply"](json.dumps(envs), {}))


def test_wrap_dev_runs_a_body_with_percent_signs():
    out = _apply(H.wrap_dev(BODY), [{}, {}])
    assert out["out"] == ["A%zz 7", "A%zz 7"] and out["err"] == [None, None]


def test_wrap_dev_line_numbers_still_point_into_the_body():
    body = "def run(env):\n    x = '%'\n    raise KeyError('boom')\n"
    out = _apply(H.wrap_dev(body), [{}])
    assert out["out"] == [None] and "adapter line 3" in out["err"][0] and "raise KeyError" in out["err"][0]
