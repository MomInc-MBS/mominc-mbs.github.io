"""G2 gate-run fixes: A single-module tools, B pre-inspection ranking, C cheap pre-stage rejections cost an inspection (not an attempt),
D per-repo pre-score in the manifest. Fake search results, local fixture git repos, fake docker. Nothing names a real repo or tool."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))
from hive import acq_card as AC, acq_github as AG, acq_stage as ST, acquire as A, capcontract as CC  # noqa: E402
from hive.storage import Store  # noqa: E402
from test_g2_acquire import CAP, GOODBODY, POL, FakeStager, go, hooks, items, queued, serve, world  # noqa: E402,F401
from test_g2_stage import REPO, FakeDocker, make_repo, make_wheel  # noqa: E402

MIT = "Permission is hereby granted, free of charge, to any person obtaining a copy of this software.\n"
MOD = "def compare(a, b):\n    '''Distance between two hashes.'''\n    return a ^ b\n\n\ndef make(raw):\n    '''Hash raw bytes.'''\n    return 1\n"


def mod_repo(tmp, extra=None, name="repo"):
    files = {"LICENSE": MIT, "README.md": "# tool\n\nA tiny single file helper that fingerprints things for you in a very small way.\n", "hasher.py": MOD}
    files.update(extra or {})
    repo, sha = make_repo(Path(tmp) / name, files)
    return AC.build_card(repo, sha, "o/hasher", POL, Path(tmp) / "cache", api_license="MIT"), repo, sha


# ================================================================= A. single-module tools
def test_module_named_like_the_repo_is_a_tool(tmp_path):
    c, _, _ = mod_repo(tmp_path)
    assert c["packages"] == [] and c["modules"] == ["hasher.py"] and AC.admissible(c, POL) is None
    assert [i["sig"] for i in c["interfaces"]] == ["compare(a, b)", "make(raw)"] and c["interfaces"][0]["module"] == "hasher"
    assert "hasher" in AC.excerpt(c)


@pytest.mark.parametrize("extra,declared", [
    ({"setup.py": "from setuptools import setup\nsetup(name='whatever', py_modules=['hasher'])\n", "hasher.py": MOD}, "setup.py"),
    ({"setup.cfg": "[options]\npy_modules =\n    hasher\n"}, "setup.cfg"),
    ({"pyproject.toml": "[tool.setuptools]\npy-modules = ['hasher']\n[project]\nname='zzz'\n"}, "pyproject"),
    ({"setup.py": "setup(name='hasher')\n"}, "dist name from setup.py")])
def test_module_found_by_static_declaration_or_distribution_name(tmp_path, extra, declared):
    files = {"LICENSE": MIT, "README.md": "# t\n\nSome sufficiently long description of the tool goes right here.\n", "hasher.py": MOD, "other.py": "X = 1\n"}
    files.update(extra)
    repo, sha = make_repo(tmp_path / declared.replace(" ", "_"), files)
    c = AC.build_card(repo, sha, "o/not-the-name", POL, tmp_path / "cache", api_license="MIT")
    assert c["modules"] == ["hasher.py"], declared


def test_unrelated_top_level_files_are_not_modules(tmp_path):
    c, _, _ = mod_repo(tmp_path, {"hasher.py": None} if False else None)
    repo, sha = make_repo(tmp_path / "x", {"LICENSE": MIT, "README.md": "# t\n\nSome sufficiently long description of the tool goes right here.\n", "utils.py": MOD, "setup.py": "setup(name='zz')\n", "test_a.py": "x=1\n"})
    c = AC.build_card(repo, sha, "o/other", POL, tmp_path / "cache", api_license="MIT")
    assert c["modules"] == [] and AC.admissible(c, POL) == "NO_IMPORTABLE_PACKAGE"


def test_src_layout_module_and_hostile_setup_py(tmp_path):
    repo, sha = make_repo(tmp_path, {"LICENSE": MIT, "README.md": "# t\n\nSome sufficiently long description of the tool goes right here.\n", "src/hasher.py": MOD,
                                     "setup.py": "x = " + "(" * 150 + "1" + ")" * 150 + "\nsetup(py_modules=['hasher'])\n"})
    c = AC.build_card(repo, sha, "o/hasher", POL, tmp_path / "cache", api_license="MIT")
    assert c["modules"] == ["src/hasher.py"]  # the name match still finds it; the unparseable setup.py declares nothing and crashes nothing


def test_package_dir_wins_over_a_module(tmp_path):
    c, _, _ = mod_repo(tmp_path, {"hasher/__init__.py": MOD})
    assert c["packages"] == ["hasher"] and c["modules"] == []


def test_vendor_module_checks_and_stage_installs_it_at_the_top_level(tmp_path):
    c, repo, sha = mod_repo(tmp_path)
    files, t = ST.vendor_module(repo, sha, "hasher.py", POL, tmp_path / "cc")
    assert list(files) == ["hasher.py"] and t == ST.vendor_module(repo, sha, "hasher.py", POL, tmp_path / "cc2")[1]
    p = dict(POL, limits=dict(POL["limits"], max_file_bytes=20))
    with pytest.raises(ST.StageRejected) as e:
        ST.vendor_module(repo, sha, "hasher.py", p, tmp_path / "cc3")
    assert e.value.code == "VENDOR_FILE_REFUSED"
    for bad in ("json", "sitecustomize", "os"):
        r2, s2 = make_repo(tmp_path / ("m" + bad), {bad + ".py": "A = 1\n"})
        with pytest.raises(ST.StageRejected) as e:
            ST.vendor_module(r2, s2, bad + ".py", POL, tmp_path / "cc4")
        assert e.value.code == "VENDOR_NAME_REFUSED"
    f = FakeDocker()
    env = ST.Stager(POL, run=f, prefix="hive-stage-mod").stage(repo, c, tmp_path / "store", tmp_path / "cc5", downloader=lambda r, d: None)
    assert env["packages"] == ["hasher"] and env["vendored_files"] == 1
    smoke = next(x for x in f.calls if x[1] == "run")
    assert smoke[-1] == "import hasher"


# ================================================================= B. pre-inspection ranking
def repo(name, qs, desc="", size=100, pushed="2026-01-01", stars=0, **kw):
    return dict({"full_name": name, "url": "https://github.com/" + name, "description": desc, "license_spdx": "MIT", "stars": stars, "pushed_at": pushed, "size_kb": size,
                 "archived": False, "fork": False, "topics": [], "queries": [q for q, _ in qs], "hits": [{"q": q, "pos": p} for q, p in qs]}, **kw)


TERMS = ["image", "duplicate", "manifest", "perceptual"]


def order(repos, terms=TERMS, cap=1000):
    ranked, skipped = AG.rank_hits(repos, terms, cap)
    return [r["full_name"] for r, _ in ranked], skipped


def test_more_distinct_queries_beat_everything_else():
    a = repo("o/a", [("q1", 5), ("q2", 5), ("q3", 9)], desc="unrelated words", size=900, stars=0)
    b = repo("o/b", [("q1", 0)], desc="image duplicate manifest perceptual", size=1, stars=10**6)
    assert order([b, a])[0] == ["o/a", "o/b"]


def test_best_position_per_query_then_overlap_then_size_then_recency_then_stars():
    p0, p3 = repo("o/p0", [("q1", 0), ("q2", 1)]), repo("o/p3", [("q1", 3), ("q2", 4)])
    assert order([p3, p0])[0] == ["o/p0", "o/p3"]  # same number of queries, better positions
    same = dict(qs=[("q1", 2)])
    ov = repo("o/ov", **same, desc="finds duplicate image files")
    no = repo("o/no", **same, desc="something else entirely")
    assert order([no, ov])[0] == ["o/ov", "o/no"]  # overlap with the contract/spec/type terms
    small, big = repo("o/small", **same, size=10), repo("o/big", **same, size=500)
    assert order([big, small])[0] == ["o/small", "o/big"]
    new, old = repo("o/new", **same, pushed="2026-05-01T00:00:00Z"), repo("o/old", **same, pushed="2020-05-01T00:00:00Z")
    assert order([old, new])[0] == ["o/new", "o/old"]
    hi, lo = repo("o/hi", **same, stars=500), repo("o/lo", **same, stars=3)
    assert order([lo, hi])[0] == ["o/hi", "o/lo"]  # stars only as the very last tie-break
    assert order([repo("o/b", **same), repo("o/a", **same)])[0] == ["o/a", "o/b"]  # then the name, so the order is deterministic


def test_description_topics_and_name_count_as_overlap_with_light_stemming():
    r = repo("o/image-matcher", [("q", 0)], desc="", topics=["duplicates", "perceptual-hash"])
    ranked, _ = AG.rank_hits([r], TERMS, 1000)
    bd = ranked[0][1]
    assert set(bd["overlap_terms"]) == {"image", "duplicate", "perceptual"} and bd["overlap"] == 3


def test_archived_forks_and_oversized_repos_are_skipped_with_reasons():
    ok = repo("o/ok", [("q", 0)])
    ranked, skipped = AG.rank_hits([repo("o/arch", [("q", 0)], archived=True), repo("o/fork", [("q", 0)], fork=True), repo("o/huge", [("q", 0)], size=5000), ok], TERMS, 1000)
    assert [r["full_name"] for r, _ in ranked] == ["o/ok"]
    assert {r["full_name"]: why.split(":")[0] for r, why, _ in skipped} == {"o/arch": "ARCHIVED", "o/fork": "FORK", "o/huge": "REPO_TOO_LARGE"}
    assert all("n_queries" in bd for _, _, bd in skipped)


def test_search_results_carry_forks_topics_and_positions(tmp_path):
    it = items("o/a", "o/b")
    it[1].update(fork=True, topics=["x", 5, "y" * 80], archived=False)
    gh = AG.GitHubSearch(tmp_path / "c", POL, lambda u, h: (200, {}, json.dumps({"items": it}).encode()))
    got = gh.search("some words")
    assert [r["fork"] for r in got] == [False, True] and got[1]["topics"] == ["x", "y" * 50]


def test_ranking_terms_come_from_contract_spec_and_type_descriptions(world):
    rid = queued(world, ["o0/a"])
    terms = A._ranking_terms(Store(world.store).get(A.KEY + rid))
    assert {"image", "manifest", "duplicate", "png"} <= set(terms) and len(terms) == len(set(terms)) and "the" not in terms and "admitted" not in terms and "registered" not in terms


def test_run_inspects_in_ranked_order_and_records_pre_scores(world):
    names = ["o0/zzz", "o1/aaa", "o2/mmm"]
    rid = queued(world, names)
    its = [dict(items(n)[0]) for n in names]
    its[0]["description"], its[1]["description"], its[2]["description"] = "unrelated", "unrelated", "find duplicate image files and write a manifest"
    its[0]["size"], its[1]["size"], its[2]["size"] = 5, 6, 900  # the smallest would win on size alone
    tr = lambda u, hd: (200, {}, json.dumps({"items": its}).encode())
    h = hooks(world, names, transport=tr)
    rec = go(world, rid, h, run_kw=serve(world, [GOODBODY]))
    assert [i["repo"] for i in rec["inspected"]][0] == "o0/zzz"  # same queries for all three: the better result position decides (overlap and size come later)
    by = {i["repo"]: i["pre_score"] for i in rec["inspected"]}
    assert by["o2/mmm"]["overlap"] >= 3 and by["o0/zzz"]["overlap"] == 0 and by["o0/zzz"]["best_pos"] and by["o0/zzz"]["rank"] == 0
    for i in rec["inspected"]:
        pre = i["pre_score"]
        assert {"queries", "n_queries", "best_pos", "pos_score", "overlap", "overlap_terms", "size_kb", "pushed_at", "stars", "rank"} <= set(pre)
    st = Store(world.store)
    m = A.manifest(st, rec)
    st.close()
    assert "skipped_before_inspection" in m
    assert [i["pre_score"]["rank"] for i in m["inspected"]] == sorted(i["pre_score"]["rank"] for i in m["inspected"])


# ================================================================= C. cheap pre-stage failures never use an attempt
def test_prestage_rejection_costs_an_inspection_not_an_attempt(world):
    names = ["o0/a", "o1/b"]
    shadow = {"LICENSE": MIT, "README.md": REPO["README.md"], "pyproject.toml": REPO["pyproject.toml"], "json/__init__.py": "def f():\n    '''x'''\n    return 1\n"}
    rid = queued(world, names, files=REPO)
    # first candidate: a package that would shadow the standard library (cheap local rejection); second: fine
    from test_g2_acquire import make_repos
    world.local, world.sha = {}, {}
    for nm, files in (("o0/a", shadow), ("o1/b", REPO)):
        r, sha = make_repo(world.tmp / ("p" + nm.replace("/", "_")), files)
        world.local["https://github.com/" + nm], world.sha["https://github.com/" + nm] = r, sha
    h = hooks(world, names)
    rec = go(world, rid, h, run_kw=serve(world, [GOODBODY]))
    rej = next(i for i in rec["inspected"] if i["repo"] == "o0/a")
    assert rej["rejection"].startswith("VENDOR_NAME_REFUSED")
    assert rec["ledger"]["attempts"] == 1 and [a["repo"] for a in rec["attempts"]] == ["o1/b"] and world.stager.stages == ["o1/b"]
    assert rec["ledger"]["builds"] == 1


def test_licence_compiled_and_no_module_rejections_never_become_attempts(world):
    bad = {"o0/gpl": dict(REPO, LICENSE="GNU GENERAL PUBLIC LICENSE Version 3\n"), "o1/c": dict(REPO, **{"src/x.c": "int x;\n"}),
           "o2/none": {"LICENSE": MIT, "README.md": REPO["README.md"], "x.txt": "nothing\n"}, "o3/ok": REPO}
    names = list(bad)
    rid = queued(world, names)
    world.local, world.sha = {}, {}
    for nm, files in bad.items():
        r, sha = make_repo(world.tmp / ("q" + nm.replace("/", "_")), files)
        world.local["https://github.com/" + nm], world.sha["https://github.com/" + nm] = r, sha
    rec = go(world, rid, hooks(world, names), run_kw=serve(world, [GOODBODY]))
    codes = {i["repo"]: (i["rejection"] or "ok").split(":")[0] for i in rec["inspected"]}
    assert codes == {"o0/gpl": "LICENSE_NOT_ALLOWED", "o1/c": "COMPILED_OR_SDIST_ONLY", "o2/none": "NO_IMPORTABLE_PACKAGE", "o3/ok": "ok"}
    assert rec["ledger"]["attempts"] == 1 and len(rec["attempts"]) == 1 and rec["attempts"][0]["repo"] == "o3/ok"
    assert len(rec["inspected"]) <= rec["frozen"]["budget"]["inspect"]


def test_a_single_module_candidate_is_staged_and_adapted_end_to_end(world):
    names = ["o0/hasher"]
    rid = queued(world, names)
    world.local, world.sha = {}, {}
    r, sha = make_repo(world.tmp / "single", {"LICENSE": MIT, "README.md": REPO["README.md"], "hasher.py": MOD})
    world.local["https://github.com/o0/hasher"], world.sha["https://github.com/o0/hasher"] = r, sha
    body = "```python\nimport json\nimport hasher\n\n\ndef run(env):\n    return json.dumps({})\n```"
    rec = go(world, rid, hooks(world, names), run_kw=serve(world, [GOODBODY]))
    assert rec["inspected"][0]["rejection"] is None and body  # card + local prestage accepted the single-file tool
    assert rec["state"] == "AWAITING_ADMISSION" and world.stager.stages == ["o0/hasher"]  # (the fake stager's package list is its own; the real stager is covered above)
