"""G2 gate-run-2 fixes: (1) one policy git timeout, (2) runtime dependencies from declarations first, (3) script entry points allowed unless they
collide with the base image or start with python/pip. Docker-free except one opt-in listing of the real base image."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import zipfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))
from hive import acq_card as AC, acq_stage as ST, acquire as A, repo_intel as RI  # noqa: E402
from hive.adapters.isolation import PINNED_IMAGE  # noqa: E402
from test_g2_acquire import GOODBODY, POL, go, hooks, queued, serve, world  # noqa: E402,F401
from test_g2_stage import REPO, make_repo, make_wheel  # noqa: E402

MIT = "Permission is hereby granted, free of charge, to any person obtaining a copy of this software.\n"
README = "# t\n\nSome sufficiently long description of the tool goes right here for the card.\n"


# ================================================================= 1. timeouts
def test_policy_git_timeout_is_180_and_is_the_default_everywhere():
    assert POL["limits"]["git_timeout_s"] == 180 and RI.GIT_TIMEOUT_S == 180


def test_clone_and_lazy_reads_use_the_policy_timeout(tmp_path, monkeypatch):
    repo, sha = make_repo(tmp_path, REPO)
    seen = []
    real = subprocess.run

    def spy(argv, **kw):
        if "fetch" in argv:
            seen.append(kw.get("timeout"))
        return real(argv, **kw)
    monkeypatch.setattr(RI.subprocess, "run", spy)
    RI.clone_pinned(str(repo), sha, tmp_path / "c1")
    RI.clone_pinned(str(repo), sha, tmp_path / "c2", timeout=33)
    assert seen == [180, 33]
    seen.clear()
    monkeypatch.setattr(RI, "GIT_TIMEOUT_S", 77)
    RI.clone_pinned(str(repo), sha, tmp_path / "c3")
    assert seen == [77]


def test_acquire_run_applies_the_policy_timeout_to_every_git_call(world, monkeypatch):
    monkeypatch.setattr(RI, "GIT_TIMEOUT_S", 5)
    rid = queued(world, ["o0/a"])
    h = hooks(world, ["o0/a"])
    h["policy"] = dict(POL, limits=dict(POL["limits"], git_timeout_s=211))
    go(world, rid, h, run_kw=serve(world, [GOODBODY]))
    assert RI.GIT_TIMEOUT_S == 211


def test_blobless_depth_one_fetch_time_on_a_local_repo(tmp_path):
    files = {f"pkg/m{i}.py": f"X = {i}\n" * 200 for i in range(80)}
    files.update({"LICENSE": MIT, "README.md": README})
    repo, sha = make_repo(tmp_path, files)
    for i in range(10):  # history that a depth-1 fetch must not take
        (repo / "pkg" / "m0.py").write_text(f"X = {i}\n" * 300, encoding="utf-8")
        subprocess.run(["git", "-C", str(repo), "commit", "-qam", f"h{i}"], check=True, capture_output=True)
    head = subprocess.run(["git", "-C", str(repo), "rev-parse", "HEAD"], capture_output=True, text=True, check=True).stdout.strip()
    t0 = time.perf_counter()
    dest = RI.clone_pinned(str(repo), head, tmp_path / "clone", max_bytes=POL["limits"]["max_clone_bytes"])
    elapsed = time.perf_counter() - t0
    n = int(subprocess.run(["git", "-C", str(dest), "rev-list", "--count", head], capture_output=True, text=True, check=True).stdout.strip())
    print(f"BLOBLESS_DEPTH1_FETCH_SECONDS={elapsed:.3f}")
    assert n == 1 and elapsed < POL["limits"]["git_timeout_s"] / 10  # one commit, no history, far inside the 180 s policy timeout
    assert RI.SelectiveFetcher(dest, RI.ContentCache(tmp_path / "cc")).fetch(head, "LICENSE").startswith(b"Permission")  # blobs arrive on demand


# ================================================================= 2. dependency selection
def deps_of(tmp, files, name="r"):
    base = {"LICENSE": MIT, "README.md": README, "vtool/__init__.py": "def f():\n    '''x'''\n    return 1\n"}
    base.update(files)
    repo, sha = make_repo(Path(tmp) / name, base)
    return [d["name"] for d in AC.build_card(repo, sha, "o/vtool", POL, Path(tmp) / "cache", api_license="MIT")["deps"]]


def test_declared_runtime_deps_win_over_any_requirements_file(tmp_path):
    dev = {"dev-requirements.txt": "pygments\npytest\n", "requirements-dev.txt": "pygments\n", "requirements.txt": "pygments\n"}
    assert deps_of(tmp_path, dict(dev, **{"pyproject.toml": "[project]\nname='v'\ndependencies=['numpy>=1']\n"}), "a") == ["numpy"]
    assert deps_of(tmp_path, dict(dev, **{"setup.cfg": "[options]\ninstall_requires =\n    six\n"}), "b") == ["six"]
    assert deps_of(tmp_path, dict(dev, **{"setup.py": "from setuptools import setup\nsetup(name='v', install_requires=['attrs', 'idna>=2'])\n"}), "c") == ["attrs", "idna"]
    assert deps_of(tmp_path, dict(dev, **{"pyproject.toml": "[project]\nname='v'\ndependencies=[]\n"}), "d") == []  # declared empty: no fallback


def test_requirements_file_only_when_nothing_is_declared(tmp_path):
    assert deps_of(tmp_path, {"requirements.txt": "# c\nsix\n-r other.txt\nattrs>=2\n"}, "a") == ["six", "attrs"]
    assert deps_of(tmp_path, {"requirements-prod.txt": "six\n", "requirements.txt": "attrs\n"}, "b") == ["six", "attrs"]  # sorted file order


@pytest.mark.parametrize("name", ["requirements-dev.txt", "dev-requirements.txt", "test-requirements.txt", "requirements_test.txt", "docs-requirements.txt",
                                  "requirements-doc.txt", "lint-requirements.txt", "ci-requirements.txt", "requirements-ci.txt", "requirements-examples.txt",
                                  "example_requirements.txt", "requirements.dev.txt", "requirements/base.txt"])
def test_non_runtime_requirements_files_are_never_read(tmp_path, name):
    assert deps_of(tmp_path, {name: "pygments\n"}, "x") == []
    assert AC.req_files([name]) == []


def test_requirements_file_name_filter_is_by_word_not_substring():
    assert AC.req_files(["requirements.txt", "requirements-specific.txt", "contest-requirements.txt", "requirements-dev.txt", "README.txt", "sub/requirements.txt"]) == \
        ["contest-requirements.txt", "requirements-specific.txt", "requirements.txt"]


def test_hostile_setup_py_declares_nothing_and_crashes_nothing(tmp_path):
    bad = "x = " + "(" * 6000 + "1" + ")" * 6000 + "\nsetup(install_requires=['a'])\n"
    assert deps_of(tmp_path, {"setup.py": bad, "requirements.txt": "six\n"}, "h") == ["six"]


# ================================================================= 3. script entry points
LS = ("/usr/local/bin:\npython\npython3\npip\n\n/usr/bin:\nenv\nls\nperl\n\n/bin:\nsh\nbash\n").encode()


class Docker:
    def __init__(self, out=LS, rc=0):
        self.calls, self.out, self.rc = [], out, rc

    def __call__(self, argv, timeout):
        self.calls.append(list(argv))
        return (self.rc, self.out, b"") if argv[1] == "run" else (0, b"", b"")


def ep(tmp, text, n=[0]):
    n[0] += 1
    return make_wheel(Path(tmp) / f"e{n[0]}", extra={"tinydep-1.0.dist-info/entry_points.txt": text})


def test_ordinary_console_and_gui_scripts_are_allowed(tmp_path):
    d = Docker()
    s = ST.Stager(POL, run=d)
    assert s.scan_wheel(ep(tmp_path, "[console_scripts]\ntinytool = tinydep:main\nother-tool = tinydep:x [extra]\n[gui_scripts]\ntinygui = tinydep:g\n"))["name"] == "tinydep"
    assert s.scan_wheel(ep(tmp_path, "[tinydep.plugins]\nls = a:b\n"))  # not a script section: nothing to check
    assert sum(1 for c in d.calls if c[1] == "run") == 1  # the listing ran once, only because scripts exist


@pytest.mark.parametrize("script", ["python3", "Python", "pip", "pip3.11", "pipx", "python-config"])
def test_python_and_pip_script_names_are_refused(tmp_path, script):
    with pytest.raises(ST.StageRejected, match="entry point"):
        ST.Stager(POL, run=Docker()).scan_wheel(ep(tmp_path, f"[console_scripts]\n{script} = x:y\n"))


@pytest.mark.parametrize("script", ["ls", "env", "sh", "perl", "bash"])
def test_names_already_in_the_base_image_are_refused(tmp_path, script):
    with pytest.raises(ST.StageRejected, match="already in the base image"):
        ST.Stager(POL, run=Docker()).scan_wheel(ep(tmp_path, f"[console_scripts]\n{script} = x:y\n"))


@pytest.mark.parametrize("script", ["../evil", "a b", "-x", ".hidden", "a/b", "x" * 80])
def test_script_name_pattern_is_enforced(tmp_path, script):
    with pytest.raises(ST.StageRejected, match="entry point"):
        ST.Stager(POL, run=Docker()).scan_wheel(ep(tmp_path, f"[console_scripts]\n{script} = x:y\n"))


def test_base_listing_is_cached_by_digest_in_memory_and_on_disk(tmp_path):
    d = Docker()
    s = ST.Stager(POL, run=d, cache_dir=tmp_path / "cache")
    names = s.base_executables()
    assert {"python", "pip", "ls", "env", "sh", "bash", "perl"} <= names and "/usr/bin:" not in names
    s.base_executables()
    listing = [c for c in d.calls if c[1] == "run"]
    assert len(listing) == 1 and PINNED_IMAGE["digest"] in " ".join(listing[0]) and "--network=none" in listing[0] and "ls" in listing[0]
    f = tmp_path / "cache" / f"base-bins-{PINNED_IMAGE['digest'].split(':')[-1][:16]}.json"
    assert f.is_file() and "ls" in json.loads(f.read_text(encoding="utf-8"))

    def never(argv, timeout):
        raise AssertionError("must come from the cache")
    assert "ls" in ST.Stager(POL, run=never, cache_dir=tmp_path / "cache").base_executables()  # a new process reads the digest-keyed file


def test_unlistable_base_fails_closed(tmp_path):
    with pytest.raises(ST.StageRejected, match="could not be listed"):
        ST.Stager(POL, run=Docker(out=b"", rc=1)).scan_wheel(ep(tmp_path, "[console_scripts]\nfine = x:y\n"))
    with pytest.raises(ST.StageRejected, match="could not be listed"):
        ST.Stager(POL, run=Docker(out=b"", rc=0)).scan_wheel(ep(tmp_path, "[console_scripts]\nfine = x:y\n"))


def test_wheels_without_scripts_never_touch_docker(tmp_path):
    d = Docker()
    ST.Stager(POL, run=d).scan_wheel(make_wheel(tmp_path))
    assert not d.calls


def test_data_scripts_dir_is_still_refused(tmp_path):
    with pytest.raises(ST.StageRejected, match="outside purelib/platlib"):
        ST.Stager(POL, run=Docker()).scan_wheel(make_wheel(tmp_path, extra={"tinydep-1.0.data/scripts/x": "y"}))


@pytest.mark.skipif(os.environ.get("HIVE_REAL_DOCKER") != "1", reason="opt-in: runs one real throwaway container to list the base image")
def test_real_base_image_listing(tmp_path):
    s = ST.Stager(POL, prefix="hive-stage-bins", cache_dir=tmp_path)
    names = s.base_executables()
    assert {"python", "python3", "pip", "ls", "sh"} <= names
    assert subprocess.run(["docker", "ps", "-a", "-q", "--filter", "name=hive-stage-bins"], capture_output=True, text=True).stdout.strip() == ""
