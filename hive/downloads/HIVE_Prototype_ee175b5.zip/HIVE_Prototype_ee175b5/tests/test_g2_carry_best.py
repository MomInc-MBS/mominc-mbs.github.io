"""Carry the best dev candidate into the next prompt, and retry a repository once when it made dev progress. No model, no network."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))
from hive import acquire as A, capcontract as CC, discovery as D  # noqa: E402
from hive.operator_runtime import Refused  # noqa: E402
from hive.storage import Store  # noqa: E402
from test_g2_acquire import GOODBODY, FakeStager, go, hooks, queued, serve, world  # noqa: E402,F401

DEV = [{"name": f"c{i}", "env": {"files": []}, "expected": "e"} for i in range(4)]


def test_note_feedback_keeps_best_body_latest_wins_ties():
    rec = {"feedback": ""}
    D._note_feedback(rec, 1, 2, 4, "t1", "body1")
    D._note_feedback(rec, 2, 1, 4, "t2", "body2")
    assert rec["best"]["body"] == "body1" and rec["best"]["dev_pass"] == 2
    D._note_feedback(rec, 3, 2, 4, "t3", "body3")
    assert rec["best"]["body"] == "body3"


def test_seed_best_validation_and_prompt(world):
    queued(world, ["o0/a"])
    rec = _frozen(world)
    secret = "HIDDEN-ANSWER-123"
    assert "best previous" not in D.prompt(rec, DEV)[1]["content"]
    rec["feedback"] = "case c0: expected e got x"
    assert "best previous" not in D.prompt(rec, DEV)[1]["content"]  # no best yet
    rec["best"] = {"sha256": "s", "dev_pass": 3, "body": "def run(env):\n    return 'mine'\n" + "#" * 7000}
    u = D.prompt(rec, DEV)[1]["content"]
    assert "(dev 3 of 4 passed)" in u and "def run(env):" in u and "Fix it; keep what works." in u and u.index("best previous") < u.index("failed on the cases")
    assert u.count("#") <= 6000 and secret not in u
    rec["frozen"]["budget"]["max_prompt_tokens"] = (len(D.system_for(D.contract_of(rec), rec)) + len(D.prompt(rec, DEV)[1]["content"])) // 4 - 800
    rec["best"]["body"] = "x" * 6000
    small = D.prompt(rec, DEV)
    assert "best previous" not in small[1]["content"] and "failed on the cases" in small[1]["content"]


def _frozen(world, **kw):
    s = Store(world.store)
    try:
        env = FakeStager().stage(None, {"repo": "o0/a"}, world.tmp / "img", None)
        return D.open_experiment(s, world.goal["gap_ref"], private_dir=world.tmp / "priv", seed=5, environment=CC.env_record(env), tool_modules=["vtool"], **kw)
    finally:
        s.close()


@pytest.mark.parametrize("bad", [{"body": 1, "dev_pass": 1}, {"body": "x" * 20001, "dev_pass": 1}, {"body": "x", "dev_pass": -1}, {"body": "x", "dev_pass": True}, "x"])
def test_seed_best_rejected(world, bad):
    queued(world, ["o0/a"])
    with pytest.raises(Refused, match="seed_best"):
        _frozen(world, seed_best=bad)


def test_seed_best_initialises(world):
    queued(world, ["o0/a"])
    rec = _frozen(world, seed_best={"body": "def run(env): pass\n", "dev_pass": 2, "feedback": "fb"})
    assert rec["best"]["dev_pass"] == 2 and rec["feedback"] == "fb" and rec["best"]["body"].startswith("def run")


def _partial(monkeypatch, passes):
    """passes: an int, or one value per dev run (one dev run per experiment here: the stub replies with a single distinct candidate)."""
    seq = list(passes) if isinstance(passes, (list, tuple)) else None
    calls = []

    def dev_run(body, dev, harness, timeout=60, **kw):
        calls.append(1)
        return {"n": len(dev), "pass_count": seq[min(len(calls), len(seq)) - 1] if seq else passes}, "case c: expected e got x"
    monkeypatch.setattr(D, "_dev_run", dev_run)


def _run(world, monkeypatch, names, passes, replies=None):
    _partial(monkeypatch, passes)
    rid = queued(world, names)
    kw = serve(world, replies or [GOODBODY])
    return go(world, rid, hooks(world, names), run_kw=kw)


def _seeds(monkeypatch):
    first = {}
    real = D.prompt

    def spy(rec, dev):
        first.setdefault(rec["exp_id"], (rec.get("best") or {}).get("dev_pass"))
        return real(rec, dev)
    monkeypatch.setattr(D, "prompt", spy)
    return first


def test_retry_is_not_an_attempt_reuses_environment_and_grows_the_queue(world, monkeypatch):
    rec = _run(world, monkeypatch, ["o0/a", "o1/b"], 1)  # each repo: dev 1, retry also 1 (not strictly better) -> stop
    assert rec["state"] == "CANDIDATES_EXHAUSTED" and len(rec["attempts"]) == 4
    assert [a.get("retry_of") for a in rec["attempts"]] == [None, 0, None, 2] and [q.get("retry_of") for q in rec["queue"]] == [None, 0, None, 2]
    assert rec["ledger"]["attempts"] == 2 and rec["ledger"]["builds"] == 2 and len(world.stager.stages) == 2  # retries: no attempt, no build
    assert rec["attempts"][1]["environment"] == rec["attempts"][0]["environment"] and rec["attempts"][1]["repo"] == rec["attempts"][0]["repo"]


def test_chain_continues_only_on_strict_improvement_seeded_with_best_so_far(world, monkeypatch):
    first = _seeds(monkeypatch)
    rec = _run(world, monkeypatch, ["o0/a"], [1, 2, 2])
    assert [a.get("retry_of") for a in rec["attempts"]] == [None, 0, 1] and rec["ledger"]["attempts"] == 1  # 2 -> 2 is not progress: chain ends
    assert list(first.values()) == [None, 1, 2]


def test_chain_has_at_most_three_retries(world, monkeypatch):
    first = _seeds(monkeypatch)
    rec = _run(world, monkeypatch, ["o0/a"], [1, 2, 3, 4, 5])
    assert [a.get("retry_of") for a in rec["attempts"]] == [None, 0, 1, 2] and list(first.values()) == [None, 1, 2, 3]
    assert rec["ledger"]["attempts"] == 1 and rec["ledger"]["model_calls"] <= rec["frozen"]["budget"]["model_calls"] == 16


def test_resume_mid_chain_makes_no_repeat_model_call(world, monkeypatch):
    _partial(monkeypatch, [1, 1])
    names = ["o0/a"]
    rid = queued(world, names)
    h, kw = hooks(world, names), serve(world, [GOODBODY])
    real, n = D.run_experiment, {"k": 0}

    def flaky(*a, **k):
        n["k"] += 1
        if n["k"] == 2:  # the retry's experiment
            raise OSError("simulated crash")
        return real(*a, **k)
    monkeypatch.setattr(D, "run_experiment", flaky)
    rec = go(world, rid, h, run_kw=kw)
    assert rec["state"] == "INTERRUPTED" and [a.get("retry_of") for a in rec["attempts"]] == [None, 0] and rec["ledger"]["model_calls"] == 3
    rec = go(world, rid, h, run_kw=kw)
    assert rec["state"] == "CANDIDATES_EXHAUSTED" and [a.get("retry_of") for a in rec["attempts"]] == [None, 0]
    assert rec["ledger"]["model_calls"] == 6 and len(world.stager.stages) == 1 and rec["ledger"]["attempts"] == 1  # the finished experiment was not re-run


def test_no_retry_without_dev_progress(world, monkeypatch):
    rec = _run(world, monkeypatch, ["o0/a", "o1/b", "o2/c"], 0)
    assert len(rec["attempts"]) == 3 and all(a.get("retry_of") is None for a in rec["attempts"]) and len({a["repo"] for a in rec["attempts"]}) == 3


def test_single_repo_gets_exactly_one_retry(world, monkeypatch):
    rec = _run(world, monkeypatch, ["o0/a"], 2)
    assert [a.get("retry_of") for a in rec["attempts"]] == [None, 0] and len(world.stager.stages) == 1
    s = Store(world.store)
    try:
        m = A.manifest(s, rec)
    finally:
        s.close()
    assert [a["retry_of"] for a in m["attempts"]] == [None, 0]


class RejectFirst(FakeStager):
    def __init__(self, k=1):
        super().__init__()
        self.k = k

    def stage(self, repo_path, card, store_dir, cache_dir):
        if len(self.stages) < self.k:
            self.stages.append(card["repo"])
            raise A.ST.StageRejected("WHEELHOUSE_TOO_LARGE", "fake")
        return super().stage(repo_path, card, store_dir, cache_dir)


def test_stage_rejection_is_refunded_and_next_repo_takes_the_slot(world, monkeypatch):
    _partial(monkeypatch, 0)
    names = ["o0/a", "o1/b", "o2/c", "o3/d"]
    rid = queued(world, names)
    rec = go(world, rid, hooks(world, names, stager=RejectFirst(1)), run_kw=serve(world, [GOODBODY]))
    rej = [a for a in rec["attempts"] if a["state"] == "REJECTED"]
    assert len(rej) == 1 and rej[0]["refunded"] and rej[0]["n"] == 0
    live = [a for a in rec["attempts"] if not a.get("refunded")]
    assert len(live) == 3 and rec["ledger"]["attempts"] == 3 and rec["ledger"]["builds"] == 3 and len(world.stager.stages) == 4
    s = Store(world.store)
    try:
        m = A.manifest(s, rec)
    finally:
        s.close()
    assert [a["refunded"] for a in m["attempts"]][0] is True and rec["state"] == "CANDIDATES_EXHAUSTED"


def test_stage_rejects_are_bounded(world):
    names = [f"o{i}/t{i}" for i in range(6)]
    rid = queued(world, names)
    rec = go(world, rid, hooks(world, names, stager=RejectFirst(99)))
    assert rec["state"] == "CANDIDATES_EXHAUSTED" and "stage_rejects 3" in rec["reason"] and len(world.stager.stages) == 4
    assert rec["ledger"]["attempts"] == 0 and rec["ledger"]["model_calls"] == 0
