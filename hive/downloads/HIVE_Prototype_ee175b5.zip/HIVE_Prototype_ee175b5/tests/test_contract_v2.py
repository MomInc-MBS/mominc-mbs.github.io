"""P1 contract v2: two new public cases per cap, authored bodies still pass, wrong variants fail, opt-in decoded prompt view. No model, no network."""
import base64
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))
from hive import capcontract as CC  # noqa: E402
from hive import discovery as D  # noqa: E402
from hive import m2_model as M  # noqa: E402
from test_discovery import env, opened  # noqa: E402,F401

EXT, RES = "site.ref-extract", "site.ref-resolve"


def cases(cap):
    return D._load("gen_public", CC.get(cap)).cases()


def body(cap):
    return (ROOT / "build/g1/authored" / f"{cap}.py").read_text(encoding="utf-8")


def fails(src, dev):
    ns = {}
    exec(compile(src, "cand", "exec"), ns)
    return [k["name"] for k in dev if ns["run"](k["env"]) != k["expected"]]


def swap(src, old, new):
    assert old in src
    return src.replace(old, new, 1)


def test_new_public_cases_exist_and_authored_pass():
    for cap, name in ((EXT, "style-body-before-tag"), (RES, "literal-non-ascii")):
        dev = cases(cap)
        assert name in [k["name"] for k in dev]
        assert fails(body(cap), dev) == []


def test_deferred_style_variant_fails():
    src = swap(body(EXT), "for u in urls(t[b:e]):\n                    rows.append(('css-url', u))", "for u in urls(t[b:e]):\n                    late.append(('css-url', u))")
    src = swap(src, "        rows = []\n        t = re.sub", "        rows = []\n        late = []\n        t = re.sub")
    src = swap(src, "        return rows\n\n    try", "        return rows + late\n\n    try")
    assert fails(src, cases(EXT)) == ["style-body-before-tag"]


def test_non_ascii_mangling_resolve_variant_fails():
    src = swap(body(RES), "def dec(s):\n", "def dec(s):\n        s = s.encode('ascii', 'ignore').decode()\n")
    assert "literal-non-ascii" in fails(src, cases(RES))


def _rec(cap, policy):
    return {"frozen": {"contract": {"capability_id": cap}, "budget": {}, **({"eval_policy": policy} if policy else {})}, "feedback": None}


def test_legacy_prompt_unchanged_and_placeholder_shown():
    for cap in (EXT, RES):
        dev = cases(cap)
        text = D.prompt(_rec(cap, None), dev)[1]["content"]
        assert text == D.prompt({"frozen": {"contract": {"capability_id": cap}, "budget": {}}, "feedback": None}, dev)[1]["content"]
        for k in dev:
            old = json.dumps({"files": [dict(f, data=f"<base64 {len(f['data'])} chars>") for f in k["env"]["files"]]}, separators=(",", ":"))
            assert f"input: {old}\n  expected: " in text


def test_policy_on_shows_decoded_text_and_is_clean():
    for cap in (EXT, RES):
        dev = cases(cap)
        msgs = D.prompt(_rec(cap, D.SEALED_POLICY), dev)
        text = msgs[1]["content"]
        assert "<base64 " not in text
        assert ("...(truncated, " in text) == (cap == RES)  # extract's public files fit whole; resolve's are cut per file
        assert json.loads(base64.b64decode(dev[0]["env"]["files"][0]["data"]))["schema"] in text
        assert M.data_problem(msgs) is None
        assert sum(len(m["content"]) for m in msgs) // 4 + 1 <= 8000  # EXP_BUDGET max_prompt_tokens, first call


def test_frozen_identity_covers_view(env):
    exp = opened(env, policy=D.SEALED)
    assert exp["frozen"]["eval_policy"]["prompt_view"] == "decoded-public-v1"
    other = json.loads(D._json(exp["frozen"]))
    other["eval_policy"]["prompt_view"] = "length-only"
    assert D._sha(D._json(other)) != exp["frozen_sha"]
