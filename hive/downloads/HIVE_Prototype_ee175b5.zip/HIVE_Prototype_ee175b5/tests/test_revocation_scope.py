"""P1: revocation scope. A normal revoke is store-local; only an explicit global (or legacy unscoped) entry reaches every store."""
import copy
import json
import shutil
import sys
import time
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "tests"))
import hive_admission as H  # noqa: E402
import test_capability_admission as TA  # noqa: E402
from test_capability_admission import auth, runs  # noqa: E402,F401  (fixtures)
from hive import capability_registry as CR  # noqa: E402
from hive import discovery as D  # noqa: E402
from hive import goal_runner as G  # noqa: E402
from hive.operator_runtime import Refused  # noqa: E402
from hive.storage import Store  # noqa: E402

pytestmark = pytest.mark.skipif(not TA.SRC.exists() or not CR.keygen(), reason="C3 store or ssh-keygen unavailable")
CAP = "inventory-diff"


def _independent(root):
    """Give a store copied from the shared template its own identity (the template may already carry one from an earlier test)."""
    s = Store(root)
    try:
        s.db.execute("DELETE FROM kv WHERE key = ?", (CR.STORE_UUID_KEY,))
    finally:
        s.close()


def mk(tmp_path, name, auth, other_body=False):
    """A store with v1 admitted. other_body: v1 is the scripted baseline body (signed with the test key) instead of the experiment's candidate."""
    root = tmp_path / name
    shutil.copytree(TA.SRC, root)
    _independent(root)
    if not other_body:
        H.admit(root, TA.EXP, auth, rerun=TA.rerun_fake(root))
        return root
    H.admit(root, TA.EXP, auth, rerun=TA.rerun_fake(root))
    s = Store(root)
    try:
        ev = CR.history(s, CAP)[-1]
        st = copy.deepcopy(s.read_artifact(ev["statement_ref"]))
        body = D._read_lf(root / "discovery" / TA.EXP / "baseline.py")
        st.update(body=body, impl_sha256=H._sha(body))
        s.db.execute("DELETE FROM kv WHERE key = ?", (CR.CHAIN + CAP,))
        CR.append(s, CAP, "admit", statement=st, statement_sha=H._sha(CR.canon(st)), signature=CR.sign(CR.canon(st), auth))
    finally:
        s.close()
    return root


def state(root):
    s = Store(root)
    try:
        return CR._state(s, CAP)
    finally:
        s.close()


def live(root):
    s = Store(root)
    try:
        return CR.resolve_discovered(s, CAP)["version"]
    except Refused:
        return None
    finally:
        s.close()


def entries():
    return CR.revocations()


@pytest.fixture
def ab(tmp_path, auth):
    return mk(tmp_path, "A", auth), mk(tmp_path, "B", auth, other_body=True)


def test_local_revoke_hits_only_this_store(ab, auth):
    a, b = ab
    assert live(a) == live(b) == 1
    H.revoke(a, CAP, 1, "bad", auth)
    assert live(a) is None and live(b) == 1
    (e,) = entries()
    assert e["scope"] == "store" and e["store_uuid"] and e["statement_sha"] and e["impl_sha256"] and e["at"]


def test_global_revoke_blocks_both(ab, auth):
    a, b = ab
    H.revoke(a, CAP, 1, "emergency", auth, global_scope=True)
    assert entries()[0]["scope"] == "global" and live(a) is None and live(b) is None


def test_legacy_unscoped_entry_blocks_both(ab):
    a, b = ab
    Path(CR.revocations_path()).write_text(json.dumps({"revoked": [{"cap_id": CAP, "version": 1, "impl_sha256": None, "statement_sha": None, "reason": "old", "at": "x"}]}))
    assert live(a) is None and live(b) is None


def test_unknown_scope_or_malformed_fails_closed(ab):
    a, _ = ab
    for bad in ({"cap_id": CAP, "version": 1, "scope": "galaxy"}, {"cap_id": CAP, "version": 1, "scope": "store"}):
        CR.revocations_path().write_text(json.dumps({"revoked": [bad]}))
        with pytest.raises(Refused):
            state(a)


def test_identity_survives_restart_move_copy_and_new_store_differs(ab, auth, tmp_path):
    a, b = ab
    s = Store(a); u1 = CR.store_uuid(s); s.close()
    s = Store(a); assert CR.store_uuid(s) == u1; s.close()  # reopen
    H.revoke(a, CAP, 1, "bad", auth)
    assert live(a) is None
    cp = tmp_path / "A-copy"
    shutil.copytree(a, cp)
    moved = tmp_path / "moved" / "A"
    moved.parent.mkdir()
    shutil.move(str(a), str(moved))
    assert live(moved) is None and live(cp) is None and live(b) == 1
    s = Store(b); assert CR.store_uuid(s) != u1; s.close()


def test_append_only_and_idempotent(ab, auth):
    a, _ = ab
    H.revoke(a, CAP, 1, "first", auth)
    first = entries()
    CR.record_revocation(CAP, 1, "x", "y", "other store", scope="store", store_uuid="other")
    CR.record_revocation(CAP, 1, "x", "y", "other store", scope="store", store_uuid="other")  # identical: not added again
    CR.record_revocation(CAP, 1, "x", "y", "global now", scope="global")
    now = entries()
    assert now[:1] == first and len(now) == 3


def test_stale_plan_refuses_at_execution(ab, auth):
    a, _ = ab
    s = Store(a)
    r = CR.resolve_discovered(s, CAP)
    step = {"op": CAP, "statement_sha": r["statement_sha"]}
    H.revoke(a, CAP, 1, "bad", auth)  # after the plan was made
    with pytest.raises(Refused):  # goal_runner._run_discovered re-resolves on every use (goal_runner.py:591)
        G._run_discovered(s, a, {"contract_id": "c"}, step, [], {}, None)
    s.close()


def test_admission_of_locally_revoked_body_allowed_elsewhere_global_refused_everywhere(tmp_path, auth):
    a, b = mk(tmp_path, "A", auth), tmp_path / "B"
    shutil.copytree(TA.SRC, b)  # B: nothing admitted yet, same candidate body as A's v1
    _independent(b)  # a copy keeps the template's identity (conservative); B must be its own store
    H.revoke(a, CAP, 1, "bad body", auth)
    assert live(a) is None
    time.sleep(1.1)  # an independent admission: a statement byte-identical to A's (same template experiment, same second) IS A's lineage and stays revoked
    H.admit(b, TA.EXP, auth, rerun=TA.rerun_fake(b))  # store-local revoke of the body in A does not bar B
    assert live(b) == 1
    c = tmp_path / "C"
    shutil.copytree(TA.SRC, c)
    _independent(c)
    H.revoke(a, CAP, 1, "bad body everywhere", auth, global_scope=True)
    with pytest.raises(Refused):
        H.admit(c, TA.EXP, auth, rerun=TA.rerun_fake(c))
