"""G2 S3: staging runner. Unit tests use a fake docker runner and a local wheel; Docker-gated tests build a real image offline.
Every container/image carries this test's unique prefix; leak checks filter only on it. The real-network test is opt-in (HIVE_LIVE_NET=1)."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import zipfile
from pathlib import Path

import pytest

from hive import acq_card as AC, acq_stage as ST
from hive.adapters.isolation import PINNED_IMAGE

POL = json.loads((Path(__file__).resolve().parents[1] / "configs" / "acquisition_policy.json").read_text(encoding="utf-8"))
MIT = "Permission is hereby granted, free of charge, to any person obtaining a copy of this software.\n"


def have_docker():
    try:
        return subprocess.run(["docker", "image", "inspect", PINNED_IMAGE["reference"]], capture_output=True, timeout=20).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


needs_docker = pytest.mark.skipif(not have_docker(), reason="docker or the pinned base image is unavailable")


def make_wheel(d, name="tinydep", version="1.0", lic="License-Expression: MIT", extra=None, body="VALUE = 7\n"):
    d = Path(d)
    d.mkdir(parents=True, exist_ok=True)
    w = d / f"{name}-{version}-py3-none-any.whl"
    files = {f"{name}/__init__.py": body, f"{name}-{version}.dist-info/METADATA": f"Metadata-Version: 2.1\nName: {name}\nVersion: {version}\n{lic}\n",
             f"{name}-{version}.dist-info/WHEEL": "Wheel-Version: 1.0\nGenerator: t\nRoot-Is-Purelib: true\nTag: py3-none-any\n",
             f"{name}-{version}.dist-info/RECORD": ""}
    files.update(extra or {})
    with zipfile.ZipFile(w, "w") as z:
        for n, t in files.items():
            z.writestr(n, t)
    return w


def git(cwd, *a):
    return subprocess.run(["git", "-C", str(cwd), *a], check=True, capture_output=True, text=True).stdout.strip()


def make_repo(tmp, files):
    r = Path(tmp) / "repo"
    r.mkdir(parents=True)
    git(r, "init", "-q", "-b", "main")
    git(r, "config", "user.email", "t@t.test")
    git(r, "config", "user.name", "T")
    for p, t in files.items():
        (r / p).parent.mkdir(parents=True, exist_ok=True)
        (r / p).write_bytes(t.encode("utf-8"))
    git(r, "add", "-A")
    git(r, "commit", "-q", "-m", "c")
    return r, git(r, "rev-parse", "HEAD")


REPO = {"LICENSE": MIT, "README.md": "# t\n\nA vendored tool used by the staging tests, nothing else.\n",
        "pyproject.toml": '[project]\nname="vtool"\ndependencies=["tinydep>=1.0"]\n',
        "vtool/__init__.py": "import tinydep\n\n\ndef go():\n    '''Returns the dependency value.'''\n    return tinydep.VALUE\n", "vtool/sub.py": "X = 1\n"}


class FakeDocker:
    def __init__(self, ids=None, fail=()):
        self.calls, self.ids, self.fail = [], dict(ids or {}), set(fail)

    def __call__(self, argv, timeout):
        self.calls.append(list(argv))
        sub = argv[1] if argv[0] == "docker" else ""
        if sub in self.fail:
            return 1, b"", b"boom"
        if sub == "image" and argv[2] == "inspect":
            i = self.ids.get(argv[-1])
            return (0, i.encode(), b"") if i else (1, b"", b"No such image")
        if sub == "build":
            self.ids[argv[argv.index("-t") + 1]] = "sha256:" + "a" * 64
            return 0, b"sha256:" + b"a" * 64, b""
        if sub == "save":
            Path(argv[argv.index("-o") + 1]).write_bytes(b"TARBYTES")
            return 0, b"", b""
        if sub == "load":
            self.ids["sha256:" + "a" * 64] = "sha256:" + "a" * 64
            return 0, b"", b""
        return 0, b"", b""


def stager(fake=None, **kw):
    return ST.Stager(POL, run=fake or FakeDocker(), **kw)


# ---------------------------------------------------------------- wheels
def test_scan_wheel_ok_and_facts(tmp_path):
    w = ST.Stager(POL).scan_wheel(make_wheel(tmp_path))
    assert (w["name"], w["version"], w["license"], w["top_level"]) == ("tinydep", "1.0", "MIT", ["tinydep"]) and len(w["sha256"]) == 64


@pytest.mark.parametrize("kw,code", [
    ({"extra": {"evil.pth": "import os"}}, "WHEEL_REFUSED"),
    ({"extra": {"../up.py": "x"}}, "WHEEL_REFUSED"),
    ({"extra": {"/abs.py": "x"}}, "WHEEL_REFUSED"),
    ({"lic": "License-Expression: GPL-3.0-only"}, "LICENSE_NOT_ALLOWED"),
    ({"lic": "Classifier: License :: OSI Approved :: MIT License"}, None),
    ({"lic": "Classifier: License :: OSI Approved :: Historical Permission Notice and Disclaimer (HPND)"}, None),
    ({"lic": "Name: x"}, "LICENSE_NOT_ALLOWED")])
def test_scan_wheel_refusals(tmp_path, kw, code):
    w = make_wheel(tmp_path, **kw)
    if code is None:
        assert ST.Stager(POL).scan_wheel(w)["license"] in POL["licenses"]
        return
    with pytest.raises(ST.StageRejected) as e:
        ST.Stager(POL).scan_wheel(w)
    assert e.value.code == code


def test_sdist_and_garbage_refused(tmp_path):
    (tmp_path / "x-1.0.tar.gz").write_bytes(b"x")
    with pytest.raises(ST.StageRejected) as e:
        ST.Stager(POL).scan_all(tmp_path)
    assert e.value.code == "WHEEL_REFUSED"
    (tmp_path / "x-1.0.tar.gz").unlink()
    (tmp_path / "bad.whl").write_bytes(b"not a zip")
    with pytest.raises(ST.StageRejected):
        ST.Stager(POL).scan_all(tmp_path)


def test_size_caps(tmp_path):
    p = dict(POL, stage=dict(POL["stage"], max_wheelhouse_bytes=10))
    make_wheel(tmp_path)
    with pytest.raises(ST.StageRejected) as e:
        ST.Stager(p).scan_all(tmp_path)
    assert e.value.code == "WHEELHOUSE_TOO_LARGE"
    p = dict(POL, stage=dict(POL["stage"], max_wheels=0))
    with pytest.raises(ST.StageRejected) as e:
        ST.Stager(p).scan_all(tmp_path)
    assert e.value.code == "TOO_MANY_WHEELS"


def test_lock_is_hashed_sorted_and_deterministic(tmp_path):
    s = ST.Stager(POL)
    ws = [s.scan_wheel(make_wheel(tmp_path, "zeta")), s.scan_wheel(make_wheel(tmp_path, "alpha", "2.1"))]
    lock = s.lock_text(ws)
    lines = lock.splitlines()
    assert lines[0].startswith("alpha==2.1 --hash=sha256:") and lines[1].startswith("zeta==1.0 --hash=sha256:")
    assert lock == s.lock_text(list(reversed(ws))) and "\r" not in lock


# ---------------------------------------------------------------- requirements, downloader argv, Dockerfile
def test_requirements_validation():
    assert ST.requirements([{"name": "pillow", "spec": ">=9, <12"}, {"name": "numpy", "spec": ""}], POL) == ["pillow>=9,<12", "numpy"]
    for bad in ({"name": "-e git+https://x"}, {"name": None}, {"name": "a b"}, {"name": "ok", "spec": ">=1; rm -rf"}, {"name": "ok", "spec": "@ http://x"}):
        with pytest.raises(ST.StageRejected) as e:
            ST.requirements([bad], POL)
        assert e.value.code == "BAD_DEPENDENCY"
    with pytest.raises(ST.StageRejected) as e:
        ST.requirements([{"name": f"d{i}", "spec": ""} for i in range(9)], POL)
    assert e.value.code == "TOO_MANY_DEPS"


def test_download_container_is_least_privilege(tmp_path):
    s = stager()
    a = s.download_argv(["pillow>=9"], tmp_path, "n")
    j = " ".join(a)
    assert "--only-binary=:all:" in a and "--cap-drop=ALL" in a and "--read-only" in a and "--user=1000:1000" in a
    assert a[a.index("--index-url") + 1] == "https://pypi.org/simple/" and "--network=none" not in a  # the one step that has network
    assert j.count("--mount") == 1 and "dst=/out" in j and "/var/run/docker.sock" not in j and "-e HOME=/out/.hive-tmp" in j and "-e TMPDIR=/out/.hive-tmp" in j
    assert PINNED_IMAGE["digest"] in j and "--pull=never" in a


def test_download_no_wheel_is_recorded_as_sdist_only(tmp_path):
    class D(FakeDocker):
        def __call__(self, argv, timeout):
            if "pip" in argv:
                return 1, b"", b"ERROR: No matching distribution found for x (only-binary)"
            return super().__call__(argv, timeout)
    with pytest.raises(ST.StageRejected) as e:
        stager(D()).download(["x"], tmp_path)
    assert e.value.code == "COMPILED_OR_SDIST_ONLY"
    f = FakeDocker()
    stager(f).download([], tmp_path)
    assert not f.calls


def test_dockerfile_text_snapshot():
    base = {"reference": "python:3.11-slim", "digest": "sha256:" + "b" * 64}
    assert ST.Stager.dockerfile(base, True).splitlines() == [
        "FROM python:3.11-slim@sha256:" + "b" * 64, "COPY wheelhouse/ /wheelhouse/", "COPY lock.txt /lock.txt",
        "RUN python -m pip install --no-index --no-deps --require-hashes --disable-pip-version-check --no-cache-dir --find-links /wheelhouse -r /lock.txt && rm -rf /wheelhouse /lock.txt",
        "COPY vendor/ /usr/local/lib/python3.11/site-packages/"]
    d = ST.Stager.dockerfile(base, False)
    assert "pip" not in d and d.count("RUN") == 0


def test_build_argv_has_no_network_and_unique_prefix(tmp_path):
    f = FakeDocker()
    s = stager(f, prefix="hive-stage-unit")
    tag, iid = s.build(tmp_path, PINNED_IMAGE, True)
    b = next(c for c in f.calls if c[1] == "build")
    assert "--network=none" in b and "--pull=false" in b and tag.startswith("hive-stage-unit:") and iid == "sha256:" + "a" * 64
    assert (tmp_path / "Dockerfile").read_bytes().count(b"\r") == 0
    s.cleanup()
    assert ["docker", "rmi", "--force", tag] in f.calls and s.images == []


# ---------------------------------------------------------------- vendor
def test_vendor_tree_pinned_and_capped(tmp_path):
    repo, sha = make_repo(tmp_path, REPO)
    files, t = ST.vendor_tree(repo, sha, "vtool", POL, tmp_path / "cc")
    assert sorted(files) == ["vtool/__init__.py", "vtool/sub.py"] and t == ST.vendor_tree(repo, sha, "vtool", POL, tmp_path / "cc2")[1]
    p = dict(POL, limits=dict(POL["limits"], max_tree_bytes=10))
    with pytest.raises(ST.StageRejected) as e:
        ST.vendor_tree(repo, sha, "vtool", p, tmp_path / "cc3")
    assert e.value.code == "VENDOR_TREE_SIZE"
    with pytest.raises(ST.StageRejected):
        ST.vendor_tree(repo, sha, "nothere", POL, tmp_path / "cc4")


def test_vendor_src_layout_installs_under_package_name(tmp_path):
    repo, sha = make_repo(tmp_path, {"src/vtool/__init__.py": "A = 1\n"})
    files, _ = ST.vendor_tree(repo, sha, "src/vtool", POL, tmp_path / "cc")
    assert list(files) == ["vtool/__init__.py"]


# ---------------------------------------------------------------- stage orchestration (fake docker, fake downloader)
def card_for(repo, sha):
    return AC.build_card(repo, sha, "a/b", POL, repo.parent / "cardcache", api_license="MIT")


def test_stage_with_fakes_records_everything(tmp_path):
    repo, sha = make_repo(tmp_path, REPO)
    f = FakeDocker()
    s = stager(f, prefix="hive-stage-unit")
    env = s.stage(repo, card_for(repo, sha), tmp_path / "store", tmp_path / "cc", downloader=lambda reqs, d: make_wheel(d))
    assert env["id"] == "sha256:" + "a" * 64 and env["packages"] == ["tinydep", "vtool"] and env["image_tar_sha256"] == ST._sha(b"TARBYTES")
    assert Path(env["tar_path"]).read_bytes() == b"TARBYTES" and env["wheelhouse"][0]["name"] == "tinydep" and env["vendored_files"] == 2
    assert env["base"] == PINNED_IMAGE and len(env["lock_sha256"]) == 64
    smoke = next(c for c in f.calls if c[1] == "run")
    assert "--network=none" in smoke and "--user=1000:1000" in smoke and smoke[-1] == "import tinydep,vtool"
    assert next(c for c in f.calls if c[1] == "build") and not any("--network=host" in c for c in f.calls)


def test_stage_rejects_missing_wheel_and_bad_wheel(tmp_path):
    repo, sha = make_repo(tmp_path, REPO)
    with pytest.raises(ST.StageRejected) as e:  # declared dep has no wheel in the wheelhouse
        stager().stage(repo, card_for(repo, sha), tmp_path / "s1", tmp_path / "c1", downloader=lambda r, d: None)
    assert e.value.code == "COMPILED_OR_SDIST_ONLY"
    with pytest.raises(ST.StageRejected) as e:
        stager().stage(repo, card_for(repo, sha), tmp_path / "s2", tmp_path / "c2", downloader=lambda r, d: make_wheel(d, extra={"x.pth": "y"}))
    assert e.value.code == "WHEEL_REFUSED"


def test_build_and_smoke_failures_are_rejections(tmp_path):
    repo, sha = make_repo(tmp_path, REPO)
    for sub, code in (("build", "BUILD_FAILED"), ("save", "SAVE_FAILED")):
        with pytest.raises(ST.StageRejected) as e:
            stager(FakeDocker(fail=[sub])).stage(repo, card_for(repo, sha), tmp_path / ("o" + sub), tmp_path / "c", downloader=lambda r, d: make_wheel(d))
        assert e.value.code == code


def test_ensure_inspects_then_loads_verified_tar_never_rebuilds(tmp_path):
    tar = tmp_path / "i.tar"
    tar.write_bytes(b"TARBYTES")
    env = {"id": "sha256:" + "a" * 64, "tar_path": str(tar), "image_tar_sha256": ST._sha(b"TARBYTES")}
    f = FakeDocker(ids={env["id"]: env["id"]})
    assert stager(f).ensure(env) == env["id"] and not any(c[1] == "load" for c in f.calls)
    f = FakeDocker()  # image gone: load from the tar
    assert stager(f).ensure(env) == env["id"] and any(c[1] == "load" for c in f.calls) and not any(c[1] == "build" for c in f.calls)
    tar.write_bytes(b"TAMPERED")
    with pytest.raises(ST.StageRejected) as e:
        stager(FakeDocker()).ensure(env)
    assert e.value.code == "IMAGE_TAR_MISMATCH"
    tar.unlink()
    with pytest.raises(ST.StageRejected) as e:
        stager(FakeDocker()).ensure(env)
    assert e.value.code == "IMAGE_MISSING"


def test_core_module_names_no_task():
    t = (Path(__file__).resolve().parents[1] / "src" / "hive" / "acq_stage.py").read_text(encoding="utf-8").lower()
    assert not any(w in t for w in ("imagehash", "pillow", "perceptual", "inventory", "interval"))


# ---------------------------------------------------------------- real Docker (offline build from a local wheel)
def _leaked(prefix):
    ps = subprocess.run(["docker", "ps", "-a", "-q", "--filter", f"name={prefix}"], capture_output=True, text=True).stdout.split()
    im = subprocess.run(["docker", "images", "--format", "{{.Repository}}:{{.Tag}}", "--filter", f"reference={prefix}*"], capture_output=True, text=True).stdout.split()
    return ps, im


@needs_docker
def test_real_build_smoke_save_rmi_load_roundtrip(tmp_path, capsys):
    repo, sha = make_repo(tmp_path, REPO)
    s = ST.Stager(POL)
    try:
        env = s.stage(repo, card_for(repo, sha), tmp_path / "store", tmp_path / "cc", downloader=lambda reqs, d: make_wheel(d))
        assert env["id"].startswith("sha256:") and env["packages"] == ["tinydep", "vtool"]
        size = Path(env["tar_path"]).stat().st_size
        print(f"IMAGE_TAR_BYTES={size}")
        # the vendored tool really imports its staged dependency, offline, read-only, non-root, with -I
        out = subprocess.run(["docker", "run", "--pull=never", "--rm", "--name", s.prefix + "-use", "--network=none", "--read-only", "--cap-drop=ALL",
                              "--user=1000:1000", env["id"], "python", "-I", "-c", "import vtool;print(vtool.go())"], capture_output=True, text=True)
        assert out.stdout.strip() == "7", out.stderr
        # network really is unavailable at run time
        net = subprocess.run(["docker", "run", "--pull=never", "--rm", "--name", s.prefix + "-net", "--network=none", env["id"], "python", "-I", "-c",
                              "import socket;socket.create_connection(('1.1.1.1',53),2)"], capture_output=True, text=True)
        assert net.returncode != 0
        # remove the image; ensure() reloads the exact ID from the verified tar
        subprocess.run(["docker", "rmi", "--force", s.images[0]], capture_output=True)
        assert s.image_id(env["id"]) is None
        assert s.ensure(env) == env["id"] and s.image_id(env["id"]) == env["id"]
    finally:
        s.cleanup()
        subprocess.run(["docker", "rmi", "--force", env["id"]] if "env" in dir() else ["docker", "version"], capture_output=True)
    assert _leaked(s.prefix) == ([], [])


@needs_docker
def test_real_build_failure_leaves_nothing(tmp_path):
    s = ST.Stager(POL)
    repo, sha = make_repo(tmp_path, REPO)
    with pytest.raises(ST.StageRejected):  # a wheel whose hash cannot match: lock is generated from files, so corrupt it after the scan
        def bad(reqs, d):
            w = make_wheel(d)
            return w
        orig = s.lock_text
        s.lock_text = lambda ws: orig(ws).replace("--hash=sha256:", "--hash=sha256:00")
        s.stage(repo, card_for(repo, sha), tmp_path / "st", tmp_path / "cc", downloader=bad)
    s.cleanup()
    assert _leaked(s.prefix) == ([], [])


@pytest.mark.skipif(os.environ.get("HIVE_LIVE_NET") != "1" or not have_docker(), reason="opt-in: set HIVE_LIVE_NET=1 (real network in the pip-download container)")
def test_live_download_of_a_pure_python_wheel(tmp_path):
    s = ST.Stager(POL)
    d = tmp_path / "w"
    d.mkdir()
    s.download(["six"], d)
    assert [w["name"] for w in s.scan_all(d)] == ["six"]
    assert _leaked(s.prefix)[0] == []
