"""F3: approval validity (L4), project spend budget and ledger fail-closed (L5), explicit backend into discovery (T18). Stub endpoints only."""
from __future__ import annotations

import copy
import hashlib
import json
import shutil
import sys
import threading
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import m2_stub_server as STUB  # noqa: E402
from test_discovery import WRONGS, env, fake_runs, opened  # noqa: E402,F401
from hive import discovery as D, m2_model as M, m2_workflow as W  # noqa: E402

QWEN, GPT = "qwen/qwen3.8-27b", "openai/gpt-oss-20b"
DRAFT = ROOT / "build" / "prototype" / "approvals" / "qwen3.8-27b.approval.DRAFT.json"
MSGS = [{"role": "system", "content": "s"}, {"role": "user", "content": "Target type: Source\nreply"}]
PRICED = {GPT: {"fresh_input": 1000.0, "cached_read": 0.0, "cache_write": 0.0, "output": 1000.0}}


def serve(tmp_path, model_id=GPT, replies=None):
    srv = STUB.make_server(replies, 0, str(tmp_path / "req.jsonl"), model_id=model_id)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{srv.server_port}/v1"


def cfg_with(sha=None):
    c = json.loads((ROOT / "configs" / "model_dispatch.json").read_text(encoding="utf-8"))
    for e in c["backends"]["list"]:
        if e["id"] == QWEN: e["approval_sha256"], e["approval_path"] = sha, "approval.json"
    return c


def active(tmp_path, name="approval.json", **over):
    """An ACTIVE copy of the draft in a temp tree; returns (cfg bound to it, path). Never touches the owner's draft."""
    d = json.loads(DRAFT.read_text(encoding="utf-8"))
    d.update(status="active", approver="owner", approved_at="2026-11-26T00:00:00Z", statement="test authorisation", **over)
    d["context"] = "test"
    p = tmp_path / name
    raw = (json.dumps(d, indent=2) + "\n").encode()
    p.write_bytes(raw)
    return p, hashlib.sha256(raw).hexdigest()


def problems(path, sha):
    c = cfg_with(sha)
    return M.approval_problems(path, M.apply_backend(W.load_policy(), QWEN, c))


def test_draft_is_refused_even_renamed_and_with_a_bound_sha(tmp_path):
    p = tmp_path / "qwen.approval.json"  # the draft renamed, unedited
    shutil.copy(DRAFT, p)
    sha = hashlib.sha256(p.read_bytes()).hexdigest()
    assert any("DRAFT" in b for b in problems(p, sha))
    with pytest.raises(M.Refused, match="DRAFT"):
        M.Model(tmp_path / "o", backend=QWEN, dispatch_cfg=cfg_with(sha), approval_path=p)


def test_active_bound_approval_passes_the_approval_body_checks_but_renamed_or_edited_is_refused(tmp_path):
    p, sha = active(tmp_path)
    assert not [b for b in problems(p, sha) if "sha256" in b or "DRAFT" in b or "status" in b]  # remaining problems (manifest, protocol) are unrelated
    assert any("not bound" in b for b in problems(p, None))  # unbound sha
    assert any("differs" in b for b in problems(p, "0" * 64))  # a different file under the bound name
    d = json.loads(p.read_text(encoding="utf-8")); d["approver"] = "someone else"
    p.write_text(json.dumps(d, indent=2) + "\n", encoding="utf-8")  # edited after binding
    assert any("differs" in b for b in problems(p, sha))
    p2, sha2 = active(tmp_path, name="renamed.DRAFT.json")
    assert any("DRAFT" in b for b in problems(p2, sha2))
    p3, sha3 = active(tmp_path, name="s.json")
    d = json.loads(p3.read_text(encoding="utf-8")); d["status"] = "pending"
    p3.write_text(json.dumps(d) + "\n", encoding="utf-8")
    assert any("status" in b for b in problems(p3, hashlib.sha256(p3.read_bytes()).hexdigest()))


def test_default_backend_approval_is_unchanged_by_the_binding():
    pol = W.load_policy()
    assert "approval_sha256" not in M.apply_backend(pol, GPT) and M.apply_backend(pol, None) is pol


def test_unqualified_backend_is_refused_by_dispatch_and_by_discovery(env, fake_runs, tmp_path):
    c = {"classes": {"c3-proposal": {"mode": "active", "canary_limit": 1}}, "fallback": "P0",
         "qualified": {GPT: {"measured": True, "context": 32768, "evidence": ["t"]}}, "backends": cfg_with()["backends"]}  # qwen configured but NOT qualified
    srv, url = serve(tmp_path, QWEN, {"R": WRONGS})
    exp = opened(env)
    done = D.run_experiment(env[0], exp["exp_id"], stub_endpoint=url, private_dir=env[2], requested_model=QWEN, dispatch_cfg=c)
    assert srv.counters["total"] == 0 and done["state"] == "MODEL_UNAVAILABLE"


def test_priced_backend_with_no_budget_is_refused_before_any_http_request(tmp_path):
    srv, url = serve(tmp_path)
    m = M.Model(tmp_path / "o", stub=True, endpoint=url, pricing=PRICED, dispatch_cfg={"backends": {"default": GPT, "list": [{"id": GPT}]}})  # no budget block, none passed
    with pytest.raises(M.BudgetRefused, match="no spend budget"):
        m.call("propose", MSGS, 1)
    assert srv.counters["total"] == 0
    m2 = M.Model(tmp_path / "o2", stub=True, endpoint=url, pricing=PRICED, dispatch_cfg={"backends": {"default": GPT, "list": [{"id": GPT}]}, "budget": {"remaining_usd": 0.0}})
    with pytest.raises(M.BudgetRefused, match="budget refused"):  # a configured project budget is picked up from the dispatch config and enforced
        m2.call("propose", MSGS, 1)
    assert srv.counters["total"] == 0
    m3 = M.Model(tmp_path / "o3", stub=True, endpoint=url, backend=QWEN)  # local $0 backend: no budget needed
    assert m3.call("propose", MSGS, 1)["status"] == "ok"


@pytest.mark.parametrize("line", ['{"kind": "usage", "run_id": "x"', '{"kind": "usage", "run_id": "x"}', "[1]", "not json"])
def test_torn_or_malformed_ledger_line_fails_closed(tmp_path, line):
    srv, url = serve(tmp_path)
    led = tmp_path / "led.jsonl"
    led.write_text(line + "\n", encoding="utf-8")
    m = M.Model(tmp_path / "o", stub=True, endpoint=url, pricing=PRICED, budget_usd=1.0, ledger_path=led)
    with pytest.raises(M.BudgetRefused, match="usage ledger unavailable"):
        m.call("propose", MSGS, 1)
    assert srv.counters["total"] == 0


def test_discovery_with_backend_qwen_uses_the_qwen_policy_on_the_stub(env, fake_runs, tmp_path):
    c = cfg_with()
    c["classes"] = {"c3-proposal": {"mode": "shadow", "canary_limit": 1}}
    c["qualified"] = {GPT: c["qualified"][GPT], QWEN: dict(c["qualified"][QWEN], measured=True)}  # as if a live smoke receipt existed (shipped config: measured false)
    srv, url = serve(tmp_path, QWEN, {"R": WRONGS})
    exp = opened(env)
    done = D.run_experiment(env[0], exp["exp_id"], stub_endpoint=url, private_dir=env[2], requested_model=QWEN, dispatch_cfg=c)
    bodies = [json.loads(l) for l in (tmp_path / "req.jsonl").read_text(encoding="utf-8").splitlines()]
    assert srv.counters["total"] >= 1 and {b["model"] for b in bodies} == {QWEN}
    assert done["state"] != "MODEL_UNAVAILABLE"
    rows = (env[0] / "discovery" / exp["exp_id"] / "model" / "model_dispatch.jsonl").read_text(encoding="utf-8")
    assert QWEN in rows
    led = (env[0] / "discovery" / exp["exp_id"] / "model" / "usage-ledger.jsonl").read_text(encoding="utf-8")
    assert QWEN in led
