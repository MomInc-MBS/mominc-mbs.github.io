"""T08/T09: real-Docker isolation checks (opt-in: HIVE_REAL_DOCKER=1, like the other real-container tests). Host secrets and paths are invisible inside
a capability container, memory exhaustion is a contained failure, and no hive-code-* container is left behind."""
from __future__ import annotations

import json
import os
import subprocess
import time

import pytest

from hive.adapters.isolation import DockerIsolation, PINNED_IMAGE, SandboxUnavailable
from hive.experiment_compare import run_isolated

try:
    DockerIsolation().inspect(PINNED_IMAGE)
    WHY = "" if os.environ.get("HIVE_REAL_DOCKER") == "1" else "opt-in: set HIVE_REAL_DOCKER=1"
except SandboxUnavailable as e:
    WHY = str(e)
pytestmark = pytest.mark.skipif(bool(WHY), reason=WHY or "docker")


def run(src, text="a,b\n", **kw):
    return run_isolated(src, text, {}, backend="container", **kw)


def leftovers():
    return subprocess.run(["docker", "ps", "-aq", "--filter", "name=hive-code-"], capture_output=True, text=True).stdout.split()


def test_host_canary_env_var_is_not_visible(monkeypatch):
    monkeypatch.setenv("HIVE_CANARY_SECRET", "canary-7f3a91")
    monkeypatch.setenv("HIVE_GITHUB_TOKEN", "canary-token-5c2")
    src = ("import os\ndef apply(t, c):\n    e = dict(os.environ)\n    hit = [k for k, v in e.items() if 'canary' in v or 'CANARY' in k or 'TOKEN' in k or 'HIVE' in k]\n"
           "    try: p = open('/proc/self/environ').read()\n    except OSError: p = ''\n"
           "    return str([hit, 'canary' in p])\n")
    assert run(src) == "[[], False]"


def test_no_host_path_outside_the_readonly_work_mount_is_readable(tmp_path):
    secret = tmp_path / "host-secret.txt"
    secret.write_text("HOSTSECRET-9d41", encoding="utf-8")
    src = ("import os\nTOKEN = 'HOSTSECRET-9d41'\n\ndef apply(t, c):\n    found, work = [], sorted(os.listdir('/work'))\n"
           "    for root, dirs, files in os.walk('/'):\n        if root in ('/proc', '/sys', '/dev', '/work'):\n            dirs[:] = []\n            continue\n"
           "        for f in files:\n            try:\n                if os.path.getsize(os.path.join(root, f)) < 200000 and TOKEN.encode() in open(os.path.join(root, f), 'rb').read(): found.append(os.path.join(root, f))\n"
           "            except OSError: pass\n"
           "    bad = [p for p in ('/host_mnt', '/mnt/c', '/mnt/d', '/c', '/d', 'C:/Users', 'D:/Repos', '/run/desktop') if os.path.exists(p)]\n"
           "    ro = []\n    for p in ('/work/x', '/x'):\n        try: open(p, 'w').write('x'); ro.append('W')\n        except OSError: ro.append('ro')\n"
           "    return str([found, bad, work, ro])\n")
    assert run(src) == "[[], [], ['in.json'], ['ro', 'ro']]"


def test_memory_exhaustion_is_a_contained_failure_and_leaves_no_container():
    before = set(leftovers())
    src = "def apply(t, c):\n    b = []\n    while True:\n        b.append(bytearray(8 * 1024 * 1024))\n"
    t0 = time.time()
    with pytest.raises(RuntimeError, match="candidate process failed"):
        run(src, limits={"memory_mb": 64, "cpu_count": 1, "pids": 32}, timeout=60)
    assert time.time() - t0 < 60
    time.sleep(1)
    assert set(leftovers()) <= before


def test_memory_limit_still_allows_a_small_honest_run():
    assert run("def apply(t, c):\n    return str(len(bytearray(1024 * 1024)))\n", limits={"memory_mb": 64, "cpu_count": 1, "pids": 32}) == "1048576"


def test_cpu_limit_is_applied_to_the_container():
    """The limit is a cgroup quota: from inside, cpu.max reports the cap (0.5 CPU -> '50000 100000'). Cheap and deterministic, no timing."""
    src = ("def apply(t, c):\n    for p in ('/sys/fs/cgroup/cpu.max', '/sys/fs/cgroup/cpu/cpu.cfs_quota_us'):\n        try: return open(p).read().strip()\n        except OSError: pass\n    return 'none'\n")
    out = run(src, limits={"memory_mb": 128, "cpu_count": 0.5, "pids": 32})
    assert out == "none" or out.startswith("50000"), out  # "none" = cgroup file unreadable on this host; never an unlimited quota
