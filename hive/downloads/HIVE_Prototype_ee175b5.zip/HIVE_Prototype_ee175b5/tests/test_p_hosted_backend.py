"""T18, hosted class: NVIDIA NIM as a second selectable proposer backend. Local stub HTTP server only; the host/scheme allowlist is patched ONLY inside these tests.
The opt-in live smoke (NVIDIA_API_KEY set and HIVE_LIVE_NIM=1) writes build/prototype/approvals/nim-smoke-receipt.json."""
from __future__ import annotations

import base64
import copy
import hashlib
import json
import os
import shutil
import sys
import threading
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import m2_stub_server as STUB  # noqa: E402
from test_discovery import WRONGS, env, fake_runs, opened  # noqa: E402,F401
from hive import discovery as D, m2_model as M, m2_workflow as W  # noqa: E402

NIM, GPT, QWEN = "moonshotai/kimi-k3.1-pro", "openai/gpt-oss-20b", "qwen/qwen3.8-27b"
DRAFT = ROOT / "build" / "prototype" / "approvals" / "nim-moonshotai-kimi-k3.1-pro.approval.DRAFT.json"
KEY = "nvapi-TESTKEY0123456789abcdefghijklmnopqrstuvwxyz"
MSGS = [{"role": "system", "content": "s"}, {"role": "user", "content": "Target type: Source\nreply"}]
CFG_PATH = ROOT / "configs" / "model_dispatch.json"


class Hosted:
    """A scriptable OpenAI-compatible server. mode: ok | no_usage | partial | echo | e401 | redirect | big. Records headers and bodies per path."""

    def __init__(self, mode="ok", redirect_to=None):
        self.mode, self.redirect_to, self.seen, outer = mode, redirect_to, [], self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a): pass

            def _send(self, code, raw, headers=()):
                self.send_response(code)
                for k, v in headers: self.send_header(k, v)
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def handle_any(self, method):
                n = int(self.headers.get("Content-Length") or 0)
                body = self.rfile.read(n) if n else b""
                outer.seen.append({"method": method, "path": self.path, "auth": self.headers.get("Authorization"), "body": body.decode("utf-8", "replace")})
                if outer.mode == "redirect": return self._send(302, b"", [("Location", outer.redirect_to + self.path)])
                if outer.mode == "e401": return self._send(401, json.dumps({"error": "bad key " + str(self.headers.get("Authorization"))}).encode())
                if method == "GET": return self._send(200, json.dumps({"data": [{"id": NIM}, {"id": "other/model"}]}).encode())
                if outer.mode == "big": return self._send(200, b'{"x":"' + b"a" * (M.HOSTED_MAX_BYTES + 10) + b'"}')
                content = "```python\ndef run(env):\n    return 'ok'\n```"
                if outer.mode == "echo": content += "\nkey was " + str(self.headers.get("Authorization"))
                msg = {"role": "assistant", "content": content, "reasoning_content": "think " + str(self.headers.get("Authorization"))}
                resp = {"id": "x", "object": "chat.completion", "model": NIM, "choices": [{"index": 0, "message": msg, "finish_reason": "stop"}]}
                if outer.mode != "no_usage":
                    resp["usage"] = {"prompt_tokens": 50, "completion_tokens": 20, "total_tokens": 70, "prompt_tokens_details": {"cached_tokens": 10}}
                if outer.mode == "partial": resp["usage"] = {"prompt_tokens": 50}
                self._send(200, json.dumps(resp).encode())

            def do_GET(self): self.handle_any("GET")
            def do_POST(self): self.handle_any("POST")

        self.srv = HTTPServer(("127.0.0.1", 0), H)
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
        self.url = f"http://127.0.0.1:{self.srv.server_port}/v1"

    def posts(self): return [s for s in self.seen if s["method"] == "POST"]


def cfg_for(url, sha=None, measured=False):
    c = json.loads(CFG_PATH.read_text(encoding="utf-8"))
    for e in c["backends"]["list"]:
        if e["id"] == NIM: e.update(endpoint=url, approval_sha256=sha, approval_path="approval.json")
    c["qualified"][NIM]["measured"] = measured
    c["classes"] = {"c3-proposal": {"mode": "shadow", "canary_limit": 1}}
    return c


def active(tmp_path, url, name="approval.json"):
    d = json.loads(DRAFT.read_text(encoding="utf-8"))
    d.update(status="active", approver="owner", approved_at="2026-11-26T00:00:00Z", statement="test authorisation", endpoint=url, host="127.0.0.1", context="test")
    p = tmp_path / name
    raw = (json.dumps(d, indent=2) + "\n").encode()
    p.write_bytes(raw)
    return p, hashlib.sha256(raw).hexdigest()


@pytest.fixture
def patched(monkeypatch):
    """Tests only: the stub is http on loopback, so the allowlist is widened to it. Production values are asserted untouched elsewhere."""
    monkeypatch.setattr(M, "HOSTED_HOSTS", {"127.0.0.1": "NVIDIA_API_KEY"})
    monkeypatch.setattr(M, "HOSTED_SCHEMES", ("http", "https"))
    monkeypatch.setenv("NVIDIA_API_KEY", KEY)


def init_ledger(path):
    """A live hosted call needs an initialised hosted ledger (it fails closed otherwise); tests use a temp one."""
    from hive.usage_ledger import HostedLedger
    path = Path(path)
    if not path.exists(): HostedLedger(path, {}).init()


def live_model(tmp_path, srv, **kw):
    """A NON-stub hosted Model against the stub: real approval gate (active, sha bound), real key path, real spend gate."""
    p, sha = active(tmp_path, srv.url)
    kw.setdefault("budget_usd", 5.0)
    kw.setdefault("ledger_path", tmp_path / "ledger.jsonl")  # never the project ledger
    init_ledger(kw["ledger_path"])
    return M.Model(tmp_path / "o", backend=NIM, pol=D.pol(), dispatch_cfg=cfg_for(srv.url, sha), approval_path=p, manifest_path=None, **kw)


@pytest.fixture(autouse=True)
def _manifest(monkeypatch):
    """The evaluation manifest is a separate, already-tested gate (tests/test_p_fix_model.py); here only the hosted pins are under test."""
    monkeypatch.setattr(M, "manifest_problems", lambda *a, **k: [])


def all_bytes(root):
    return b"".join(p.read_bytes() for p in Path(root).rglob("*") if p.is_file())


# ---------------------------------------------------------------- config, approval draft, allowlist
def test_config_draft_and_defaults():
    cfg = json.loads(CFG_PATH.read_text(encoding="utf-8"))
    assert M.list_backends() == [GPT, QWEN, "nvidia/nemotron-3.5-super-vl-120b-a12b", NIM] and cfg["backends"]["default"] == GPT
    assert cfg["qualified"][NIM]["measured"] is True and cfg["backends"]["list"][3]["approval_sha256"]  # activated 26 Nov by the owner's answer
    price = cfg["pricing"][NIM]
    assert all(v > 0 for v in price.values()) and cfg["budget"]["remaining_usd"] == 5.0  # a hosted backend is priced, never zero
    p = M.apply_backend(D.pol(), NIM)
    m = p["model"]
    assert m["id"] == NIM and m["hosted"] and m["endpoint"] == "https://integrate.api.nvidia.com/v1" and m["key_env"] == "NVIDIA_API_KEY"
    assert not {"file", "bytes", "sha256"} & set(m)  # no weights to hash: said honestly, not faked
    assert p["approval_caps"] == D.APPROVAL_CAPS and p["sampling"]["max_tokens"] == 4096 and p["model"]["system_prefix"] == ""
    assert M.apply_backend(D.pol(), GPT)["model"] == D.pol()["model"] and "key_env" not in M.apply_backend(D.pol(), QWEN)["model"]
    assert M.HOSTED_HOSTS == {"integrate.api.nvidia.com": "NVIDIA_API_KEY"} and M.HOSTED_SCHEMES == ("https",)  # tests patch copies; the shipped values are exact


def test_draft_approval_binds_provider_host_and_model_and_is_refused():
    a = json.loads(DRAFT.read_text(encoding="utf-8"))
    pol = M.apply_backend(D.pol(), NIM)
    assert a["status"] == "DRAFT" and a["model_id"] == NIM and a["provider"] == "nvidia-nim" and a["host"] == "integrate.api.nvidia.com" and a["hosted"] is True
    assert a["model_file_sha256"] is None and a["caps"] == D.APPROVAL_CAPS and a["endpoint"] == pol["model"]["endpoint"]
    probs = set(M.approval_problems(DRAFT, pol))  # the DRAFT stays refused after activation: it is not the bound file
    assert {"approval is a DRAFT", "status is not active", "status must be 'active'"} <= probs and any("sha256" in x for x in probs)
    for k, v in (("model_id", "other/model"), ("host", "evil.example"), ("provider", "x"), ("model_file_sha256", "a" * 64), ("hosted", False)):
        bad = copy.deepcopy(a)
        bad[k] = v
        f = ROOT / "tmp-nim-bad.json"
        try:
            f.write_text(json.dumps(bad), encoding="utf-8")
            assert any(k in b for b in M.approval_problems(f, pol)), k
        finally:
            f.unlink(missing_ok=True)


def test_draft_approval_is_refused_at_model_construction(tmp_path, patched):
    srv = Hosted()
    shutil.copy(DRAFT, tmp_path / "approval.json")  # renamed, unedited
    sha = hashlib.sha256((tmp_path / "approval.json").read_bytes()).hexdigest()
    with pytest.raises(M.Refused, match="DRAFT"):
        M.Model(tmp_path / "o", backend=NIM, dispatch_cfg=cfg_for(srv.url, sha), approval_path=tmp_path / "approval.json")
    with pytest.raises(M.Refused, match="approval file missing"):
        M.Model(tmp_path / "o", backend=NIM, dispatch_cfg=cfg_for(srv.url), approval_path=tmp_path / "nope.json")
    assert srv.seen == []


@pytest.mark.parametrize("url", ["http://integrate.api.nvidia.com/v1", "https://evil.example/v1", "https://integrate.api.nvidia.com.evil.example/v1",
                                 "https://evil.example/integrate.api.nvidia.com/v1", "https://user@integrate.api.nvidia.com/v1", "https://integrate.api.nvidia.com/v1?x=1",
                                 "https://integrate.api.nvidia.com/v2", "https://127.0.0.1/v1", "ftp://integrate.api.nvidia.com/v1"])
def test_only_the_allowlisted_host_over_https_is_accepted(url):
    c = cfg_for(url)
    with pytest.raises(M.Invalidated, match="hosted backend endpoint refused"):
        M.apply_backend(D.pol(), NIM, c)
    assert M.hosted_endpoint_problem("https://integrate.api.nvidia.com/v1") is None and M.hosted_endpoint_problem("https://integrate.api.nvidia.com:443/v1/") is None


def test_hosted_cannot_be_default_and_the_endpoint_cannot_be_swapped_at_call_time(tmp_path, patched):
    srv = Hosted()
    c = cfg_for(srv.url)
    c["backends"]["default"] = NIM
    with pytest.raises(M.Refused, match="cannot be the default"):
        M.apply_backend(D.pol(), NIM, c)
    p, sha = active(tmp_path, srv.url)
    with pytest.raises(M.Invalidated, match="host other than"):
        M.Model(tmp_path / "o", backend=NIM, dispatch_cfg=cfg_for(srv.url, sha), approval_path=p, endpoint="https://evil.example/v1")
    assert srv.seen == []


def test_a_local_entry_cannot_claim_a_remote_host():
    c = {"backends": {"default": GPT, "list": [{"id": "x/y", "endpoint": "https://integrate.api.nvidia.com/v1", "file": "f", "bytes": 1, "sha256": "a" * 64, "context": 1}]}}
    with pytest.raises(M.Invalidated, match="loopback"):  # without class "hosted" the old loopback-only rule still applies
        M.apply_backend(D.pol(), "x/y", c)


# ---------------------------------------------------------------- the protocol: key, redirect, size, scrub
def test_live_call_sends_the_key_only_as_a_header_and_never_writes_it(tmp_path, patched):
    srv = Hosted("echo")  # the server echoes the Authorization header in content AND reasoning_content, and in its 401 text
    m = live_model(tmp_path, srv)
    assert m.list_models() == [NIM, "other/model"]
    r = m.call("propose", MSGS, 7)
    assert r["status"] == "ok" and "[REDACTED]" in r["content"] and KEY not in r["content"]
    gets, posts = [s for s in srv.seen if s["method"] == "GET"], srv.posts()
    assert gets[0]["auth"] == f"Bearer {KEY}" and posts[0]["auth"] == f"Bearer {KEY}" and KEY not in posts[0]["body"]
    body = json.loads(posts[0]["body"])
    assert body["model"] == NIM and "top_k" not in body and "repeat_penalty" not in body and body["max_tokens"] == D.pol()["sampling"]["max_tokens"]
    # an error reply that echoes the key
    bad = Hosted("e401")
    init_ledger(tmp_path / "l2.jsonl")
    m2 = M.Model(tmp_path / "o2", backend=NIM, pol=D.pol(), dispatch_cfg=cfg_for(bad.url, active(tmp_path, bad.url, "a2.json")[1]), approval_path=tmp_path / "a2.json", budget_usd=5.0, ledger_path=tmp_path / "l2.jsonl")
    assert m2.call("propose", MSGS, 7)["status"] == "transport_failure"
    assert bad.posts()[0]["auth"] == f"Bearer {KEY}"
    blob = all_bytes(tmp_path)
    assert KEY.encode() not in blob  # no file anywhere holds the key: out dirs, ledgers, approvals, receipts
    assert b"[REDACTED]" in blob


def test_missing_or_malformed_key_is_refused_with_zero_requests(tmp_path, patched, monkeypatch):
    srv = Hosted()
    m = live_model(tmp_path, srv)
    for bad in (None, "", "short", "has space inside key", "a\r\nX-Evil: 1" + "k" * 10):
        monkeypatch.delenv("NVIDIA_API_KEY", raising=False)
        if bad is not None: monkeypatch.setenv("NVIDIA_API_KEY", bad)
        with pytest.raises(M.Refused, match="NVIDIA_API_KEY"):
            m.call("propose", MSGS, 1)
    assert srv.seen == []


def test_redirects_are_not_followed_and_the_key_never_reaches_the_target(tmp_path, patched):
    target = Hosted()
    srv = Hosted("redirect", redirect_to=target.url.rsplit("/v1", 1)[0])
    m = live_model(tmp_path, srv)
    assert m.call("propose", MSGS, 1)["status"] == "transport_failure"
    with pytest.raises(Exception):
        m.list_models()
    assert target.seen == [] and len(srv.posts()) == 1
    assert m.ledger()[0]["http_status"] == 302


def test_oversized_reply_is_refused(tmp_path, patched):
    srv = Hosted("big")
    m = live_model(tmp_path, srv)
    r = m.call("propose", MSGS, 1)
    assert r["status"] == "transport_failure" and "over" in m.ledger()[0]["error"]


def test_https_is_required_for_the_real_endpoint(tmp_path, monkeypatch):
    monkeypatch.setattr(M, "HOSTED_HOSTS", {"127.0.0.1": "NVIDIA_API_KEY"})  # host patched, scheme NOT: http is still refused
    with pytest.raises(M.Invalidated, match="scheme"):
        M.apply_backend(D.pol(), NIM, cfg_for("http://127.0.0.1:9/v1"))


# ---------------------------------------------------------------- spend gate
def test_budget_refusal_makes_zero_requests(tmp_path, patched):
    srv = Hosted()
    m = live_model(tmp_path, srv, budget_usd=0.0001)  # far below one worst-case reservation
    with pytest.raises(M.BudgetRefused, match="budget refused"):
        m.call("propose", MSGS, 1)
    assert srv.seen == [] and m.ledger()[0]["status"] == "budget_refused"
    led = [json.loads(x) for x in (tmp_path / "ledger.jsonl").read_text(encoding="utf-8").splitlines() if json.loads(x).get("kind") != "genesis"]
    assert led[0]["source"].startswith("refusal: budget refused") and led[0]["cost_usd"] == 0.0


def test_worst_case_is_reserved_then_missing_usage_is_charged_at_the_worst_case(tmp_path, patched):
    srv = Hosted("no_usage")
    m = live_model(tmp_path, srv)
    price, mt = json.loads(CFG_PATH.read_text(encoding="utf-8"))["pricing"][NIM], m.pol["sampling"]["max_tokens"]
    raw = json.dumps(m.body(MSGS, 1), sort_keys=True, ensure_ascii=True).encode()
    worst = ((len(raw) + 256) * price["fresh_input"] + mt * price["output"]) / 1e6
    assert m.call("propose", MSGS, 1)["status"] == "ok"
    led = [json.loads(x) for x in (tmp_path / "ledger.jsonl").read_text(encoding="utf-8").splitlines() if json.loads(x).get("kind") != "genesis"]
    assert [x.get("kind", "usage") for x in led] == ["reservation", "usage"]
    assert abs(led[0]["cost_usd"] - worst) < 1e-12
    assert led[1]["measured"] is False and led[1]["source"] == "estimate" and abs(led[1]["cost_usd"] - worst) < 1e-12 and led[1]["output_tokens"] == mt  # never zero
    # partial usage (no completion count) is also worst case
    srv.mode = "partial"
    m.call("propose", MSGS, 2)
    led = [json.loads(x) for x in (tmp_path / "ledger.jsonl").read_text(encoding="utf-8").splitlines() if json.loads(x).get("kind") != "genesis"]
    assert led[-1]["measured"] is False and led[-1]["output_tokens"] == mt
    # the project budget is spent by the estimates: a tight budget now refuses with no new request
    n = len(srv.posts())
    m.budget_usd = worst * 2.5
    with pytest.raises(M.BudgetRefused):
        m.call("propose", MSGS, 3)
    assert len(srv.posts()) == n


def test_measured_usage_latency_and_status_are_recorded(tmp_path, patched):
    srv = Hosted("ok")
    m = live_model(tmp_path, srv)
    m.call("propose", MSGS, 1)
    row = m.ledger()[0]
    assert row["http_status"] == 200 and row["usage"]["prompt_tokens"] == 50 and row["usage"]["completion_tokens"] == 20 and row["latency_s"] >= 0 and row["response_model"] == NIM
    led = [json.loads(x) for x in (tmp_path / "ledger.jsonl").read_text(encoding="utf-8").splitlines() if json.loads(x).get("kind") != "genesis"]
    u = led[-1]
    assert (u["fresh_input_tokens"], u["cached_read_tokens"], u["output_tokens"], u["measured"]) == (40, 10, 20, True) and 0 < u["cost_usd"] < led[0]["cost_usd"]


def test_unpriced_hosted_model_fails_closed_even_on_the_stub(tmp_path):
    srv = Hosted()
    pol = M.apply_backend(D.pol(), NIM)
    m = M.Model(tmp_path / "o", stub=True, endpoint=srv.url, pol=pol, pricing={}, budget_usd=5.0)
    with pytest.raises(M.BudgetRefused, match="no price"):  # a stub zero-fills local prices only
        m.call("propose", MSGS, 1)
    assert srv.seen == []


# ---------------------------------------------------------------- data guard
def test_real_input_content_is_never_sent_to_a_hosted_backend(tmp_path, patched):
    srv = Hosted()
    real = b"id,group,bytes\nsecret-customer.txt,docs,10\nother-private-row.png,img,2048\n"
    m = live_model(tmp_path, srv, private_blobs=[real])
    clean = [{"role": "user", "content": "Worked cases: a.txt docs 10"}]
    assert m.call("propose", clean, 1)["status"] == "ok"
    n = len(srv.posts())
    leaks = [real.decode(), "see: " + real.decode().splitlines()[2], base64.b64encode(real).decode(), "x" + base64.b64encode(real).decode()[:60] + "y",
             "data: " + base64.b64encode(os.urandom(600)).decode()]  # text, a row, base64, a base64 slice, and an unregistered long payload
    for t in leaks:
        with pytest.raises(M.DataRefused):
            m.call("propose", [{"role": "system", "content": "s"}, {"role": "user", "content": t}], 1)
    assert len(srv.posts()) == n  # none of them left the process
    assert any(r.get("status") == "data_refused" for r in m.ledger()) and real.decode() not in all_bytes(tmp_path).decode("utf-8", "replace")
    local = M.Model(tmp_path / "ol", stub=True, endpoint=STUB.serve_thread(None, log=str(tmp_path / "l.jsonl"))[1], private_blobs=[real])
    assert local.call("propose", [{"role": "user", "content": "Target type: Source\n" + real.decode()}], 1)["status"] == "ok"  # the guard is for hosted backends only


def test_discovery_on_a_hosted_backend_cannot_carry_a_registered_input(env, fake_runs, tmp_path):
    """Whole path: the discovery prompt is built from the frozen spec + public dev cases. A blob taken from a public dev case stands in for a real input that
    leaked into it: the hosted call is refused (experiment INTERRUPTED, zero requests); a registered real input that is NOT in the prompt changes nothing."""
    c = cfg_for("https://integrate.api.nvidia.com/v1", measured=True)
    exp = opened(env, proposer_model=NIM)
    gp = D._load("gen_public", D.contract_of(exp))
    leaked = next(f["text"] for k in gp.cases() for f in k["env"]["files"] if len(f["text"]) > 40)
    srv = STUB.make_server({"R": WRONGS}, 0, str(tmp_path / "req.jsonl"), model_id=NIM)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{srv.server_port}/v1"
    done = D.run_experiment(env[0], exp["exp_id"], stub_endpoint=url, private_dir=env[2], requested_model=NIM, dispatch_cfg=c, private_blobs=[leaked])
    assert srv.counters["total"] == 0 and done["state"] == "INTERRUPTED" and "DataRefused" in done["reason"]
    done = D.run_experiment(env[0], exp["exp_id"], stub_endpoint=url, private_dir=env[2], requested_model=NIM, dispatch_cfg=c, private_blobs=[b"id,real,user\nnever-in-a-prompt-1234567890,1\n"])
    assert srv.counters["total"] >= 1 and done["state"] != "INTERRUPTED"


# ---------------------------------------------------------------- discovery: policy, request, gating
def test_discovery_with_backend_nim_builds_the_nim_policy_and_request(env, fake_runs, tmp_path):
    c = cfg_for("https://integrate.api.nvidia.com/v1", measured=True)  # as if a live smoke receipt existed (shipped config: measured false)
    exp = opened(env, proposer_model=NIM)
    srv = STUB.make_server({"R": WRONGS}, 0, str(tmp_path / "req.jsonl"), model_id=NIM)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{srv.server_port}/v1"
    done = D.run_experiment(env[0], exp["exp_id"], stub_endpoint=url, private_dir=env[2], requested_model=NIM, dispatch_cfg=c)
    bodies = [json.loads(x) for x in (tmp_path / "req.jsonl").read_text(encoding="utf-8").splitlines()]
    assert srv.counters["total"] >= 1 and {b["model"] for b in bodies} == {NIM} and done["state"] != "MODEL_UNAVAILABLE"
    b = bodies[0]
    assert b["max_tokens"] <= 4096 and b["temperature"] == 0.2 and "top_k" not in b and "repeat_penalty" not in b
    system = b["messages"][0]["content"]
    assert not system.startswith("Reasoning:") and system.startswith("You write one pure Python 3 function.")  # prefix swapped for "", the task text is intact
    assert D.SYSTEM.split("\n", 1)[1] == system  # exactly the gpt-oss prompt minus its first line
    disp = json.loads((env[0] / "discovery" / exp["exp_id"] / "model" / "model_dispatch.jsonl").read_text(encoding="utf-8").splitlines()[0])
    assert disp["executed_model"] == NIM and disp["cost_usd"] is None and disp["reason_codes"] == []


def test_default_gpt_oss_system_line_is_unchanged(env, fake_runs, tmp_path):
    exp = opened(env)
    srv, url = STUB.serve_thread({"R": WRONGS}, log=str(tmp_path / "req.jsonl"))
    D.run_experiment(env[0], exp["exp_id"], stub_endpoint=url, private_dir=env[2])
    b = json.loads((tmp_path / "req.jsonl").read_text(encoding="utf-8").splitlines()[0])
    assert b["messages"][0]["content"] == D.SYSTEM and D.SYSTEM.startswith("Reasoning: low\n") and "top_k" in b and "repeat_penalty" in b


def test_system_prefix_is_per_backend_and_only_replaces_the_reasoning_line(tmp_path):
    srv, url = STUB.serve_thread(None)
    pol = M.apply_backend(D.pol(), NIM)
    for pref, want in (("", "BODY"), ("Think briefly.", "Think briefly.\nBODY")):
        pol["model"]["system_prefix"] = pref
        m = M.Model(tmp_path / ("o" + str(len(pref))), stub=True, endpoint=url, pol=pol, budget_usd=5.0)
        msgs = [{"role": "system", "content": "Reasoning: low\nBODY"}, {"role": "user", "content": "Reasoning: low\nstays"}]
        b = m.body(msgs, 1)
        assert b["messages"][0]["content"] == want and b["messages"][1]["content"] == "Reasoning: low\nstays"
        assert msgs[0]["content"] == "Reasoning: low\nBODY"  # the caller's messages are not mutated


def test_unqualified_nim_is_refused_by_dispatch_before_any_call(env, fake_runs, tmp_path):
    c = cfg_for("https://integrate.api.nvidia.com/v1", measured=False)  # an unqualified hosted backend
    exp = opened(env, proposer_model=NIM)
    srv = STUB.make_server({"R": WRONGS}, 0, str(tmp_path / "req.jsonl"), model_id=NIM)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    done = D.run_experiment(env[0], exp["exp_id"], stub_endpoint=f"http://127.0.0.1:{srv.server_port}/v1", private_dir=env[2], requested_model=NIM, dispatch_cfg=c)
    assert srv.counters["total"] == 0 and done["state"] == "MODEL_UNAVAILABLE"


def test_lm_studio_state_probe_is_never_sent_to_a_hosted_host():
    from hive import model_dispatch as MD
    assert MD.loaded("https://integrate.api.nvidia.com/v1", NIM) is None


# ---------------------------------------------------------------- opt-in live smoke (NVIDIA_API_KEY + HIVE_LIVE_NIM=1): one models list + at most 2 chat calls
@pytest.mark.skipif(not os.environ.get("NVIDIA_API_KEY") or os.environ.get("HIVE_LIVE_NIM") != "1", reason="opt-in: NVIDIA_API_KEY set and HIVE_LIVE_NIM=1 (real, billed calls)")
def test_live_nim_smoke_writes_a_receipt(tmp_path):
    """The REAL path: production allowlist, https, the real model list, the spend gate on a throwaway ledger (so the project ledger is not touched),
    a temporary ACTIVE approval under tmp_path (the owner's DRAFT is never activated)."""
    ep = M.apply_backend(D.pol(), NIM)["model"]["endpoint"]
    d = json.loads(DRAFT.read_text(encoding="utf-8"))
    d.update(status="active", approver="smoke", approved_at=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), statement="live smoke only", context="smoke")
    ap = tmp_path / "approval.json"
    raw = (json.dumps(d, indent=2) + "\n").encode()
    ap.write_bytes(raw)
    cfg = json.loads(CFG_PATH.read_text(encoding="utf-8"))
    for e in cfg["backends"]["list"]:
        if e["id"] == NIM: e.update(approval_sha256=hashlib.sha256(raw).hexdigest(), approval_path="approval.json")
    pol = copy.deepcopy(D.pol())
    pol["sampling"]["max_tokens"], pol["call_timeout_s"], pol["transport_retries"] = 1024, 240, 0
    init_ledger(tmp_path / "ledger.jsonl")
    m = M.Model(tmp_path / "o", backend=NIM, pol=pol, dispatch_cfg=cfg, approval_path=ap, ledger_path=tmp_path / "ledger.jsonl", budget_usd=1.0)
    assert m.endpoint == ep
    t0 = time.time()
    ids = m.list_models()
    list_s = round(time.time() - t0, 3)
    msgs = [{"role": "system", "content": D.SYSTEM.split("\n", 1)[1]}, {"role": "user", "content": "Write `def run(env): return 'ok'`."}]
    calls = []
    for i in range(2):
        r = m.call("smoke", msgs, 2026119100 + i)
        row = m.ledger()[-1]
        calls.append({"status": r["status"], "http_status": row.get("http_status"), "latency_s": row.get("latency_s"), "usage": row.get("usage"),
                      "response_model": row.get("response_model"), "has_code": bool(D.extract_code(r["content"]))})
        if r["status"] == "ok" and calls[-1]["has_code"]: break
    ok = [c for c in calls if c["status"] == "ok"]
    rec = {"model_id": NIM, "provider": "nvidia-nim", "host": "integrate.api.nvidia.com", "listed": NIM in ids, "models_listed": len(ids), "list_latency_s": list_s, "calls": calls,
           "spend_ledger_usd": round(sum(json.loads(x)["cost_usd"] for x in (tmp_path / "ledger.jsonl").read_text(encoding="utf-8").splitlines() if '"kind":"usage"' in x or '"reservation_id"' in x and '"kind"' not in x), 6),
           "measured_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "note": "adapter smoke only: not an evaluator measurement; approval stays unqualified until the conductor activates it"}
    assert ok and ok[0]["response_model"] == NIM
    assert os.environ["NVIDIA_API_KEY"].encode() not in all_bytes(tmp_path) and os.environ["NVIDIA_API_KEY"] not in json.dumps(rec)
    (ROOT / "build" / "prototype" / "approvals" / "nim-smoke-receipt.json").write_text(json.dumps(rec, indent=2) + "\n", encoding="utf-8", newline="\n")
