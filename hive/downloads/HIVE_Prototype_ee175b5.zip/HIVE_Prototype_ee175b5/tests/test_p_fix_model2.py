"""F3b: proposer per-call budget (4096) stays inside the owner caps; qwen not 'measured' without a receipt; qwen approval accepted on the discovery path."""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_p_fix_model import QWEN, active, cfg_with  # noqa: E402
from hive import acquire as A, discovery as D, m2_model as M  # noqa: E402


def test_proposer_cap_is_4096_and_inside_the_owner_caps():
    B, M2 = D.BUDGET, json.loads((ROOT / "build/m2/operator_inference_approval.json").read_text(encoding="utf-8"))["caps"]
    assert B["max_tokens_per_call"] == 4096 and B["out_tokens"] == 6000 == D.APPROVAL_CAPS["output_tokens"] and A.BUDGET["max_out_tokens"] == 4096
    assert D.pol()["sampling"]["max_tokens"] == 4096 and D.pol()["max_tokens_total"] == B["in_tokens"] + B["out_tokens"]
    assert D.pol()["call_timeout_s"] >= 4096 / 150 * 3  # 4,096 tokens at ~150 tok/s is ~27 s; 3x margin
    per_call = B["in_tokens"] // B["calls"] + B["max_tokens_per_call"]  # prompt share + full output
    assert M2["model_calls"] * per_call <= M2["tokens_total"]  # even a campaign spending every call at the cap
    assert B["proposals"] <= M2["proposals_total"] and B["calls"] <= M2["model_calls"]
    assert (B["in_tokens"] + B["out_tokens"]) * (M2["proposals_total"] // B["proposals"]) <= M2["tokens_total"]  # one experiment per 3 proposals


def test_qwen_unmeasured_until_a_live_receipt():
    q = json.loads((ROOT / "configs/model_dispatch.json").read_text(encoding="utf-8"))["qualified"][QWEN]
    assert q["measured"] is False


def test_activated_qwen_approval_passes_the_discovery_caps_and_may_say_draft(tmp_path):
    p, sha = active(tmp_path, statement_note="x")  # kwargs land in the approval body
    pol = M.apply_backend(D.pol(), QWEN, cfg_with(sha))
    assert not [b for b in M.approval_problems(p, pol) if b == "caps"]
    d = json.loads(p.read_text(encoding="utf-8")); d["statement"] = "approved from the draft"
    p.write_text(json.dumps(d), encoding="utf-8")
    assert "approval is a DRAFT" not in M.approval_problems(p, pol)  # N9: the word in prose is not a draft
