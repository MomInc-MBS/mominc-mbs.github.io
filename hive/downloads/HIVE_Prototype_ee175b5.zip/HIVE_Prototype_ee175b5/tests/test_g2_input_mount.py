"""filesystem: "read-only-inputs": input files appear as read-only files under /in/files, in the dev run, the evaluator run and retained execution.
Unit tests use a fake DockerIsolation; the real-container end-to-end test is opt-in (HIVE_REAL_DOCKER=1)."""
from __future__ import annotations

import base64
import copy
import json
import os
import sys
import threading
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))
from hive import acq_stage as ST, capcontract as CC, discovery as D, experiment_compare as EC  # noqa: E402
from hive.adapters import isolation as ISO  # noqa: E402
from hive.operator_runtime import Refused  # noqa: E402
from hive.storage import Store  # noqa: E402
from test_g2_acquire import CAP, GOODBODY, POL, go, hooks, queued, serve, world  # noqa: E402,F401
from test_g2_kernel import _mod, env_rec  # noqa: E402
from test_g2_stage import FakeDocker  # noqa: E402

HARNESS = _mod(ROOT / "evaluator" / "g2" / "harness.py")


def env_of(*pairs):
    return {"files": [{"name": n, "format": "base64", "data": base64.b64encode(b).decode()} for n, b in pairs]}


# ================================================================= contract
def test_image_contract_opts_in_and_the_schema_accepts_only_known_values():
    c = CC.get(CAP)
    assert c["permissions"]["filesystem"] == "read-only-inputs" and CC.exec_args(c)["inputs"] == "read-only"
    assert "PATH" in CC.envelope_text(c)
    for bad in ("read-write", "all", True, None):
        x = copy.deepcopy(c)
        x["permissions"]["filesystem"] = bad
        with pytest.raises(Refused):
            CC.validate(x)
    x = copy.deepcopy(c)
    x["inputs"].update(envelope="files-v1", format="text")
    x["inputs"].pop("limits")
    with pytest.raises(Refused, match="files-v2|read-only-inputs"):
        CC.validate(x)


def test_contracts_without_the_permission_are_unchanged():
    v1 = CC.get("inventory-diff")
    assert v1["permissions"]["filesystem"] == "none" and CC.exec_args(v1) == {} and "path" not in CC.envelope_text(v1).lower().replace("pathology", "")
    c = copy.deepcopy(CC.get(CAP))
    c["permissions"]["filesystem"] = "none"
    assert CC.validate(c) is c and "inputs" not in CC.exec_args(c, {"id": "sha256:" + "a" * 64}) and "PATH" not in CC.envelope_text(c)
    v1x = copy.deepcopy(v1)
    v1x["permissions"]["filesystem"] = "read-only-inputs"
    with pytest.raises(Refused):  # v1 stays const "none"
        CC.validate(v1x)


# ================================================================= materialisation
def test_safe_aliases_are_deterministic_unique_and_host_safe():
    used = set()
    a = [ISO.safe_alias(n, used) for n in ("photo.png", "Photo.PNG", "with space.jpg", "CON.png", "nul", "trail.", "../x.png", "a/b.png", "x" * 150 + ".png", "ünï.png", "")]
    assert a[0] == "photo.png" and a[1] != "Photo.PNG" and a[1].startswith("f-")  # a case-insensitive repeat gets an alias
    assert all(ISO.SAFE_NAME.match(x) and not x.endswith(".") and x.split(".")[0].upper() not in ISO._RESERVED for x in a), a
    assert len({x.lower() for x in a}) == len(a)
    again = [ISO.safe_alias(n, set()) for n in ("with space.jpg", "../x.png")]
    assert again == [ISO.safe_alias(n, set()) for n in ("with space.jpg", "../x.png")] and again[0].endswith(".jpg") and "/" not in again[1]


def test_materialize_writes_matching_bytes_and_sets_paths_per_env(tmp_path):
    e0 = env_of(("a.png", b"\x89PNG\x00one"), ("my pic.jpg", b"\xff\xd8two"), ("A.PNG", b"three"))
    e1 = env_of(("a.png", b"other-env"))
    text = ISO.materialize_inputs(json.dumps([e0, e1]), tmp_path)
    out = json.loads(text)
    for i, (env, src) in enumerate(zip(out, [e0, e1])):
        for f, g in zip(env["files"], src["files"]):
            assert f["name"] == g["name"] and f["data"] == g["data"]  # name and data untouched
            assert f["path"].startswith(f"/in/files/{i}/")
            p = tmp_path / f["path"][len("/in/files/"):]
            assert p.read_bytes() == base64.b64decode(f["data"]) and not os.access(p, os.W_OK) or p.read_bytes() == base64.b64decode(f["data"])
    assert out[0]["files"][0]["path"] == "/in/files/0/a.png" and out[0]["files"][1]["path"].startswith("/in/files/0/f-") and out[0]["files"][2]["path"].startswith("/in/files/0/f-")
    assert out[1]["files"][0]["path"] == "/in/files/1/a.png"  # a different env, its own directory: no collisions across batched cases
    assert (tmp_path / "0" / "a.png").stat().st_mode & 0o222 == 0 or os.name == "nt"


def test_materialize_leaves_text_entries_alone_and_rejects_bad_base64(tmp_path):
    env = {"files": [{"format": "text", "text": "hello"}]}
    assert json.loads(ISO.materialize_inputs(json.dumps([env]), tmp_path)) == [env]
    with pytest.raises(Exception):
        ISO.materialize_inputs(json.dumps([{"files": [{"name": "a", "format": "base64", "data": "!!!not base64"}]}]), tmp_path / "x")


# ================================================================= runner plumbing (fake DockerIsolation)
class FakeIso:
    seen = []

    def execute(self, request):
        src = {dst: Path(s) for s, dst in request.get("read_only_mounts", [])}
        work = Path(request["repo_copy"])
        info = {"request": request, "mounts": dict(src), "in_json": json.loads((work / "in.json").read_text(encoding="utf-8")),
                "existed": {dst: s.is_dir() for dst, s in src.items()}, "files": {dst: sorted(str(p.relative_to(s)) for p in s.rglob("*") if p.is_file()) for dst, s in src.items()}}
        FakeIso.seen.append(info)
        return ISO.IsolationResult("passed", {"stdout": '{"out": "ok"}', "timed_out_or_output_capped": False, "exit_code": 0})


@pytest.fixture
def fake_iso(monkeypatch):
    FakeIso.seen = []
    monkeypatch.setattr(ISO, "DockerIsolation", FakeIso)
    return FakeIso


def test_run_isolated_mounts_inputs_read_only_and_cleans_up(fake_iso):
    text = json.dumps([env_of(("a.png", b"abc"), ("b c.jpg", b"xyz"))])
    assert EC.run_isolated("s", text, {}, backend="container", operator_class="generated", inputs="read-only") == "ok"
    seen = fake_iso.seen[0]
    assert list(seen["mounts"]) == ["/in/files"] and seen["existed"]["/in/files"] and len(seen["files"]["/in/files"]) == 2  # exactly the inputs, one mount
    assert [m for m in seen["request"]["read_only_mounts"]] == [(str(seen["mounts"]["/in/files"]), "/in/files")]
    sent = json.loads(seen["in_json"]["text"])
    assert [f["path"].startswith("/in/files/0/") for f in sent[0]["files"]] == [True, True]
    assert not seen["mounts"]["/in/files"].exists() and not Path(seen["request"]["repo_copy"]).exists()  # both temp dirs removed


def test_temp_dirs_are_removed_when_the_container_fails_or_times_out(monkeypatch):
    kept = []

    class Boom:
        def execute(self, request):
            kept.extend([Path(request["repo_copy"]), Path(request["read_only_mounts"][0][0])])
            raise ISO.SandboxUnavailable("BLOCKED_SANDBOX: simulated")
    monkeypatch.setattr(ISO, "DockerIsolation", Boom)
    with pytest.raises(ISO.SandboxUnavailable):
        EC.run_isolated("s", json.dumps([env_of(("a.png", b"x"))]), {}, backend="container", operator_class="generated", inputs="read-only")
    assert len(kept) == 2 and not any(p.exists() for p in kept)

    class Slow:
        def execute(self, request):
            kept.append(Path(request["read_only_mounts"][0][0]))
            return ISO.IsolationResult("failed", {"stdout": "", "timed_out_or_output_capped": True, "exit_code": 137})
    monkeypatch.setattr(ISO, "DockerIsolation", Slow)
    with pytest.raises(RuntimeError, match="timed out"):
        EC.run_isolated("s", json.dumps([env_of(("a.png", b"x"))]), {}, timeout=3, backend="container", operator_class="generated", inputs="read-only")
    assert not kept[-1].exists()


def test_without_the_mode_nothing_is_added_and_bad_modes_are_refused(fake_iso):
    text = json.dumps([env_of(("a.png", b"abc"))])
    EC.run_isolated("s", text, {}, backend="container", operator_class="generated")
    seen = fake_iso.seen[0]
    assert seen["request"]["read_only_mounts"] == [] and json.loads(seen["in_json"]["text"]) == json.loads(text)  # byte-for-byte the old behaviour
    with pytest.raises(ValueError):
        EC.run_isolated("s", text, {}, backend="container", operator_class="generated", inputs="read-write")
    with pytest.raises(RuntimeError, match="container backend"):
        EC.run_isolated("s", text, {}, backend="process", inputs="read-only")


def test_docker_argv_has_only_readonly_mounts_and_no_new_writable_one(tmp_path, monkeypatch):
    seen = {}
    monkeypatch.setattr(ISO.DockerIsolation, "inspect", lambda self, image: {"engine": "docker"})
    monkeypatch.setattr(ISO, "_bounded_process", lambda argv, **kw: (seen.update(argv=argv) or (0, b"{}", b"", False, False)))
    d = tmp_path / "files"
    d.mkdir()
    ISO.DockerIsolation("docker").execute({"repo_copy": tmp_path, "image": {"id": "sha256:" + "c" * 64}, "command": ["x"], "read_only_mounts": [(d, "/in/files")],
                                           "limits": {"memory_mb": 128, "cpu_count": 1, "pids": 32, "timeout_s": 5, "output_bytes": 9}})
    a = seen["argv"]
    mounts = [a[i + 1] for i, x in enumerate(a) if x == "--mount"]
    assert len(mounts) == 2 and all(m.endswith(",readonly") for m in mounts) and any("dst=/in/files" in m for m in mounts)
    assert "--read-only" in a and "--tmpfs=/tmp:rw,noexec,nosuid,size=16m" in a and "--network=none" in a and not any(x.startswith("--volume") or x == "-v" for x in a)


# ================================================================= all three run paths pass the mode
def test_dev_run_evaluator_run_and_retained_execution_all_use_the_mount(world):
    names = ["o0/a"]
    rid = queued(world, names)
    rec = go(world, rid, hooks(world, names), run_kw=serve(world, [GOODBODY]))
    assert rec["state"] == "AWAITING_ADMISSION" and world.kws
    assert all(k.get("inputs") == "read-only" for k in world.kws if "image" in k)  # the dev run (image + limits + inputs)
    prompt = json.loads((world.tmp / "req.jsonl").read_text(encoding="utf-8").splitlines()[0])["messages"][1]["content"]
    assert "BOTH as base64" in prompt and "read-only file at the entry's `path`" in prompt


def test_evaluator_forwards_inputs_to_the_container_runner(tmp_path, monkeypatch):
    ev = _mod(ROOT / "evaluator" / "g2" / "evaluate.py")
    c = CC.get(CAP)
    suite = ROOT / c["verification"]["suite_ref"]
    gp = _mod(suite / "gen_private.py")
    orc = _mod(suite / "oracle.py")
    cases = gp.generate(4, 2)
    sha = gp.set_sha(cases)
    (tmp_path / "priv" / sha).mkdir(parents=True)
    (tmp_path / "priv" / sha / "cases.json").write_text(json.dumps(cases), encoding="utf-8")
    body = "import json\nimport tinytool\n\n\ndef run(env):\n    return ''\n"
    (tmp_path / "c.py").write_text(body, encoding="utf-8", newline="\n")
    got = {}
    monkeypatch.setattr(EC, "run_isolated", lambda src, text, checks, **k: (got.update(k), json.dumps([orc.expected(e) for e in json.loads(text)]))[1])
    a = SimpleNamespace(suite=str(suite), exp="d-1", frozen_sha="f", candidate_file=str(tmp_path / "c.py"), candidate_sha=D._sha(body), private=str(tmp_path / "priv"), set=sha,
                        label="candidate", out=str(tmp_path / "r.json"), baseline_receipt=None, timeout=60, image_id="sha256:" + "c" * 64, imports="json,tinytool",
                        memory_mb=512, cpus=2, pids=64, tmpfs_mb=64, inputs="read-only")
    with CC.scope(c):  # evaluate() imports the suite's bare modules at call time
        assert ev.evaluate(a)["verdict"] == "PASS" and got["inputs"] == "read-only" and got["image"] == {"id": a.image_id}
        got.clear()
        a.inputs = None
        ev.evaluate(a)
    assert "inputs" not in got


def test_discovery_passes_the_flag_to_the_evaluator_and_v1_contracts_do_not(tmp_path, monkeypatch):
    c = CC.get(CAP)
    s = Store(tmp_path / "s")
    s.set("gap/x", {"missing_step": {"in": "image_file", "arity": 3, "out": "image_match_manifest", "ordered": True}, "partial_plan": []})
    rec = D.open_experiment(s, "gap/x", private_dir=tmp_path / "p", seed=1, environment=env_rec(), card_excerpt="x")
    s.close()
    got = {}
    monkeypatch.setattr(D, "_launch", lambda args, ev: got.update(args=args) or SimpleNamespace(returncode=1, stdout=b"", stderr=b"", timed_out=False))
    (tmp_path / "b.py").write_text("x", encoding="utf-8")
    with pytest.raises(RuntimeError):
        D._evaluate(rec, tmp_path, tmp_path / "b.py", "candidate", tmp_path / "p")
    a = got["args"]
    assert a[a.index("--inputs") + 1] == "read-only" and c


# ================================================================= 3. pip temp churn
def test_tree_size_ignores_vanishing_paths_and_missing_roots(tmp_path):
    (tmp_path / "a").mkdir()
    (tmp_path / "a" / "f").write_bytes(b"x" * 10)
    assert ST.tree_size(tmp_path) == 10 and ST.tree_size(tmp_path / "nope") == 0
    stop, errors = threading.Event(), []

    def churn():
        i = 0
        while not stop.is_set():
            d = tmp_path / ST.SCRATCH / f"pip-unpack-{i % 5}"
            d.mkdir(parents=True, exist_ok=True)
            for k in range(20):
                (d / f"w{k}").write_bytes(b"y" * 100)
            for p in list(d.iterdir()):
                p.unlink(missing_ok=True)
            try:
                d.rmdir()
            except OSError:
                pass
            i += 1
    t = threading.Thread(target=churn)
    t.start()
    try:
        for _ in range(300):
            try:
                assert ST.tree_size(tmp_path) >= 10
            except Exception as e:  # noqa: BLE001
                errors.append(e)
    finally:
        stop.set()
        t.join()
    assert not errors


def test_download_survives_pip_temp_churn_and_the_watchdog_never_dies(tmp_path, monkeypatch):
    crashed = []
    monkeypatch.setattr(threading, "excepthook", lambda a: crashed.append(a.exc_type))
    real = ST.tree_size
    flaky = {"n": 0}

    def tree(path):
        flaky["n"] += 1
        if flaky["n"] % 3 == 0:
            raise FileNotFoundError("pip-unpack vanished")  # even an unexpected error must not kill the watchdog
        return real(path)
    monkeypatch.setattr(ST, "tree_size", tree)

    def run(argv, timeout):
        if argv[1] == "run":
            scratch = tmp_path / ST.SCRATCH
            for i in range(30):
                d = scratch / f"pip-unpack-{i}"
                d.mkdir(parents=True, exist_ok=True)
                (d / "f").write_bytes(b"z" * 50)
                (d / "f").unlink()
                d.rmdir()
                time.sleep(0.01)
            (tmp_path / "x.whl").write_bytes(b"wheel")
        return 0, b"", b""
    s = ST.Stager(POL, run=run)
    s.poll_s = 0.002
    s.download(["x"], tmp_path)  # completes, no exception: the candidate is not aborted
    assert not crashed and flaky["n"] > 3 and (tmp_path / "x.whl").exists() and not (tmp_path / ST.SCRATCH).exists()


def test_cap_still_enforced_with_churn(tmp_path):
    calls = []

    def run(argv, timeout):
        calls.append(list(argv))
        if argv[1] == "run":
            (tmp_path / "huge.whl").write_bytes(b"x" * 5000)
            time.sleep(1.0)
        return 0, b"", b""
    s = ST.Stager(dict(POL, stage=dict(POL["stage"], max_wheelhouse_bytes=1000)), run=run, prefix="hive-stage-ch")
    s.poll_s = 0.02
    with pytest.raises(ST.StageRejected) as e:
        s.download(["x"], tmp_path)
    assert e.value.code == "WHEELHOUSE_TOO_LARGE" and any(c[:3] == ["docker", "rm", "--force"] for c in calls)


# ================================================================= real Docker end to end
@pytest.mark.skipif(os.environ.get("HIVE_REAL_DOCKER") != "1", reason="opt-in: starts real hive-code-* containers")
def test_real_container_reads_the_inputs_by_path_and_cannot_write_them():
    payload = [b"\x89PNG\r\n\x1a\n" + bytes(range(256)), b"second file"]
    env = env_of(("pic one.png", payload[0]), ("CON.png", payload[1]), ("PIC ONE.PNG", b"case twin"))
    body = ("import json\nimport os\n\n\ndef run(env):\n    out = {}\n    for f in env['files']:\n        with open(f['path'], 'rb') as h:\n            out[f['name']] = h.read().hex()\n"
            "    first = env['files'][0]['path']\n    res = {}\n    for label, target in (('overwrite', first), ('new_in_mount', os.path.dirname(first) + '/new.txt'), ('work', '/work/in.json'),"
            " ('root', '/etc/x')):\n        try:\n            open(target, 'wb').write(b'x')\n            res[label] = 'WROTE'\n        except OSError as e:\n            res[label] = type(e).__name__\n"
            "    try:\n        open('/tmp/ok', 'wb').write(b'x')\n        res['tmp'] = 'wrote'\n    except OSError as e:\n        res['tmp'] = type(e).__name__\n"
            "    res['paths'] = [f['path'] for f in env['files']]\n    res['files'] = out\n    return json.dumps(res)\n")
    r = json.loads(EC.run_isolated(HARNESS.wrap(body), json.dumps([env]), {}, timeout=60, backend="container", operator_class="generated", inputs="read-only"))[0]
    res = json.loads(r)
    assert res["overwrite"] != "WROTE" and res["new_in_mount"] != "WROTE" and res["work"] != "WROTE" and res["root"] != "WROTE" and res["tmp"] == "wrote"
    assert res["files"]["pic one.png"] == payload[0].hex() and res["files"]["CON.png"] == payload[1].hex() and res["files"]["PIC ONE.PNG"] == b"case twin".hex()
    assert len(set(p.lower() for p in res["paths"])) == 3 and res["paths"][0].startswith("/in/files/0/f-")  # unsafe names aliased, all distinct
    # and without the mode the same adapter sees no path at all
    plain = json.loads(EC.run_isolated(HARNESS.wrap("def run(env):\n    return str('path' in env['files'][0])\n"), json.dumps([env]), {}, timeout=60, backend="container",
                                       operator_class="generated"))
    assert plain == ["False"]
