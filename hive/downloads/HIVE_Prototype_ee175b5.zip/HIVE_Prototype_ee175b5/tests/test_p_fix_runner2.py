"""F1b: regression tests for REVIEW_P2 N1 (forged registry task replay) and N3 (_write follows a planted link). Docker-free."""
from __future__ import annotations

import json
import os

import pytest

from hive import experiment_compare as EC, goal_runner as G, operator_runtime as O
from hive.storage import Store

GOOD = b"id,group,bytes\na.txt,docs,10\nb.png,img,2048\n"


@pytest.fixture
def runs(monkeypatch):
    calls = []

    def fake(src, text, checks, timeout=None, max_out=None, *, backend, operator_class):
        calls.append(1)
        ns = {}
        exec(compile(src, "<genome>", "exec"), ns)
        return ns["apply"](text, checks)
    monkeypatch.setattr(EC, "run_isolated", fake)
    return calls


@pytest.fixture
def root(tmp_path):
    s = Store(tmp_path / "s")
    O.import_bundle(s)
    s.close()
    return tmp_path / "s"


def _forge(root, tid, edit):
    s = Store(root)
    t = s.get("operator/task/" + tid)
    edit(t)
    s.set("operator/task/" + tid, t)
    s.close()


def test_n1_forged_outside_ref_is_not_replayed(root, runs, tmp_path):
    secret = tmp_path / "outside.csv"
    secret.write_bytes(b"SECRET")
    tid = O.task_id("convert", [("x.csv", GOOD)])
    s = Store(root)
    s.set("operator/task/" + tid, {"task_id": tid, "op": "convert", "state": "VERIFIED", "capability": {"genome": O.resolve(s, "convert")["genome"]},
                                   "verification": {"verdict": "PASS", "pin": O.evaluator_pin()},
                                   "artifacts": [{"name": "rows.csv", "ref": str(secret), "sha256": O._sha(b"SECRET")}]})
    s.close()
    r = O.run_task(root, "convert", [("x.csv", GOOD)])
    assert r["mode"] != "saved_result_replay" and len(runs) == 1 and r["state"] == "VERIFIED"
    assert all(a["ref"].startswith("output/operator/" + tid + "/") for a in r["artifacts"])


def test_n1_goal_does_not_import_outside_bytes(root, runs, tmp_path):
    allowed = tmp_path / "allowed"
    allowed.mkdir()
    (allowed / "x.csv").write_bytes(GOOD)
    c, inputs = G.prepare(root, allowed, "convert", ["x.csv"])
    r0 = G.run_goal(root, c, inputs)
    st = r0["steps"][0]
    secret = tmp_path / "outside.csv"
    secret.write_bytes(b"SECRET-OUTSIDE")
    _forge(root, st["task_id"], lambda t: t.update(artifacts=[dict(a, ref=str(secret), sha256=O._sha(b"SECRET-OUTSIDE")) for a in t["artifacts"]]))
    r = G.run_goal(root, c, inputs)
    assert r["state"] == "VERIFIED" and all(a["ref"].startswith("output/operator/") for a in r["deliverable"])
    assert not any(b"SECRET-OUTSIDE" in p.read_bytes() for p in (root / "output").rglob("*") if p.is_file())


def test_n1_tampered_raw_output_reexecutes_and_honest_replays(root, runs):
    r = O.run_task(root, "convert", [("x.csv", GOOD)])
    tid = r["task_id"]
    again = O.run_task(root, "convert", [("x.csv", GOOD)])
    assert again["mode"] == "saved_result_replay" and len(runs) == 1  # honest replay still works, check re-run on saved bytes
    (root / "output" / "operator" / tid / "raw_output.json").write_text(json.dumps({"converted": "[]"}))
    r2 = O.run_task(root, "convert", [("x.csv", GOOD)])
    assert r2["mode"] != "saved_result_replay" and len(runs) == 2 and r2["state"] == "VERIFIED"


def test_n1_hash_valid_but_wrong_output_fails_independent_check(root, runs):
    r = O.run_task(root, "convert", [("x.csv", GOOD)])
    tid = r["task_id"]
    bad = json.dumps({"converted": "[]"})
    (root / "output" / "operator" / tid / "raw_output.json").write_text(bad)
    _forge(root, tid, lambda t: t.update(raw_output_sha256=O._sha(bad)))
    r2 = O.run_task(root, "convert", [("x.csv", GOOD)])
    assert r2["mode"] != "saved_result_replay" and len(runs) == 2


def test_n3_write_does_not_follow_planted_link(tmp_path):
    target = tmp_path / "victim.txt"
    target.write_bytes(b"precious")
    d = tmp_path / "out"
    d.mkdir()
    try:
        os.link(target, d / "report.json.tmp")
    except OSError:
        pytest.skip("hardlinks unavailable")
    O._write(d / "report.json", b"new")
    assert target.read_bytes() == b"precious" and (d / "report.json").read_bytes() == b"new"
