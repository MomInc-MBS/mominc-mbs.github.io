"""G1 review fixes: contract-owned evaluator (no store-planted code), planner limits, one goal deadline, job-object fail-closed, _rel, v1 contract fields."""
import json
import os
import sys
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import hive_admission as H  # noqa: E402
import test_capability_admission as TA  # noqa: E402
from hive import bounded  # noqa: E402
from hive import capcontract as CC  # noqa: E402
from hive import discovery as D  # noqa: E402
from hive import experiment_compare as EC  # noqa: E402
from hive import goal_runner as G  # noqa: E402
from hive import operator_runtime as O  # noqa: E402
from hive.operator_runtime import Refused, _sha  # noqa: E402
from hive.storage import Store  # noqa: E402
from test_capability_admission import auth, store  # noqa: E402,F401  (fixtures)
from test_goal_runner import env  # noqa: E402,F401  (fixture)

needs_store = TA.pytestmark


# ---------------------------------------------------------------- 1. the contract, not the store, names the evaluator
def _rec(evaluator, cap="inventory-diff", contract=True):
    c = CC.get(cap)
    fz = {"schema": D.SCHEMA, "gap": {"signature": {"in": c["inputs"]["types"][0], "arity": c["inputs"]["arity"][0], "out": c["outputs"]["type"]}},
          "evaluator": dict(evaluator, pin=CC.pin(c)), "acceptance": {"set_sha256": "0" * 64, "n": 1}}
    if contract:
        fz["contract"] = {"capability_id": cap, "sha256": CC.sha(c)}
    fsha = _sha(O._json(fz))
    return {"exp_id": "d-" + fsha[:20], "frozen_sha": fsha, "frozen": fz, "state": "CANDIDATE_PASSED"}


def _evil(tmp_path):
    marker = tmp_path / "ran.txt"
    (tmp_path / "evil.py").write_text(f"open({str(marker)!r}, 'w').write('x')\n", encoding="utf-8", newline="\n")
    (tmp_path / "body.py").write_text("def run(env):\n    return ''\n", encoding="utf-8", newline="\n")
    return tmp_path / "evil.py", tmp_path / "body.py", marker


def test_store_planted_evaluator_is_refused_and_never_runs(tmp_path):  # real _launch: nothing is mocked
    evil, body, marker = _evil(tmp_path)
    for ev in ({"path": str(evil)}, {"path": "../../" + evil.name}, {"path": "/Windows/system32/x.py"}):
        with pytest.raises(Refused):
            D._evaluate(_rec(ev), tmp_path, body, "candidate", tmp_path)
    assert not marker.exists()


def test_store_planted_suite_and_stripped_contract_are_refused(tmp_path):
    evil, body, marker = _evil(tmp_path)
    good = {"path": CC.get("inventory-diff")["verification"]["evaluator"]["path"]}
    for rec in (_rec(dict(good, suite=str(tmp_path))), _rec(good, contract=False)):
        with pytest.raises(Refused):
            D._evaluate(rec, tmp_path, body, "candidate", tmp_path)
    with pytest.raises(Refused):  # a suite-taking capability whose record drops the suite
        D._evaluate(_rec({"path": CC.get("text.interval-merge")["verification"]["evaluator"]["path"]}, "text.interval-merge"), tmp_path, body, "candidate", tmp_path)
    assert not marker.exists()


def test_admission_refuses_a_planted_evaluator_before_any_rerun(tmp_path, monkeypatch):
    evil, body, marker = _evil(tmp_path)
    launched = []
    monkeypatch.setattr(D, "_launch", lambda *a, **k: launched.append(a))  # only to prove the refusal comes first; the real-launch proof is above
    with pytest.raises(Refused, match="evaluator"):
        H._recheck(tmp_path, _rec({"path": str(evil)}), CC.get("inventory-diff"), None)
    with pytest.raises(Refused, match="contract"):  # stripped contract field on a v2 record
        H._recheck(tmp_path, _rec({"path": "x"}, contract=False), CC.get("inventory-diff"), None)
    assert not marker.exists() and not launched


# ---------------------------------------------------------------- 2. planner limits
def test_twenty_inputs_plan_in_under_two_seconds(monkeypatch):
    T = {"types": {"T": {"subtype_of": None}, "X": {"subtype_of": "T"}, "P": {"subtype_of": "T"}, "Z": {"subtype_of": "X"}, "D": {"subtype_of": None}}}
    caps = {"f": {"kind": "builtin_adapter", "adapter": "a", "in": "T", "arity": [1, 1], "out": "Z", "verifier": "v"},
            "h": {"kind": "builtin_adapter", "adapter": "b", "in": "X", "arity": [2, 2], "out": "D", "verifier": "v"}}
    monkeypatch.setattr(G, "types", lambda: T)
    monkeypatch.setattr(G, "eligible_caps", lambda store: (caps, []))
    reads = []
    real = O.load_policy
    monkeypatch.setattr(O, "load_policy", lambda *a, **k: reads.append(1) or real(*a, **k))
    c = {"deliverable": "D", "budget": {"max_steps": 8}, "inputs": [{"type": "P"}] * 20}
    t0 = time.time()
    plan = G.plan_goal(None, c)
    assert time.time() - t0 < 2 and plan["steps"] == [] and "limit" in plan["limit"] and len(reads) == 1


# ---------------------------------------------------------------- 3. one deadline per goal, verifier included
def _clock(monkeypatch, after):
    n = [0]

    def mono():
        n[0] += 1
        return 0.0 if n[0] == 1 else after
    monkeypatch.setattr(G, "time", SimpleNamespace(monotonic=mono))


def _fake_run(monkeypatch):
    def fake(src, text, checks, timeout=None, max_out=None, *, backend, operator_class):
        ns = {}
        exec(compile(src, "<genome>", "exec"), ns)
        return ns["apply"](text, checks)
    monkeypatch.setattr(EC, "run_isolated", fake)


def test_registry_verifier_is_clamped_to_the_goal_deadline(env, monkeypatch):
    store_, allowed = env
    seen = []
    real = O.independent_verify
    monkeypatch.setattr(O, "independent_verify", lambda op, files, out, pol=None, timeout=60: seen.append(timeout) or real(op, files, out, pol, timeout))
    _fake_run(monkeypatch)
    c, ins = G.prepare(store_, allowed, "convert", ["one.csv"], budget={"wall_s": 10})
    _clock(monkeypatch, 8.0)
    assert G.run_goal(store_, c, ins)["state"] == "VERIFIED" and seen and seen[-1] <= 2  # not the fixed 60 s


@needs_store
def test_discovered_verifier_is_clamped_to_the_goal_deadline(auth, store, monkeypatch):
    seen = []
    real = CC.verify
    monkeypatch.setattr(CC, "verify", lambda c, env, out, timeout=60: seen.append(timeout) or real(c, env, out, timeout))
    _fake_run(monkeypatch)
    TA.admit(store, auth)
    ins = [("before.csv", "file", TA.BEFORE), ("after.csv", "file", TA.AFTER)]
    _clock(monkeypatch, 8.0)
    r = G.run_goal(store, G.make_contract("compare before and after", ins, deliverable="inventory_diff", budget={"wall_s": 10}), ins)
    assert r["state"] == "VERIFIED" and seen and seen[-1] <= 2


# ---------------------------------------------------------------- 4. job object: fail closed, never leak
@pytest.mark.skipif(os.name != "nt", reason="Windows job objects")
def test_failed_job_assignment_kills_the_child_and_closes_the_job(tmp_path, monkeypatch):
    closed, late = [], tmp_path / "late.txt"
    monkeypatch.setattr(EC, "_new_job", lambda: (lambda p: 0, lambda: closed.append(1)))
    child = f"import time;time.sleep(3);open({str(late)!r},'w').write('x')"
    with pytest.raises(OSError):
        bounded.run_bounded([sys.executable, "-c", child], timeout=20)
    assert closed == [1]
    time.sleep(4)
    assert not late.exists()


@pytest.mark.skipif(os.name != "nt", reason="Windows job objects")
def test_job_handle_is_closed_when_popen_raises(monkeypatch):
    closed = []
    monkeypatch.setattr(EC, "_new_job", lambda: (lambda p: 1, lambda: closed.append(1)))
    with pytest.raises(OSError):
        bounded.run_bounded(["definitely-not-a-program-xyz"], timeout=5)
    assert closed == [1]


# ---------------------------------------------------------------- 5. _rel
@pytest.mark.parametrize("p", ["/Windows", "C:/x", "\\Windows\\x", "a/../b", "../x"])
def test_rel_rejects_rooted_and_parent_paths(p):
    with pytest.raises(Refused):
        CC._rel(p)
    assert CC._rel("evaluator/c3/oracle.py#expected") == Path("evaluator/c3/oracle.py")


# ---------------------------------------------------------------- 6. one bad contract disables only itself
def _caps(tmp_path, monkeypatch, **names):
    """A copy of the real contracts in a scratch CAPS folder; names = {capability_id: artifact_name override}."""
    for cap in ("inventory-diff", "text.interval-merge"):
        c = json.loads((CC.CAPS / cap / "contract.json").read_text(encoding="utf-8"))
        c["outputs"]["artifact_name"] = names.get(cap, c["outputs"]["artifact_name"])
        (tmp_path / cap).mkdir()
        (tmp_path / cap / "contract.json").write_text(json.dumps(c), encoding="utf-8", newline="\n")
    monkeypatch.setattr(CC, "CAPS", tmp_path)


@pytest.mark.parametrize("bad", ["report.json", "REPORT.JSON", "s1.csv", "..", "a b"])
def test_reserved_or_unsafe_artifact_name_disables_only_that_capability(tmp_path, monkeypatch, bad):
    _caps(tmp_path, monkeypatch, **{"inventory-diff": bad})
    assert [c["capability_id"] for c in CC.contracts()] == ["text.interval-merge"]
    with pytest.raises(Refused):
        CC.get("inventory-diff")
    assert CC.get("text.interval-merge")["capability_id"] == "text.interval-merge"
    assert CC.contract_for_gap({"in": "canonical_rows", "arity": 2, "out": "inventory_diff"}) is None  # the broken one is not offered to discovery


def test_colliding_artifact_names_disable_the_later_contract(tmp_path, monkeypatch):
    _caps(tmp_path, monkeypatch, **{"inventory-diff": "same.txt", "text.interval-merge": "SAME.txt"})
    assert [c["capability_id"] for c in CC.contracts()] == ["inventory-diff"]
    with pytest.raises(Refused, match="collides"):
        CC.get("text.interval-merge")


# ---------------------------------------------------------------- 7. folder inputs keep the user's order
@needs_store
def test_folder_inputs_plan_valid_and_in_the_users_order(env, auth, store):
    goal_store, allowed = env
    TA.admit(store, auth)
    s = Store(store)
    try:
        for srcs in (["A", "B"], ["A", "one.csv"], ["one.csv", "A"]):
            c, _ = G.prepare(store, allowed, "compare before and after", srcs, deliverable="inventory_diff")
            plan = G.plan_goal(s, c)
            assert G.validate_plan(s, c, plan) == []
            diff = plan["steps"][-1]
            by = {x["step_id"]: x for x in plan["steps"]}

            def origin(ref):  # which user input a step output came from
                return int(ref[6:]) if ref.startswith("input:") else min(origin(r) for r in by[ref[5:]]["inputs"])
            assert diff["op"] == "inventory-diff" and [origin(r) for r in diff["inputs"]] == [0, 1], (srcs, plan["steps"])
    finally:
        s.close()


# ---------------------------------------------------------------- N1: old plans stay byte-identical; the enumeration only fills gaps
def _same_as_old(store_, c):
    import test_bounded as TB
    old, new = TB._old_plan(store_, c), G.plan_goal(store_, c)
    return old, new


def test_four_files_three_folders_group_summary_plans_as_before(env, monkeypatch):
    goal_store, _ = env
    pol = O.load_policy()
    monkeypatch.setattr(O, "load_policy", lambda *a, **k: pol)
    s = Store(goal_store)
    try:
        c = {"deliverable": "group_summary", "budget": {"max_steps": 8}, "inputs": [{"type": "inventory_file"}] * 4 + [{"type": "folder"}] * 3}
        old, new = _same_as_old(s, c)
        assert old["steps"] and json.dumps(new, sort_keys=True) == json.dumps(old, sort_keys=True) and "limit" not in new
        assert [x["op"] for x in new["steps"]].count("snapshot") == 3 and new["steps"][-1]["op"] == "merge"
    finally:
        s.close()


def test_sweep_new_planner_equals_old_wherever_old_found_a_plan(env, monkeypatch):
    import random
    goal_store, _ = env
    pol = O.load_policy()
    monkeypatch.setattr(O, "load_policy", lambda *a, **k: pol)
    rnd, found, s = random.Random(20261125), 0, Store(goal_store)
    try:
        for _ in range(300):
            c = {"deliverable": rnd.choice(["group_summary", "canonical_rows", "inventory_diff"]), "budget": {"max_steps": rnd.choice([3, 6, 8])},
                 "inputs": [{"type": rnd.choice(["inventory_file", "folder"])} for _ in range(rnd.randint(1, 7))]}
            old, new = _same_as_old(s, c)
            if old["steps"]:
                found += 1
                assert json.dumps(new, sort_keys=True) == json.dumps(old, sort_keys=True), c
    finally:
        s.close()
    assert found > 50


# ---------------------------------------------------------------- a relabelled frozen-v1 record cannot skip the contract check
def test_legacy_frozen_schema_only_where_the_contract_declares_it():
    c = CC.get("inventory-diff")
    assert c["compatibility"]["legacy_frozen"] is True
    legacy = _rec({"path": c["verification"]["evaluator"]["path"]})
    legacy["frozen"]["schema"] = "hive-c3-frozen-v1"
    D.check_frozen(legacy, c)  # accepted: the inventory contract declares it
    other = CC.get("text.interval-merge")
    assert not other["compatibility"].get("legacy_frozen")
    relabelled = _rec({"path": other["verification"]["evaluator"]["path"], "suite": other["verification"]["suite_ref"]}, "text.interval-merge")
    relabelled["frozen"]["schema"] = "hive-c3-frozen-v1"
    with pytest.raises(Refused, match="legacy"):
        D.check_frozen(relabelled, other)
