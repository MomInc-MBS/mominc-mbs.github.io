"""P3: image.asset-match contract 2.0.0 (transparency counts, real-like families) and the real-holdout gate. No model, no container, no real data:
the sealed set is faked in tmp from generated pictures, and the container is a stand-in that answers from the labels."""
from __future__ import annotations

import base64
import hashlib
import importlib.util
import io
import json
import random
import shutil
import sys
from pathlib import Path

import pytest
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
SUITE = ROOT / "capabilities" / "image.asset-match" / "suite"
_BARE = ("baseline", "gen_private", "gen_public", "oracle")
_saved, _path = {n: sys.modules.pop(n) for n in _BARE if n in sys.modules}, list(sys.path)
sys.path.insert(0, str(SUITE))
import gen_private as GP  # noqa: E402
import gen_public as P  # noqa: E402
import oracle  # noqa: E402
for _n in _BARE:  # the suite's bare names are shared with other evaluator families: keep our objects, leave the globals as they were
    sys.modules.pop(_n, None)
sys.modules.update(_saved)
sys.path[:] = _path

import hive_admission as H  # noqa: E402
from hive import capability_registry as CR  # noqa: E402
from hive import capcontract as CC  # noqa: E402
from hive import discovery as D  # noqa: E402
from hive.operator_runtime import Refused  # noqa: E402
from hive.storage import Store  # noqa: E402
from test_capability_admission import EXP, SRC, auth, rerun_fake, runs, store  # noqa: E402,F401  (fixtures)

CAP = "image.asset-match"
BODY = "import json\n\n\ndef run(env):\n    return json.dumps({})\n"


def sha(b):
    return hashlib.sha256(b if isinstance(b, bytes) else b.encode()).hexdigest()


def png(im):
    b = io.BytesIO()
    im.save(b, "PNG")
    return b.getvalue()


# ---------------------------------------------------------------- oracle: transparency counts
def test_contract_is_2_0_0_with_the_owner_approved_holdout_pinned():
    c = CC.get(CAP)
    assert c["version"] == "2.0.0" and "evaluator/g2/real_holdout.py" not in c["verification"]["evaluator"]["pin_files"]  # evaluate.py stays byte-identical; the gate records its own script sha
    h = c["verification"]["real_holdout"]
    assert h["dir_env"] == "HIVE_IMAGE_REAL_DIR" and h["approval_sha256"] == "1cb5a483c7e07bd74be9e8a0472f3d8829b784b96eb8d12ffee50f4ff5de089f"  # owner-approved key (27 Nov)
    text = (SUITE / "spec.md").read_text(encoding="utf-8")
    assert "over white and over black" in text and "not semantic similarity" in text


def test_different_transparent_silhouettes_differ_even_with_identical_colour_bands():
    rng = random.Random(4)
    a, b = P.figure(rng)[0], P.figure(rng)[0]
    assert oracle.distance(oracle.signature(png(a)), oracle.signature(png(b))) > oracle.THRESH
    # same RGB everywhere, only the alpha shape differs: an alpha-blind oracle sees one picture
    flat = Image.new("RGB", a.size, (10, 200, 30))
    ia, ib = flat.copy(), flat.copy()
    ia.putalpha(a.getchannel("A"))
    ib.putalpha(b.getchannel("A"))
    assert oracle.distance(oracle.signature(png(ia)), oracle.signature(png(ib))) > oracle.THRESH
    assert oracle.distance(oracle.signature(png(ia)), oracle.signature(png(ia))) == 0


def test_same_silhouette_resized_reencoded_and_palettised_still_matches():
    rng = random.Random(8)
    im, _ = P.figure(rng)
    s0 = oracle.signature(png(im))
    for kind in ("resize", "size", "bright", "exact"):
        v, _ = P.variant(rng, im, kind, jpeg=False)
        assert oracle.distance(s0, oracle.signature(png(v))) < oracle.THRESH / 1.25, kind
    pal = im.quantize(colors=64, method=Image.FASTOCTREE)  # palette PNG with a tRNS chunk
    assert oracle.distance(s0, oracle.signature(png(pal))) < oracle.THRESH / 1.25


def test_alpha_survives_every_transform():
    rng = random.Random(2)
    im, _ = P.icon(rng, rgba=True)
    assert im.mode == "RGBA" and im.getchannel("A").getextrema() == (0, 255)
    for kind in ("exact", "rename", "resize", "size", "crop", "bright", "mixed"):
        v, fmt = P.variant(rng, im, kind, jpeg=False)
        assert fmt == "PNG" and v.mode == "RGBA" and v.getchannel("A").getextrema()[0] == 0, kind
    v, _ = P.variant(rng, im, "bright", jpeg=False)
    assert v.getchannel("A").tobytes() == im.getchannel("A").tobytes()  # brightness never fades transparency


# ---------------------------------------------------------------- generators: the 1.25 gap on the new families
@pytest.mark.parametrize("seed", [1, 2, 3])
def test_new_families_hold_the_gap_rule(seed):
    rng = random.Random(seed)
    for fam in (("figure",), ("icon", "icon_rgba"), ("sparse",)):
        c = P.real_case("x", rng, 3, True, fam)
        groups = json.loads(c["expected"])
        ids = [m for g in groups["groups"] for m in g["members"]] + groups["singletons"]
        assert len(ids) == len(c["env"]["files"]) and P.within_limits(c["env"])
        assert oracle.expected(c["env"]) == c["expected"]
        intra, inter = GP.gap(c["env"], [g["members"] for g in groups["groups"]] + [[s] for s in groups["singletons"]])
        assert intra * 1.25 < oracle.THRESH < inter / 1.25, (fam, intra, inter)
    rep = []
    cases = GP.generate(seed, 6, rep)
    assert len(cases) == 6 and max(r[0] for r in rep) * 1.25 < oracle.THRESH < min(r[1] for r in rep) / 1.25


def test_sparse_transparent_icons_are_really_sparse_and_judged_on_what_a_viewer_sees():
    rng = random.Random(6)
    a, pa = P.sparse_icon(rng)
    assert a.mode == "RGBA" and sum(v > 0 for v in a.getchannel("A").tobytes()) / (a.width * a.height) < 0.15
    assert a.getpixel((2, 2)) == (0, 0, 0, 0)  # transparent, hidden colour black
    b, _ = P.sparse_icon(rng, dict(pa, glyph=next(g for g in P.GLYPHS if g != pa["glyph"])))
    assert oracle.distance(oracle.signature(png(a)), oracle.signature(png(b))) > oracle.THRESH * 1.25
    assert oracle.distance(oracle.signature(png(a)), oracle.signature(png(a.resize((512, 512), Image.LANCZOS)))) < oracle.THRESH / 1.25


def test_public_cases_carry_real_like_evidence_and_still_match_the_oracle():
    cases = P.cases()
    assert len(cases) == 11 and cases == P.cases()
    for c in cases:
        assert oracle.expected(c["env"]) == c["expected"], c["name"]
    raws = [base64.b64decode(f["data"]) for c in cases if c["name"].startswith("real-") for f in c["env"]["files"]]
    modes = {Image.open(io.BytesIO(r)).mode for r in raws}
    sizes = {Image.open(io.BytesIO(r)).size[0] for r in raws if Image.open(io.BytesIO(r)).size[0] == Image.open(io.BytesIO(r)).size[1]}
    assert "RGBA" in modes and {180, 192, 512} <= sizes and len(set(raws)) < len(raws)  # alpha, size families, byte-identical copies
    assert not any(Image.open(io.BytesIO(r)).format == "JPEG" for r in raws)
    sp = next(c for c in cases if c["name"] == "real-sparse-transparent-icons")
    assert all(Image.open(io.BytesIO(base64.b64decode(f["data"]))).mode == "RGBA" for f in sp["env"]["files"])


# ---------------------------------------------------------------- the real-holdout gate (fake sealed set built in tmp)
def _mod(path):
    spec = importlib.util.spec_from_file_location("p3m_" + path.stem, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


RH = _mod(ROOT / "evaluator" / "g2" / "real_holdout.py")


@pytest.fixture(scope="module")
def sealed(tmp_path_factory):
    """(truth, files): three fake cases of generated pictures with labels written beside them; truth[k] = (groups, sizes)."""
    root = tmp_path_factory.mktemp("sealed")
    rng, truth, files = random.Random(31), [], {}
    for k in range(3):
        env, groups, sizes = P.build_real(rng, 3, True)
        (root / f"case{k}").mkdir()
        for f in env["files"]:
            raw = base64.b64decode(f["data"])
            (root / f"case{k}" / f["name"]).write_bytes(raw)
            files[f"case{k}/{f['name']}"] = sha(raw)
        lab = {"schema": "p3-real-labels-v1", "case": f"case{k}", "groups": [g for g in groups if len(g) > 1], "singletons": [g[0] for g in groups if len(g) == 1]}
        raw = json.dumps(lab).encode()
        (root / f"case{k}" / "labels.json").write_bytes(raw)
        files[f"case{k}/labels.json"] = sha(raw)
        truth.append((groups, sizes))
    return root, truth, files


@pytest.fixture
def gate(tmp_path, sealed):
    """A throw-away capability folder whose contract pins this fake set, an empty store and a candidate file."""
    real, truth, files = sealed
    work = tmp_path / "w"
    shutil.copytree(real, work / "real")
    (work / "real" / "APPROVAL.json").write_text(json.dumps({"files": files, "owner": "test"}), encoding="utf-8")
    asha = sha((work / "real" / "APPROVAL.json").read_bytes())
    cap = work / "cap"
    shutil.copytree(SUITE, cap / "suite", ignore=shutil.ignore_patterns("__pycache__"))
    c = json.loads((ROOT / "capabilities" / CAP / "contract.json").read_text(encoding="utf-8"))
    c["verification"]["real_holdout"]["approval_sha256"] = asha
    (cap / "contract.json").write_text(json.dumps(c), encoding="utf-8")
    (work / "cand.py").write_text(BODY, encoding="utf-8", newline="\n")
    Store(work / "store").close()

    def run(*, container=None, real_dir=None, store_dir=None):
        argv = ["--suite", str(cap / "suite"), "--store", str(store_dir or work / "store"), "--candidate-file", str(work / "cand.py"),
                "--candidate-sha", sha(BODY), "--real-dir", str(real_dir or work / "real")]
        with CC.scope(CC.get(CAP)):
            return RH.main(argv, run_container=container or perfect)
    return run, work, asha, truth


def _answer(truth, wrong=None):
    out = []
    for k, (groups, sizes) in enumerate(truth):
        g = [list(x) for x in groups]
        if k == wrong:  # one group wrong: two groups fused
            multi = [x for x in g if len(x) > 1]
            g = [x for x in g if x not in multi[:2]] + [sum(multi[:2], [])]
        out.append(oracle.render(g, sizes))
    return json.dumps(out)


_TRUTH = {}


def perfect(src, text):
    return _answer(_TRUTH["t"])


def test_gate_exact_pass_writes_a_receipt_without_labels_or_names(gate, capsys):
    run, work, asha, truth = gate
    _TRUTH["t"] = truth
    assert run() == 0
    s = Store(work / "store")
    try:
        r = s.get(CC.HOLDOUT_RECEIPT + CAP + "/" + sha(BODY))
        names = [n for g, _ in truth for grp in g for n in grp]
        dump = json.dumps(r)
        assert r["verdict"] == "PASS" and r["case_pass"] == [True] * 3 and r["approval_sha256"] == asha and r["candidate_sha256"] == sha(BODY)
        assert r["receipt_sha256"] == CC.holdout_receipt_sha(r)
        assert not [n for n in names if n in dump] and "groups" not in dump and "singletons" not in dump and "labels" not in dump
        assert CC.holdout_problem(s, json.loads((work / "cap" / "contract.json").read_text(encoding="utf-8")), sha(BODY)) is None
    finally:
        s.close()
    out = capsys.readouterr().out
    assert "PASS" in out and not [n for g, _ in truth for grp in g for n in grp if n in out]


def test_gate_one_group_wrong_fails_and_the_opening_is_spent(gate):
    run, work, asha, truth = gate
    assert run(container=lambda s, t: _answer(truth, wrong=1)) == 1
    s = Store(work / "store")
    try:
        r = s.get(CC.HOLDOUT_RECEIPT + CAP + "/" + sha(BODY))
        assert r["verdict"] == "FAIL" and r["case_pass"] == [True, False, True] and r["pass_count"] == 2
        assert "no PASS receipt" not in (CC.holdout_problem(s, json.loads((work / "cap" / "contract.json").read_text(encoding="utf-8")), sha(BODY)) or "")
    finally:
        s.close()
    _TRUTH["t"] = truth
    with pytest.raises(SystemExit, match="already opened"):  # a second opening is refused whatever the first result was
        run()


def test_gate_second_opening_refused_after_a_pass(gate):
    run, work, asha, truth = gate
    _TRUTH["t"] = truth
    assert run() == 0
    with pytest.raises(SystemExit, match="already opened"):
        run()


def test_gate_crash_still_spends_the_opening(gate):
    run, work, asha, truth = gate

    def boom(src, text):
        raise RuntimeError("container died")
    assert run(container=boom) == 1
    _TRUTH["t"] = truth
    with pytest.raises(SystemExit, match="already opened"):
        run()


def test_gate_approval_hash_mismatch_is_refused_and_does_not_burn_the_opening(gate):
    run, work, asha, truth = gate
    p = work / "real" / "APPROVAL.json"
    good = p.read_bytes()
    p.write_bytes(good + b" ")
    with pytest.raises(SystemExit, match="approval pin"):
        run()
    p.write_bytes(good)
    _TRUTH["t"] = truth
    assert run() == 0  # the refusal above left the opening unspent


def test_gate_file_hash_mismatch_is_refused(gate):
    run, work, asha, truth = gate
    victim = next((work / "real" / "case1").glob("*.png"))
    victim.write_bytes(victim.read_bytes() + b"x")
    with pytest.raises(SystemExit, match="approved hash"):
        run()


def test_gate_refuses_a_label_set_that_disagrees_with_the_approved_files(gate):
    run, work, asha, truth = gate
    # a file approved but named in no label: re-approve everything so only the labels disagree
    extra = work / "real" / "case0" / "extra.png"
    extra.write_bytes(png(Image.new("RGB", (8, 8), "red")))
    files = json.loads((work / "real" / "APPROVAL.json").read_text(encoding="utf-8"))
    files["files"]["case0/extra.png"] = sha(extra.read_bytes())
    (work / "real" / "APPROVAL.json").write_text(json.dumps(files), encoding="utf-8")
    c = json.loads((work / "cap" / "contract.json").read_text(encoding="utf-8"))
    c["verification"]["real_holdout"]["approval_sha256"] = sha((work / "real" / "APPROVAL.json").read_bytes())
    (work / "cap" / "contract.json").write_text(json.dumps(c), encoding="utf-8")
    with pytest.raises(SystemExit, match="labels and approved files disagree"):
        run()


def test_placeholder_contract_refuses_any_set(tmp_path, sealed):
    real, truth, files = sealed
    (tmp_path / "r").mkdir()
    shutil.copytree(real, tmp_path / "r" / "x")
    (tmp_path / "r" / "APPROVAL.json").write_text(json.dumps({"files": files}), encoding="utf-8")
    cand = tmp_path / "c.py"
    cand.write_text(BODY, encoding="utf-8", newline="\n")
    Store(tmp_path / "s").close()
    with CC.scope(CC.get(CAP)), pytest.raises(SystemExit, match="approval pin"):
        RH.main(["--suite", str(SUITE), "--store", str(tmp_path / "s"), "--candidate-file", str(cand), "--candidate-sha", sha(BODY), "--real-dir", str(tmp_path / "r")],
                run_container=perfect)


# ---------------------------------------------------------------- admission needs the receipt
pytestmark_admit = pytest.mark.skipif(not SRC.exists() or not CR.keygen(), reason="C3 store or ssh-keygen unavailable")


def _declare(monkeypatch, pin="PINPINPIN1"):
    base = D.contract_of

    def with_holdout(rec):
        c = json.loads(json.dumps(base(rec)))
        c["verification"]["real_holdout"] = {"approval_sha256": pin, "dir_env": "HIVE_X_DIR"}
        return c
    monkeypatch.setattr(D, "contract_of", with_holdout)
    monkeypatch.setattr(D, "check_frozen", lambda rec, c: None)  # the repo contract differs from the declared one only by this field
    return pin


def _receipt(cand, cap, pin, verdict="PASS"):
    r = {"schema": "hive-real-holdout-receipt-v1", "capability_id": cap, "candidate_sha256": cand, "approval_sha256": pin, "n": 3,
         "case_pass": [verdict == "PASS"] * 3, "pass_count": 3 if verdict == "PASS" else 0, "verdict": verdict}
    r["receipt_sha256"] = CC.holdout_receipt_sha(r)
    return r


@pytestmark_admit
def test_admission_refused_without_a_pass_receipt_and_allowed_with_one(auth, store, runs, monkeypatch):
    pin = _declare(monkeypatch)
    s = Store(store)
    try:
        rec = next(e for e in D.experiments(s) if e["exp_id"] == EXP)
        cand, cap = rec["candidate_sha256"], D.contract_of(rec)["capability_id"]
        with pytest.raises(Refused, match="no PASS receipt"):
            H.admit(store, EXP, auth, rerun=rerun_fake(store))
        s.set(CC.HOLDOUT_RECEIPT + cap + "/" + cand, _receipt(cand, cap, pin, "FAIL"))
    finally:
        s.close()
    with pytest.raises(Refused, match="not a PASS bound"):
        H.admit(store, EXP, auth, rerun=rerun_fake(store))
    s = Store(store)
    try:
        s.set(CC.HOLDOUT_RECEIPT + cap + "/" + cand, _receipt(cand, cap, "OTHERPIN12"))  # a PASS for another approval does not count
    finally:
        s.close()
    with pytest.raises(Refused, match="not a PASS bound"):
        H.admit(store, EXP, auth, rerun=rerun_fake(store))
    s = Store(store)
    try:
        s.set(CC.HOLDOUT_RECEIPT + cap + "/" + cand, _receipt(cand, cap, pin))
    finally:
        s.close()
    assert H.admit(store, EXP, auth, rerun=rerun_fake(store))["version"] == 1


def test_gate_a_fresh_store_cannot_reopen_a_spent_key(gate):
    run, work, asha, truth = gate
    assert run(container=lambda s, t: _answer(truth, wrong=1)) == 1  # FAIL in the first store spends the sealed key
    Store(work / "store2").close()
    _TRUTH["t"] = truth
    with pytest.raises(SystemExit, match="any store"):
        run(store_dir=work / "store2")
