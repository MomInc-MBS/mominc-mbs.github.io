"""P-B: planning over the site.* capabilities. Docker-free: retained capabilities are served through the real eligible_discovered (only the signed-chain lookups are
replaced), as in test_g3_planner. Shows the three learning goals are genuine single-step gaps, the held-out workflows plan from raw inputs by chaining capabilities
with no new code, the same-interface candidate gives the planner a real choice, and no input pairing is ambiguous. Fixture author: Sol-B, not Ian."""
from __future__ import annotations

import pytest

from hive import capability_registry as CR
from hive import capcontract as CC
from hive import goal_runner as G
from hive import operator_runtime as O
from hive.storage import Store

EXTRACT, RESOLVE, CHECK, ALT, DIFF = "site.ref-extract", "site.ref-resolve", "site.ref-check", "site.ref-check-alt", "site.release-diff"
MATCH, PROPS, RECON = "image.asset-match", "asset.properties", "report.reconcile"
PAGES = b'{"schema":"site-pages-v1","commit":"c","pages":[]}'
MAN = b'{"schema":"site-manifest-v1","commit":"c","committed_at":"2026-01-01T00:00:00Z","excluded_prefixes":[],"files":[]}'
TAB = b'{"schema":"ref-table-v1","commit":"c","refs":[]}'
RAW = b'{"schema":"raw-ref-table-v1","commit":"c","pages":0,"refs":[]}'
PROPTAB = b'{"schema":"asset-properties-v1","assets":[]}'
PICS = [("a.png", "file", b"A" * 30), ("b.png", "file", b"B" * 20), ("c.jpg", "file", b"C" * 10), ("d.png", "file", b"A" * 30)]
G_L1 = "Scan the pages of this site for every raw reference."
G_L1B = "Resolve these scanned page references into a reference table."
G_L2 = "Check these references against the site manifest and list the broken links."
G_L3 = "Produce the release change report for these two site manifests."
G_H1 = "Check the references in these site pages against the site manifest and list the broken links."
G_H2 = "Write a reconciliation report: which of these pictures are copies, and how much space can I reclaim?"


@pytest.fixture
def store(tmp_path):
    s = Store(tmp_path / "s")
    O.import_bundle(s)
    yield s
    s.close()


@pytest.fixture
def held(monkeypatch):
    caps = {}

    def resolve(store, cid):
        st = {"schema": CC.V3, "cap_id": cid, "version": 1, "contract": caps[cid]}
        return {"cap_id": cid, "version": 1, "statement": st, "statement_sha": "sha-" + cid, "event_ref": "ev"}
    monkeypatch.setattr(CR, "cap_ids", lambda store: sorted(caps))
    monkeypatch.setattr(CR, "resolve_discovered", resolve)
    return caps


def retain(held, *ids):
    for i in ids:
        held[i] = CC.get(i)


def ops(plan): return [s["op"] for s in plan["steps"]]


def mk(goal, *ins): return G.make_contract(goal, [(n, "file", b) for n, b in ins])


L1 = lambda: mk(G_L1, ("site-pages-2633d9b.json", PAGES))
L1B = lambda: mk(G_L1B, ("raw-reference-table-2633d9b.json", RAW))
L2 = lambda: mk(G_L2, ("reference-table-2633d9b.json", TAB), ("site-manifest-2633d9b.json", MAN))
L3 = lambda: mk(G_L3, ("site-manifest-2633d9b.json", MAN), ("site-manifest-0b3854a.json", MAN))
H1 = lambda: mk(G_H1, ("site-pages-0b3854a.json", PAGES), ("site-manifest-0b3854a.json", MAN))


@pytest.mark.parametrize("make,cap", [(L1, EXTRACT), (L1B, RESOLVE), (L2, CHECK), (L3, DIFF)])
def test_each_learning_goal_is_a_genuine_single_step_gap_that_names_its_contract(store, held, make, cap):
    c = make()
    assert G.plan_goal(store, c)["steps"] == []
    sig, partial = G.missing_step(store, c)
    assert partial == [] and CC.contract_for_gap(sig)["capability_id"] == cap
    rec = G.run_goal(store.root, c, [(i["name"], "file", PAGES if i["type"] == "site_pages" else MAN if i["type"] == "site_manifest" else RAW if i["type"] == "raw_reference_table" else TAB) for i in c["inputs"]])
    assert rec["state"] == "UNRESOLVED" and rec["gap_ref"]


def test_a_learning_goal_is_not_solved_by_the_other_site_capabilities(store, held):
    retain(held, EXTRACT, RESOLVE, CHECK, DIFF)
    for make, want in ((L1, EXTRACT), (L1B, RESOLVE), (L2, CHECK), (L3, DIFF)):
        plan = G.plan_goal(store, make())
        assert ops(plan) == [want] and G.validate_plan(store, make(), plan) == []
    held.pop(DIFF)
    assert G.plan_goal(store, L3())["steps"] == []  # nothing else makes a change report


def test_held_out_site_workflow_plans_from_raw_inputs_by_chaining(store, held):
    retain(held, EXTRACT, RESOLVE, CHECK)
    c = H1()
    plan = G.plan_goal(store, c)
    assert ops(plan) == [EXTRACT, RESOLVE, CHECK] and plan["dag"] is True
    s1, s2, s3 = plan["steps"]
    assert s1["inputs"] == ["input:0"] and s2["inputs"] == ["step:" + s1["step_id"]] and sorted(s3["inputs"]) == sorted(["step:" + s2["step_id"], "input:1"]) and s3["report_name"] == "report.json"
    assert G.validate_plan(store, c, plan) == [] and plan["estimate"]["steps"] == 3
    swapped = mk(G_H1, ("site-manifest-0b3854a.json", MAN), ("site-pages-0b3854a.json", PAGES))  # input order does not matter: the join is by type
    assert ops(G.plan_goal(store, swapped)) == [EXTRACT, RESOLVE, CHECK]


@pytest.mark.parametrize("have", [[EXTRACT, RESOLVE], [EXTRACT, CHECK], [RESOLVE, CHECK], [EXTRACT], [CHECK], []])
def test_held_out_site_workflow_is_unresolved_when_a_step_is_missing(store, held, have):
    retain(held, *have)
    assert G.plan_goal(store, H1())["steps"] == []


def test_goal_b_reuse_and_extend_only_the_last_capability_is_the_gap(store, held):
    retain(held, EXTRACT, RESOLVE)
    sig, partial = G.missing_step(store, H1())
    assert [p["op"] for p in partial] == [EXTRACT, RESOLVE] and CC.contract_for_gap(sig)["capability_id"] == CHECK
    assert sig["ins"] == ["reference_table", "site_manifest"] and sig["out"] == "broken_ref_report"
    held.pop(RESOLVE)
    assert G.missing_step(store, H1()) is None  # two capabilities missing: not a single typed gap, nothing is named for acquisition


def test_same_interface_candidate_gives_the_planner_a_choice_with_a_stated_tie_break(store, held):
    retain(held, EXTRACT, RESOLVE, CHECK, ALT)
    plan = G.plan_goal(store, H1())
    assert ops(plan) == [EXTRACT, RESOLVE, CHECK] and plan["ranking"]["considered"] == 2  # equal steps and cost: the op name decides
    assert {tuple(a["ops"]) for a in plan["ranking"]["alternatives"]} == {(EXTRACT, RESOLVE, CHECK), (EXTRACT, RESOLVE, ALT)}
    held[CHECK] = {**held[CHECK], "execution": {**held[CHECK]["execution"], "timeout_seconds": 90}}
    assert ops(G.plan_goal(store, H1())) == [EXTRACT, RESOLVE, ALT]  # a cheaper declared cost wins
    assert ops(G.plan_goal(store, L2()))[0] == ALT


def test_held_out_workflows_h2_and_h3_use_the_open_source_capability_with_no_new_code(store, held):
    retain(held, MATCH, PROPS, RECON)
    c = mk(G_H2, *[(n, b) for n, _, b in PICS])
    plan = G.plan_goal(store, c)
    assert sorted(ops(plan)) == sorted([MATCH, PROPS, RECON]) and plan["steps"][-1]["op"] == RECON and G.validate_plan(store, c, plan) == []
    c3 = mk(G_H2, *([(n, b) for n, _, b in PICS] + [("asset-properties-images.json", PROPTAB)]))
    assert [i["type"] for i in c3["inputs"]] == ["image_file"] * 4 + ["asset_property_table"]
    p3 = G.plan_goal(store, c3)
    assert ops(p3)[-1] == RECON and MATCH in ops(p3) and PROPS not in ops(p3) and len(p3["steps"]) == 2 and G.validate_plan(store, c3, p3) == []


def test_held_out_workflows_are_declared_in_the_type_table_with_their_chains(store, held):
    T = G.types()
    hw = {h["id"]: h for h in T["held_out_workflows"]}
    assert len(hw) >= 3 and all(len(h["expected_chain"]) >= 2 and h["deliverable"] in T["deliverables"] for h in hw.values())
    assert any(len(h["expected_chain"]) >= 3 and "image.asset-match" in h["expected_chain"] for h in hw.values())
    assert hw["H1"]["expected_chain"] == [EXTRACT, RESOLVE, CHECK] and hw["H3"]["inputs"] == ["image_file x 19", "asset_property_table"]  # 19 pictures + 1 table = the 20-input goal cap
    for h in hw.values():
        assert all(CC.get(cap) for cap in h["expected_chain"])
    # no pairing is ambiguous: within every held-out workflow the typed inputs are distinct types, or the repeats feed one n-ary step
    assert len(set(hw["H1"]["inputs"])) == len(hw["H1"]["inputs"])
    assert len(hw["H2"]["inputs"]) == 1 and len(set(hw["H3"]["inputs"])) == 2
