"""T14: explicit improvement of an admitted capability. Stub proposer (tests only), real ssh-keygen, in-process containers and evaluator.
Fixture = a copy of the committed C3 run store; v1 is admitted with the test key, then `acquire.improve` makes (or refuses) v2."""
import json
import shutil
import sys
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "tests"))
import hive_admission as H  # noqa: E402
import m2_stub_server as STUB  # noqa: E402
import test_capability_admission as TA  # noqa: E402  (module import only: its tests are not collected here)
from hive import acquire as A  # noqa: E402
from hive import capability_registry as CR  # noqa: E402
from hive import capcontract as CC  # noqa: E402
from hive import discovery as D  # noqa: E402
from hive import experiment_compare as EC  # noqa: E402
from hive import operator_runtime as O  # noqa: E402
from hive.operator_runtime import Refused  # noqa: E402
from hive.storage import Store  # noqa: E402

pytestmark = pytest.mark.skipif(not TA.SRC.exists() or not CR.keygen(), reason="C3 store or ssh-keygen unavailable")
CAP = "inventory-diff"
WRONG = "wrong_output"
FC = {"kind": "failure_class", "value": WRONG}
DEV_N = 6  # public dev cases; the hidden holdout has 24


def reply(body): return "```python\n" + body + "```"


@pytest.fixture
def beh():
    return SimpleNamespace(slow_old=False, flaw_old=False)


@pytest.fixture
def engine(monkeypatch, tmp_path, beh):
    """In-process containers and evaluator. Behaviour by marker in the generated source: the admitted v1 has none; a candidate carries `# v2`.
    flaw_old: v1 is wrong on a hidden holdout (not on the 6 public cases). slow_old: v1 is slow. `# HOLDOUT_BAD` fails any hidden holdout."""
    def run(src, text, checks=None, timeout=None, max_out=None, *, backend="container", operator_class="generated", **kw):
        hidden = text[:1] == "[" and len(json.loads(text)) > DEV_N
        old = "# v2" not in src
        if (beh.flaw_old and old and hidden) or ("# HOLDOUT_BAD" in src and hidden):
            return json.dumps(["{}"] * len(json.loads(text)))
        if beh.slow_old and old:
            time.sleep(0.25)
        ns = {}
        exec(compile(src, "<genome>", "exec"), ns)
        return ns["apply"](text, checks)
    monkeypatch.setattr(EC, "run_isolated", run)

    def launch(args, evaluator=None):
        c = next(x for x in CC.contracts() if x["verification"]["evaluator"]["path"] == evaluator)
        with CC.scope(c):
            CC.load_module("evaluate", c).main(args, run_container=lambda src, text: run(src, text))
        return SimpleNamespace(returncode=0, stdout="", stderr="")
    monkeypatch.setattr(D, "_launch", launch)
    monkeypatch.setattr(D, "PRIVATE", tmp_path / "priv")
    return run


@pytest.fixture
def auth(tmp_path, monkeypatch):
    info = H.init(str(tmp_path / "keys"), str(tmp_path / "signers"))
    monkeypatch.setattr(CR, "SIGNERS", Path(info["signers"]))
    return Path(info["key"])


@pytest.fixture
def store(tmp_path, auth, engine):
    root = tmp_path / "store"
    shutil.copytree(TA.SRC, root)
    H.admit(root, TA.EXP, auth, rerun=TA.rerun_fake(root))  # v1
    return root


def v1_body(store):
    s = Store(store)
    try:
        return CR.resolve_discovered(s, CAP)["statement"]["body"]
    finally:
        s.close()


def admitter(auth):
    return lambda root, exp: H.admit(root, exp, auth, rerun=TA.rerun_fake(root))


def improve(store, auth, tmp_path, replies, objective=FC, admit=True, **kw):
    srv, url = STUB.serve_thread({"R": replies}, log=str(tmp_path / "req.jsonl"))
    try:
        return A.improve(store, CAP, objective, admit=admitter(auth) if (admit and auth) else None, stub_endpoint=url, private_dir=tmp_path / "priv", **kw)
    finally:
        srv.shutdown()


def chain_types(store):
    s = Store(store)
    try:
        return [e["type"] for e in CR.history(s, CAP)]
    finally:
        s.close()


def active(store):
    s = Store(store)
    try:
        return CR.resolve_discovered(s, CAP)["version"]
    finally:
        s.close()


def other_cap_ok(store, n):
    """The unrelated retained capability (convert) still produces a VERIFIED goal on a fresh input."""
    ins = [(f"x{n}.csv", "file", TA.BEFORE + f"z{n}.md,docs,{n}\n".encode())]
    r = TA.G.run_goal(store, TA.G.make_contract("convert this file", ins, deliverable="canonical_rows"), ins)
    return r["state"] == "VERIFIED"


def receipt_of(store, out):
    s = Store(store)
    try:
        return s.read_artifact(out["comparison"]["ref"])
    finally:
        s.close()


# ---------------------------------------------------------------- defective improvement is rejected, v1 stays
def test_defective_improvement_rejected_and_v1_stays_active(store, tmp_path):
    assert other_cap_ok(store, 1)
    wrong = [reply(f"import json\ndef run(env):\n    return json.dumps({{\"v\": {i}}})\n") for i in range(3)]
    out = improve(store, None, tmp_path, wrong)
    assert out["state"] == "REJECTED" and out["version"] is None and out["active_version"] == 1
    assert chain_types(store) == ["admit", "rejected"] and active(store) == 1
    r = receipt_of(store, out)
    assert r["verdict"] == "REJECTED" and r["new"]["version"] is None and len(r["proposals"]) == 3 and r["bypass"]
    assert other_cap_ok(store, 2)
    s = Store(store)
    exp = s.get(D.KEY + out["exp_id"])
    s.close()
    assert exp["state"] == "NO_QUALIFYING_CANDIDATE" and exp["ledger"]["calls"] <= 6  # evidence kept on the record


def test_candidate_that_fails_the_hidden_holdout_is_rejected(store, tmp_path):
    bad = [reply(v1_body(store) + f"\n# v2\n# HOLDOUT_BAD {i}\n") for i in range(3)]
    out = improve(store, None, tmp_path, bad)
    assert out["state"] == "REJECTED" and out["active_version"] == 1
    r = receipt_of(store, out)
    assert all(p["dev"]["pass_count"] == p["dev"]["n"] for p in r["proposals"]) and all(p["acceptance"]["verdict"] == "FAIL" for p in r["proposals"])


def test_valid_but_not_better_is_rejected(store, tmp_path, beh):
    """v1 already passes the fresh holdout: a correct v2 does not improve 'wrong_output' and is not admitted."""
    ok = [reply(v1_body(store) + f"\n# v2 {i}\n") for i in range(3)]
    out = improve(store, None, tmp_path, ok, objective=FC)
    assert out["state"] == "REJECTED" and active(store) == 1
    r = receipt_of(store, out)
    assert all(p["acceptance"]["verdict"] == "PASS" and p["objective"]["met"] is False for p in r["proposals"])


# ---------------------------------------------------------------- valid improvement admits v2 with a comparison receipt
@pytest.mark.parametrize("objective,flag", [(FC, "flaw_old")])
def test_valid_improvement_admits_v2_with_comparison(store, auth, tmp_path, beh, objective, flag):
    setattr(beh, flag, True)
    out = improve(store, auth, tmp_path, [reply(v1_body(store) + "\n# v2\n")], objective=objective)
    assert out["state"] == "ADMITTED" and out["version"] == 2 and out["active_version"] == 2
    r = receipt_of(store, out)
    assert r["verdict"] == "ADMITTED" and r["old"]["version"] == 1 and r["new"]["version"] == 2 and r["old"]["impl_sha256"] != r["new"]["impl_sha256"]
    assert r["objective_result"]["met"] is True and r["objective"] == objective and r["explicit_request"] is True
    assert r["new"]["holdout"]["pass_count"] == r["new"]["holdout"]["n"] == 24 and r["old"]["holdout"]["n"] == 24
    assert r["regression"]["new_passes_all"] and len(r["regression"]["fixtures"]) == DEV_N
    if flag == "flaw_old":
        assert r["old"]["holdout"]["pass_count"] < 24 and r["old"]["holdout"]["run_error"] is None
    s = Store(store)
    try:
        cur = CR.resolve_discovered(s, CAP)
        st = cur["statement"]
        assert st["version"] == 2 and st["improvement"]["base_version"] == 1 and st["improvement"]["objective"] == objective
        assert st["lineage"]["prev_version_statement_sha"] and st["pin"] == CC.pin(CC.get(CAP)) and r["evaluator_pin"] == st["pin"]
        exp = s.get(D.KEY + out["exp_id"])
        assert exp["frozen"]["improve"]["bypass"] and exp["frozen"]["acceptance"]["set_sha256"] not in {e["frozen"]["acceptance"]["set_sha256"] for e in D.experiments(s) if e["exp_id"] != exp["exp_id"]}
    finally:
        s.close()
    assert chain_types(store) == ["admit", "admit"]


def test_unsigned_path_does_not_exist_admit_needs_the_authority(store, tmp_path, beh):
    beh.flaw_old = True
    out = improve(store, None, tmp_path, [reply(v1_body(store) + "\n# v2\n")])  # no admit callable: nothing is signed
    assert out["state"] == "AWAITING_ADMISSION" and out["version"] is None and active(store) == 1 and chain_types(store) == ["admit"]


# ---------------------------------------------------------------- rollback / revoke / unrelated capability
def goal_state(store, n):
    ins = [("before.csv", "file", TA.BEFORE), ("after.csv", "file", TA.AFTER + f"q{n}.md,docs,{n}\n".encode())]
    return TA.G.run_goal(store, TA.G.make_contract("compare before and after", ins, deliverable="inventory_diff"), ins)


def test_rollback_and_revoke_between_two_real_versions(store, auth, tmp_path, beh):
    beh.flaw_old = True
    before = O.status(store)["capabilities"]
    assert improve(store, auth, tmp_path, [reply(v1_body(store) + "\n# v2\n")])["version"] == 2
    assert other_cap_ok(store, 3)
    g2 = goal_state(store, 1)
    assert g2["state"] == "VERIFIED" and g2["steps"][-1]["capability"]["version"] == 2
    out = H.rollback(store, CAP, auth)
    assert (out["from_version"], out["to_version"]) == (2, 1) and active(store) == 1
    g1 = goal_state(store, 2)
    assert g1["state"] == "VERIFIED" and g1["steps"][-1]["capability"]["version"] == 1 and other_cap_ok(store, 4)
    # v2 is superseded, not current: revoking it leaves v1 running
    H.revoke(store, CAP, 2, "test: v2 withdrawn", auth)
    assert active(store) == 1
    s = Store(store)
    _, revoked, cur = CR._state(s, CAP)
    s.close()
    assert revoked == {2} and cur == 1 and other_cap_ok(store, 5)
    assert O.status(store)["capabilities"] == before  # the other capability's own chain is untouched


def test_revoking_the_current_v2_makes_it_unexecutable_then_rollback_restores_v1(store, auth, tmp_path, beh):
    beh.flaw_old = True
    improve(store, auth, tmp_path, [reply(v1_body(store) + "\n# v2\n")])
    H.revoke(store, CAP, 2, "test: bad v2", auth)
    n_before = len(D.experiments(Store(store)))
    r = goal_state(store, 7)
    assert r["state"] == "UNRESOLVED" and not any(x["op"] == CAP for x in (r["plan"] or {}).get("steps", [])) and len(D.experiments(Store(store))) == n_before
    assert other_cap_ok(store, 8)
    assert H.rollback(store, CAP, auth)["to_version"] == 1
    assert goal_state(store, 9)["steps"][-1]["capability"]["version"] == 1


# ---------------------------------------------------------------- boundaries
@pytest.mark.parametrize("bad", [{"kind": "outcome", "value": "make it much better"}, {"kind": "failure_class", "value": "fix everything"}, {"kind": "latency_ms", "value": "fast"},
                                 {"kind": "latency_ms", "value": True}, {"kind": "latency_ms", "value": -5}, {"kind": "latency_ms", "value": 100, "note": "x"}, "fast", None])
def test_objective_is_an_enum_or_a_number_never_free_text(store, bad):
    s = Store(store)
    try:
        with pytest.raises(Refused):
            D.open_improvement(s, CAP, bad)
        assert len(D.experiments(s)) == 1
    finally:
        s.close()


def test_improve_needs_an_active_admitted_capability_and_names_no_other(store, auth):
    s = Store(store)
    try:
        with pytest.raises(Refused):
            D.open_improvement(s, "text.interval-merge", FC)  # never admitted
        with pytest.raises(Refused):
            D.open_improvement(s, "convert", FC)  # an M2 op is not a discovered capability
    finally:
        s.close()
    H.revoke(store, CAP, 1, "test", auth)
    s = Store(store)
    try:
        with pytest.raises(CR.Unavailable):
            D.open_improvement(s, CAP, FC)  # revoked: nothing to improve
    finally:
        s.close()


def test_bypass_is_only_for_improve_and_is_bounded(store, tmp_path):
    s = Store(store)
    try:
        gap = CR.resolve_discovered(s, CAP)["statement"]["lineage"]["gap_key"]
        with pytest.raises(Refused, match="open or passed"):
            D.open_experiment(s, gap, private_dir=tmp_path / "priv")  # the ordinary path still refuses a gap with a finished run
        a = D.open_improvement(s, CAP, FC, private_dir=tmp_path / "priv", budget={"calls": 99, "container_runs": 2})
        assert a["frozen"]["improve"]["explicit_request"] and a["frozen"]["budget"]["calls"] == D.BUDGET["calls"] and a["frozen"]["budget"]["container_runs"] == 2
        with pytest.raises(Refused, match="open experiment"):
            D.open_improvement(s, CAP, FC, private_dir=tmp_path / "priv")
        for k in range(2):
            x = s.get(D.KEY + a["exp_id"]); x["state"] = "NO_QUALIFYING_CANDIDATE"; s.set(D.KEY + x["exp_id"], x)
            if k == 0:
                a = D.open_improvement(s, CAP, FC, private_dir=tmp_path / "priv")
        with pytest.raises(Refused, match="at most 2"):
            D.open_improvement(s, CAP, FC, private_dir=tmp_path / "priv")
    finally:
        s.close()


def test_proposer_never_sees_the_holdout_and_cannot_touch_evaluator_or_policy(store, auth, tmp_path, beh):
    beh.flaw_old = True
    signers = (ROOT / "configs" / "admission_signers").read_bytes()
    m2_before = O.status(store)["capabilities"]
    evil = reply("import os\ndef run(env):\n    return os.environ['X']\n")
    out = improve(store, auth, tmp_path, [evil, evil.replace("X", "Y"), reply(v1_body(store) + "\n# v2\n")])
    assert out["state"] == "ADMITTED"
    s = Store(store)
    try:
        exp = s.get(D.KEY + out["exp_id"])
        assert exp["proposals"][0]["static"] and exp["proposals"][1]["static"]  # forbidden imports refused by the static check, not run
        priv = json.loads((tmp_path / "priv" / exp["frozen"]["acceptance"]["set_sha256"] / "cases.json").read_text(encoding="utf-8"))
        asked = (tmp_path / "req.jsonl").read_text(encoding="utf-8")
        assert exp["frozen"]["acceptance"]["set_sha256"] not in asked and "cases" not in exp["frozen"]["acceptance"]
        for c in priv:  # no hidden case or answer reaches the proposer or the stored record
            assert c["expected"] not in asked and all(f["text"] not in asked for f in c["env"]["files"] if len(f["text"]) > 60)
        assert all(c["expected"] not in json.dumps(exp) for c in priv)
        assert exp["frozen"]["evaluator"]["pin"] == CC.pin(CC.get(CAP)) == s.read_artifact(CR.history(s, CAP)[-1]["statement_ref"])["pin"]
        assert CR.cap_ids(s) == [CAP]  # no other capability chain was created or touched
    finally:
        s.close()
    assert (ROOT / "configs" / "admission_signers").read_bytes() == signers and O.status(store)["capabilities"] == m2_before


def test_stale_improvement_is_refused(store, auth, tmp_path, beh):
    """Two improvements made from v1: once one is admitted the other no longer replaces the current version."""
    beh.flaw_old = True
    a = improve(store, None, tmp_path, [reply(v1_body(store) + "\n# v2 a\n")])
    b = improve(store, None, tmp_path, [reply(v1_body(store) + "\n# v2 b\n")])
    assert a["state"] == b["state"] == "AWAITING_ADMISSION"
    assert H.admit(store, a["exp_id"], auth, rerun=TA.rerun_fake(store))["version"] == 2
    with pytest.raises(Refused, match="stale"):
        H.admit(store, b["exp_id"], auth, rerun=TA.rerun_fake(store))
    assert active(store) == 2 and chain_types(store) == ["admit", "admit", "rejected"]


def test_admit_refuses_an_improvement_that_did_not_meet_its_objective(store, auth, tmp_path, beh):
    out = improve(store, None, tmp_path, [reply(v1_body(store) + "\n# v2\n")], objective=FC)  # v1 is fine on the holdout: wrong_output cannot improve
    assert out["state"] == "REJECTED"
    s = Store(store)
    exp = s.get(D.KEY + out["exp_id"])
    s.close()
    exp["state"] = "CANDIDATE_PASSED"  # an attacker with store write access flips the state; the authority still refuses
    exp["candidate_sha256"] = exp["proposals"][0]["sha256"]
    exp["receipt"] = {"path": f"receipt-candidate-{exp['candidate_sha256'][:12]}.json", "receipt_sha256": exp["proposals"][0]["acceptance"]["receipt_sha256"]}
    s = Store(store)
    s.set(D.KEY + exp["exp_id"], exp)
    s.close()
    with pytest.raises(Refused):
        H.admit(store, exp["exp_id"], auth, rerun=TA.rerun_fake(store))
    assert active(store) == 1
