"""G3: the two new capability contracts and their fixture suites (asset.properties, report.reconcile). Fixture author: a conductor-side agent, not Ian.
Checks contracts, independent oracles against by-construction truth, determinism, bounds, hash-only private generation, baselines, and that the repo ships no adapter."""
from __future__ import annotations

import base64
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))
from g3_adapters import PROPS, RECON  # noqa: E402
from hive import capcontract as CC  # noqa: E402

NAME = re.compile(r"[A-Za-z0-9._ -]{1,128}")
CAPS = ["asset.properties", "report.reconcile"]


def mods(cap):
    c = CC.get(cap)
    return c, {m: CC.load_module(m, c) for m in ("oracle", "gen_public", "gen_private", "baseline", "harness")}


def run_body(body, env):
    ns = {}
    exec(compile(body, "<adapter>", "exec"), ns)
    return ns["run"](env)


@pytest.mark.parametrize("cap", CAPS)
def test_contract_is_valid_v2_pinned_stdlib_and_names_no_adapter(cap):
    c = CC.get(cap)
    assert CC.is_v2(c) and c["execution"]["adapter_ref"] is None and c["execution"]["environment_ref"]["kind"] == "pinned"
    assert c["inputs"]["envelope"] == "files-v2" and c["permissions"]["imports"]["staged"] is False and c["permissions"]["network"] is False
    assert set(c["permissions"]["imports"]["stdlib"]) <= {"json", "base64", "hashlib"}
    assert "fixture author" in (ROOT / c["proposer"]["behaviour_spec_ref"]).read_text(encoding="utf-8").lower()
    assert not list((ROOT / "capabilities" / cap).glob("adapter*")), "the repo ships no adapter for a G3 capability"
    assert len(CC.pin(c)) == 64


def test_contract_interfaces():
    p, r = CC.get("asset.properties"), CC.get("report.reconcile")
    assert (p["inputs"]["types"], p["inputs"]["arity"], p["outputs"]["type"]) == (["image_file"], [1, 20], "asset_property_table")
    assert CC.get("image.asset-match")["inputs"]["types"] == p["inputs"]["types"]  # same input type as the G2 capability
    assert (r["inputs"]["types"], r["inputs"]["arity"], r["outputs"]["type"]) == (["image_match_manifest", "asset_property_table"], [2, 2], "reconciliation_report")
    assert len({CC.get(c)["outputs"]["artifact_name"] for c in ("image.asset-match", *CAPS)}) == 3


@pytest.mark.parametrize("cap", CAPS)
def test_public_cases_are_deterministic_and_match_the_oracle(cap):
    _, m = mods(cap)
    a, b = m["gen_public"].cases(), m["gen_public"].cases()
    assert a == b and len(a) == 6
    for c in a:
        assert m["oracle"].expected(c["env"]) == c["expected"], c["name"]


@pytest.mark.parametrize("cap", CAPS)
def test_private_generation_is_seeded_bounded_and_oracle_consistent(cap):
    c, m = mods(cap)
    g = m["gen_private"]
    a, b, d = g.generate(5, 12), g.generate(5, 12), g.generate(6, 12)
    assert a == b and g.set_sha(a) == g.set_sha(b) and g.set_sha(a) != g.set_sha(d)
    lim = c["inputs"]["limits"]
    for case in g.generate(21, 24):
        fs = case["env"]["files"]
        assert c["inputs"]["arity"][0] <= len(fs) <= c["inputs"]["arity"][1] and len({f["name"].lower() for f in fs}) == len(fs)
        assert all(len(base64.b64decode(f["data"])) <= lim["max_file_bytes"] and NAME.fullmatch(f["name"]) and f["format"] == "base64" for f in fs)
        assert m["oracle"].expected(case["env"]) == case["expected"]


@pytest.mark.parametrize("cap", CAPS)
def test_cli_writes_only_under_out_and_prints_hash_only(cap, tmp_path):
    suite = ROOT / "capabilities" / cap / "suite"
    r = subprocess.run([sys.executable, "-I", str(suite / "gen_private.py"), "--out", str(tmp_path), "--seed", "3"], capture_output=True, text=True, timeout=120)
    assert r.returncode == 0, r.stderr
    got = json.loads(r.stdout.strip().splitlines()[-1])
    assert set(got) == {"set_sha256", "n"} and got["n"] == 24 and "expected" not in r.stdout and "base64" not in r.stdout
    cases = json.loads((tmp_path / got["set_sha256"] / "cases.json").read_text(encoding="utf-8"))
    assert hashlib.sha256(json.dumps(cases, sort_keys=True, separators=(",", ":")).encode()).hexdigest() == got["set_sha256"]
    assert not list(suite.glob("cases*"))


def test_properties_oracle_reads_the_bytes_not_the_name():
    _, m = mods("asset.properties")
    o = m["oracle"]
    png, jpg = o.PNG + b"x", o.JPEG + b"y"
    f = lambda n, raw: {"name": n, "format": "base64", "data": base64.b64encode(raw).decode()}
    out = json.loads(o.expected({"files": [f("b.png", jpg), f("a.jpg", png), f("c.gif", b"GIF89a"), f("d", o.PNG[:7]), f("e", b"")]}))
    assert [(a["name"], a["format"]) for a in out["assets"]] == [("a.jpg", "png"), ("b.png", "jpeg"), ("c.gif", "other"), ("d", "other"), ("e", "other")]
    assert out["assets"][4]["sha256"] == hashlib.sha256(b"").hexdigest() and out["assets"][1]["bytes"] == len(jpg)
    with pytest.raises(ValueError):
        o.expected({"files": [f("a", b"1"), f("a", b"2")]})


def test_properties_cases_cover_misleading_names_and_shared_digests():
    _, m = mods("asset.properties")
    for c in m["gen_private"].generate(9, 24):
        rows = json.loads(c["expected"])["assets"]
        assert [r["name"] for r in rows] == sorted(r["name"] for r in rows)
    wrong = [r for c in m["gen_private"].generate(9, 24) for r in json.loads(c["expected"])["assets"]
             if r["format"] != {"png": "png", "jpg": "jpeg", "jpeg": "jpeg"}.get(r["name"].lower().rsplit(".", 1)[-1], "other")]
    assert wrong, "some names must contradict their bytes"
    digs = [r["sha256"] for c in m["gen_private"].generate(9, 24) for r in json.loads(c["expected"])["assets"]]
    assert len(set(digs)) < len(digs), "byte copies under other names must occur"


def test_reconcile_oracle_rules():
    _, m = mods("report.reconcile")
    o = m["oracle"]
    man = {"schema": o.MANIFEST, "groups": [{"id": "g001", "keeper": "b.png", "members": ["a.png", "b.png", "c.png"]}], "singletons": ["z.png"]}
    tab = {"schema": o.TABLE, "assets": [{"name": n, "bytes": b, "sha256": "0" * 64, "format": "png"} for n, b in (("a.png", 10), ("b.png", 5), ("c.png", 7), ("z.png", 99))]}
    f = lambda n, d: {"name": n, "format": "base64", "data": base64.b64encode(json.dumps(d).encode()).decode()}
    for env in ({"files": [f("x", man), f("y", tab)]}, {"files": [f("manifest.json", tab), f("properties.json", man)]}):  # name and position never decide
        out = json.loads(o.expected(env))
        assert out == {"schema": "asset-reconcile-v1", "groups": [{"id": "g001", "keeper": "b.png", "duplicates": ["a.png", "c.png"], "reclaimable_bytes": 17}],
                       "totals": {"assets": 4, "groups": 1, "duplicates": 2, "reclaimable_bytes": 17}}  # the keeper is the manifest's, even though a.png is larger
    bad = [{"files": [f("x", man), f("y", man)]}, {"files": [f("x", man)]}, {"files": [f("x", man), f("y", dict(tab, assets=tab["assets"][:3]))]},
           {"files": [f("x", dict(man, singletons=["z.png", "z.png"])), f("y", tab)]}, {"files": [f("x", dict(man, groups=[dict(man["groups"][0], keeper="q.png")])), f("y", tab)]}]
    assert [o.expected(e) for e in bad] == ["ERROR"] * 5


def test_reconcile_private_cases_include_errors_and_ok_cases():
    _, m = mods("report.reconcile")
    exp = [c["expected"] for c in m["gen_private"].generate(5, 24)]
    assert 0 < sum(e == "ERROR" for e in exp) < len(exp)


@pytest.mark.parametrize("cap,body", [("asset.properties", PROPS), ("report.reconcile", RECON)])
def test_independent_adapters_pass_static_check_and_every_case(cap, body):
    c, m = mods(cap)
    assert m["harness"].static_problems(body, CC.import_policy(c)) == []
    for case in m["gen_public"].cases() + m["gen_private"].generate(41, 24):
        assert run_body(body, case["env"]) == case["expected"], case["name"]


@pytest.mark.parametrize("cap", CAPS)
def test_scripted_baseline_fails_acceptance(cap):
    _, m = mods(cap)
    cases = m["gen_private"].generate(2, 24)

    def ok(case):
        try:
            return m["baseline"].run(case["env"]) == case["expected"]
        except Exception:
            return False
    assert sum(map(ok, cases)) < len(cases)
