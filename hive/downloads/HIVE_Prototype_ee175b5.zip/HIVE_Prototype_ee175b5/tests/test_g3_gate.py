"""G3 gate, fake-engine form (the live form is scripts/g3_qualify.py with real containers and LM Studio).
A store holding the admitted picture-matching capability acquires two more through the normal path (goal -> typed gap -> experiment -> stub model ->
independent evaluator -> admission), then ONE held-out composite goal is planned and executed from the retained capabilities alone, verified step by step
and against the suites' own oracles, with zero model calls; a second unseen set repeats it; the same set again is a cached replay; a store with nothing
retained cannot do it. The picture matcher is admitted directly with a stand-in body (its real acquisition is G2's gate); the stand-ins live in tests/."""
from __future__ import annotations

import base64
import json
import random
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "tests"))
import g3_qualify as Q3  # noqa: E402
import hive_admission as H  # noqa: E402
import m2_stub_server as STUB  # noqa: E402
from g3_adapters import PROPS, RECON  # noqa: E402
from hive import capability_registry as CR  # noqa: E402
from hive import capcontract as CC  # noqa: E402
from hive import discovery as D  # noqa: E402
from hive import experiment_compare as EC  # noqa: E402
from hive import operator_runtime as O  # noqa: E402
from hive.operator_runtime import _sha  # noqa: E402
from hive.storage import Store  # noqa: E402

pytestmark = pytest.mark.skipif(not CR.keygen(), reason="ssh-keygen unavailable")


def exact_env(seed):
    """Picture sets whose duplicates are byte copies under other names (so a stand-in matcher is oracle-correct)."""
    gp = CC.load_module("gen_public", CC.get(Q3.MATCH))
    rng, used, files = random.Random(seed), set(), []
    for _ in range(3):
        raw = gp.encode(gp.scene(rng)[0], "PNG", rng)
        for _ in range(rng.randint(1, 3)):
            files.append({"name": gp.file_name(rng, "PNG", used), "format": "base64", "data": base64.b64encode(raw).decode("ascii")})
    rng.shuffle(files)
    return {"files": files}


def new_store(path):
    s = Store(path)
    O.import_bundle(s)
    s.close()
    return path


def admit_direct(store, cap, body, key):
    c = CC.get(cap)
    st = {"schema": CC.V3, "cap_id": cap, "version": 1, "contract": c, "contract_sha256": CC.sha(c), "impl_sha256": _sha(body), "body": body,
          "harness_sha256": CC.harness_sha(c), "pin": CC.pin(c), "evaluation": {}, "lineage": {}, "authority": {}, "admitted_at": "t",
          "environment": {"id": "sha256:" + "0" * 64}}  # the matcher's contract is derived: a recorded image id (its image is never started here)
    s = Store(store)
    try:
        CR.append(s, cap, "admit", statement=st, statement_sha=_sha(CR.canon(st)), signature=CR.sign(CR.canon(st), key), exp_id="direct")
    finally:
        s.close()


@pytest.fixture
def rig(tmp_path, monkeypatch):
    info = H.init(str(tmp_path / "keys"), str(tmp_path / "signers"))
    monkeypatch.setattr(CR, "SIGNERS", Path(info["signers"]))
    monkeypatch.setattr(D, "PRIVATE", tmp_path / "priv")
    monkeypatch.setattr(Q3, "picture_env", exact_env)
    real = CC.recheck
    monkeypatch.setattr(CC, "recheck", lambda st, d=None: None if st["cap_id"] == Q3.MATCH else real(st, d))  # only the unstarted derived image is skipped

    def run(src, text, checks=None, timeout=None, max_out=None, *, backend="container", operator_class="generated", **kw):
        ns = {}
        exec(compile(src, "<genome>", "exec"), ns)
        return ns["apply"](text, checks)
    monkeypatch.setattr(EC, "run_isolated", run)

    def launch(args, evaluator=None):
        c = next(x for x in CC.contracts() if x["verification"]["evaluator"]["path"] == evaluator)
        with CC.scope(c):
            CC.load_module("evaluate", c).main(args, run_container=lambda src, text: run(src, text))
        return SimpleNamespace(returncode=0, stdout="", stderr="")
    monkeypatch.setattr(D, "_launch", launch)
    store = new_store(tmp_path / "store")
    baseline_gap_free = (ROOT / "capabilities" / "image.asset-match" / "suite" / "baseline.py").read_text(encoding="utf-8")
    admit_direct(store, Q3.MATCH, baseline_gap_free, Path(info["key"]))
    srv, url = STUB.serve_thread({"R": ["```python\n" + PROPS + "```", "```python\n" + RECON + "```"]}, log=str(tmp_path / "req.jsonl"))
    return SimpleNamespace(store=store, key=Path(info["key"]), url=url, tmp=tmp_path, out=tmp_path / "out")


def cli(rig, *argv, store=None):
    return Q3.main(["--store", str(store or rig.store), "--out", str(rig.out), "--private", str(rig.tmp / "priv"), *argv])


def manifest(rig, out=None):
    return json.loads(((out or rig.out) / "manifest.json").read_text(encoding="utf-8"))


def test_g3_gate_fake_engine(rig):
    # no-retention baseline first: a fresh store with nothing admitted cannot run the goal and says why
    base = new_store(rig.tmp / "base")
    assert cli(rig, "--phase", "baseline", "--unseen-seed", "7", store=base) == 0
    b = manifest(rig)["phases"]["baseline"]
    assert b["state"] == "UNRESOLVED" and b["retained_in_this_store"] == [] and b["model_calls"] == 0 and b["plan_steps"] == 0 and b["experiment_opened"] is None
    assert b["missing_step"]["out"] == "reconciliation_report" and b["what_it_means"]

    # acquire the two missing capabilities through the normal path (goal -> gap -> experiment -> stub model -> evaluator -> admission)
    assert cli(rig, "--phase", "acquire", "--stub-endpoint", rig.url, "--admit-key", str(rig.key)) == 0
    a = manifest(rig)["phases"]["acquire"]
    g = {x["label"]: x for x in a["gaps"]}
    assert [g[k]["state"] for k in ("properties", "reconcile")] == ["ADMITTED", "ADMITTED"]
    assert g["properties"]["missing_step"]["in"] == "image_file" and g["reconcile"]["missing_step"]["ins"] == ["asset_property_table", "image_match_manifest"]
    assert all(x["cost"]["calls"] == 1 and x["attempts"][0]["receipt"]["verdict"] == "PASS" for x in g.values())
    assert all(a["retained_after"][c] for c in (Q3.MATCH, Q3.PROPS, Q3.RECON))

    # the held-out composite goal: composed by the planner from the retained capabilities, nothing hardcoded
    assert cli(rig, "--phase", "composite", "--unseen-seed", "11") == 0
    c = manifest(rig)["phases"]["composite"]
    assert c["ok"] and c["state"] == "VERIFIED" and c["final_verified_by_independent_oracles"] and c["model_calls"] == 0 and c["new_experiments"] == 0
    assert c["plan"]["dag"] and sorted(x["op"] for x in c["plan"]["steps"]) == sorted([Q3.MATCH, Q3.PROPS, Q3.RECON]) and c["plan"]["estimate"]["container_runs"] == 3
    assert (c["fresh_steps"], c["cached_steps"]) == (3, 0) and all(x["verdict"] == "PASS" and x["verification"]["verdict"] == "PASS" for x in c["steps"])
    assert [x["matches_oracle_output"] for x in c["steps"]].count(True) == 2 and c["steps"][-1]["matches_oracle_output"] is None  # both upstream outputs equal their oracles

    # repeat on a new unseen seed (a fresh process in the live run), fresh execution again; the reused seed is refused
    assert cli(rig, "--phase", "repeat", "--unseen-seed", "12") == 0
    r = manifest(rig)["phases"]["repeat"]
    assert r["ok"] and (r["fresh_steps"], r["cached_steps"]) == (3, 0) and r["model_calls"] == 0 and r["seed_sha256"] != c["seed_sha256"]
    assert cli(rig, "--phase", "repeat", "--unseen-seed", "11") == 4

    # the same inputs again are served from the saved verified results: cached, not fresh, and still verified
    again = Q3.phase_composite(SimpleNamespace(store=str(rig.store), unseen_seed=11), {})
    assert again["ok"] and (again["fresh_steps"], again["cached_steps"]) == (0, 3) and again["mode"] == "saved_result_replay" and again["model_calls"] == 0

    # the whole composite work opened no experiment beyond the two acquisitions
    s = Store(rig.store)
    try:
        assert len(D.experiments(s)) == 2
    finally:
        s.close()

    # the baseline can be costed from the acquisition that the retained run paid once
    assert cli(rig, "--phase", "baseline", "--unseen-seed", "8", "--acquire-manifest", str(rig.out / "manifest.json"), store=base) == 0
    cost = manifest(rig)["phases"]["baseline"]["acquisition_cost"]["to_acquire_the_missing_capabilities"]
    assert cost["calls"] == 2 and cost["proposals"] == 2


def test_a_failing_step_stops_the_goal_and_withholds_output(rig, monkeypatch):
    assert cli(rig, "--phase", "acquire", "--stub-endpoint", rig.url, "--admit-key", str(rig.key)) == 0
    real = EC.run_isolated

    def broken(src, text, checks=None, timeout=None, max_out=None, **kw):
        out = json.loads(real(src, text, checks, timeout, max_out, **kw))
        if '"asset-properties-v1"' in (out[0] or ""):
            out[0] = out[0].replace('"format":"png"', '"format":"jpeg"', 1).replace('"format":"other"', '"format":"png"', 1)
        return json.dumps(out)
    monkeypatch.setattr(EC, "run_isolated", broken)
    assert cli(rig, "--phase", "composite", "--unseen-seed", "21") == 3
    c = manifest(rig)["phases"]["composite"]
    assert c["state"] == "STEP_FAILED" and not c["ok"] and c["final_artifact"] is None
    assert any(x["verdict"] == "FAIL" and x["state"] == "VERIFICATION_FAILED" for x in c["steps"]) and len(c["steps"]) < 3
