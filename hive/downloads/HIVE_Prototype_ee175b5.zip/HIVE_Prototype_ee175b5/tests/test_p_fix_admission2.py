"""F2b regression tests for REVIEW_P2 N2 / M4 (revocation outside the store). Each fails on a8e0a3d."""
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "tests"))
import hive_admission as H  # noqa: E402
import test_capability_admission as TA  # noqa: E402
from test_p_improve import CAP, active, auth, beh, engine, store  # noqa: E402,F401
from hive import capability_registry as CR  # noqa: E402
from hive.operator_runtime import Refused  # noqa: E402
from hive.storage import Store  # noqa: E402

pytestmark = pytest.mark.skipif(not TA.SRC.exists() or not CR.keygen(), reason="C3 store or ssh-keygen unavailable")


def test_n2_chain_head_rollback_cannot_reactivate_revoked_version(store, auth):
    s = Store(store); admit_ref = CR.head(s, CAP); s.close()
    H.revoke(store, CAP, 1, "v1 withdrawn", auth)
    s = Store(store)
    s.set(CR.CHAIN + CAP, admit_ref)  # store write only; no key
    with pytest.raises(CR.Unavailable):
        CR.resolve_discovered(s, CAP)
    assert CAP not in CR.eligible_discovered(s)[0]
    s.close()


def test_m4c_deleted_chain_cannot_readmit_revoked_body(store, auth):
    H.revoke(store, CAP, 1, "v1 withdrawn", auth)
    s = Store(store); s.db.execute("DELETE FROM kv WHERE key = ?", (CR.CHAIN + CAP,)); s.db.commit(); s.close()
    with pytest.raises(Refused, match="capability_revocations"):
        H.admit(store, TA.EXP, auth, rerun=TA.rerun_fake(store))


def test_revocation_file_format_is_sorted_lf_and_complete(store, auth):
    H.revoke(store, CAP, 1, "v1 withdrawn", auth)
    raw = CR.revocations_path().read_bytes()
    assert b"\r" not in raw and raw.endswith(b"\n")
    (e,) = json.loads(raw)["revoked"]
    assert e["cap_id"] == CAP and e["version"] == 1 and len(e["impl_sha256"]) == 64 and len(e["statement_sha"]) == 64 and e["reason"] and e["at"]
    assert raw == (json.dumps(json.loads(raw), indent=1, sort_keys=True) + "\n").encode()


def test_rollback_cannot_target_a_listed_version(store, auth):
    CR.record_revocation(CAP, 1, "0" * 64, None, "listed by owner")  # v1 listed although the chain never revoked it
    s = Store(store)
    with pytest.raises(CR.Unavailable):
        CR.rollback_target(s, CAP)
    s.close()


def test_malformed_revocation_file_fails_closed(store, auth):
    CR.revocations_path().write_text("{not json", encoding="utf-8")
    s = Store(store)
    with pytest.raises(Refused):
        CR.resolve_discovered(s, CAP)
    s.close()
