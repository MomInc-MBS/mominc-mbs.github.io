"""G3 planner: typed DAG planning over retained capabilities (fan-out, join by type, ranking, edge validation, cycle refusal, size/expansion caps,
cost estimate before start), existing plans unchanged, and no route for the composite deliverable anywhere in code. Docker-free: the retained
capabilities are served through the real eligible_discovered from patched chain lookups."""
from __future__ import annotations

import copy
import re
from pathlib import Path

import pytest

from hive import capability_registry as CR
from hive import capcontract as CC
from hive import goal_runner as G
from hive import operator_runtime as O
from hive.storage import Store

ROOT = Path(__file__).resolve().parents[1]
MATCH, PROPS, RECON = "image.asset-match", "asset.properties", "report.reconcile"
COMPOSITE = "Write a reconciliation report: which of these pictures are copies, and how much space can I reclaim?"
PICS = [("a.png", "file", b"A" * 30), ("b.png", "file", b"B" * 20), ("c.jpg", "file", b"C" * 10), ("d.png", "file", b"A" * 30)]


@pytest.fixture
def store(tmp_path):
    s = Store(tmp_path / "s")
    O.import_bundle(s)
    yield s
    s.close()


@pytest.fixture
def held(monkeypatch):
    """The retained capabilities, name -> contract. Served by the real CR.eligible_discovered (only the signed-chain lookups are replaced)."""
    caps = {c: CC.get(c) for c in (MATCH, PROPS, RECON)}

    def resolve(store, cid):
        st = {"schema": CC.V3, "cap_id": cid, "version": 1, "contract": caps[cid]}
        return {"cap_id": cid, "version": 1, "statement": st, "statement_sha": "sha-" + cid, "event_ref": "ev"}
    monkeypatch.setattr(CR, "cap_ids", lambda store: sorted(caps))
    monkeypatch.setattr(CR, "resolve_discovered", resolve)
    return caps


def contract(**kw):
    return G.make_contract(COMPOSITE, PICS, **kw)


def ops(plan): return [s["op"] for s in plan["steps"]]


def test_composite_goal_is_typed_with_no_clarification_needed():
    c = contract()
    assert c["deliverable"] == "reconciliation_report" and [i["type"] for i in c["inputs"]] == ["image_file"] * 4


def test_planner_composes_fan_out_and_join_by_type(store, held):
    c = contract()
    plan = G.plan_goal(store, c)
    assert plan["dag"] is True and sorted(ops(plan)) == sorted([MATCH, PROPS, RECON])
    by = {s["op"]: s for s in plan["steps"]}
    every = [f"input:{n}" for n in range(4)]
    assert by[MATCH]["inputs"] == every and by[PROPS]["inputs"] == every  # fan-out: the pictures feed two steps
    assert by[RECON]["inputs"] == ["step:" + by[MATCH]["step_id"], "step:" + by[PROPS]["step_id"]]  # join by type: manifest slot, then table slot
    assert plan["steps"][-1]["op"] == RECON and plan["steps"][-1]["report_name"] == "report.json" and by[MATCH]["report_name"].endswith(".report.json")
    assert G.validate_plan(store, c, plan) == []


def test_join_is_by_type_whatever_order_the_steps_were_found_in(store, held):
    c = contract()
    plan = G.plan_goal(store, c)
    s = {x["op"]: x for x in plan["steps"]}
    swapped = copy.deepcopy(plan)
    swapped["steps"][-1]["inputs"] = swapped["steps"][-1]["inputs"][::-1]
    problems = G.validate_plan(store, c, swapped)
    assert problems and "not accepted as" in problems[0] and s[RECON]["inputs"][0] != swapped["steps"][-1]["inputs"][0]


def test_plan_carries_an_estimate_before_anything_runs(store, held):
    plan = G.plan_goal(store, contract())
    est = plan["estimate"]
    want_wall = sum(held[c]["execution"]["timeout_seconds"] for c in (MATCH, PROPS, RECON))
    want_cpu = sum(held[c]["execution"]["timeout_seconds"] * held[c]["execution"]["resources"]["cpus"] for c in (MATCH, PROPS, RECON))
    assert est == {"steps": 3, "container_runs": 3, "worst_wall_s": want_wall, "worst_cpu_s": want_cpu}
    assert plan["ranking"]["considered"] == 1 and plan["ranking"]["by"] == "steps, estimated cost, op names"


def test_run_goal_refuses_an_over_budget_plan_before_starting(store, held, tmp_path):
    for budget in ({"container_runs": 2}, {"wall_s": 100}):
        c = contract(budget=budget)
        rec = G.run_goal(store.root, c, PICS)
        assert rec["state"] == "BUDGET_EXHAUSTED" and "nothing ran" in rec["reason"] and rec["steps"] == []
        assert rec["usage"] == {"container_runs": 0, "model_calls": 0, "proposal_calls": 0}


def test_ranking_prefers_fewer_steps_then_cost_then_op_name(store, held):
    cheap = copy.deepcopy(held[RECON])
    cheap["capability_id"] = "zz.cheap"
    cheap["execution"]["timeout_seconds"] = 5
    held["zz.cheap"] = cheap
    plan = G.plan_goal(store, contract())
    assert ops(plan)[-1] == "zz.cheap" and plan["ranking"]["considered"] == 2  # same steps, lower estimated cost wins over the name order
    assert [a["cost"] for a in plan["ranking"]["alternatives"]] == sorted(a["cost"] for a in plan["ranking"]["alternatives"])
    tie = copy.deepcopy(held[RECON])
    tie["capability_id"] = "a.same-cost"
    held["a.same-cost"] = tie
    held["zz.cheap"] = copy.deepcopy(held[RECON])  # now the costs are equal: the op name decides
    assert ops(G.plan_goal(store, contract()))[-1] == "a.same-cost"


def test_a_longer_chain_never_beats_a_shorter_plan(store, held):
    held["z.pre"] = {**copy.deepcopy(held[PROPS]), "capability_id": "z.pre", "outputs": dict(held[PROPS]["outputs"], type="asset_property_table")}
    plan = G.plan_goal(store, contract())
    assert len(plan["steps"]) == 3 and "z.pre" not in ops(plan)


@pytest.mark.parametrize("drop", [MATCH, PROPS, RECON])
def test_goal_is_unresolved_without_any_one_retained_capability(store, held, drop):
    del held[drop]
    c = contract()
    plan = G.plan_goal(store, c)
    assert plan["steps"] == [] and "dag" not in plan
    rec = G.run_goal(store.root, c, PICS)
    assert rec["state"] == "UNRESOLVED" and rec["gap_ref"]


def test_goal_is_unresolved_with_nothing_retained(store, monkeypatch):
    monkeypatch.setattr(CR, "cap_ids", lambda s: [])
    rec = G.run_goal(store.root, contract(), PICS)
    assert rec["state"] == "UNRESOLVED" and rec["plan"]["steps"] == []
    gap = store.get(rec["gap_ref"])
    assert gap["unmet_type"] == "reconciliation_report" and gap["input_types"] == ["image_file"] * 4


def test_cycles_and_bad_edges_are_refused(store, held):
    c = contract()
    plan = G.plan_goal(store, c)
    ids = {x["op"]: x["step_id"] for x in plan["steps"]}
    cyc = copy.deepcopy(plan)
    for x in cyc["steps"]:
        x["after"] = []
        if x["op"] == MATCH:
            x["inputs"] = ["input:0", "step:" + ids[PROPS]]
        elif x["op"] == PROPS:
            x["inputs"] = ["input:0", "step:" + ids[MATCH]]
    assert any("cycle" in p or "later step" in p for p in G.validate_plan(store, c, cyc))
    twice = copy.deepcopy(plan)
    twice["steps"][-1]["inputs"] = [twice["steps"][-1]["inputs"][0]] * 2
    assert G.validate_plan(store, c, twice)
    wrong = copy.deepcopy(plan)
    for x in wrong["steps"]:
        if x["op"] == RECON:
            x["inputs"] = ["input:0", "step:" + ids[PROPS]]  # a picture where the manifest belongs
    assert "not accepted as" in G.validate_plan(store, c, wrong)[0]
    leftover = copy.deepcopy(plan)
    leftover["steps"] = [x for x in leftover["steps"] if x["op"] != PROPS]
    for x in leftover["steps"]:
        x["after"] = [a for a in x["after"] if a != ids[PROPS]]
        x["inputs"] = [r for r in x["inputs"] if r != "step:" + ids[PROPS]]
    assert G.validate_plan(store, c, leftover)


def test_fan_out_is_only_valid_in_a_dag_plan(store, held):
    c = contract()
    plan = G.plan_goal(store, c)
    legacy = {k: v for k, v in plan.items() if k != "dag"}
    assert any("twice" in p for p in G.validate_plan(store, c, legacy))


def test_plan_size_and_expansion_caps(store, held, monkeypatch):
    c = contract()
    monkeypatch.setattr(G, "MAX_DAG_STEPS", 2)
    assert G.plan_goal(store, c)["steps"] == []  # the plan needs 3 steps
    monkeypatch.setattr(G, "MAX_DAG_STEPS", 8)
    monkeypatch.setattr(G, "MAX_DAG_EXPANSIONS", 1)
    p = G.plan_goal(store, c)
    assert p["steps"] == [] and "expansion limit" in p["limit"]
    monkeypatch.setattr(G, "MAX_DAG_EXPANSIONS", 600)
    big = copy.deepcopy(G.plan_goal(store, c))
    monkeypatch.setattr(G, "MAX_DAG_STEPS", 2)
    assert any("exceeds the DAG plan cap" in p for p in G.validate_plan(store, c, big))


def test_a_goal_budget_below_the_plan_size_gives_no_plan(store, held):
    c = contract(budget={"max_steps": 2})
    assert G.plan_goal(store, c)["steps"] == []


def test_existing_plans_keep_their_shape(store):
    two = [("one.csv", "file", b"id,group,bytes\na,docs,1\n"), ("two.csv", "file", b"id,group,bytes\nb,img,2\n")]
    plan = G.plan_goal(store, G.make_contract("Merge these into a summary", two))
    assert ops(plan) == ["merge"] and set(plan) == {"schema", "steps", "excluded"}
    assert all("report_name" not in s for s in plan["steps"])


# ---------------------------------------------------------------- no route for the composite deliverable
def test_no_code_path_names_the_composite_deliverable():
    word = re.compile("reconciliation_report")
    allowed = {ROOT / "configs" / "capability_types.json", ROOT / "capabilities" / "report.reconcile" / "contract.json"}
    hits = []
    for base in ("src", "scripts", "evaluator", "capabilities", "configs", "schemas"):
        for p in (ROOT / base).rglob("*"):
            if p.is_file() and p.suffix in (".py", ".json", ".md", ".cmd", ".ps1", ".toml") and "__pycache__" not in p.parts and word.search(p.read_text(encoding="utf-8", errors="replace")):
                hits.append(p)
    assert set(hits) == allowed, f"unexpected references: {sorted(set(hits) - allowed)}"


def test_core_names_no_g3_task_in_code():
    from test_capcontract import CORE, _code_text
    bad = re.compile(r"reconcil|asset|propert|manifest", re.I)
    hits = sorted({t for p in CORE for t in _code_text(p) if bad.search(t) and t not in ("additionalProperties", "properties", "wheelhouse_manifest_sha256")})
    assert not hits, hits[:8]


def test_fan_out_never_counts_an_input_twice(store):
    one = [("one.csv", "file", b"id,group,bytes\na,docs,1\n")]
    assert G.plan_goal(store, G.make_contract("Merge these into a summary", one))["steps"] == []  # merge(file, convert(file)) would double count it


def test_typed_gap_signature_and_json_schema_typing():
    sig = {"in": "asset_property_table", "ins": ["asset_property_table", "image_match_manifest"], "arity": 2, "out": "reconciliation_report"}
    assert CC.contract_for_gap(sig)["capability_id"] == RECON
    assert CC.contract_for_gap({"in": "image_match_manifest", "arity": 2, "out": "reconciliation_report"}) is None  # two manifests are not the two typed slots
    assert CC.contract_for_gap({"in": "image_file", "arity": 3, "out": "asset_property_table"})["capability_id"] == PROPS
    man = b'{"schema":"image-match-manifest-v1","groups":[],"singletons":["a.png"]}'
    tab = b'{"schema":"asset-properties-v1","assets":[]}'
    c = G.make_contract("Write a reconciliation report using these two files", [("x.json", "file", tab), ("y.json", "file", man)])
    assert [i["type"] for i in c["inputs"]] == ["asset_property_table", "image_match_manifest"]
    plain = G.make_contract("Write a reconciliation report using these two files", [("x.json", "file", b'[{"id":"a","group":"g","bytes":1}]')])
    assert plain["inputs"][0]["type"] == "inventory_file"  # no tag, no typing: the old path
