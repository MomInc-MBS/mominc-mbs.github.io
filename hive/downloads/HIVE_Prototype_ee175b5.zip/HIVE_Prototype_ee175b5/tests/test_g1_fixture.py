"""G1 gate: ONE test body drives two structurally different capabilities through the same path:
goal (discovery allowed) -> typed gap -> open_experiment (contract found by gap signature) -> stub model endpoint returns a checked-in
adapter -> independent evaluator PROCESS -> admission with a test key -> run_goal on fresh unseen inputs VERIFIED by retained execution
-> a FRESH PROCESS on yet another unseen input, VERIFIED with zero model/proposal calls and no new experiment.
`fake` = container runs are in-process stand-ins (and the evaluator runs in-process); `docker` = real containers + a real `python -I` evaluator.
The stub proposer returns a hand-written adapter: this proves generalization of the engine, not autonomous acquisition."""
import importlib.util
import json
import shutil
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "tests"))
import hive_admission as H  # noqa: E402
import m2_stub_server as STUB  # noqa: E402
from hive import capability_registry as CR  # noqa: E402
from hive import capcontract as CC  # noqa: E402
from hive import discovery as D  # noqa: E402
from hive import experiment_compare as EC  # noqa: E402
from hive import goal_runner as G  # noqa: E402
from hive import operator_runtime as O  # noqa: E402
from hive.adapters import isolation as ISO  # noqa: E402
from hive.operator_runtime import Refused  # noqa: E402
from hive.storage import Store  # noqa: E402

needs_ssh = pytest.mark.skipif(not CR.keygen(), reason="ssh-keygen unavailable")


def _docker_ok():
    try:
        ISO.DockerIsolation().inspect(ISO.PINNED_IMAGE)
        return True
    except Exception:
        return False


def _module(path):
    spec = importlib.util.spec_from_file_location("g1_mod_" + path.stem, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


def _rows(csv):
    out = []
    for line in csv.decode().splitlines()[1:]:
        i, g, b = line.split(",")
        out.append({"id": i, "group": g, "bytes": int(b)})
    return json.dumps(out)


def _inventory_expected(files):
    o = _module(ROOT / "evaluator" / "c3" / "oracle.py")
    return o.expected({"files": [{"format": "json", "text": _rows(f)} for f in files]})


def _interval_expected(files):
    o = _module(ROOT / "capabilities" / "text.interval-merge" / "suite" / "oracle.py")
    return o.expected({"files": [{"format": "text", "text": files[0].decode()}]})


def _csv(*rows):
    return ("id,group,bytes\n" + "".join(f"{i},{g},{b}\n" for i, g, b in rows)).encode()


SPECS = {
    "inventory-diff": dict(
        goal="Compare the before and after inventories", deliverable="inventory_diff", names=["before.csv", "after.csv"], plan=["convert", "convert", "inventory-diff"],
        first=[_csv(("a.txt", "docs", 10), ("b.png", "img", 2048)), _csv(("a.txt", "docs", 11), ("c.md", "docs", 5))],
        fresh=[[_csv(("m.txt", "docs", 3), ("n.png", "img", 9)), _csv(("m.txt", "docs", 4), ("o.md", "docs", 1))],
               [_csv(("p", "g", 1)), _csv(("p", "g", 1), ("q", "g", 2))]],
        artifact="diff.json", expected=_inventory_expected, proposal=ROOT / "evaluator" / "c3" / "baseline_script.py"),
    "text.interval-merge": dict(
        goal="Merge the overlapping ranges in this file", deliverable="merged_intervals", names=["ranges.txt"], plan=["text.interval-merge"],
        first=[b"1-3\n5-8\n"],
        fresh=[[b"# ranges\n10-20\n15-30\n31-40\n-5-2\n"], [b"4-6\n1-2\n3-3\n100-100\n"]],
        artifact="merged.txt", expected=_interval_expected, proposal=ROOT / "capabilities" / "text.interval-merge" / "adapter.py"),
}

FRESH_PROCESS = """
import json, sys
from pathlib import Path
sys.path.insert(0, sys.argv[1])
from hive import capability_registry as CR, discovery as D, experiment_compare as EC, goal_runner as G, operator_runtime as O
from hive.storage import Store
store, signers, fake, goal, deliverable, artifact, *files = sys.argv[2:]
CR.SIGNERS = Path(signers)
if fake == "1":
    def f(src, text, checks=None, timeout=None, max_out=None, *, backend="container", operator_class="generated"):
        ns = {}
        exec(compile(src, "<genome>", "exec"), ns)
        return ns["apply"](text, checks)
    EC.run_isolated = f
ins = [(Path(p).name, "file", Path(p).read_bytes()) for p in files]
r = G.run_goal(store, G.make_contract(goal, ins, deliverable=deliverable), ins)
s = Store(store)
cnt, n = O._counters(s), len(D.experiments(s))
s.close()
art = next((Path(store) / a["ref"] for a in r.get("deliverable") or [] if a["name"] == artifact), None)
print(json.dumps({"state": r["state"], "reason": r["reason"], "mode": r["steps"][-1]["mode"] if r["steps"] else None, "usage": r.get("usage"),
                  "model_calls": cnt["model_calls"], "proposal_calls": cnt["proposal_calls"], "experiments": n, "artifact": art.read_text(encoding="utf-8") if art else None}))
"""


@pytest.fixture
def auth(tmp_path, monkeypatch):
    info = H.init(str(tmp_path / "keys"), str(tmp_path / "signers"))
    monkeypatch.setattr(CR, "SIGNERS", Path(info["signers"]))
    return Path(info["key"])


@pytest.fixture(params=["fake", "docker"])
def engine(request, monkeypatch, tmp_path):
    """fake: in-process containers and evaluator. docker: nothing patched (real containers, real evaluator process)."""
    monkeypatch.setattr(D, "PRIVATE", tmp_path / "priv")
    if request.param == "docker":
        if not _docker_ok():
            pytest.skip("Docker/pinned image unavailable")
        return request.param

    def run(src, text, checks=None, timeout=None, max_out=None, *, backend="container", operator_class="generated"):
        ns = {}
        exec(compile(src, "<genome>", "exec"), ns)
        return ns["apply"](text, checks)
    monkeypatch.setattr(EC, "run_isolated", run)

    def launch(args, evaluator=None):  # the evaluator the contract names, in-process, with the same stand-in container
        c = next(x for x in CC.contracts() if x["verification"]["evaluator"]["path"] == evaluator)
        with CC.scope(c):
            CC.load_module("evaluate", c).main(args, run_container=lambda src, text: run(src, text))
        return SimpleNamespace(returncode=0, stdout="", stderr="")
    monkeypatch.setattr(D, "_launch", launch)
    return request.param


def _goal(store, spec, files, allow=False):
    ins = [(n, "file", b) for n, b in zip(spec["names"], files)]
    return G.run_goal(store, G.make_contract(spec["goal"], ins, deliverable=spec["deliverable"], allow_discovery=allow), ins)


def _artifact(store, rec, name):
    return (Path(store) / next(a["ref"] for a in rec["deliverable"] if a["name"] == name)).read_text(encoding="utf-8")


@needs_ssh
@pytest.mark.parametrize("cap", ["inventory-diff", "text.interval-merge"])
def test_gap_to_retained_capability_to_fresh_process(cap, engine, auth, tmp_path):
    spec = SPECS[cap]
    store = tmp_path / "store"
    s = Store(store)
    O.import_bundle(s)
    s.close()
    # 1. goal with discovery -> typed gap -> experiment whose contract is found by the gap signature
    r = _goal(store, spec, spec["first"], allow=True)
    assert r["state"] == "DISCOVERY_QUEUED" and r["missing_step"]["out"] == spec["deliverable"], r["reason"]
    exp_id = r["experiment_id"]
    s = Store(store)
    assert s.get(D.KEY + exp_id)["frozen"]["contract"]["capability_id"] == cap
    s.close()
    # 2. the stub model returns the checked-in adapter; an independent evaluator process judges it on private cases
    srv, url = STUB.serve_thread({"R": ["```python\n" + spec["proposal"].read_text(encoding="utf-8") + "```"]}, log=str(tmp_path / "req.jsonl"))
    done = D.run_experiment(store, exp_id, stub_endpoint=url, private_dir=tmp_path / "priv")
    assert done["state"] == "CANDIDATE_PASSED", done.get("reason")
    assert done["receipt"]["pass_count"] == done["receipt"]["n"] and done["ledger"]["calls"] == 1
    # 3. admission (independent re-run, test key) -> a version of exactly this capability
    out = H.admit(store, exp_id, auth)
    assert out["cap_id"] == cap and out["version"] == 1
    # 4. fresh unseen inputs: the plan reuses the admitted capability; retained execution, independently verified, zero model calls
    r = _goal(store, spec, spec["fresh"][0])
    assert r["state"] == "VERIFIED", r["reason"]
    assert [x["op"] for x in r["plan"]["steps"]] == spec["plan"]
    last = r["steps"][-1]
    assert last["mode"] == "retained_capability_execution" and last["verdict"] == "PASS" and last["capability"]["cap_id"] == cap
    assert r["usage"]["model_calls"] == 0 and r["usage"]["proposal_calls"] == 0
    assert _artifact(store, r, spec["artifact"]) == spec["expected"](spec["fresh"][0])
    s = Store(store)
    before = O._counters(s)
    assert len(D.experiments(s)) == 1  # no new experiment
    s.close()
    # 5. a FRESH PROCESS on another unseen input: still VERIFIED, no model/proposal call, no new experiment
    files = []
    for n, b in zip(spec["names"], spec["fresh"][1]):
        p = tmp_path / "fresh" / n
        p.parent.mkdir(exist_ok=True)
        p.write_bytes(b)
        files.append(str(p))
    script = tmp_path / "fresh_run.py"
    script.write_text(FRESH_PROCESS, encoding="utf-8", newline="\n")
    p = subprocess.run([sys.executable, str(script), str(ROOT / "src"), str(store), str(CR.SIGNERS), "1" if engine == "fake" else "0", spec["goal"],
                        spec["deliverable"], spec["artifact"], *files], capture_output=True, text=True, timeout=300)
    assert p.returncode == 0, p.stderr[-500:]
    res = json.loads(p.stdout.strip().splitlines()[-1])
    assert res["state"] == "VERIFIED", res["reason"]
    assert res["mode"] == "retained_capability_execution" and res["artifact"] == spec["expected"](spec["fresh"][1])
    assert res["usage"]["model_calls"] == 0 and res["usage"]["proposal_calls"] == 0
    assert res["model_calls"] == before["model_calls"] and res["proposal_calls"] == before["proposal_calls"] and res["experiments"] == 1


# ---------------------------------------------------------------- the engine only loses what is removed
def test_removing_a_capability_folder_loses_only_that_capability(tmp_path, monkeypatch):
    caps = tmp_path / "capabilities"
    shutil.copytree(CC.CAPS, caps)
    shutil.rmtree(caps / "text.interval-merge")
    shutil.rmtree(caps / "image.asset-match")
    shutil.rmtree(caps / "asset.properties")
    shutil.rmtree(caps / "report.reconcile")
    for d in caps.glob("site.*"):
        shutil.rmtree(d)
    monkeypatch.setattr(CC, "CAPS", caps)
    monkeypatch.setattr(D, "PRIVATE", tmp_path / "priv")
    assert [c["capability_id"] for c in CC.contracts()] == ["inventory-diff"]
    store = tmp_path / "store"
    s = Store(store)
    O.import_bundle(s)
    s.close()
    gone = _goal(store, SPECS["text.interval-merge"], SPECS["text.interval-merge"]["first"], allow=True)
    assert gone["state"] == "UNRESOLVED" and "discovery not opened" in gone["reason"] and not gone.get("experiment_id")
    with pytest.raises(Refused, match="no capability contract"):
        s = Store(store)
        try:
            D.open_experiment(s, gone["gap_ref"], private_dir=tmp_path / "priv")
        finally:
            s.close()
    kept = _goal(store, SPECS["inventory-diff"], SPECS["inventory-diff"]["first"], allow=True)
    assert kept["state"] == "DISCOVERY_QUEUED"  # the remaining capability still discovers


def test_both_contracts_are_found_by_their_own_gap_signature():
    ids = {c["capability_id"]: c for c in CC.contracts()}
    assert set(ids) >= {"inventory-diff", "text.interval-merge"}
    assert CC.contract_for_gap({"in": "interval_text", "arity": 1, "out": "merged_intervals"})["capability_id"] == "text.interval-merge"
    assert CC.contract_for_gap({"in": "canonical_rows", "arity": 2, "out": "inventory_diff"})["capability_id"] == "inventory-diff"
    assert CC.contract_for_gap({"in": "interval_text", "arity": 2, "out": "merged_intervals"}) is None


def test_deliverable_choices_come_from_the_type_table():
    import argparse
    from hive import cli
    want = G.types()["deliverables"]
    assert "merged_intervals" in want
    ap = cli.parser()
    if True:
        sub = next(a for a in ap._actions if isinstance(a, argparse._SubParsersAction))
        op = next(p for n, p in sub.choices.items() if n == "operator")
        goal = next(a for a in op._actions if isinstance(a, argparse._SubParsersAction)).choices["goal"]
        assert next(a for a in goal._actions if a.dest == "deliverable").choices == want
    html = (ROOT / "src" / "hive" / "console.html").read_text(encoding="utf-8")
    assert "<!--DELIVERABLE_OPTIONS-->" in html and "inventory_diff" not in html.split("<!--STYLE-->")[0]
