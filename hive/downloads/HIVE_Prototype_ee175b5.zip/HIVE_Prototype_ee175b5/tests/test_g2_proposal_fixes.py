"""G2 gate-run-3 fixes: (1) the adapter must use the vendored tool, (2) the prompt lists the staged distributions and tool signatures,
(3) dev-run crash feedback, (4) three proposals per attempt within an 8-call run budget, (5) every proposal persists and is linked."""
from __future__ import annotations

import json
import sys
import types
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))
from hive import acq_card as AC, acq_propose as AP, acquire as A, capcontract as CC, discovery as D  # noqa: E402
from hive import experiment_compare as EC  # noqa: E402
from hive.storage import Store  # noqa: E402
from test_g2_acquire import CAP, GOODBODY, POL, go, hooks, queued, serve, world  # noqa: E402,F401
from test_g2_kernel import _mod  # noqa: E402

HARNESS = _mod(ROOT / "evaluator" / "g2" / "harness.py")
NOTOOL = "```python\nimport json\n\n\ndef run(env):\n    return json.dumps({'n': len(env['files'])})\n```"


def fence(code, n=0):
    return f"```python\n{code}\n```" + ("" if not n else "")


def distinct(i, tool=True):
    return f"```python\nimport json\n{'import vtool' if tool else ''}\n\n\ndef run(env):\n    return json.dumps({{'v': {i}}})\n```"


def requests(world):
    return [json.loads(x) for x in (world.tmp / "req.jsonl").read_text(encoding="utf-8").splitlines()]


def user_text(req):
    return req["messages"][1]["content"]


# ================================================================= 1. the adapter must use the vendored tool
def frozen(tool):
    return {"frozen": {"tool_modules": tool, "environment": {"packages": ["vtool", "tinydep"]}}}


def test_static_check_requires_a_vendored_tool_import_when_there_is_one():
    c = CC.get(CAP)
    for body in ("import json\ndef run(env):\n    return ''", "import json\nimport tinydep\ndef run(env):\n    return ''"):
        bad = D._static(HARNESS, c, frozen(["vtool"]), body)
        assert bad and "does not use the vendored tool" in bad[0] and "vtool" in bad[0] and "reimplement" in bad[0]
    for body in ("import vtool\ndef run(env):\n    return ''", "from vtool import compare\ndef run(env):\n    return ''", "import json\nimport vtool.sub as s\ndef run(env):\n    return ''"):
        assert D._static(HARNESS, c, frozen(["vtool"]), body) == []
    assert D._static(HARNESS, c, frozen([]), "import json\ndef run(env):\n    return ''") == []  # no tool recorded: no extra rule
    assert D._static(HARNESS, c, frozen(["vtool", "tinydep"]), "import tinydep\ndef run(env):\n    return ''") == []  # any one of several is enough
    assert D._static(HARNESS, c, frozen(["vtool"]), "import os\ndef run(env):\n    return ''")  # the harness's own problems still come first


def test_proposal_without_the_tool_is_refused_before_any_dev_run_and_the_reason_goes_back(world):
    names = ["o0/a"]
    rid = queued(world, names)
    kw = serve(world, [NOTOOL, GOODBODY])
    rec = go(world, rid, hooks(world, names), run_kw=kw)
    st = Store(world.store)
    exp = D.experiments(st)[0]
    st.close()
    p0, p1 = exp["proposals"][0], exp["proposals"][1]
    assert p0["static"] and "does not use the vendored tool" in p0["static"][0] and p0["dev"] is None and p0["acceptance"] is None  # no dev run, no evaluator
    assert p1["static"] == [] and p1["dev"] and rec["state"] == "AWAITING_ADMISSION"
    second = user_text(requests(world)[1])
    assert "static check refused it" in second and "does not use the vendored tool" in second  # the model is told why
    assert sum(1 for k in world.kws if "image" in k) >= 1


# ================================================================= 2. prompt: staged distributions, versions, signatures
def test_prompt_lists_staged_distributions_versions_stdlib_and_tool_signatures(world):
    names = ["o0/a"]
    rid = queued(world, names)
    go(world, rid, hooks(world, names), run_kw=serve(world, [GOODBODY]))
    text = user_text(requests(world)[0])
    assert "AVAILABLE IN THE RUN (nothing else can be imported or used)" in text and "tinydep==1.0" in text
    assert "standard-library modules:" in text and "json" in text and "base64" in text
    assert "Importable top-level names: vtool" in text and "Vendored tool module(s) your adapter MUST import and call: vtool" in text
    assert "UNTRUSTED REPOSITORY DATA" in text and "reimplement" in text
    assert "go()" in text and "Returns the dependency value" in text  # the tool's public signature and doc from the card
    assert AP.tokens(text) <= AP.MAX_PROMPT_TOKENS
    sysmsg = requests(world)[0]["messages"][0]["content"]
    assert "vtool" in sysmsg and "tinydep" not in sysmsg.replace("vtool", "")  # the import allowlist names the staged packages


def test_staged_text_is_sanitised_and_capped(tmp_path):
    card = {"purpose": "p", "packages": ["vtool"], "modules": [], "deps": [], "interfaces": [{"module": "vtool", "sig": "go(x)", "doc": "does it"}]}
    env = {"wheelhouse": [{"name": "evil\x00name", "version": "1\n2"}, {"name": "ok", "version": "9.9"}], "packages": ["vtool"], "tool_modules": ["vtool"]}
    t = AP.staged_text(card, env, ["json", "io"])
    assert "\x00" not in t and "ok==9.9" in t and "go(x)" in t and t.index("AVAILABLE") < t.index("UNTRUSTED")
    assert "none besides the tool" in AP.staged_text(card, {"packages": [], "tool_modules": []}, ["json"])


# ================================================================= 3. dev crash feedback
def test_wrap_dev_reports_type_message_and_the_adapter_line_only_in_dev_runs():
    body = "import json\n\n\ndef run(env):\n    x = env['nope']\n    return json.dumps(x)\n"
    ns = {}
    exec(compile(HARNESS.wrap_dev(body), "candidate", "exec"), ns)
    out = json.loads(ns["apply"](json.dumps([{"a": 1}]), {}))
    assert out["out"] == [None] and out["err"][0] == "KeyError: 'nope' (adapter line 5: x = env['nope'])"
    ns2 = {}
    exec(compile(HARNESS.wrap(body), "candidate", "exec"), ns2)
    assert json.loads(ns2["apply"](json.dumps([{"a": 1}]), {})) == [None]  # the evaluator/retained wrapper reveals nothing
    ns3 = {}
    exec(compile(HARNESS.wrap_dev("def run(env):\n    return 5\n"), "candidate", "exec"), ns3)
    assert json.loads(ns3["apply"]("[{}]", {}))["err"] == ["run returned int, not text"]
    long = "def run(env):\n    raise ValueError('" + "y" * 900 + "')\n"
    ns4 = {}
    exec(compile(HARNESS.wrap_dev(long), "candidate", "exec"), ns4)
    assert len(json.loads(ns4["apply"]("[{}]", {}))["err"][0]) <= 300


def test_dev_run_feedback_uses_the_diagnostics_and_ordinary_mismatches_are_unchanged(monkeypatch):
    def container(src, text, checks=None, timeout=None, max_out=None, *, backend="container", operator_class="generated", **kw):
        ns = {}
        exec(compile(src, "candidate", "exec"), ns)
        return ns["apply"](text, checks)
    monkeypatch.setattr(D.EC, "run_isolated", container)
    dev = [{"name": "c1", "env": {"a": 1}, "expected": "A"}, {"name": "c2", "env": {"a": 2}, "expected": "B"}, {"name": "c3", "env": {"a": 3}, "expected": "C"}]
    body = "def run(env):\n    if env['a'] == 1:\n        return env['missing']\n    return 'zzz' if env['a'] == 2 else 'C'\n"
    r, fb = D._dev_run(body, dev, HARNESS)
    assert r == {"n": 3, "pass_count": 1}
    assert "case c1: raised KeyError: 'missing' (adapter line 3: return env['missing'])" in fb and "case c2: first difference at char 0: expected ...'B' got ...'zzz'" in fb and len(fb) <= 1500


def test_whole_run_crash_feedback_keeps_the_message(world, monkeypatch):
    names = ["o0/a"]
    rid = queued(world, names)

    def boom(src, text, checks=None, timeout=None, max_out=None, *, backend="container", operator_class="generated", **kw):
        raise RuntimeError("candidate process failed (exit 1)")
    monkeypatch.setattr(EC, "run_isolated", boom)
    go(world, rid, hooks(world, names), run_kw=serve(world, [GOODBODY, distinct(2)]))
    assert "RuntimeError: candidate process failed (exit 1)" in user_text(requests(world)[1])


def test_the_crash_reason_reaches_the_next_prompt_through_the_acquisition_path(world, monkeypatch):
    names = ["o0/a"]
    rid = queued(world, names)
    world.mode["v"] = "exec"
    monkeypatch.setitem(sys.modules, "vtool", types.ModuleType("vtool"))
    crash = "```python\nimport json\nimport vtool\n\n\ndef run(env):\n    return json.dumps(vtool.nothing(env))\n```"
    go(world, rid, hooks(world, names), run_kw=serve(world, [crash, distinct(3)]))
    nxt = user_text(requests(world)[1])
    assert "raised AttributeError" in nxt and "adapter line 6: return json.dumps(vtool.nothing(env))" in nxt
    for hidden in ("receipt", "private", "acceptance cases", "expected_sha256"):
        assert hidden not in nxt


def test_diagnostics_exist_only_in_the_dev_path():
    for rel in ("evaluator/g2/evaluate.py", "src/hive/goal_runner.py", "src/hive/capcontract.py"):
        assert "wrap_dev" not in (ROOT / rel).read_text(encoding="utf-8"), rel


# ================================================================= 4. three proposals per attempt, run budget 8
def test_each_attempt_may_make_three_proposals_and_the_run_budget_is_eight_calls(world):
    assert A.BUDGET["model_calls"] == 16
    names = ["o0/a", "o1/b", "o2/c"]
    rid = queued(world, names)
    world.mode["v"] = "wrong"
    rec = go(world, rid, hooks(world, names), run_kw=serve(world, [distinct(i) for i in range(1, 12)]))
    assert rec["state"] == "CANDIDATES_EXHAUSTED" and len(rec["attempts"]) == 3
    calls = [a["results"]["ledger"]["calls"] for a in rec["attempts"]]
    props = [a["results"]["ledger"]["proposals"] for a in rec["attempts"]]
    assert calls[0] == 3 and props[0] == 3 and calls[1] == 3 and sum(calls) <= 16 and calls[2] == 3 and rec["ledger"]["model_calls"] == sum(calls) == 9


def test_attempts_stop_early_when_the_call_budget_runs_out(world):
    names = ["o0/a", "o1/b", "o2/c"]
    rid = queued(world, names)
    s = Store(world.store)
    r = s.get(A.KEY + rid)
    r["frozen"]["budget"]["model_calls"] = 4
    s.set(A.KEY + rid, r)
    s.close()
    world.mode["v"] = "wrong"
    rec = go(world, rid, hooks(world, names), run_kw=serve(world, [distinct(i) for i in range(1, 12)]))
    assert rec["state"] == "BUDGET_EXHAUSTED" and "model_calls exhausted" in rec["reason"]
    assert [a["results"]["ledger"]["calls"] for a in rec["attempts"]] == [3, 1] and rec["ledger"]["model_calls"] == 4 and len(rec["attempts"]) == 2


# ================================================================= 5. every proposal persists and is linked
def test_every_call_and_proposal_has_its_files_and_the_manifest_links_them(world):
    names = ["o0/a"]
    rid = queued(world, names)
    world.mode["v"] = "wrong"
    replies = ["I will not write any code.", NOTOOL, distinct(1)]  # no code, a static refusal, a distinct dev failure
    rec = go(world, rid, hooks(world, names), run_kw=serve(world, replies))
    a = rec["attempts"][0]
    d = world.store / "discovery" / a["exp_id"]
    names_on_disk = sorted(p.name for p in d.iterdir())
    assert {"reply-1.txt", "reply-2.txt", "reply-3.txt"} <= set(names_on_disk)  # a reply per call, code or not
    props = a["results"]["proposals"]
    assert len(props) == 2 and [p["static"] != [] for p in props] == [True, False]
    for p in props:
        assert (d / p["files"]["cand"]).is_file() and (d / p["files"]["reply"]).is_file()
        assert (d / p["files"]["cand"]).read_text(encoding="utf-8").startswith(("import", "def"))
    m = json.loads((world.store / "acquisition" / rid / "run-manifest.json").read_text(encoding="utf-8"))
    pers = m["persistence"][a["exp_id"]]
    assert pers["missing"] == [] and pers["expected"] == 4 and pers["dir"] == f"discovery/{a['exp_id']}"
    assert m["attempts"][0]["results"]["proposals"][0]["files"]["cand"].startswith("cand-")
    (d / props[1]["files"]["cand"]).unlink()  # a file that goes missing is reported, not silent
    assert A._persistence(world.store, rec)[a["exp_id"]]["missing"] == [props[1]["files"]["cand"]]


def test_a_duplicate_proposal_is_recorded_as_a_duplicate_with_its_reply(world):
    names = ["o0/a"]
    rid = queued(world, names)
    world.mode["v"] = "wrong"
    rec = go(world, rid, hooks(world, names), run_kw=serve(world, [distinct(1)]))  # the stub repeats the same reply
    st = Store(world.store)
    exp = D.experiments(st)[0]
    st.close()
    d = world.store / "discovery" / exp["exp_id"]
    assert len(exp["proposals"]) == 1 and any("duplicate_of" in c for c in exp["calls"]) and (d / "reply-1.txt").is_file() and (d / "reply-2.txt").is_file()
    assert len(list(d.glob("cand-*.py"))) == 1 and rec["attempts"][0]["state"] == "FAILED"
