"""G2 security-review fixes (findings 1-6 + GitHub error detail) and the live-diagnostic fixes (pip scratch space, model-suggested queries,
generic evidence scoring). Fake docker / transport / model only; the one real-Docker check at the end is opt-in (HIVE_REAL_DOCKER=1)."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
import zipfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "tests"))
import hive_admission as H  # noqa: E402
import m2_stub_server as STUB  # noqa: E402
from hive import acq_card as AC, acq_github as AG, acq_propose as AP, acq_stage as ST, acquire as A, capcontract as CC, repo_intel as RI  # noqa: E402
from hive.operator_runtime import Refused  # noqa: E402
from hive.storage import Store  # noqa: E402
from test_g2_acquire import CAP, GOODBODY, POL, FakeStager, go, hooks, items, make_repos, queue_goal, queued, rec_of, serve, world  # noqa: E402,F401
from test_g2_kernel import _mod, env_rec  # noqa: E402
from test_g2_stage import REPO, FakeDocker, make_repo, make_wheel  # noqa: E402

needs_ssh = pytest.mark.skipif(not __import__("hive.capability_registry", fromlist=["x"]).keygen(), reason="ssh-keygen unavailable")
HARNESS = _mod(ROOT / "evaluator" / "g2" / "harness.py")
MIT = "Permission is hereby granted, free of charge, to any person obtaining a copy of this software.\n"


def card_of(tmp, files, name="repo"):
    repo, sha = make_repo(Path(tmp) / name, files)
    return AC.build_card(repo, sha, "a/b", POL, Path(tmp) / "cache", api_license="MIT"), repo, sha


# ================================================================= 1. hostile content rejects one candidate, never wedges the run
def test_hostile_toml_and_deep_source_do_not_crash_the_card(tmp_path):
    evil = dict(REPO, **{"pyproject.toml": "[" * 120000, "vtool/deep.py": "def f(a=" + "+".join(["1"] * 30000) + "):\n    pass\n",
                         "vtool/nest.py": "x = " + "(" * 150 + "1" + ")" * 150 + "\n"})
    c, _, _ = card_of(tmp_path, evil)
    assert c["deps"] == [] and c["packages"] == ["vtool"] and all(i["module"] != "deep" for i in c["interfaces"])
    cfg = dict(REPO, **{"setup.cfg": "[options]\ninstall_requires =\n" + "  a\n" * 10, "pyproject.toml": "\x00\x00"})
    assert [d["name"] for d in card_of(tmp_path / "b", cfg)[0]["deps"]] == ["a"]


def test_a_candidate_that_raises_recursion_is_rejected_and_the_run_continues(world):
    names = ["o0/a", "o1/b"]
    rid = queued(world, names)
    h = hooks(world, names)
    real = h["clone"]

    def clone(url, sha, dest):
        if url.endswith("o0/a"):
            raise RecursionError("maximum recursion depth exceeded")
        return real(url, sha, dest)
    h["clone"] = clone
    rec = go(world, rid, h, run_kw=serve(world, [GOODBODY]))
    assert rec["inspected"][0]["rejection"].startswith("INSPECT_FAILED: RecursionError")
    assert rec["state"] == "AWAITING_ADMISSION" and rec["attempts"][0]["repo"] == "o1/b"
    assert go(world, rid, h)["state"] == "AWAITING_ADMISSION"  # a resume re-inspects nothing and does not crash


# ================================================================= 2. static check bypasses
@pytest.mark.parametrize("body,why", [
    ("import json\ndef run(env):\n    return json.codecs.open('x').read()", "codecs"),
    ("import json\ndef run(env):\n    return getattr(json, '_' + '_builtins__')", "getattr"),
    ("import pkg\ndef run(env):\n    return pkg.os.popen('id').read()", "os"),
    ("import pkg\ndef run(env):\n    return pkg.sys.modules", "sys"),
    ("def run(env):\n    return type(env)", "type"),
    ("def run(env):\n    return vars(env)", "vars"),
    ("def run(env):\n    return globals()", "globals"),
    ("def run(env):\n    return setattr(env, 'a', 1)", "setattr"),
    ("def run(env):\n    return __builtins__", "__builtins__"),
    ("from json import codecs\ndef run(env):\n    return ''", "codecs"),
    ("import operator\ndef run(env):\n    return operator.attrgetter('x')(env)", "operator"),
    ("import json\ndef run(env):\n    return json.decoder.shutil", "shutil"),
    ("import ctypes\ndef run(env):\n    return ''", "ctypes"),
    ("def run(env):\n    return eval('1')", "eval"),
    ("import json\ndef run(env):\n    return json.__loader__", "__loader__")])
def test_static_check_bypasses_are_refused(body, why):
    bad = HARNESS.static_problems(body, ["json", "pkg", "ctypes", "operator", "os", "sys"])  # even when a caller lists them
    assert bad and any(why in b or "outside" in b for b in bad), (body, bad)


def test_static_check_still_admits_ordinary_adapter_code():
    ok = ("import io\nimport json\nimport base64\nfrom PIL import Image\n\n\ndef run(env):\n    out = []\n    for f in env['files']:\n"
          "        im = Image.open(io.BytesIO(base64.b64decode(f['data']))).convert('L').copy()\n        out.append(im.getdata())\n    return json.dumps({'n': len(out)})\n")
    assert HARNESS.static_problems(ok, ["json", "io", "base64", "PIL"]) == []


def test_stdlib_names_never_become_staged_packages_or_imports():
    assert ST.safe_packages({"ctypes", "importlib", "builtins", "shutil", "Shutil", "sitecustomize", "usercustomize", "vtool", "a-b", "x.y"}) == ["vtool"]
    c = CC.get(CAP)
    pol = CC.import_policy(c, ["ctypes", "importlib", "vtool", "Json"])
    assert "vtool" in pol and "ctypes" not in pol and "importlib" not in pol and "Json" not in pol and "json" in pol
    with pytest.raises(Refused, match="malformed"):
        CC.check_environment(env_rec(packages=["ctypes"]))
    with pytest.raises(Refused, match="malformed"):
        CC.check_environment(env_rec(packages=["Shutil"]))


# ================================================================= 3. licence gate
def lic_wheel(tmp, lic, n=[0]):
    n[0] += 1
    return make_wheel(Path(tmp) / f"w{n[0]}", lic=lic)


@pytest.mark.parametrize("lic,ok", [
    ("License-Expression: GPL-3.0-only\nClassifier: License :: OSI Approved :: MIT License", False),
    ("Classifier: License :: OSI Approved :: GNU General Public License v3 (GPLv3)\nClassifier: License :: OSI Approved :: MIT License", False),
    ("License: GPL-3.0\nClassifier: License :: OSI Approved :: MIT License", False),
    ("License-Expression: MIT AND GPL-2.0-only", False),
    ("License-Expression: MIT WITH Classpath-exception-2.0", False),
    ("Classifier: License :: Other/Proprietary License", False),
    ("Classifier: License :: OSI Approved", False),
    ("Name: nothing", False),
    ("Classifier: License :: OSI Approved :: MIT License\nClassifier: License :: OSI Approved :: Apache Software License", True),
    ("License-Expression: MIT OR Apache-2.0", True),
    ("License-Expression: Apache-2.0\nClassifier: License :: OSI Approved :: GNU General Public License v3 (GPLv3)", True),  # the expression alone decides
    ("License: MIT\nClassifier: License :: OSI Approved :: MIT License", True)])
def test_wheel_licence_every_operand_must_be_allowed(tmp_path, lic, ok):
    s = ST.Stager(POL)
    if ok:
        assert s.scan_wheel(lic_wheel(tmp_path, lic))["license"]
    else:
        with pytest.raises(ST.StageRejected) as e:
            s.scan_wheel(lic_wheel(tmp_path, lic))
        assert e.value.code == "LICENSE_NOT_ALLOWED"


# ================================================================= 4. nothing installs outside site-packages
@pytest.mark.parametrize("extra", [
    {"tinydep-1.0.data/scripts/run": "x"}, {"tinydep-1.0.data/data/etc/x": "y"}, {"tinydep-1.0.data/headers/h.h": "y"}, {"tinydep-1.0.data/x": "y"},
    {"sitecustomize.py": "x"}, {"usercustomize/__init__.py": "x"}, {"tinydep-1.0.data/purelib/sitecustomize.py": "x"},
    {"tinydep-1.0.dist-info/entry_points.txt": "[console_scripts]\npython3 = x:y\n"}, {"tinydep-1.0.dist-info/entry_points.txt": "[gui_scripts]\npip3 = y:z\n"}])
def test_wheel_install_escapes_are_refused(tmp_path, extra):
    with pytest.raises(ST.StageRejected) as e:
        ST.Stager(POL).scan_wheel(make_wheel(tmp_path, extra=extra))
    assert e.value.code == "WHEEL_REFUSED"


def test_wheel_purelib_data_and_plain_entry_points_are_fine(tmp_path):
    w = ST.Stager(POL).scan_wheel(make_wheel(tmp_path, extra={"tinydep-1.0.data/purelib/extrapkg/__init__.py": "", "tinydep-1.0.dist-info/entry_points.txt": "[tinydep.plugins]\na = b:c\n"}))
    assert w["top_level"] == ["extrapkg", "tinydep"]


@pytest.mark.parametrize("pkg", ["sitecustomize", "usercustomize", "json", "importlib"])
def test_vendored_package_cannot_hook_or_shadow(tmp_path, pkg):
    repo, sha = make_repo(tmp_path, {pkg + "/__init__.py": "A = 1\n"})
    with pytest.raises(ST.StageRejected) as e:
        ST.vendor_tree(repo, sha, pkg, POL, tmp_path / "cc")
    assert e.value.code == "VENDOR_NAME_REFUSED"


# ================================================================= 5. resource caps
def test_git_calls_have_timeouts(tmp_path, monkeypatch):
    seen = []

    def fake(argv, **kw):
        seen.append(kw.get("timeout"))
        raise subprocess.TimeoutExpired(argv, kw.get("timeout"))
    monkeypatch.setattr(RI.subprocess, "run", fake)
    with pytest.raises(RI.RepoIntelError, match="timed out"):
        RI._run(tmp_path, "ls-tree", "x")
    assert seen == [RI.GIT_TIMEOUT_S]
    (tmp_path / "x").mkdir()
    with pytest.raises(RI.RepoIntelError, match="timed out"):
        RI.RepoTreeIndex(tmp_path, "a" * 40).list()


def test_clone_pinned_enforces_a_byte_cap(tmp_path):
    repo, sha = make_repo(tmp_path, REPO)
    with pytest.raises(RI.RepoIntelError, match="exceeds"):
        RI.clone_pinned(str(repo), sha, tmp_path / "c1", max_bytes=10)
    assert RI.clone_pinned(str(repo), sha, tmp_path / "c2", max_bytes=10**8).exists()


def test_big_repos_are_rejected_before_and_after_cloning(world):
    names = ["o0/big", "o1/ok"]
    rid = queued(world, names)
    big = items("o0/big")[0]
    big["size"] = 10**7
    tr = lambda u, hd: (200, {}, json.dumps({"items": [big] + items("o1/ok")}).encode())
    h = hooks(world, names, transport=tr)
    cloned = []
    real = h["clone"]
    h["clone"] = lambda url, sha, dest: (cloned.append(url), real(url, sha, dest))[1]
    rec = go(world, rid, h, run_kw=serve(world, [GOODBODY]))
    big_row = next(i for i in rec["skipped"] if i["repo"] == "o0/big")  # skipped before any inspection, no clone
    assert big_row["reason"].startswith("REPO_TOO_LARGE") and not any(i["repo"] == "o0/big" for i in rec["inspected"]) and cloned == ["https://github.com/o1/ok"] and rec["state"] == "AWAITING_ADMISSION"


def test_clone_bytes_over_the_policy_cap_reject_and_delete(world):
    names = ["o0/a"]
    rid = queued(world, names)
    h = hooks(world, names)
    h["policy"] = dict(POL, limits=dict(POL["limits"], max_clone_bytes=1))
    rec = go(world, rid, h)
    assert rec["state"] == "NO_CANDIDATE" and "REPO_TOO_LARGE" in rec["inspected"][0]["rejection"]
    assert not (world.store / "acquisition" / "cache" / "repos" / world.sha["https://github.com/o0/a"]).exists()


def test_pypi_metadata_precheck_rejects_huge_wheels_and_never_blocks_on_failure():
    s = ST.Stager(POL, run=FakeDocker())
    huge = json.dumps({"urls": [{"packagetype": "bdist_wheel", "size": 10**9}, {"packagetype": "sdist", "size": 5}]}).encode()
    with pytest.raises(ST.StageRejected) as e:
        s.precheck(["bigdep>=1"], fetch=lambda u: huge)
    assert e.value.code == "WHEEL_TOO_LARGE"
    small = json.dumps({"urls": [{"packagetype": "bdist_wheel", "size": 10**9}, {"packagetype": "bdist_wheel", "size": 1000}]}).encode()
    s.precheck(["x"], fetch=lambda u: small)  # the smallest wheel fits
    s.precheck(["x"], fetch=lambda u: (_ for _ in ()).throw(OSError("offline")))  # unavailable metadata: skipped, the hard caps still apply
    s.precheck(["x"], fetch=lambda u: b"not json")
    s.precheck(["x"], fetch=lambda u: json.dumps({"urls": [{"packagetype": "sdist", "size": 10**10}]}).encode())
    with pytest.raises(ValueError):
        s._pypi_fetch("http://evil.example/pypi/x/json")


def test_download_watchdog_kills_the_container_when_the_directory_passes_the_cap(tmp_path):
    calls = []

    def run(argv, timeout):
        calls.append(list(argv))
        if argv[1] == "run":
            src = next(a for a in argv if a.startswith("type=bind")).split("src=")[1].split(",")[0]
            (Path(src) / "huge.whl").write_bytes(b"x" * 5000)
            time.sleep(1.5)
        return 0, b"", b""
    pol = dict(POL, stage=dict(POL["stage"], max_wheelhouse_bytes=1000))
    s = ST.Stager(pol, run=run, prefix="hive-stage-wd")
    s.poll_s = 0.05
    t0 = time.monotonic()
    with pytest.raises(ST.StageRejected) as e:
        s.download(["x"], tmp_path)
    assert e.value.code == "WHEELHOUSE_TOO_LARGE" and any(c[:3] == ["docker", "rm", "--force"] and c[3].startswith("hive-stage-wd-dl") for c in calls)
    assert not (tmp_path / ST.SCRATCH).exists() and time.monotonic() - t0 < 10


def test_per_wheel_unpacked_size_cap(tmp_path):
    p = dict(POL, stage=dict(POL["stage"], max_unpacked_bytes=10))
    with pytest.raises(ST.StageRejected, match="expands"):
        ST.Stager(p).scan_wheel(make_wheel(tmp_path))
    p = dict(POL, stage=dict(POL["stage"], max_wheel_bytes=5))
    with pytest.raises(ST.StageRejected, match="expands"):
        ST.Stager(p).scan_wheel(make_wheel(tmp_path / "b", body="X = '" + "y" * 50 + "'\n"))


# ================================================================= 6. tar hashed at admission every time
def test_tar_is_verified_even_when_the_image_is_present(tmp_path, monkeypatch):
    tar = tmp_path / "abc.tar"
    tar.write_bytes(b"TARBYTES")
    env = env_rec(tar_name="abc.tar", image_tar_sha256=ST._sha(b"TARBYTES"))
    called = []
    monkeypatch.setattr(CC, "ensure_image", lambda e, d: called.append(1) or e["id"])  # present: ensure() would return immediately
    CC.verify_tar(env, tmp_path)
    tar.write_bytes(b"TAMPERED")
    with pytest.raises(Refused, match="IMAGE_TAR_MISMATCH"):
        CC.verify_tar(env, tmp_path)
    tar.unlink()
    with pytest.raises(Refused, match="IMAGE_MISSING"):
        CC.verify_tar(env, tmp_path)
    assert not called


@needs_ssh
def test_admission_refuses_a_tampered_tar_though_the_image_is_present(world, tmp_path, monkeypatch):
    from hive import capability_registry as CR
    names = ["o0/a"]
    rid = queued(world, names)
    rec = go(world, rid, hooks(world, names), run_kw=serve(world, [GOODBODY]))
    assert rec["state"] == "AWAITING_ADMISSION"
    a = next(x for x in rec["attempts"] if x["state"] == "PASSED")
    tar = world.store / "acquisition" / "images" / Path(a["environment"]["tar_path"]).name
    tar.write_bytes(b"not the saved image")  # image still "present" (ensure_image is faked to succeed)
    info = H.init(str(tmp_path / "keys"), str(tmp_path / "signers"))
    monkeypatch.setattr(CR, "SIGNERS", Path(info["signers"]))
    with pytest.raises(Refused, match="tar"):
        H.admit(str(world.store), a["exp_id"], str(info["key"]))


# ================================================================= GitHub error detail
def test_github_error_detail_is_recorded_sanitised_and_secret_free(tmp_path, monkeypatch):
    monkeypatch.setenv(AG.TOKEN_ENV, "ghp_SECRETSECRET")
    msg = "API rate limit exceeded for 1.2.3.4.\x00\x07 token ghp_SECRETSECRET " + "x" * 400
    body = json.dumps({"message": msg, "documentation_url": "https://docs"}).encode()
    gh = AG.GitHubSearch(tmp_path / "c", POL, lambda u, h: (403, {"Retry-After": "1", "X-Secret": "ghp_SECRETSECRET"}, body), sleep=lambda s: None)
    with pytest.raises(AG.NetworkUnavailable) as e:
        gh.search("some query")
    assert e.value.status == 403 and e.value.detail.startswith("API rate limit exceeded") and len(e.value.detail) <= 200
    assert "SECRET" not in str(e.value) and "SECRET" not in e.value.detail and "\x00" not in str(e.value) and "403" in str(e.value)
    assert AG.why(500, b"<html>") == "" and AG.why(500, b'{"message": 5}') == ""
    gh2 = AG.GitHubSearch(tmp_path / "c2", POL, lambda u, h: (500, {}, b'{"message":"Server Error"}'))
    with pytest.raises(AG.NetworkUnavailable, match="GitHub status 500: Server Error"):
        gh2.search("q")


def test_network_error_status_and_message_reach_the_manifest(world):
    rid = queued(world, ["o0/a"])
    h = hooks(world, [], transport=lambda u, hd: (403, {}, b'{"message":"Forbidden by policy"}'))
    h["github"].lim = dict(h["github"].lim, max_retries=0)
    rec = go(world, rid, h)
    assert rec["state"] == "NETWORK_UNAVAILABLE" and "Forbidden by policy" in rec["reason"] and rec["network_error"] == {"status": 403, "detail": "Forbidden by policy"}
    m = json.loads((world.store / "acquisition" / rid / "run-manifest.json").read_text(encoding="utf-8"))
    assert m["network_error"]["status"] == 403 and "Forbidden by policy" in m["reason"]


# ================================================================= 7. pip scratch space
def test_pip_temp_and_home_live_under_the_mount_and_are_removed(tmp_path):
    seen = {}

    def run(argv, timeout):
        if argv[1] == "run":
            seen["argv"] = argv
            seen["scratch_existed"] = (tmp_path / ST.SCRATCH).is_dir()
            (tmp_path / ST.SCRATCH / "pip-build").mkdir(exist_ok=True)
            (tmp_path / ST.SCRATCH / "pip-build" / "junk").write_bytes(b"x" * 100)
            make_wheel(tmp_path)
        return 0, b"", b""
    s = ST.Stager(POL, run=run)
    s.download(["tinydep"], tmp_path)
    a = seen["argv"]
    assert a[a.index("HOME=/out/.hive-tmp") - 1] == "-e" and a[a.index("TMPDIR=/out/.hive-tmp") - 1] == "-e" and seen["scratch_existed"]
    assert not (tmp_path / ST.SCRATCH).exists()  # removed after, so it is in no lock or hash
    (tmp_path / ST.SCRATCH).mkdir()
    (tmp_path / ST.SCRATCH / "left").write_bytes(b"z")
    assert [w["name"] for w in s.scan_all(tmp_path)] == ["tinydep"]  # and ignored by the scan even if a crash left it behind


# ================================================================= 8. model-suggested queries + generic scoring
SUGGEST = "near duplicate image finder\nperceptual comparison library\nbad;line\n"


def test_model_queries_run_after_keyword_queries_and_are_attributed(world):
    names = ["o0/a"]
    rid = queued(world, names)
    h = hooks(world, names)
    sent, prompts = [], []
    tr = h["github"].transport
    h["github"].transport = lambda u, hd: (sent.append(u), tr(u, hd))[1]
    h["suggest"] = lambda msgs: (prompts.append(msgs), (SUGGEST, {"completion_tokens": 17}))[1]
    rec = go(world, rid, h, run_kw=serve(world, [GOODBODY]))
    q = rec["search"]["query_sources"]
    assert q["model"] == ["near duplicate image finder", "perceptual comparison library"] and q["model_status"] == "ok" and q["keywords"]
    assert rec["search"]["queries"] == q["keywords"] + q["model"]
    import urllib.parse
    order = [urllib.parse.unquote(u.split("q=")[1].split("&")[0]).replace(" language:Python", "") for u in sent]
    assert order == q["keywords"] + q["model"]  # the model's queries run after the keyword ones
    assert rec["ledger"]["model_calls"] == 2 and rec["ledger"]["out_tokens"] >= 17  # one suggestion call + the proposer's one
    st = Store(world.store)
    m = A.manifest(st, rec)
    st.close()
    assert m["search"]["query_sources"]["model"] == q["model"] and m["search"]["query_sources"]["keywords"] == q["keywords"]
    assert len(prompts) == 1  # one model call per run, even across a resume
    go(world, rid, h)
    assert len(prompts) == 1


def test_suggestion_prompt_has_only_contract_purpose_spec_and_types(world):
    rec = {"frozen": {"budget": {"max_prompt_tokens": 8000, "model_calls": 6}}, "ledger": A._zero()}
    got = []
    c = CC.get(CAP)
    qs, st = A._suggest(None, rec, {"suggest": lambda m: (got.append(m), ("a b c", {}))[1]}, c, A._types(), [])
    text = "\n".join(m["content"] for m in got[0])
    assert qs == ["a b c"] and st == "ok" and c["purpose"][:40] in text and "image_file" in text and "image_match_manifest" in text and "application/json" in text
    assert AP.tokens(text) <= 8000
    for secret in ("UNTRUSTED", "pin_files", "oracle.py", "private", "signers", "admit", "environment_ref", "permissions", "gen_private", "THRESH"):
        assert secret not in text, secret


def test_suggestion_respects_budgets_and_failures():
    c, T = CC.get(CAP), A._types()

    def boom(m):
        raise AssertionError("must not be called")
    rec = {"frozen": {"budget": {"max_prompt_tokens": 8000, "model_calls": 0}}, "ledger": A._zero()}
    assert A._suggest(None, rec, {"suggest": boom}, c, T, []) == ([], "no model-call budget") and rec["ledger"]["model_calls"] == 0
    rec = {"frozen": {"budget": {"max_prompt_tokens": 5, "model_calls": 6}}, "ledger": A._zero()}
    assert A._suggest(None, rec, {"suggest": boom}, c, T, []) == ([], "prompt over the input-token limit")
    assert A._suggest(None, rec, {}, c, T, []) == ([], "not configured")
    rec = {"frozen": {"budget": {"max_prompt_tokens": 8000, "model_calls": 6}}, "ledger": A._zero()}
    qs, st = A._suggest(None, rec, {"suggest": lambda m: (_ for _ in ()).throw(RuntimeError("endpoint down"))}, c, T, [])
    assert qs == [] and st.startswith("RuntimeError") and rec["ledger"]["model_calls"] == 1  # a failed call still counts


def test_default_suggest_goes_through_the_model_client(tmp_path):
    srv, url = STUB.serve_thread({"R": ["alpha beta library\nsecond query words"]}, log=str(tmp_path / "req.jsonl"))
    content, usage = A.make_suggest(tmp_path, {"stub_endpoint": url})(AP.query_messages({"purpose": "p", "behaviour_spec": "b", "inputs": ["x"], "output": "o", "media_type": "m"}))
    assert AP.parse_queries(content) == ["alpha beta library", "second query words"]
    with pytest.raises(RuntimeError, match="no executable"):
        A.make_suggest(tmp_path, {"stub_endpoint": url, "requested_model": "not/qualified"})([{"role": "user", "content": "x"}])


def test_wanted_terms_come_only_from_the_contract_and_type_table():
    c, T = CC.get(CAP), A._types()
    terms = AC.wanted_terms(c, T)
    assert {"image", "manifest", "json", "png", "jpeg", "duplicate"} <= set(terms) and len(terms) == len(set(terms)) and "the" not in terms
    other = CC.get("inventory-diff")
    assert "image" not in AC.wanted_terms(other, T) and "png" not in AC.wanted_terms(other, T)


def test_selection_follows_evidence_not_stars(world):
    fit = dict(REPO, **{"README.md": "# tool\n\nMatches duplicate images across renamed files and writes a json manifest for pictures.\n",
                        "vtool/__init__.py": "def match_images(paths):\n    '''Group duplicate image files into a manifest.'''\n    return {}\n"})
    unfit = dict(REPO, **{"README.md": "# tool\n\nA plain text fingerprint helper for documents and strings only.\n",
                          "vtool/__init__.py": "def fingerprint(text):\n    '''Hash a string.'''\n    return 1\n"})
    rid = queued(world, ["o0/stars", "o1/fit"])
    world.local, world.sha = {}, {}
    for nm, files in (("o0/stars", unfit), ("o1/fit", fit)):
        repo, sha = make_repo(world.tmp / ("x" + nm.replace("/", "_")), files)
        world.local["https://github.com/" + nm], world.sha["https://github.com/" + nm] = repo, sha
    popular = items("o0/stars")[0]
    popular["stargazers_count"] = 10**6
    h = hooks(world, [], transport=lambda u, hd: (200, {}, json.dumps({"items": [popular] + items("o1/fit")}).encode()))
    rec = go(world, rid, h, run_kw=serve(world, [GOODBODY]))
    assert rec["queue"][0]["repo"] == "o1/fit" and rec["attempts"][0]["repo"] == "o1/fit"


def test_scoring_weights_signatures_over_readme_and_ignores_stars(tmp_path):
    a, _, _ = card_of(tmp_path, dict(REPO, **{"vtool/__init__.py": "def go(image):\n    '''Compare image bytes.'''\n    return 1\n"}), "a")
    b, _, _ = card_of(tmp_path, dict(REPO, **{"README.md": "# t\n\nWorks with image data in many ways described here.\n", "vtool/__init__.py": "def go(x):\n    return 1\n"}), "b")
    assert AC.score(a, ["image"], {}) > AC.score(b, ["image"], {})
    assert AC.score(a, ["image"], {"stars": 1}) == AC.score(a, ["image"], {"stars": 10**9})


# ================================================================= opt-in real Docker: scratch dir really holds pip's temp files
@pytest.mark.skipif(os.environ.get("HIVE_REAL_DOCKER") != "1", reason="opt-in: starts a real throwaway container")
def test_real_download_container_can_write_its_scratch_under_the_mount(tmp_path):
    s = ST.Stager(POL, prefix="hive-stage-scratch")
    (tmp_path / ST.SCRATCH).mkdir()
    full = s.download_argv([], tmp_path, "hive-stage-scratch-t")
    argv = full[:next(k for k, x in enumerate(full) if "@sha256:" in x) + 1]  # everything up to and including the image reference
    r = subprocess.run(argv + ["python", "-c", "import tempfile,os;f=tempfile.NamedTemporaryFile();print(os.path.dirname(f.name), os.environ['HOME'])"], capture_output=True, text=True, timeout=120)
    assert r.returncode == 0 and r.stdout.split() == ["/out/.hive-tmp", "/out/.hive-tmp"], r.stderr
    assert subprocess.run(["docker", "ps", "-a", "-q", "--filter", "name=hive-stage-scratch"], capture_output=True, text=True).stdout.strip() == ""
