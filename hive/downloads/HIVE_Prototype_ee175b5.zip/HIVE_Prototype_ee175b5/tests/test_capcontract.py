"""G1 slices 1-2: the capability contract, the versioned statement reader, generic admission/registry/execution, and the
no-task-literal rule for the core modules. Real ssh-keygen; containers faked. Fixture = a copy of the committed C3 run store."""
import ast
import copy
import hashlib
import importlib.util
import json
import re
import shutil
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
import hive_admission as H  # noqa: E402
from hive import capability_registry as CR  # noqa: E402
from hive import capcontract as CC  # noqa: E402
from hive import discovery as D  # noqa: E402
from hive import experiment_compare as EC  # noqa: E402
from hive import goal_runner as G  # noqa: E402
from hive.adapters import isolation as ISO  # noqa: E402
from hive.operator_runtime import Refused, _sha  # noqa: E402
from hive.storage import Store  # noqa: E402

SRC = ROOT / "build" / "c-series" / "c3-run" / "store"
EXP = "d-563f4dc928c28acb7944"
BEFORE = b"id,group,bytes\na.txt,docs,10\nb.png,img,2048\nc.md,docs,5\nd.md,docs,7\n"
AFTER = b"id,group,bytes\na.txt,docs,10\nb.png,img,4096\ne.md,docs,9\nd.md,docs,7\n"
C3_FILES = {"evaluate.py": "d958d269abaa3873de6e3265701208446e2256e52a5fcfa7052dd7463c26725b", "oracle.py": "f6d2c5c84bd4be90857196685daf42a6a7924be56e70795984b657f8655e0998",
            "harness.py": "25c504856dd37c4b3cc0fb155d3362681bea1393aa9ba4da3709743d3f839a17", "gen_private.py": "d245215d9c061f9067ec3ef41e8b4d7cb6a4dd9a418903e859304f60b68d15d9",
            "gen_public.py": "ee6da5bf4ec53c3a2b1af227d938bb6da9761365f99cd7d2bc9a776d2e3110e9"}
needs_store = pytest.mark.skipif(not SRC.exists() or not CR.keygen(), reason="C3 store or ssh-keygen unavailable")


# ---------------------------------------------------------------- fixtures
@pytest.fixture
def auth(tmp_path, monkeypatch):
    info = H.init(str(tmp_path / "keys"), str(tmp_path / "signers"))
    monkeypatch.setattr(CR, "SIGNERS", Path(info["signers"]))
    return Path(info["key"])


@pytest.fixture
def store(tmp_path):
    root = tmp_path / "store"
    shutil.copytree(SRC, root)
    return root


@pytest.fixture
def runs(monkeypatch):
    calls = []

    def fake(src, text, checks, timeout=None, max_out=None, *, backend, operator_class):
        calls.append(1)
        ns = {}
        exec(compile(src, "<genome>", "exec"), ns)
        return ns["apply"](text, checks)
    monkeypatch.setattr(EC, "run_isolated", fake)
    return calls


def admit(store, key):
    def rerun(rec, out, body_path):
        p = Path(store) / "discovery" / rec["exp_id"] / rec["receipt"]["path"]
        return json.loads(p.read_text(encoding="utf-8")), p
    return H.admit(store, EXP, key, rerun=rerun)


def goal(store, after=AFTER):
    ins = [("before.csv", "file", BEFORE), ("after.csv", "file", after)]
    return G.run_goal(store, G.make_contract("compare before and after", ins, deliverable="inventory_diff"), ins)


def eligible(store):
    s = Store(store)
    try:
        return CR.eligible_discovered(s)
    finally:
        s.close()


def head_event(store):
    s = Store(store)
    try:
        ev = CR.history(s, "inventory-diff")[-1]
        return ev, s.read_artifact(ev["statement_ref"])
    finally:
        s.close()


def sign_head(store, key, mutate):
    """Replace the head admit by a statement the authority itself signed after `mutate` (artifact consistent, signature valid)."""
    s = Store(store)
    try:
        ev = CR.history(s, "inventory-diff")[-1]
        st = s.read_artifact(ev["statement_ref"])
        mutate(st)
        e = {k: v for k, v in ev.items() if k != "ref"}
        e.update(statement_ref=s.put_artifact(st), statement_sha=_sha(CR.canon(st)), signature=CR.sign(CR.canon(st), key))
        s.set(CR.CHAIN + "inventory-diff", s.put_artifact(e))
    finally:
        s.close()


def add_v1(store, key, version=1):
    """A legacy hive-capability-admission-v1 statement exactly as the pre-G1 authority wrote it (signature over canon(st))."""
    s = Store(store)
    try:
        rec = next(e for e in D.experiments(s) if e["exp_id"] == EXP)
        body = D._read_lf(Path(store) / "discovery" / EXP / f"cand-{rec['candidate_sha256']}.py")
        prev = [e for e in CR.history(s, "inventory-diff") if e["type"] == "admit"]
        st = {"schema": CC.V1, "cap_id": "inventory-diff", "version": version, "in_type": "canonical_rows", "out_type": "inventory_diff", "arity": [2, 2], "ordered": True,
              "impl_sha256": _sha(body), "body": body, "harness": {"path": "evaluator/c3/harness.py", "sha256": C3_FILES["harness.py"]},
              "env": {"image": ISO.PINNED_IMAGE["reference"], "digest": ISO.PINNED_IMAGE["digest"], "backend": "container", "network": "none"},
              "permissions": {"imports": ["json"], "network": False, "files": False}, "limits": {"timeout_s": 120, "max_out": 1 << 20},
              "verifier": {"path": "evaluator/c3/oracle.py", "evaluator": "evaluator/c3/evaluate.py", "pin": c3_pin()},
              "evaluation": {"exp_id": EXP, "frozen_sha": rec["frozen_sha"], "receipt_sha256": rec["receipt"]["receipt_sha256"], "pass_count": rec["receipt"]["pass_count"],
                             "n": rec["receipt"]["n"], "admission_rerun_receipt_sha256": rec["receipt"]["receipt_sha256"], "case_result_sha256_match": True},
              "lineage": {"prev_version_statement_sha": prev[-1]["statement_sha"] if prev else None, "gap_key": rec["gap_key"], "proposer_model": "test"},
              "authority": {"principal": CR.PRINCIPAL}, "admitted_at": "2026-01-01T00:00:00+00:00"}
        CR.append(s, "inventory-diff", "admit", statement=st, statement_sha=_sha(CR.canon(st)), signature=CR.sign(CR.canon(st), key), exp_id=EXP)
        return st
    finally:
        s.close()


def c3_pin():
    return _sha("".join(f"{n}:{h}\n" for n, h in C3_FILES.items()))  # evaluate, oracle, harness, gen_private, gen_public (the legacy order)


def assert_refused(store, runs, why=None):
    ok, ex = eligible(store)
    assert "inventory-diff" not in ok and ex and (why is None or why in ex[0]["reason"]), ex
    n = len(runs)
    r = goal(store)
    assert r["state"] == "UNRESOLVED" and len(runs) == n  # nothing executed


# ---------------------------------------------------------------- contract
def test_repo_contracts_validate_and_describe_the_c3_evaluator():
    c = CC.get("inventory-diff")
    assert CC.validate(c) is c and [x["capability_id"] for x in CC.contracts()] == sorted(x["capability_id"] for x in CC.contracts())
    assert c["inputs"]["types"] == ["canonical_rows"] and c["inputs"]["arity"] == [2, 2] and c["outputs"]["artifact_name"] == "diff.json"
    assert CC.contract_for_gap({"in": "canonical_rows", "arity": 2, "out": "inventory_diff"}) == c
    assert CC.contract_for_gap({"in": "canonical_rows", "arity": 3, "out": "inventory_diff"}) is None
    assert CC.contract_for_gap({"in": "canonical_rows", "arity": 2, "out": "group_summary"}) is None


def test_c3_evaluator_files_are_byte_pinned():
    for n, h in C3_FILES.items():
        assert CC.lf_sha(f"evaluator/c3/{n}") == h, f"evaluator/c3/{n} changed: every admitted statement pins these bytes"
    c = CC.get("inventory-diff")
    assert [Path(p).name for p in c["verification"]["evaluator"]["pin_files"]] == list(C3_FILES) and CC.pin(c) == c3_pin()


@pytest.mark.parametrize("name", ["unknown_field", "network", "imports", "secrets", "fs", "timeout", "output", "memory", "digest", "adapter", "no_oracle_in_pins",
                                  "escape", "missing_file", "dup_names", "bad_id", "bad_envelope", "bad_arity"])
def test_invalid_contract_refused(name):
    c = copy.deepcopy(CC.get("inventory-diff"))
    v, ex = c["verification"], c["execution"]
    {"unknown_field": lambda: c.update(extra=1), "network": lambda: c["permissions"].update(network=True), "imports": lambda: c["permissions"].update(imports=["json", "os"]),
     "secrets": lambda: c["permissions"].update(secrets=True), "fs": lambda: c["permissions"].update(filesystem="rw"),
     "timeout": lambda: ex.update(timeout_seconds=100000), "output": lambda: ex.update(max_output_bytes=1 << 30), "memory": lambda: ex["resources"].update(memory_mb=4096),
     "digest": lambda: ex["environment_ref"].update(digest="sha256:" + "0" * 64), "adapter": lambda: ex.update(adapter_ref={"path": "evaluator/c3/oracle.py", "sha256": "0" * 64}),
     "no_oracle_in_pins": lambda: v["evaluator"]["pin_files"].remove("evaluator/c3/oracle.py"), "escape": lambda: v.update(baseline="../x.py"),
     "missing_file": lambda: v.update(baseline="evaluator/c3/none.py"), "dup_names": lambda: v["evaluator"]["pin_files"].append("evaluator/m1/oracle.py"),
     "bad_id": lambda: c.update(capability_id="Bad Id"), "bad_envelope": lambda: c["inputs"].update(envelope="raw"), "bad_arity": lambda: c["inputs"].update(arity=[2])}[name]()
    with pytest.raises(Refused):
        CC.validate(c)


def test_contract_adapter_ref_must_match_its_bytes():
    c = copy.deepcopy(CC.get("inventory-diff"))
    c["execution"]["adapter_ref"] = {"path": "evaluator/c3/baseline_script.py", "sha256": CC.lf_sha("evaluator/c3/baseline_script.py")}
    CC.validate(c)
    c["execution"]["adapter_ref"]["sha256"] = "1" * 64
    with pytest.raises(Refused):
        CC.validate(c)


# ---------------------------------------------------------------- v1 statements still work
@needs_store
def test_v1_statement_normalizes_verifies_and_executes(auth, store, runs):
    st1 = add_v1(store, auth)
    ev, st = head_event(store)
    assert st["schema"] == CC.V1 and ev["statement_sha"] == _sha(CR.canon(st1))  # the stored event is untouched
    view = CC.normalize(st)
    assert view["inputs"]["arity"] == [2, 2] and view["outputs"] == CC.get("inventory-diff")["outputs"] and CC.pin(view) == st["verifier"]["pin"]
    ok, _ = eligible(store)
    assert ok["inventory-diff"]["in"] == "canonical_rows" and ok["inventory-diff"]["out"] == "inventory_diff" and ok["inventory-diff"]["arity"] == [2, 2]
    assert ok["inventory-diff"]["verifier"] == "evaluator/c3/oracle.py"
    r = goal(store)
    assert r["state"] == "VERIFIED", r["reason"]
    assert r["steps"][-1]["mode"] == "retained_capability_execution" and r["steps"][-1]["verdict"] == "PASS" and r["steps"][-1]["capability"]["version"] == 1
    assert goal(store)["mode"] == "saved_result_replay"


@needs_store
@pytest.mark.parametrize("name", ["harness_path", "pin", "image", "body"])
def test_v1_statement_tampering_refused(auth, store, runs, monkeypatch, name):
    if name == "harness_path":
        add_v1(store, auth)
        sign_head(store, auth, lambda st: st["harness"].update(path="evaluator/m2/harness.py"))
    elif name == "pin":
        add_v1(store, auth)
        sign_head(store, auth, lambda st: st["verifier"].update(pin="0" * 64))
    elif name == "image":
        add_v1(store, auth)
        sign_head(store, auth, lambda st: st["env"].update(digest="sha256:" + "0" * 64))
    else:
        add_v1(store, auth)
        sign_head(store, auth, lambda st: st.update(body=st["body"] + "\n# x\n"))
    assert_refused(store, runs)


# ---------------------------------------------------------------- v2 admission
@needs_store
def test_v2_admission_round_trip(auth, store, runs):
    out = admit(store, auth)
    ev, st = head_event(store)
    c = CC.get("inventory-diff")
    assert out["cap_id"] == "inventory-diff" and st["schema"] == CC.V2 and st["contract"] == c and st["contract_sha256"] == CC.sha(c)
    assert st["pin"] == CC.pin(c) and st["harness_sha256"] == CC.harness_sha(c) and st["impl_sha256"] == _sha(st["body"])
    assert CC.normalize(st) == c and "limits" not in st and "verifier" not in st
    r = goal(store)
    assert r["state"] == "VERIFIED" and r["steps"][-1]["capability"]["version"] == 1 and len(runs) == 3
    assert (Path(store) / next(a["ref"] for a in r["deliverable"] if a["name"] == c["outputs"]["artifact_name"])).is_file()
    again = goal(store)  # restart
    assert again["mode"] == "saved_result_replay" and len(runs) == 3


@needs_store
@pytest.mark.parametrize("name", ["contract", "contract_resigned_consistent", "pin", "adapter", "harness_sha", "unknown_cap_contract"])
def test_v2_tampered_contract_pin_or_adapter_refused(auth, store, runs, monkeypatch, name):
    admit(store, auth)
    assert eligible(store)[0]
    if name == "contract":  # contract edited but statement_sha/contract_sha256 kept: signed by the authority, still refused on use
        sign_head(store, auth, lambda st: st["contract"]["execution"].update(timeout_seconds=999))
    elif name == "contract_resigned_consistent":  # even a consistent contract hash cannot smuggle a weaker permission
        def weaker(st):
            st["contract"]["permissions"]["network"] = True
            st["contract_sha256"] = CC.sha(st["contract"])
        sign_head(store, auth, weaker)
    elif name == "pin":
        monkeypatch.setattr(CC, "pin", lambda c: "0" * 64)
    elif name == "adapter":
        def adapter(st):
            st["contract"]["execution"]["adapter_ref"] = {"path": "evaluator/c3/oracle.py", "sha256": "0" * 64}
            st["contract_sha256"] = CC.sha(st["contract"])
        sign_head(store, auth, adapter)
    elif name == "harness_sha":
        sign_head(store, auth, lambda st: st.update(harness_sha256="0" * 64))
    else:
        sign_head(store, auth, lambda st: st["contract"].update(capability_id="other"))
    assert_refused(store, runs)


@needs_store
def test_admit_refuses_a_changed_contract_or_unmatched_gap(auth, store, monkeypatch):
    monkeypatch.setattr(CC, "pin", lambda c: "0" * 64)
    with pytest.raises(Refused):
        admit(store, auth)
    s = Store(store)
    try:
        assert [e["type"] for e in CR.history(s, "inventory-diff")] == ["rejected"]
        rec = next(e for e in D.experiments(s) if e["exp_id"] == EXP)
    finally:
        s.close()
    monkeypatch.setattr(CC, "contract_for_gap", lambda sig: None)
    with pytest.raises(Refused):
        D.contract_of(rec)


@needs_store
def test_mixed_v1_v2_chain_rolls_back_and_executes(auth, store, runs):
    admit(store, auth)  # v1: the real schema-v2 admission (re-admitting the same experiment is refused now, so the legacy statement goes on top)
    add_v1(store, auth, version=2)  # a signature-valid legacy-schema statement as v2
    assert [e["type"] for e in CR.history(Store(store), "inventory-diff")] == ["admit", "admit"]
    r2 = goal(store)
    assert r2["state"] == "VERIFIED" and r2["steps"][-1]["capability"]["version"] == 2
    assert head_event(store)[1]["lineage"]["prev_version_statement_sha"]
    out = H.rollback(store, "inventory-diff", auth)
    assert (out["from_version"], out["to_version"]) == (2, 1)
    r1 = goal(store, after=AFTER + b"y.md,docs,3\n")
    assert r1["state"] == "VERIFIED" and r1["steps"][-1]["capability"]["version"] == 1
    s = Store(store)
    try:
        assert CR.resolve_discovered(s, "inventory-diff")["statement"]["schema"] == CC.V2
    finally:
        s.close()
    H.revoke(store, "inventory-diff", 1, "test", auth)
    assert_refused(store, runs, "no eligible version")


def test_cap_is_required_for_revoke_and_rollback(capsys):
    for argv in (["rollback", "--store", "x"], ["revoke", "--store", "x", "--version", "1", "--reason", "r"]):
        with pytest.raises(SystemExit) as e:
            H.main(argv)
        assert e.value.code == 2
    assert "--cap" in capsys.readouterr().err


# ---------------------------------------------------------------- generic evaluator folder
def test_g1_evaluator_is_generic_over_its_suite_folder(tmp_path):
    suite = tmp_path / "suite"
    suite.mkdir()
    (suite / "oracle.py").write_text("def expected(env):\n    return env['files'][0]['text'].upper()\n", encoding="utf-8", newline="\n")
    (suite / "gen_public.py").write_text("def cases():\n    return []\n", encoding="utf-8", newline="\n")
    (suite / "gen_private.py").write_text("import hashlib, json\n\n\ndef set_sha(cases):\n    return hashlib.sha256(json.dumps(cases, sort_keys=True, separators=(',', ':')).encode()).hexdigest()\n",
                                          encoding="utf-8", newline="\n")
    cases = [{"name": "a", "env": {"files": [{"format": "text", "text": "ab"}]}}, {"name": "b", "env": {"files": [{"format": "text", "text": "x y"}]}}]
    sha = hashlib.sha256(json.dumps(cases, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    (tmp_path / "priv" / sha).mkdir(parents=True)
    (tmp_path / "priv" / sha / "cases.json").write_text(json.dumps(cases), encoding="utf-8", newline="\n")
    spec = importlib.util.spec_from_file_location("g1_evaluate", ROOT / "evaluator" / "g1" / "evaluate.py")
    ev = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(ev)

    def container(src, text):
        ns = {}
        exec(compile(src, "<cand>", "exec"), ns)
        return ns["apply"](text, None)

    def run(body, label):
        f = tmp_path / f"{label}.py"
        f.write_text(body, encoding="utf-8", newline="\n")
        out = tmp_path / f"{label}.json"
        args = ["--suite", str(suite), "--exp", "e", "--frozen-sha", "f" * 64, "--candidate-file", str(f), "--candidate-sha", _sha(body), "--private", str(tmp_path / "priv"),
                "--set", sha, "--out", str(out), "--label", label]
        with CC.scope():
            ev.main(args, run_container=container)
        return json.loads(out.read_text(encoding="utf-8"))
    good = run("def run(env):\n    return env['files'][0]['text'].upper()\n", "candidate")
    bad = run("def run(env):\n    return 'no'\n", "candidate2")
    assert (good["verdict"], good["pass_count"], good["n"]) == ("PASS", 2, 2) and (bad["verdict"], bad["pass_count"]) == ("FAIL", 0)
    want = _sha("".join(f"{n}:{_sha((p / n).read_bytes().replace(bytes([13, 10]), bytes([10])))}\n"
                        for n, p in (("evaluate.py", Path(ev.HERE)), ("oracle.py", suite), ("harness.py", Path(ev.HERE)), ("gen_private.py", suite), ("gen_public.py", suite))))
    assert good["evaluator"]["pin"] == want and good["receipt_sha256"] == ev.receipt_sha(good) and "expected" not in json.dumps(good)
    assert D.receipt_problems({"frozen": {"acceptance": {"set_sha256": sha, "n": 2}, "evaluator": {"pin": want}}, "exp_id": "e", "frozen_sha": "f" * 64}, good, _sha("def run(env):\n    return env['files'][0]['text'].upper()\n"), "candidate") == []


# ---------------------------------------------------------------- no task literals in the core
CORE = ["src/hive/goal_runner.py", "src/hive/discovery.py", "src/hive/capability_registry.py", "src/hive/capcontract.py", "src/hive/bounded.py", "scripts/hive_admission.py"]
TASK = re.compile(r"inventory|canonical_rows|inventory_diff|inventory-diff|evaluator/c3|interval|reconcil|asset[._-]", re.I)


ALLOWED = {"capability_inventory"}  # the gap record's stored key (generic: the capability catalog); kept so stored records still read


def _code_text(path):
    """Identifiers and string literals of a module, docstrings and comments excluded."""
    tree = ast.parse((ROOT / path).read_text(encoding="utf-8"))
    doc = {id(n.body[0].value) for n in ast.walk(tree) if isinstance(n, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and n.body
           and isinstance(n.body[0], ast.Expr) and isinstance(n.body[0].value, ast.Constant) and isinstance(n.body[0].value.value, str)}
    out = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Constant) and isinstance(n.value, str) and id(n) not in doc:
            out.append(n.value)
        elif isinstance(n, ast.Name):
            out.append(n.id)
        elif isinstance(n, ast.Attribute):
            out.append(n.attr)
        elif isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            out.append(n.name)
        elif isinstance(n, ast.arg):
            out.append(n.arg)
        elif isinstance(n, ast.keyword) and n.arg:
            out.append(n.arg)
        elif isinstance(n, ast.alias):
            out.append(n.name)
    return out


@pytest.mark.parametrize("path", CORE)
def test_core_has_no_task_literals(path):
    hits = sorted({t for t in _code_text(path) if TASK.search(t) and t not in ALLOWED})
    assert not hits, f"{path} names a task: {hits[:5]}"


def test_literal_scan_sees_strings_and_ignores_docstrings(tmp_path, monkeypatch):
    p = tmp_path / "m.py"
    p.write_text('"""inventory in a docstring"""\n# interval in a comment\nx = "Inventory-Diff"\n', encoding="utf-8")
    monkeypatch.setattr(sys.modules[__name__], "ROOT", tmp_path)
    assert [t for t in _code_text("m.py") if TASK.search(t)] == ["Inventory-Diff"]
