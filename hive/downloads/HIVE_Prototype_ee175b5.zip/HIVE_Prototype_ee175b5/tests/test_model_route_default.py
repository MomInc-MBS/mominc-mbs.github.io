"""model-route-v1: auto is the default route, an explicit --model stays authoritative, one bounded fallback for auto-routed goals. Stubs/mocks only: no model, no network."""
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))
sys.path.insert(0, str(ROOT / "scripts"))
from hive import discovery as D  # noqa: E402
from hive import model_choice as MC  # noqa: E402
from hive import operator_runtime as O  # noqa: E402
from hive.storage import Store  # noqa: E402
from test_discovery import env, fake_runs, submit  # noqa: E402,F401
from test_sealed_final import CAP, GOAL, INS  # noqa: E402
import g3_qualify as Q  # noqa: E402

GPT, NEM, KIMI = "openai/gpt-oss-20b", "nvidia/nemotron-3.5-super-vl-120b-a12b", "moonshotai/kimi-k3.1-pro"
LEDGER = {k: 0 for k in ("calls", "proposals", "container_runs", "in_tokens", "out_tokens", "wall_s")}
TRANSPORT = "fallback P0: transport_failure (no retry beyond transport_retries)"
DEAD = f"fallback P0: MODEL_NOT_LOADED: URLError: <urlopen error [WinError 10061]>"
REFUSED = "fallback P0: MODEL_NOT_LOADED: Refused: operator approval gate refused: x"
IDENT = "fallback P0: reply verification failed: unexpected model id in response: 'other'"


def mc_for(rank, backend=None):
    return {"policy_version": "model-route-v1", "backend": backend or rank[0], "reason": "pass_rate", "rank": [{"backend": b, "reason": "pass_rate"} for b in rank],
            "rejected": [], "evidence_sha256": "e" * 64, "store_id": None}


# ------------------------------------------------------------------------------------------------------------------ classification / receipt
@pytest.mark.parametrize("state,reason,want", [
    ("MODEL_UNAVAILABLE", TRANSPORT, "retryable"),
    ("MODEL_UNAVAILABLE", DEAD, "retryable"),
    ("MODEL_UNAVAILABLE", "fallback P0: MODEL_NOT_LOADED: Invalidated: x is listed but not loaded", "retryable"),
    ("MODEL_UNAVAILABLE", "fallback P0: MODEL_NOT_LOADED: Invalidated: unexpected model ids ['y']", "retryable"),
    ("MODEL_UNAVAILABLE", "fallback P0: CONTEXT_DOES_NOT_FIT", "retryable"),
    ("MODEL_UNAVAILABLE", "fallback P0: NO_EXECUTABLE_MODEL", "retryable"),
    ("MODEL_UNAVAILABLE", REFUSED, "stop"),
    ("MODEL_UNAVAILABLE", "fallback P0: MODEL_NOT_LOADED: DataRefused: hosted backend refused: private input", "stop"),
    ("MODEL_UNAVAILABLE", "fallback P0: MODEL_NOT_LOADED: Invalidated: weight sha mismatch at c3-run", "stop"),
    ("MODEL_UNAVAILABLE", IDENT, "stop"),
    ("MODEL_UNAVAILABLE", "fallback P0: something new", "stop"),
    ("MODEL_UNAVAILABLE", None, "stop"),
    ("STOPPED", "operator stop", "stop"),
    ("BUDGET_EXHAUSTED", TRANSPORT, "stop"),
    ("CANDIDATE_PASSED", "", "stop"),
    ("PUBLIC_CANDIDATE_FROZEN", "", "stop"),
    ("NO_QUALIFYING_CANDIDATE", "", "stop"),
    ("SOMETHING_ELSE", TRANSPORT, "stop"),
])
def test_classify_failure_table(state, reason, want):
    assert MC.classify_failure(state, reason) == want


def test_choose_receipt_has_policy_version_rejected_with_reason_codes_and_store_id(monkeypatch):
    mc = MC.choose("inventory-diff", store_id="abc")
    assert mc["policy_version"] == "model-route-v1" and mc["store_id"] == "abc" and mc["evidence_sha256"] and mc["rank"][0]["reason"]
    assert {"backend": "qwen/qwen3.8-27b", "reason": "not_qualified"} in mc["rejected"]
    codes = {"not_qualified", "approval_refused", "unknown_pins"}
    assert all(r["reason"] in codes for r in mc["rejected"])
    # approval refused / unknown pins are reported, not dropped silently
    import hive.m2_model as M
    monkeypatch.setattr(M, "approval_problems", lambda *a, **k: ["no"])
    rej = []
    assert MC.eligible(None, rej) == [] and {"backend": GPT, "reason": "approval_refused"} in rej
    monkeypatch.setattr(M, "approval_problems", lambda *a, **k: (_ for _ in ()).throw(M.Refused("missing pins")))
    rej = []
    MC.eligible(None, rej)
    assert {"backend": GPT, "reason": "unknown_pins"} in rej


# ------------------------------------------------------------------------------------------------------------------ routing order
def test_retained_capability_means_zero_calls_and_no_routing(monkeypatch):
    monkeypatch.setattr(Q, "retained", lambda store, cap: {"cap_id": cap, "version": 1, "statement_sha": "s"})
    monkeypatch.setattr(Q.MC, "choose", lambda *a, **k: pytest.fail("routing must not run for a retained capability"))
    monkeypatch.setattr(Q.D, "run_experiment", lambda *a, **k: pytest.fail("no experiment for a retained capability"))
    out = Q.acquire_gap(SimpleNamespace(model="auto", private=None, stub_endpoint=None, admit_key=None), "S", "x", CAP, GOAL, INS)
    assert out["state"] == "ALREADY_RETAINED"


def test_omitted_model_is_auto_and_explicit_model_is_kept(monkeypatch, tmp_path):
    seen = []
    monkeypatch.setattr(Q, "phase_acquire", lambda a, m: (seen.append(a.model), {"ok": True})[1])
    for extra, want in (([], "auto"), (["--model", GPT], GPT)):
        assert Q.main(["--phase", "acquire", "--store", str(tmp_path / "s"), "--out", str(tmp_path / "o")] + extra) == 0
        assert seen[-1] == want


def test_explicit_pin_keeps_protocol_and_exp_id_byte_identical(env, fake_runs, monkeypatch):
    store = env[0]
    gap = Q.G.run_goal(store, Q.G.make_contract(GOAL, INS, allow_discovery=False), INS)["gap_ref"]
    monkeypatch.setattr(Q.MC, "choose", lambda *a, **k: pytest.fail("a pinned model never consults the router"))
    monkeypatch.setattr(Q.D, "run_experiment", lambda store, exp, **k: {"exp_id": exp, "state": "STOPPED", "ledger": LEDGER})
    a = SimpleNamespace(model=GPT, private=None, stub_endpoint="http://127.0.0.1:1", admit_key=None)
    out = Q.acquire_gap(a, store, "inv", CAP, GOAL, INS)
    first = out["attempts"][0]["exp_id"]
    s = Store(store)
    try:
        rec = s.get(D.KEY + first)
        assert "model_choice" not in rec["frozen"] and rec["frozen"]["proposer"]["model"] == GPT and "model_choice" not in out and "escalate_to" not in out
        s.set(D.KEY + first, dict(rec, state="NO_QUALIFYING_CANDIDATE"))
        old = D.open_experiment(s, gap, private_dir=None, budget=dict(Q.EXP_BUDGET), acq_run=Q.CAMPAIGN, proposer_model=GPT, coop=None, seed_base=None, model_choice=None)
    finally:
        s.close()
    skip = ("attempt", "acceptance")  # the hidden acceptance set is freshly generated per experiment
    new_core = {k: v for k, v in rec["frozen"].items() if k not in skip}
    assert {k: v for k, v in old["frozen"].items() if k not in skip} == new_core  # same frozen protocol as the pre-router call shape


# ------------------------------------------------------------------------------------------------------------------ bounded fallback
class Rig:
    """Real goal/gap/store; open_experiment and run_experiment are scripted so every end state is exact."""

    def __init__(self, monkeypatch, store, ends):
        self.opens, self.runs, self.ends = [], [], list(ends)
        monkeypatch.setattr(Q.D, "open_experiment", self.open)
        monkeypatch.setattr(Q.D, "run_experiment", self.run)

    def open(self, s, gap, **k):
        self.opens.append(k)
        return {"exp_id": f"e{len(self.opens)}"}

    def run(self, store, exp, **k):
        self.runs.append(dict(k, exp=exp))
        state, reason = self.ends.pop(0)
        return {"exp_id": exp, "state": state, "reason": reason, "ledger": dict(LEDGER, calls=1), "proposals": [], "dispatches": [],
                "frozen": {"proposer": {"model": GPT}}, "frozen_sha": "f", "best": None}


def go(env, monkeypatch, ends, model="auto", rank=(GPT, NEM, KIMI), sealed=False):
    rig = Rig(monkeypatch, env[0], ends)
    if model == "auto":
        monkeypatch.setattr(Q.MC, "choose", lambda *a, **k: mc_for(list(rank)))
    a = SimpleNamespace(model=model, private=None, stub_endpoint="http://127.0.0.1:1", admit_key=None, manifest=None)
    return rig, Q.acquire_gap(a, env[0], "inv", CAP, GOAL, INS, policy=D.SEALED if sealed else None)


@pytest.mark.parametrize("sealed", [False, True])
def test_retryable_failure_gets_exactly_one_alternate_with_one_call(env, monkeypatch, sealed):
    rig, out = go(env, monkeypatch, [("MODEL_UNAVAILABLE", DEAD), ("NO_QUALIFYING_CANDIDATE", ""), ("NO_QUALIFYING_CANDIDATE", "")], sealed=sealed)
    assert len(rig.opens) == 3  # still at most three experiments per gap
    alt = rig.opens[1]
    assert alt["budget"]["calls"] == 1 and alt["budget"]["proposals"] == 1 and alt["proposer_model"] == NEM
    assert alt["model_choice"]["backend"] == NEM and alt["model_choice"]["fallback_of"] == {"backend": GPT, "class": "retryable", "reason_code": "model_not_loaded"}
    assert rig.runs[1]["requested_model"] == NEM and rig.runs[0]["requested_model"] == GPT
    assert out["attempts"][1]["fallback"] == {"from": GPT, "to": NEM, "reason_code": "model_not_loaded"} and "fallback" not in out["attempts"][0]
    assert sum("fallback" in x for x in out["attempts"]) == 1
    assert rig.opens[0]["model_choice"]["backend"] == GPT and "fallback_of" not in rig.opens[0]["model_choice"]
    assert rig.opens[2]["budget"]["calls"] == Q.EXP_BUDGET["calls"]  # the alternate's tiny budget does not leak into later slots
    assert out["escalate_to"] == KIMI  # the hint never names a backend already used (GPT, NEM)


@pytest.mark.parametrize("sealed", [False, True])
def test_second_retryable_failure_means_no_further_fallback(env, monkeypatch, sealed):
    rig, out = go(env, monkeypatch, [("MODEL_UNAVAILABLE", TRANSPORT), ("MODEL_UNAVAILABLE", TRANSPORT), ("MODEL_UNAVAILABLE", TRANSPORT)], sealed=sealed)
    assert len(rig.opens) == 2 and [x["model_choice"]["backend"] for x in rig.opens] == [GPT, NEM]
    assert sum("fallback" in x for x in out["attempts"]) == 1


@pytest.mark.parametrize("sealed", [False, True])
@pytest.mark.parametrize("state,reason", [("MODEL_UNAVAILABLE", REFUSED), ("MODEL_UNAVAILABLE", IDENT), ("STOPPED", "operator stop"), ("BUDGET_EXHAUSTED", "calls")])
def test_stop_class_ends_never_fall_back(env, monkeypatch, sealed, state, reason):
    rig, out = go(env, monkeypatch, [(state, reason), ("NO_QUALIFYING_CANDIDATE", ""), ("NO_QUALIFYING_CANDIDATE", "")], sealed=sealed)
    assert all(o["model_choice"]["backend"] == GPT and "fallback_of" not in o["model_choice"] for o in rig.opens)
    assert all(r["requested_model"] == GPT for r in rig.runs) and not any("fallback" in x for x in out["attempts"])
    assert all(o["budget"]["calls"] == Q.EXP_BUDGET["calls"] for o in rig.opens)
    if state == "MODEL_UNAVAILABLE":
        assert len(rig.opens) == 1  # a refusing / mismatching backend is not retried either


@pytest.mark.parametrize("sealed", [False, True])
def test_pinned_model_never_falls_back(env, monkeypatch, sealed):
    rig, out = go(env, monkeypatch, [("MODEL_UNAVAILABLE", TRANSPORT), ("MODEL_UNAVAILABLE", TRANSPORT), ("MODEL_UNAVAILABLE", TRANSPORT)], model=GPT, sealed=sealed)
    assert all(o["model_choice"] is None and o["proposer_model"] == GPT for o in rig.opens) and all(r["requested_model"] == GPT for r in rig.runs)
    assert not any("fallback" in x for x in out["attempts"]) and "escalate_to" not in out


def test_last_ranked_backend_has_nothing_to_fall_back_to(env, monkeypatch):
    rig, out = go(env, monkeypatch, [("MODEL_UNAVAILABLE", TRANSPORT)], rank=(GPT,))
    assert len(rig.opens) == 1 and not any("fallback" in x for x in out["attempts"])


def test_frozen_protocol_records_the_alternate_backend(env, fake_runs, monkeypatch):
    """Real open_experiment: the fallback copy is frozen into the protocol (a hosted alternate freezes itself as the proposer)."""
    store = env[0]
    gap = Q.G.run_goal(store, Q.G.make_contract(GOAL, INS, allow_discovery=False), INS)["gap_ref"]
    first = mc_for([GPT, NEM])
    alt = Q._fallback(first, {"state": "MODEL_UNAVAILABLE", "reason": TRANSPORT})
    assert alt and alt[1] == {"from": GPT, "to": NEM, "reason_code": "transport_failure"} and first["backend"] == GPT  # the original is not mutated
    s = Store(store)
    try:
        e = D.open_experiment(s, gap, budget=dict(Q.EXP_BUDGET, calls=1, proposals=1), acq_run=Q.CAMPAIGN, proposer_model=NEM, model_choice=alt[0])
    finally:
        s.close()
    assert e["frozen"]["model_choice"]["backend"] == NEM and e["frozen"]["model_choice"]["fallback_of"]["backend"] == GPT
    assert e["frozen"]["proposer"]["model"] == NEM and e["frozen"]["budget"]["calls"] == 1 and e["frozen"]["budget"]["proposals"] == 1


def test_discover_run_default_is_the_frozen_route_else_incumbent(env, fake_runs):
    store = env[0]
    gap = Q.G.run_goal(store, Q.G.make_contract(GOAL, INS, allow_discovery=False), INS)["gap_ref"]
    s = Store(store)
    try:
        e = D.open_experiment(s, gap, budget=dict(Q.EXP_BUDGET), acq_run=Q.CAMPAIGN, proposer_model=GPT, model_choice=mc_for([GPT, NEM]))
        assert MC.frozen_route(store, e["exp_id"]) == GPT
        rec = s.get(D.KEY + e["exp_id"])
        s.set(D.KEY + e["exp_id"], dict(rec, frozen={k: v for k, v in rec["frozen"].items() if k != "model_choice"}))
    finally:
        s.close()
    assert MC.frozen_route(store, e["exp_id"]) is None  # legacy experiment: unchanged incumbent
