"""Oracle sanity for site.ref-extract / site.ref-resolve: the operator-authored G1 body (written from spec + public cases, no oracle access) passes the public
generator cases and the private evaluator on a fresh private set; wrong / empty / malformed / constant bodies fail. Qualifies the public construction answers
used by the selector check coop-construct-check-v1. Needs Docker (same skip rule as test_experiment_container)."""
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

import pytest
from hive.adapters.isolation import DockerIsolation, PINNED_IMAGE, SandboxUnavailable
from hive.experiment_compare import run_isolated

try:
    DockerIsolation().inspect(PINNED_IMAGE)
    OK = ""
except SandboxUnavailable as e:
    OK = str(e)
pytestmark = pytest.mark.skipif(bool(OK), reason=OK or "docker")

ROOT = Path(__file__).resolve().parents[1]
EV = ROOT / "evaluator" / "g2"
CAPS = ("site.ref-extract", "site.ref-resolve")
AUTHORED = ROOT / "build" / "g1" / "authored"
BAD = {  # name -> body; every one must fail something
    "empty": "def run(env):\n    return ''\n",
    "malformed": "def run(env):\n    return '{not json'\n",
    "non-text": "def run(env):\n    return None\n",
    "constant-error": "def run(env):\n    return 'ERROR'\n",
    "raises": "def run(env):\n    raise ValueError('x')\n",
}


def load(name, path):
    for m in ("oracle", "gen_public", "gen_private"):  # both suites import these by bare name: never reuse the other suite's module
        sys.modules.pop(m, None)
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(path.parent))
    try:
        spec.loader.exec_module(m)
    finally:
        sys.path.pop(0)
    return m


def suite(cap):
    return ROOT / "capabilities" / cap / "suite"


def run_cases(body, cases):
    sys.path.insert(0, str(EV))
    try:
        import harness
    finally:
        sys.path.pop(0)
    out = run_isolated(harness.wrap(body), json.dumps([c["env"] for c in cases]), {}, timeout=120, backend="container", operator_class="generated")
    return json.loads(out)


def public(cap):
    g = load("gp_" + cap.replace(".", "_").replace("-", "_"), suite(cap) / "gen_public.py")
    return g.cases()


def body(cap):
    return (AUTHORED / (cap + ".py")).read_text(encoding="utf-8")


@pytest.mark.parametrize("cap", CAPS)
def test_authored_passes_public_and_all_public_answers_are_distinct_from_trivial(cap):
    cs = public(cap)
    got = run_cases(body(cap), cs)
    assert [g == c["expected"] for g, c in zip(got, cs)] == [True] * len(cs)
    errs = [c for c in cs if c["expected"] == "ERROR"]
    assert errs and len(errs) < len(cs)  # a constant answer cannot pass the whole public set


@pytest.mark.parametrize("cap", CAPS)
@pytest.mark.parametrize("name", sorted(BAD))
def test_wrong_bodies_fail_public_cases(cap, name):
    cs = public(cap)
    got = run_cases(BAD[name], cs)
    assert [g == c["expected"] for g, c in zip(got, cs)] != [True] * len(cs)
    if name == "constant-error":  # passes exactly the error cases
        assert [g == c["expected"] for g, c in zip(got, cs)] == [c["expected"] == "ERROR" for c in cs]
    else:
        assert not any(g == c["expected"] for g, c in zip(got, cs) if c["expected"] != "ERROR")


def evaluate(cap, cand, tmp, seed, label):
    gp = load("gpr_" + cap.replace(".", "_").replace("-", "_"), suite(cap) / "gen_private.py")
    cases = gp.generate(seed)
    sha = gp.set_sha(cases)
    d = tmp / "private" / sha
    d.mkdir(parents=True, exist_ok=True)
    (d / "cases.json").write_text(json.dumps(cases, sort_keys=True, separators=(",", ":")), encoding="utf-8", newline="\n")
    import hashlib
    csha = hashlib.sha256(cand.encode()).hexdigest()
    f = tmp / f"{label}.py"
    f.write_text(cand, encoding="utf-8", newline="\n")
    out = tmp / f"{label}.receipt.json"
    r = subprocess.run([sys.executable, "-I", str(EV / "evaluate.py"), "--suite", str(suite(cap)), "--exp", "sanity", "--frozen-sha", "0", "--candidate-file", str(f),
                        "--candidate-sha", csha, "--private", str(tmp / "private"), "--set", sha, "--out", str(out), "--label", label, "--imports", "json,base64,re"],
                       capture_output=True, text=True, timeout=300)
    assert r.returncode == 0, r.stderr[-500:]
    return json.loads(out.read_text(encoding="utf-8"))


@pytest.mark.parametrize("cap", CAPS)
def test_authored_passes_fresh_private_set_and_bad_bodies_fail(cap, tmp_path):
    good = evaluate(cap, body(cap), tmp_path, 20261127, "good")
    assert good["verdict"] == "PASS" and good["pass_count"] == good["n"] == 24
    for name in ("malformed", "constant-error"):
        bad = evaluate(cap, BAD[name], tmp_path, 20261127, name)
        assert bad["verdict"] == "FAIL" and bad["pass_count"] < bad["n"]
    assert evaluate(cap, BAD["constant-error"], tmp_path, 20261127, "c2")["pass_count"] == sum(
        c["expected"] == "ERROR" for c in load("g", suite(cap) / "gen_private.py").generate(20261127))
