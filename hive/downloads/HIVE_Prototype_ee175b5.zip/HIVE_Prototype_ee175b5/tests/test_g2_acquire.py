"""G2 S4: the acquisition state machine. Fake GitHub transport, local fixture git repos, fake stager, the repo's stub model endpoint, and a fake
container that answers with the independent oracle (it stands in for the container only: it is the *test double* of a perfect adapter, not an
adapter). No Docker, no network, no model. Real admission/registry/retained-execution code runs on top of those doubles."""
from __future__ import annotations

import base64
import hashlib
import json
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "tests"))
import hive_admission as H  # noqa: E402
import m2_stub_server as STUB  # noqa: E402
from hive import acq_card as AC, acq_github as AG, acq_propose as AP, acq_stage as ST, acquire as A  # noqa: E402
from hive import capability_registry as CR, capcontract as CC, discovery as D, experiment_compare as EC, goal_runner as G, operator_runtime as O  # noqa: E402
from hive.adapters.isolation import PINNED_IMAGE  # noqa: E402
from hive.operator_runtime import Refused  # noqa: E402
from hive.repo_intel import clone_pinned  # noqa: E402
from hive.storage import Store  # noqa: E402
from test_g2_stage import REPO, make_repo  # noqa: E402

CAP = "image.asset-match"
SUITE = ROOT / "capabilities" / "image.asset-match" / "suite"
POL = json.loads((ROOT / "configs" / "acquisition_policy.json").read_text(encoding="utf-8"))
needs_ssh = pytest.mark.skipif(not CR.keygen(), reason="ssh-keygen unavailable")
GOODBODY = "```python\nimport json\nimport vtool\n\n\ndef run(env):\n    return json.dumps({\"n\": len(env[\"files\"])})\n```"


class FakeStager:
    def __init__(self, fail=None, boom=None):
        self.fail, self.boom, self.stages, self.ensures = dict(fail or {}), boom, [], []

    def stage(self, repo_path, card, store_dir, cache_dir):
        self.stages.append(card["repo"])
        if card["repo"] in self.fail:
            raise ST.StageRejected(self.fail[card["repo"]], "fake")
        if self.boom:
            raise self.boom
        Path(store_dir).mkdir(parents=True, exist_ok=True)
        data = ("tar:" + card["repo"]).encode()
        tar = Path(store_dir) / (hashlib.sha256(data).hexdigest()[:16] + ".tar")
        tar.write_bytes(data)
        return {"id": "sha256:" + hashlib.sha256(data).hexdigest(), "tag": "t", "base": dict(PINNED_IMAGE), "lock_sha256": "1" * 64, "wheelhouse_manifest_sha256": "2" * 64,
                "image_tar_sha256": hashlib.sha256(data).hexdigest(), "tar_path": str(tar), "packages": ["vtool"], "vendored_tree_sha256": "4" * 64,
                "tool_modules": ["vtool"], "wheelhouse": [{"name": "tinydep", "version": "1.0", "license": "MIT", "sha256": "5" * 64, "bytes": 1}]}

    def ensure(self, env):
        self.ensures.append(env["id"])
        return env["id"]

    def cleanup(self): pass


def items(*names, lic="MIT"):
    return [{"full_name": n, "description": "d", "license": {"spdx_id": lic}, "stargazers_count": 1, "size": 10, "open_issues_count": 0, "pushed_at": "2026-01-01"} for n in names]


class World:
    pass


@pytest.fixture
def world(tmp_path, monkeypatch):
    w = World()
    w.tmp, w.store, w.mode, w.kws = tmp_path, tmp_path / "store", {"v": "oracle"}, []
    monkeypatch.setattr(D, "PRIVATE", tmp_path / "priv")
    c = CC.get(CAP)
    orc = CC.load_module("oracle", c)
    gp = CC.load_module("gen_public", c)
    gpv = CC.load_module("gen_private", c)

    def container(src, text, checks=None, timeout=None, max_out=None, *, backend="container", operator_class="generated", **kw):
        w.kws.append(kw)
        if w.mode["v"] == "exec":  # really run the wrapped adapter (its imports must resolve in this process)
            ns = {}
            exec(compile(src, "candidate", "exec"), ns)
            return ns["apply"](text, checks)
        envs = json.loads(text)
        return json.dumps([orc.expected(e) if w.mode["v"] == "oracle" else "x" for e in envs])
    monkeypatch.setattr(EC, "run_isolated", container)

    def launch(args, evaluator=None):
        with CC.scope(c):
            CC.load_module("evaluate", c).main(args, run_container=lambda src, text: container(src, text))
        return SimpleNamespace(returncode=0, stdout=b"", stderr=b"", timed_out=False)
    monkeypatch.setattr(D, "_launch", launch)
    monkeypatch.setattr(CC, "ensure_image", lambda env, d: env["id"])
    w.orc, w.gp, w.gpv = orc, gp, gpv
    s = Store(w.store)
    O.import_bundle(s)
    s.close()
    w.files = lambda env: [(f["name"], "file", base64.b64decode(f["data"])) for f in env["files"]]
    return w


def make_repos(w, n, files=None, names=None):
    names = names or [f"o{i}/tool{i}" for i in range(n)]
    w.local, w.sha = {}, {}
    for nm in names:
        url = "https://github.com/" + nm
        repo, sha = make_repo(w.tmp / nm.replace("/", "_"), files or REPO)
        w.local[url], w.sha[url] = repo, sha
    return names


def hooks(w, names, stager=None, lic="MIT", transport=None):
    tr = transport or (lambda url, h: (200, {}, json.dumps({"items": items(*names, lic=lic)}).encode()))
    w.stager = stager or FakeStager()
    w.gh = AG.GitHubSearch(w.tmp / "ghc", POL, tr, sleep=lambda s: None)
    return {"github": w.gh, "resolve": lambda url, ref: w.sha[url], "clone": lambda url, sha, dest: clone_pinned(str(w.local[url]), sha, dest), "stager": w.stager, "policy": POL}


def queue_goal(w, allow=True, seed=11):
    case = w.gp.cases()[1]
    ins = w.files(case["env"])
    c = G.make_contract("Match these duplicate images and write a manifest", ins, deliverable="image_match_manifest", allow_acquisition=allow)
    r = G.run_goal(w.store, c, ins)
    w.goal = r
    return r


def go(w, rid, h, **kw):
    kw.setdefault("private_dir", w.tmp / "priv")
    kw.setdefault("seed", 5)
    return A.run(w.store, rid, hooks=h, **kw)


def rec_of(w, rid):
    s = Store(w.store)
    try:
        return s.get(A.KEY + rid)
    finally:
        s.close()


def serve(w, replies):
    srv, url = STUB.serve_thread({"R": replies}, log=str(w.tmp / "req.jsonl"))
    w.srv, w.url = srv, url
    return {"stub_endpoint": url}


def queued(w, names, files=None, **kw):
    make_repos(w, len(names), names=names, files=files)
    r = queue_goal(w, **kw)
    assert r["state"] == "ACQUISITION_QUEUED", r["reason"]
    return r["acquisition_run"]


# ---------------------------------------------------------------- goal hook + open_run
def test_goal_queues_an_acquisition_only_when_allowed(world):
    make_repos(world, 1)
    r = queue_goal(world, allow=False)
    assert r["state"] == "UNRESOLVED" and "acquisition_run" not in r and "acquisition" not in json.dumps(r["plan"]) and not A.runs(Store(world.store))
    r = queue_goal(world, allow=True)
    assert r["state"] == "ACQUISITION_QUEUED" and r["missing_step"]["out"] == "image_match_manifest"
    rec = rec_of(world, r["acquisition_run"])
    assert rec["state"] == "SEARCH" and rec["frozen"]["contract"]["capability_id"] == CAP and rec["ledger"]["attempts"] == 0 and rec["gap_key"] == r["gap_ref"]
    r2 = queue_goal(world, allow=True)  # the gap already has an open run
    assert r2["state"] == "UNRESOLVED" and "acquisition not opened" in r2["reason"]
    c1 = G.make_contract("g", [("a.png", "file", b"x"), ("b.png", "file", b"y")], deliverable="image_match_manifest")
    assert "acquisition" not in c1["permissions"]  # a goal that does not ask for it keeps the exact permissions (and contract id) it always had


def test_open_run_guards(world):
    s = Store(world.store)
    try:
        s.set("gap/none", {"missing_step": {"in": "folder", "arity": 1, "out": "group_summary", "ordered": True}, "partial_plan": []})
        with pytest.raises(Refused, match="derived-environment"):
            A.open_run(s, "gap/none")
        with pytest.raises(Refused):
            A.open_run(s, "gap/missing")
        s.set("gap/img", {"missing_step": {"in": "image_file", "arity": 3, "out": "image_match_manifest", "ordered": True}, "partial_plan": []})
        with pytest.raises(Refused, match="query"):
            A.open_run(s, "gap/img", queries=["a;b"])
        r1 = A.open_run(s, "gap/img", queries=["dedupe pictures"])
        with pytest.raises(Refused, match="open or completed"):
            A.open_run(s, "gap/img")
        r1["state"] = "NO_CANDIDATE"
        s.set(A.KEY + r1["run_id"], r1)
        r2 = A.open_run(s, "gap/img")
        r2["state"] = "CANDIDATES_EXHAUSTED"
        s.set(A.KEY + r2["run_id"], r2)
        with pytest.raises(Refused, match="at most 2"):
            A.open_run(s, "gap/img")
    finally:
        s.close()


# ---------------------------------------------------------------- search tiers and terminals
def test_network_failure_and_empty_search_end_with_their_own_reason(world):
    rid = queued(world, ["o0/tool0"])
    h = hooks(world, [], transport=lambda u, hd: (500, {}, b""))
    assert go(world, rid, h)["state"] == "NETWORK_UNAVAILABLE" and not world.stager.stages
    s = Store(world.store)
    try:
        rid2 = A.open_run(s, world.goal["gap_ref"])["run_id"]  # a second run on the same gap after the network is back
    finally:
        s.close()
    assert go(world, rid2, hooks(world, []))["state"] == "NO_CANDIDATE" and rid2 != rid


def test_retained_tier_satisfies_the_gap_and_require_new_external_overrides(world, monkeypatch):
    rid = queued(world, ["o0/tool0"])
    monkeypatch.setattr(A, "_retained", lambda s, sig: [{"cap_id": CAP, "version": 1}])
    h = hooks(world, ["o0/tool0"])
    rec = go(world, rid, h)
    assert rec["state"] == "DONE" and rec["outcome"]["tier"] == "retained" and not world.stager.stages and world.gh.requests == 0 and rec["ledger"]["attempts"] == 0
    # require_new_external: tiers 1-2 are recorded but never selectable, so a GitHub candidate is acquired
    rec["frozen"]["require_new_external"], rec["state"] = True, "SEARCH"
    rec["search"] = None
    s = Store(world.store)
    s.set(A.KEY + rid, rec)
    s.close()
    out = go(world, rid, hooks(world, ["o0/tool0"]), run_kw=serve(world, [GOODBODY]))
    assert out["state"] == "AWAITING_ADMISSION" and [t["selectable"] for t in out["search"]["tiers"]] == [False, False, True] and world.stager.stages


def test_inspection_rejections_are_recorded_and_end_no_candidate(world):
    files = dict(REPO, **{"LICENSE": "GNU GENERAL PUBLIC LICENSE Version 3\n"})
    rid = queued(world, ["o0/gpl"], files=files)
    rec = go(world, rid, hooks(world, ["o0/gpl"]))
    assert rec["state"] == "NO_CANDIDATE" and rec["inspected"][0]["rejection"].startswith("LICENSE_NOT_ALLOWED") and not world.stager.stages
    m = json.loads((world.store / "acquisition" / rid / "run-manifest.json").read_text(encoding="utf-8"))
    assert m["inspected"][0]["repo"] == "o0/gpl" and m["inspected"][0]["revision"] == world.sha["https://github.com/o0/gpl"] and m["state"] == "NO_CANDIDATE"


def test_inspect_is_bounded_and_lazy(world):
    names = [f"o{i}/bad{i}" for i in range(12)]
    files = dict(REPO, **{"LICENSE": "GNU GENERAL PUBLIC LICENSE Version 3\n"})
    rid = queued(world, names, files=files)
    rec = go(world, rid, hooks(world, names))
    assert rec["state"] == "NO_CANDIDATE" and len(rec["inspected"]) == rec["frozen"]["budget"]["inspect"] == 8


# ---------------------------------------------------------------- attempts
def test_stage_rejection_then_next_candidate_verifies_and_waits_for_admission(world):
    names = ["o0/a", "o1/b", "o2/c"]
    rid = queued(world, names)
    st = FakeStager(fail={})
    h = hooks(world, names, stager=st)
    first = sorted(names)[0]
    st.fail = {n: "COMPILED_OR_SDIST_ONLY" for n in names[:1]}
    kw = serve(world, [GOODBODY])
    rec = go(world, rid, h, run_kw=kw)
    assert rec["state"] == "AWAITING_ADMISSION" and "hive_admission.py admit" in rec["reason"]
    rej = [a for a in rec["attempts"] if a["state"] == "REJECTED"]
    ok = [a for a in rec["attempts"] if a["state"] == "PASSED"]
    assert len(ok) == 1 and ok[0]["adapter_sha256"] and ok[0]["environment"]["id"].startswith("sha256:")
    assert all(a["rejection"].startswith("COMPILED_OR_SDIST_ONLY") for a in rej) and first
    assert rec["ledger"]["model_calls"] == 1 and rec["ledger"]["builds"] == len(rec["attempts"]) and rec["ledger"]["cost_usd"] == 0.0
    dev = [k for k in world.kws if "image" in k]
    assert dev and all(k["image"]["id"] == ok[0]["environment"]["id"] and k["limits"]["memory_mb"] == 512 for k in dev)


def test_three_failed_attempts_end_candidates_exhausted_within_budget(world):
    names = ["o0/a", "o1/b", "o2/c"]
    rid = queued(world, names)
    world.mode["v"] = "wrong"
    kw = serve(world, [GOODBODY])
    admitted = []
    rec = go(world, rid, hooks(world, names), run_kw=kw, admit=lambda *a: admitted.append(a))
    assert rec["state"] == "CANDIDATES_EXHAUSTED" and not admitted  # never admits an unverified candidate
    assert len(rec["attempts"]) == 3 and rec["ledger"]["attempts"] == 3 and all(a["state"] == "FAILED" for a in rec["attempts"])
    B = rec["frozen"]["budget"]
    assert rec["ledger"]["model_calls"] <= B["model_calls"] and rec["ledger"]["builds"] == 3 and rec["ledger"]["container_runs"] <= B["container_runs"]
    assert all(a["rejection"] for a in rec["attempts"])  # each failed attempt says why (here: the model only ever produced the one wrong adapter)


def test_all_candidates_rejected_by_staging_is_exhausted_without_a_model_call(world):
    names = ["o0/a", "o1/b"]
    rid = queued(world, names)
    st = FakeStager(fail={n: "BUILD_FAILED" for n in names})
    rec = go(world, rid, hooks(world, names, stager=st))
    assert rec["state"] == "CANDIDATES_EXHAUSTED" and rec["ledger"]["model_calls"] == 0 and len(st.stages) == 2


def test_model_unavailable_and_prompt_limit(world):
    names = ["o0/a"]
    rid = queued(world, names)
    rec = go(world, rid, hooks(world, names), run_kw={"requested_model": "not/qualified"})
    assert rec["state"] == "MODEL_UNAVAILABLE" and rec["ledger"]["model_calls"] == 0
    # prompt over the input-token rule: the frozen limit is enforced before any call
    s = Store(world.store)
    try:
        rid2 = A.open_run(s, world.goal["gap_ref"], budget={"max_prompt_tokens": 50})["run_id"]
    finally:
        s.close()
    rec2 = go(world, rid2, hooks(world, names), run_kw=serve(world, [GOODBODY]))
    assert rec2["state"] == "BUDGET_EXHAUSTED" and "prompt exceeds 50" in rec2["reason"] and rec2["ledger"]["model_calls"] == 0


def test_budget_gate_refuses_an_attempt_that_cannot_finish(world):
    names = ["o0/a"]
    rid = queued(world, names)
    s = Store(world.store)
    rec = s.get(A.KEY + rid)
    rec["frozen"]["budget"]["container_runs"] = 2
    s.set(A.KEY + rid, rec)
    s.close()
    out = go(world, rid, hooks(world, names))
    assert out["state"] == "BUDGET_EXHAUSTED" and "container_runs" in out["reason"] and not world.stager.stages


def test_stop_ends_the_run_with_nothing_started(world):
    names = ["o0/a"]
    rid = queued(world, names)
    (world.store / "STOP").write_text("x", encoding="utf-8")
    h = hooks(world, names)
    rec = go(world, rid, h)
    assert rec["state"] == "STOPPED" and not world.stager.stages and world.gh.requests == 0 and rec["ledger"]["model_calls"] == 0
    assert go(world, rid, h)["state"] == "STOPPED"  # terminal, like a discovery experiment


def test_sandbox_unavailable_is_its_own_terminal_reason(world):
    names = ["o0/a", "o1/b"]
    rid = queued(world, names)
    st = FakeStager(boom=FileNotFoundError("docker"))
    rec = go(world, rid, hooks(world, names, stager=st))
    assert rec["state"] == "SANDBOX_UNAVAILABLE" and len(st.stages) == 1


# ---------------------------------------------------------------- crash/resume, admission, execution, reuse
def test_crash_after_staging_resumes_without_a_second_build_or_clone(world, monkeypatch):
    names = ["o0/a"]
    rid = queued(world, names)
    h = hooks(world, names)
    kw = serve(world, [GOODBODY])
    real = D.run_experiment
    boom = {"n": 0}

    def flaky(*a, **k):
        if not boom["n"]:
            boom["n"] = 1
            raise OSError("simulated crash")
        return real(*a, **k)
    monkeypatch.setattr(D, "run_experiment", flaky)
    rec = go(world, rid, h, run_kw=kw)
    assert rec["state"] == "INTERRUPTED" and "simulated crash" in rec["reason"] and len(world.stager.stages) == 1 and rec["attempts"][0]["environment"]
    clones = []
    h["clone"] = lambda *a: clones.append(a)
    rec = go(world, rid, h, run_kw=kw)
    assert rec["state"] == "AWAITING_ADMISSION" and len(world.stager.stages) == 1 and world.stager.ensures == [rec["attempts"][0]["environment"]["id"]] and not clones
    assert rec["ledger"]["model_calls"] == 1 and len(A.runs(Store(world.store))) == 1 and rec["ledger"]["builds"] == 1


def test_admission_refused_is_terminal(world):
    names = ["o0/a"]
    rid = queued(world, names)

    def refuse(store, exp):
        raise Refused("admission refused: check: nope")
    rec = go(world, rid, hooks(world, names), run_kw=serve(world, [GOODBODY]), admit=refuse)
    assert rec["state"] == "ADMISSION_REFUSED" and "nope" in rec["reason"]


FRESH = """
import json, sys
from pathlib import Path
sys.path.insert(0, sys.argv[1]); sys.path.insert(0, sys.argv[2])
from hive import capability_registry as CR, capcontract as CC, experiment_compare as EC, goal_runner as G, operator_runtime as O, discovery as D
from hive.storage import Store
import oracle
store, signers, *files = sys.argv[3:]
CR.SIGNERS = Path(signers)
CC.ensure_image = lambda env, d: env["id"]
def fake(src, text, checks=None, timeout=None, max_out=None, *, backend="container", operator_class="generated", **kw):
    return json.dumps([oracle.expected(e) for e in json.loads(text)])
EC.run_isolated = fake
ins = [(Path(p).name, "file", Path(p).read_bytes()) for p in files]
r = G.run_goal(store, G.make_contract("Match these duplicate images and write a manifest", ins, deliverable="image_match_manifest"), ins)
s = Store(store); cnt, n = O._counters(s), len(D.experiments(s)); s.close()
print(json.dumps({"state": r["state"], "reason": r["reason"], "mode": r["steps"][-1]["mode"] if r["steps"] else None, "model_calls": cnt["model_calls"],
                  "proposal_calls": cnt["proposal_calls"], "experiments": n}))
"""


def grant_holdout(store, exp_id):
    """Contract 2.0.0 declares a real holdout: stand in for the owner's one opening with a PASS receipt bound to this experiment's candidate."""
    s = Store(store)
    try:
        cand = next(e for e in D.experiments(s) if e["exp_id"] == exp_id)["candidate_sha256"]
        c = CC.get(CAP)
        r = {"schema": "hive-real-holdout-receipt-v1", "capability_id": CAP, "candidate_sha256": cand, "approval_sha256": c["verification"]["real_holdout"]["approval_sha256"],
             "n": 3, "case_pass": [True] * 3, "pass_count": 3, "verdict": "PASS"}
        r["receipt_sha256"] = CC.holdout_receipt_sha(r)
        s.set(CC.HOLDOUT_RECEIPT + CAP + "/" + cand, r)
    finally:
        s.close()


@needs_ssh
def test_full_path_admit_execute_and_reuse_in_a_fresh_process(world, tmp_path, monkeypatch):
    names = ["o0/a", "o1/b"]
    rid = queued(world, names)
    h = hooks(world, names)
    kw = serve(world, [GOODBODY])
    rec = go(world, rid, h, run_kw=kw)
    assert rec["state"] == "AWAITING_ADMISSION"
    exp_id = next(a["exp_id"] for a in rec["attempts"] if a["state"] == "PASSED")
    info = H.init(str(tmp_path / "keys"), str(tmp_path / "signers"))
    monkeypatch.setattr(CR, "SIGNERS", Path(info["signers"]))
    with pytest.raises(Refused, match="real holdout"):
        H.admit(str(world.store), exp_id, str(info["key"]))  # no holdout receipt yet: refused
    grant_holdout(world.store, exp_id)
    out = H.admit(str(world.store), exp_id, str(info["key"]))  # the key holder, out of band
    assert out["cap_id"] == CAP
    unseen = world.gpv.generate(77, 1)[0]["env"]
    ex = lambda store_root: G.run_goal(store_root, *(lambda ins: (G.make_contract("Match these duplicate images and write a manifest", ins, deliverable="image_match_manifest"), ins))(world.files(unseen)))
    rec = go(world, rid, h, run_kw=kw, execute=ex)
    assert rec["state"] == "DONE" and rec["outcome"]["executed"] and rec["outcome"]["goal_state"] == "VERIFIED" and rec["outcome"]["repo"] in names
    assert len(world.stager.stages) == len(rec["attempts"]) and rec["ledger"]["model_calls"] == 1
    m = json.loads((world.store / "acquisition" / rid / "run-manifest.json").read_text(encoding="utf-8"))
    assert m["schema"] == "hive-g2-run-v1" and m["cost_usd"] == 0.0 and m["model"] == "openai/gpt-oss-20b" and "not Ian" in m["fixture_author"]
    assert m["attempts"][-1]["adapter_sha256"] and m["attempts"][-1]["environment"]["image_tar_sha256"] and m["search"]["queries"] and m["attempts"][-1]["card_sha256"]
    assert rec["manifest"]["sha256"] == hashlib.sha256((world.store / "acquisition" / rid / "run-manifest.json").read_bytes()).hexdigest()
    s = Store(world.store)
    st = CR.resolve_discovered(s, CAP)["statement"]
    s.close()
    assert st["schema"] == CC.V3 and st["environment"]["packages"] == ["vtool"]
    # a fresh process, a third unseen input: retained execution, zero model calls, no new experiment
    s = Store(world.store)
    n_exp = len(D.experiments(s))
    s.close()
    files = []
    for n, _, b in world.files(world.gpv.generate(123, 1)[0]["env"]):
        p = tmp_path / "fresh" / n
        p.parent.mkdir(exist_ok=True)
        p.write_bytes(b)
        files.append(str(p))
    script = tmp_path / "fresh.py"
    script.write_text(FRESH, encoding="utf-8", newline="\n")
    p = subprocess.run([sys.executable, str(script), str(ROOT / "src"), str(SUITE), str(world.store), str(CR.SIGNERS), *files], capture_output=True, text=True, timeout=300)
    assert p.returncode == 0, p.stderr[-600:]
    res = json.loads(p.stdout.strip().splitlines()[-1])
    assert res["state"] == "VERIFIED" and res["mode"] == "retained_capability_execution" and res["experiments"] == n_exp  # no new experiment
    assert res["model_calls"] == 0 and res["proposal_calls"] == 0  # the fresh process made no model call (the goal counters never see discovery's own)


@needs_ssh
def test_qualify_script_run_resume_admit_and_reuse_phases(world, tmp_path, monkeypatch):
    import g2_qualify as Q
    names = ["o0/a", "o1/b"]
    make_repos(world, 2, names=names)
    h = hooks(world, names)
    monkeypatch.setattr(Q, "real_hooks", lambda store: h)
    info = H.init(str(tmp_path / "keys"), str(tmp_path / "signers"))
    monkeypatch.setattr(CR, "SIGNERS", Path(info["signers"]))
    srv, url = STUB.serve_thread({"R": [GOODBODY]}, log=str(tmp_path / "req.jsonl"))
    out = tmp_path / "out"
    base = ["--store", str(world.store), "--out", str(out), "--stub-endpoint", url, "--private", str(tmp_path / "priv"), "--private-seed", "5", "--require-new-external"]
    assert Q.main(["--phase", "run"] + base) == 3  # AWAITING_ADMISSION: stops and prints the admit command
    m = json.loads((out / "manifest.json").read_text(encoding="utf-8"))
    assert m["state"] == "AWAITING_ADMISSION" and m["require_new_external"] and "not Ian" in m["fixture_author"] and m["commands"] and m["environment"]["python"] and m["seeds_sha256"]["run"]
    rid = m["run_id"]
    grant_holdout(world.store, next(e["exp_id"] for e in json.loads((out / "manifest.json").read_text(encoding="utf-8"))["attempts"] if e["state"] == "PASSED"))
    assert Q.main(["--phase", "run", "--resume", rid, "--admit-key", str(info["key"])] + base) == 0
    m = json.loads((out / "manifest.json").read_text(encoding="utf-8"))
    assert m["state"] == "DONE" and m["outcome"]["goal_state"] == "VERIFIED" and m["cost_usd"] == 0.0
    assert Q.main(["--phase", "reuse", "--store", str(world.store), "--unseen-seed", "909", "--out", str(out)]) == 0
    r = json.loads((out / "reuse.json").read_text(encoding="utf-8"))
    assert r["ok"] and r["mode"] == "retained_capability_execution" and r["new_experiments"] == 0 and r["new_model_calls"] == 0 and r["fresh_process"]
    assert not any(c[0] == "docker" for c in [])  # nothing started a container: every container call above was the test double


def test_qualify_script_helpers_are_deterministic():
    import g2_qualify as Q
    assert Q.images(7) == Q.images(7) and Q.images(7) != Q.images(8)
    c, ins = Q.goal_for(7, allow_acquisition=True)
    assert c["permissions"]["acquisition"] and c["deliverable"] == "image_match_manifest" and len(ins) == len(c["inputs"])


# ---------------------------------------------------------------- proposer module
def test_prompt_contents_and_limits(world):
    names = ["o0/a"]
    rid = queued(world, names)
    go(world, rid, hooks(world, names), run_kw=serve(world, [GOODBODY]))
    reqs = [json.loads(line) for line in (world.tmp / "req.jsonl").read_text(encoding="utf-8").splitlines()]
    assert reqs
    text = "\n".join(m["content"] for m in reqs[0]["messages"])
    assert AP.tokens(text) <= AP.MAX_PROMPT_TOKENS and "UNTRUSTED REPOSITORY DATA" in text and "vtool" in text and "<base64" in text
    for secret in ("pin_files", "oracle.py", "private", "signers", "admit", "ssh", "permissions", "environment_ref", "gen_private", "THRESH"):
        assert secret not in text, secret


def test_proposer_helpers():
    assert AP.adapter_bytes("x\n```python\nimport json\ndef run(env):\n    return ''\n```\ntail") == b"import json\ndef run(env):\n    return ''\n"
    assert AP.adapter_bytes("```python\nprint(1)\n```") is None and AP.adapter_bytes(None) is None and AP.adapter_bytes("def run(env): return ''") is not None
    assert AP.adapter_bytes("```\ndef run(e): pass\n```ignore def run") == b"def run(e): pass\n"
    assert AP.parse_queries("1. near duplicate images\n- \"bad;query\"\n* dedupe image files\n" + "x\n" * 20) == ["near duplicate images", "dedupe image files", "x"]
    assert AP.prompt_problems([{"content": "a" * 40000}]) and not AP.prompt_problems([{"content": "a" * 100}]) and isinstance(AP.query_messages({"purpose": "p", "behaviour_spec": "b", "inputs": ["x"], "output": "o", "media_type": "m"}), list)


def test_card_excerpt_is_capped_and_fenced(world):
    names = make_repos(world, 1)
    repo, sha = world.local["https://github.com/" + names[0]], world.sha["https://github.com/" + names[0]]
    card = AC.build_card(repo, sha, names[0], POL, world.tmp / "cc", api_license="MIT")
    ex = AP.card_excerpt(card, 100)
    assert ex.startswith("=== UNTRUSTED") and ex.rstrip().endswith("=== END UNTRUSTED DATA ===") and len(ex) < 600


def test_new_modules_name_no_tool_or_task():
    banned = ("image.asset", "image_match", "image_file", "imagehash", "pillow", "perceptual", "asset-match", "phash")
    for n in ("acquire.py", "acq_propose.py"):
        t = (ROOT / "src" / "hive" / n).read_text(encoding="utf-8").lower()
        assert not [w for w in banned if w in t], (n, [w for w in banned if w in t])
    t = (ROOT / "scripts" / "g2_qualify.py").read_text(encoding="utf-8").lower()
    assert not [w for w in ("imagehash", "phash") if w in t]
