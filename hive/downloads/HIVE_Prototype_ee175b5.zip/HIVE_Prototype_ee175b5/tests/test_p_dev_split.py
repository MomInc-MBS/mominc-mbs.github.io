"""Every error class the hidden generator draws must be shown in the public dev cases as "<class>-is-an-error"."""
import importlib.util
import pathlib
import sys

import pytest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SUITES = sorted(p.parent for p in (ROOT / "capabilities").glob("*/suite/gen_private.py"))
ALIAS = {("site.release-diff", "same-time"): "same-timestamp", ("site.release-diff", "one-file"): "one-manifest"}  # (capability, hidden class) -> dev case stem, where an existing dev case uses another name for the same class
KNOWN_GAPS = {  # fix when the capability is requalified (its suite is pinned by an admission)
    "report.reconcile": {"missing-from-table", "extra-in-manifest", "keeper-not-member"},
    "site.ref-check": {"duplicate-path", "local-null-target"},
    "site.release-diff": {"bad-stamp", "duplicate-path", "wrong-schema"},
}


def load(suite, name):
    s = importlib.util.spec_from_file_location("devsplit_" + suite.parent.name.replace(".", "_") + name, suite / (name + ".py"))
    m = importlib.util.module_from_spec(s)
    sys.modules.pop("oracle", None)  # suites all `import oracle`
    sys.path.insert(0, str(suite))
    try:
        s.loader.exec_module(m)
    finally:
        sys.path.remove(str(suite))
        sys.modules.pop("oracle", None)
    return m


@pytest.mark.parametrize("suite", SUITES, ids=lambda p: p.parent.name)
def test_dev_cases_show_every_hidden_error_class(suite):
    cap = suite.parent.name
    priv = load(suite, "gen_private")
    errors = {e for e in getattr(priv, "ERRORS", []) if e}
    names = {k["name"] for k in load(suite, "gen_public").cases()}
    missing = {e for e in errors if ALIAS.get((cap, e), e) + "-is-an-error" not in names}
    assert missing <= KNOWN_GAPS.get(cap, set()), f"{cap}: hidden error classes with no dev case: {sorted(missing)}"
