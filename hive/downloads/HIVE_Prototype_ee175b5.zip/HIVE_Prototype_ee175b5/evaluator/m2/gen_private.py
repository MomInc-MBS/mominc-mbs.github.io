"""PRIVATE M2 generators G8 (F-final) and G9 (F-reuse), both effects. Not for proposers.

Writes into .hive/m2-private/ (gitignored). Seeds are random on first run, kept only in
.hive/m2-private/seeds.json, and never printed. Run:  python evaluator/m2/gen_private.py
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
sys.path.insert(0, HERE)
import gen_public as gp  # noqa: E402

# Vocabularies and id formats disjoint from G7 and from M1's G1-G6 (M1: A, B, C below).
M1_VOCABS = (["media", "docs", "logs", "cache", "builds", "backups", "mail", "photos", "café"]
             + ["tenant-north", "tenant-south", "vault", "ledger", "render", "ingest", "sandbox", "archive", "nått"]
             + ["zeta", "omega", "kappa", "delta", "sigma", "tau", "pi", "über"])
VOCAB_G8 = ["kiln", "forge", "smelter", "foundry", "mill", "quarry", "dock", "étain"]
VOCAB_G9 = ["birch", "cedar", "maple", "willow", "ash", "elm", "fir", "ørn"]
assert not set(VOCAB_G8) & set(VOCAB_G9) and not set(VOCAB_G8 + VOCAB_G9) & (set(M1_VOCABS) | set(gp.VOCAB_G7))
B36 = "0123456789abcdefghijklmnopqrstuvwxyz"

STYLE_G8 = dict(groups=VOCAB_G8, idf=lambda i: "k%06x#%d" % ((i * 40503 + 977) & 0xFFFFFF, i),
                r_rows=(1, 60), c_rows=(3, 30), files=(2, 6), rate=None, shuffle=False, inv_frac=None)
STYLE_G9 = dict(groups=VOCAB_G9, idf=lambda i: "Q.%s.%d" % (B36[i % 36] * 2, i),
                r_rows=(40, 60), c_rows=(20, 30), files=(5, 6), rate=(0.2, 0.5), shuffle=True, inv_frac=(0.33, 0.5))

CHECK = {
    "f_final_R": dict(per=15, rows_range=(1, 60), min_share=True),
    "f_reuse_R": dict(per=5, rows_range=(40, 60), rate=(0.2, 0.5)),
    "f_final_C": dict(per=15, rows_range=(3, 30), files_range=(2, 6), min_share=True),
    "f_reuse_C": dict(per=5, rows_range=(20, 30), files_range=(5, 6), rate=(0.2, 0.5), inv_frac=(0.33, 0.5)),
}


def build(seeds):
    return {
        "f_final_R": gp.build_r(seeds["f_final_R"], "finR", STYLE_G8, gp.specs(15)),
        "f_reuse_R": gp.build_r(seeds["f_reuse_R"], "reuR", STYLE_G9, gp.specs(5)),
        "f_final_C": gp.build_c(seeds["f_final_C"], "finC", STYLE_G8, gp.specs(15)),
        "f_reuse_C": gp.build_c(seeds["f_reuse_C"], "reuC", STYLE_G9, gp.specs(5)),
    }


def new_seeds():
    # 3,000,000,000+ : disjoint from M1's seed spaces (710001-710002, 900000-17.7M) and from G7 (7201xx, 7202xx)
    return {k: 3_000_000_000 + int.from_bytes(os.urandom(4), "big") for k in CHECK}


if __name__ == "__main__":
    out_dir = os.path.join(ROOT, ".hive", "m2-private")
    os.makedirs(out_dir, exist_ok=True)
    seedfile = os.path.join(out_dir, "seeds.json")
    if not os.path.exists(seedfile):
        with open(seedfile, "w", newline="\n") as f:
            json.dump(new_seeds(), f)
    with open(seedfile) as f:
        seeds = json.load(f)
    res = {}
    for name, cs in build(seeds).items():
        stats = gp.check_partition(cs, **CHECK[name])
        res[name] = {"sha256": gp.write_jsonl(os.path.join(out_dir, name + ".jsonl"), cs), "cases": len(cs),
                     "stats": stats}
    print(json.dumps(res, indent=1))
