"""M2 generator core plus the public partitions F-dev and F-sel (generator G7), both effects.

Effect R (row-convert-v1): one source file per case.  Effect C (batch-merge-v1): one batch per case.
G8/G9 (private partitions) reuse this core from gen_private.py.  A case is admitted only when the
generator's record and an independent re-derivation from the bytes (oracle.py) agree.
"""
import base64
import hashlib
import io
import json
import math
import os
import random
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oracle  # noqa: E402

CATS = {"csv": [4, 2, 3, 5], "json": [1, 2, 3, 5]}  # applicable defect categories, cycled as first-failure plan
FORMS = ["whitespace", "unsorted", "nonascii"]
CSV_BAD4 = ["01", "-1", "1.5", "abc", "", "12345678901", " 5", "1e3", "+5", "00", "0x10", "5 "]
JSON_BAD5 = [True, False, 1.0, 2.5, "5", -1, 10**9 + 1, 10**12, None, 1000.0]
JSON_BAD_ID = [None, 5, [1], True, 2.5]
JSON_BAD_GRP = [None, 3, ["a"], False]

# G7 (public). The last vocabulary entry is always the non-ASCII one.
VOCAB_G7 = ["hangar", "pantry", "garage", "attic", "loft", "cellar", "annex", "jäger"]
STYLE_G7 = dict(groups=VOCAB_G7, idf=lambda i: "item/%03d" % i, r_rows=(1, 30), c_rows=(3, 15), files=(2, 4),
                rate=None, shuffle=False, inv_frac=None)
SEEDS = {"f_dev_R": 720101, "f_sel_R": 720102, "f_dev_C": 720201, "f_sel_C": 720202}


def pad(s, n):
    return s + "z" * (n - len(s)) if len(s) < n else s


def _bad_name(rng, base, used, key, other):
    if not used[key] and rng.random() < 0.5:
        used[key] = True
        return ""
    if other and rng.random() < 0.5:
        return rng.choice(other)
    return pad(base, 129 + rng.randint(0, 19))


def make_row(rng, fmt, i, cat, style, used):
    """Return (value, record). cat is the row's first-failing category (0 = valid)."""
    sid = style["idf"](i)
    if rng.random() < 0.05:
        sid = pad(sid, 128)
    grp = rng.choice(style["groups"])
    if rng.random() < 0.04:
        grp = pad(grp, 128)
    b = rng.choice([0, 10**9, rng.randint(1, 5000), rng.randint(1, 10**9)])
    if cat == 0:
        val = [sid, grp, str(b)] if fmt == "csv" else {"id": sid, "group": grp, "bytes": b}
        return val, {"cat": 0, "id": sid, "group": grp, "bytes": b}
    rec = {"cat": cat, "id": None, "group": None, "bytes": None}
    if cat == 1:
        kind = rng.choice(["scalar", "string", "list", "null", "missing", "missing_id", "extra", "rename"])
        val = {"scalar": 7, "string": "x", "list": [sid, grp, b], "null": None,
               "missing": {"id": sid, "group": grp}, "missing_id": {"group": grp, "bytes": b},
               "extra": {"id": sid, "group": grp, "bytes": b, "note": "x"},
               "rename": {"id": sid, "grp": grp, "bytes": b}}[kind]
        return val, rec
    csv_ = fmt == "csv"
    group_bad = cat == 3 or (cat < 3 and rng.random() < 0.35)  # lower-priority defects exercise precedence
    if csv_:
        bk = cat if cat in (4, 5) else (rng.choice([4, 5]) if rng.random() < 0.35 else 0)
    else:
        bk = 5 if (cat == 5 or (cat < 5 and rng.random() < 0.35)) else 0
    vid = _bad_name(rng, sid, used, "id", None if csv_ else JSON_BAD_ID) if cat == 2 else sid
    vgrp = _bad_name(rng, grp, used, "grp", None if csv_ else JSON_BAD_GRP) if group_bad else grp
    if bk == 4:
        vb = rng.choice(CSV_BAD4)
    elif bk == 5:
        vb = str(rng.choice([10**9 + 1, 9999999999, rng.randint(10**9 + 1, 9999999999)])) if csv_ \
            else rng.choice(JSON_BAD5)
    else:
        vb = str(b) if csv_ else b
    val = [vid, vgrp, vb] if csv_ else {"id": vid, "group": vgrp, "bytes": vb}
    return val, rec


def _order(rng, d, mode):
    if not isinstance(d, dict):
        return d
    ks = list(d)
    if mode == "shuffle":
        rng.shuffle(ks)
    else:
        ks = sorted(ks, reverse=(mode == "desc"))
    return {k: d[k] for k in ks}


def _json_bytes(rng, vals, recs, style, form):
    if form == "nonascii":  # put a non-ASCII group on a valid row (every file has one: defects are at most half the rows)
        k = rng.choice([j for j, r in enumerate(recs) if r["cat"] == 0])
        vals[k]["group"] = recs[k]["group"] = style["groups"][-1]
    mode = "shuffle" if style["shuffle"] else ("desc" if form == "unsorted" else "asc")
    vals = [_order(rng, v, mode) for v in vals]
    if form == "whitespace":
        ind = rng.choice([None, 1, 2, 4])
        text = json.dumps(vals, ensure_ascii=False, indent=ind) if ind \
            else json.dumps(vals, ensure_ascii=False, separators=(", ", ": "))
    else:
        text = json.dumps(vals, ensure_ascii=False, separators=(",", ":"))
    data = text.encode("utf-8")
    forms = oracle.json_forms(data)
    assert form in forms and not oracle.is_canonical_json(data), (form, forms)
    return data, sorted(forms)


def make_file(rng, fmt, defective, style, rows_range, first_cat=None, form=None):
    lo, hi = rows_range
    n = rng.randint(max(lo, 2 if defective else 1), hi)
    cats = {}
    if defective:
        rate = style["rate"]
        if rate:
            klo, khi = max(1, math.ceil(rate[0] * n)), min(n // 2, math.floor(rate[1] * n))
        else:
            klo, khi = 1, n // 2
        k = 1 if (not rate and rng.random() < 0.4) else rng.randint(klo, khi)
        L, p = CATS[fmt], CATS[fmt].index(first_cat)
        for j, ix in enumerate(sorted(rng.sample(range(n), k))):
            cats[ix] = L[(p + j) % len(L)]
    used = {"id": False, "grp": False}
    vals, recs = [], []
    for i in range(n):
        v, r = make_row(rng, fmt, i, cats.get(i, 0), style, used)
        vals.append(v)
        recs.append(r)
    forms = []
    if fmt == "csv":
        import csv
        buf = io.StringIO(newline="")
        w = csv.writer(buf, lineterminator="\n")
        w.writerow(["id", "group", "bytes"])
        w.writerows(vals)
        data = buf.getvalue().encode("utf-8")
    else:
        data, forms = _json_bytes(rng, vals, recs, style, form)
    return {"fmt": fmt, "data": data, "recs": recs, "n": n, "defective": defective, "forms": forms,
            "form": form, "first_cat": first_cat, "cats": dict(Counter(str(c) for c in cats.values()))}


# ---- partition builders -------------------------------------------------------------------

def build_r(seed, prefix, style, specs):
    """specs: list of (fmt, defective) -> list of R cases."""
    rng = random.Random(seed)
    order = list(specs)
    rng.shuffle(order)
    ptr, fptr, out = {"csv": 0, "json": 0}, 0, []
    for j, (fmt, dfl) in enumerate(order):
        first = None
        if dfl:
            first = CATS[fmt][ptr[fmt] % 4]
            ptr[fmt] += 1
        form = None
        if fmt == "json":
            form, fptr = FORMS[fptr % 3], fptr + 1
        f = make_file(rng, fmt, dfl, style, style["r_rows"], first, form)
        exp = oracle.admit_r(fmt, f["data"], f["recs"])
        out.append({"kind": "R", "case_id": "%s-%02d" % (prefix, j), "format": fmt, "data": f["data"],
                    "expected": exp, "defective": dfl, "forms": f["forms"],
                    "counts": {"rows": f["n"], "defective": sum(f["cats"].values()), "cats": f["cats"],
                               "first_cat": first, "form": form}})
    return out


def build_c(seed, prefix, style, specs):
    """specs: list of (fmt, defective) -> list of C cases (a batch is all one format)."""
    rng = random.Random(seed)
    order = list(specs)
    rng.shuffle(order)
    ptr, dj, fptr, out = {"csv": 0, "json": 0}, {"csv": 0, "json": 0}, 0, []
    flo, fhi = style["files"]
    for j, (fmt, dfl) in enumerate(order):
        ninv = 0
        if dfl:
            multi = dj[fmt] % 2 == 1  # every other defective batch has two or more invalid files
            dj[fmt] += 1
            if style["inv_frac"]:
                nf = rng.randint(flo, fhi)
                ninv = rng.randint(math.ceil(style["inv_frac"][0] * nf), math.floor(style["inv_frac"][1] * nf))
            else:
                nf = rng.randint(max(flo, 4) if multi else flo, fhi)
                ninv = rng.randint(2, nf // 2) if multi else 1
        else:
            nf = rng.randint(flo, fhi)
        inv = sorted(rng.sample(range(nf), ninv))
        files, firsts = [], []
        for i in range(nf):
            first = None
            if i in inv:
                first = CATS[fmt][ptr[fmt] % 4]
                ptr[fmt] += 1
                firsts.append(first)
            form = None
            if fmt == "json":
                form, fptr = FORMS[fptr % 3], fptr + 1
            files.append(make_file(rng, fmt, i in inv, style, style["c_rows"], first, form))
        env = json.dumps({"files": [{"format": fmt, "text": f["data"].decode("utf-8")} for f in files]},
                         ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        exp = oracle.admit_c(env, [{"rows": f["recs"]} for f in files])
        out.append({"kind": "C", "case_id": "%s-%02d" % (prefix, j), "format": fmt, "data": env,
                    "expected": exp, "defective": dfl,
                    "counts": {"files": nf, "invalid_files": ninv, "invalid_index": inv, "first_cats": firsts,
                               "rows": [f["n"] for f in files], "forms": [f["forms"] for f in files],
                               "form": [f["form"] for f in files]}})
    return out


# ---- independent partition checks (recomputed from bytes, not from generator records) -----

def _profile(fmt, data):
    """(rows, [category per row]) recomputed from bytes by the oracle."""
    rows = oracle.raw_rows(fmt, data)
    return len(rows), [oracle.classify(fmt, r)[0] for r in rows]


def _is_noncanonical_everywhere(fmt, data):
    return fmt == "csv" or not oracle.is_canonical_json(data)


def _file_units(cases):
    """Yield (case, fmt, data, form) for every source file in the partition (R: the case; C: each file)."""
    for c in cases:
        if c["kind"] == "R":
            yield c, c["format"], c["data"]
        else:
            for fmt, data in oracle.decode_envelope(c["data"]):
                yield c, fmt, data


def check_partition(cases, per, rows_range, files_range=None, rate=None, inv_frac=None, min_share=False):
    """Assert the protocol section 5 properties; returns a stats dict.

    per = valid count per (format) cell; the invalid count per cell is the same.
    """
    kind = cases[0]["kind"]
    tab = Counter((c["format"], c["defective"]) for c in cases)
    assert tab == Counter({("csv", False): per, ("csv", True): per, ("json", False): per, ("json", True): per}), tab
    assert len(cases) == 4 * per
    first_by_fmt = {"csv": Counter(), "json": Counter()}
    inv_units, multi_cat, defective_batches, diff_first_batches = 0, 0, 0, 0
    for c in cases:
        fmt = c["format"]
        if kind == "R":
            assert c["expected"] == oracle.r_from_bytes(fmt, c["data"])
            units = [(fmt, c["data"])]
            assert rows_range[0] <= c["counts"]["rows"] <= rows_range[1]
        else:
            assert c["expected"] == oracle.c_from_envelope(c["data"])
            oracle.check_batch_rules(c["data"])
            units = oracle.decode_envelope(c["data"])
            assert files_range[0] <= len(units) <= files_range[1]
        firsts, ninv = [], 0
        for ufmt, data in units:
            assert ufmt == fmt
            n, cl = _profile(ufmt, data)
            oracle.check_source_rules(ufmt, data)
            assert rows_range[0] <= n <= rows_range[1], (c["case_id"], n)
            if ufmt == "json":
                assert not oracle.is_canonical_json(data), c["case_id"]
                assert oracle.json_forms(data), c["case_id"]
            bad = [x for x in cl if x]
            if bad:
                ninv += 1
                inv_units += 1
                assert n >= 2 and 1 <= len(bad) <= n // 2
                if rate:
                    assert rate[0] * n <= len(bad) <= rate[1] * n, (c["case_id"], n, len(bad))
                first_by_fmt[ufmt][bad[0]] += 1
                firsts.append(bad[0])
                multi_cat += len(set(bad)) >= 2
        if kind == "R":
            assert ninv == (1 if c["defective"] else 0)
        else:
            nf = len(units)
            assert (ninv >= 1) == c["defective"]
            if c["defective"]:
                defective_batches += 1
                assert ninv <= nf // 2 and nf - ninv >= 1
                if inv_frac:
                    assert inv_frac[0] * nf <= ninv <= inv_frac[1] * nf, (c["case_id"], nf, ninv)
                diff_first_batches += len(set(firsts)) >= 2 and ninv >= 2
    total_inv = sum(sum(v.values()) for v in first_by_fmt.values())
    for fmt, cnt in first_by_fmt.items():
        for cat in CATS[fmt]:
            assert cnt[cat] >= 1, ("first-failure category missing", fmt, cat, dict(cnt))
            if min_share:
                assert cnt[cat] >= 0.1 * sum(cnt.values()), (fmt, cat, dict(cnt))
    if min_share:
        for cat in range(1, 6):
            assert sum(v[cat] for v in first_by_fmt.values()) >= 0.1 * total_inv, cat
    assert multi_cat >= 0.2 * inv_units, ("multi-category invalid units", multi_cat, inv_units)
    if kind == "C":
        assert diff_first_batches >= 0.2 * defective_batches, (diff_first_batches, defective_batches)
    return {"invalid_units": inv_units, "multi_category_units": multi_cat,
            "first_failure": {f: {str(k): v for k, v in sorted(c.items())} for f, c in first_by_fmt.items()},
            "defective_batches": defective_batches, "batches_with_2plus_distinct_first": diff_first_batches}


# ---- writing ---------------------------------------------------------------------------

def to_line(c):
    rec = {"case_id": c["case_id"], "format": c["format"], "source": base64.b64encode(c["data"]).decode(),
           "expected": c["expected"], "counts": c["counts"]}
    if c["kind"] == "R":
        rec["forms"] = c["forms"]
    return json.dumps(rec, sort_keys=True) + "\n"


def write_jsonl(path, cases):
    blob = "".join(to_line(c) for c in cases)
    with open(path, "w", newline="\n", encoding="utf-8") as f:
        f.write(blob)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


def specs(per):
    return ([("csv", False)] * per + [("csv", True)] * per + [("json", False)] * per + [("json", True)] * per)


def partitions():
    """name -> (cases, check kwargs)."""
    return {
        "f_dev_R": (build_r(SEEDS["f_dev_R"], "devR", STYLE_G7, specs(6)), dict(per=6, rows_range=(1, 30))),
        "f_sel_R": (build_r(SEEDS["f_sel_R"], "selR", STYLE_G7, specs(5)), dict(per=5, rows_range=(1, 30))),
        "f_dev_C": (build_c(SEEDS["f_dev_C"], "devC", STYLE_G7, specs(6)),
                    dict(per=6, rows_range=(3, 15), files_range=(2, 4))),
        "f_sel_C": (build_c(SEEDS["f_sel_C"], "selC", STYLE_G7, specs(5)),
                    dict(per=5, rows_range=(3, 15), files_range=(2, 4))),
    }


if __name__ == "__main__":
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    d = os.path.join(root, "build", "m2", "data")
    os.makedirs(d, exist_ok=True)
    res = {}
    for name, (cs, kw) in partitions().items():
        res[name] = {"sha256": write_jsonl(os.path.join(d, name + ".jsonl"), cs), "cases": len(cs),
                     "seed": SEEDS[name], "stats": check_partition(cs, **kw)}
    print(json.dumps(res, indent=1))
