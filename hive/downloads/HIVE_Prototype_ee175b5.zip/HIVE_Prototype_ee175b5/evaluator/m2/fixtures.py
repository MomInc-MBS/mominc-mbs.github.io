"""Hand-checked validation fixtures for both effects (outside every partition).

R_FIXTURES: (name, format, source bytes, hand-written expected output)
C_FIXTURES: (name, [(format, text), ...], hand-written expected output)
The expected strings are written by hand from protocol section 2; the oracle must reproduce them.
"""
import json

from oracle import ERR, R1, R2, R3, R4, R5

I128, I129 = "a" * 128, "a" * 129
HDR = "id,group,bytes\n"


def ok(t):
    """Wrap the hand-written converted text t into the canonical valid-file output (mechanical escaping)."""
    return '{"converted":"' + t.replace("\\", "\\\\").replace('"', '\\"') + '","quarantined":[]}'


def csvb(*rows):
    return (HDR + "".join(r + "\n" for r in rows)).encode("utf-8")


R_FIXTURES = [
    ("r_csv_valid", "csv", csvb("r1,a,5", "r2,b,0"),
     ok('[{"bytes":5,"group":"a","id":"r1"},{"bytes":0,"group":"b","id":"r2"}]')),
    ("r_json_ws_unsorted_cafe", "json",
     '[ {"id" : "r1", "group": "café", "bytes": 7},\n  {"group":"b","bytes":0,"id":"r2"} ]'.encode("utf-8"),
     ok('[{"bytes":7,"group":"caf\\u00e9","id":"r1"},{"bytes":0,"group":"b","id":"r2"}]')),
    ("r_json_already_canonical", "json", b'[{"bytes":1,"group":"a","id":"r1"}]',
     ok('[{"bytes":1,"group":"a","id":"r1"}]')),
    ("r_csv_bounds_valid", "csv", csvb("r1,a,0", "r2,a,1000000000"),
     ok('[{"bytes":0,"group":"a","id":"r1"},{"bytes":1000000000,"group":"a","id":"r2"}]')),
    ("r_json_bounds_valid", "json", b'[{"id":"r1","group":"a","bytes":0},{"id":"r2","group":"a","bytes":1000000000}]',
     ok('[{"bytes":0,"group":"a","id":"r1"},{"bytes":1000000000,"group":"a","id":"r2"}]')),
    ("r_csv_row_order_kept", "csv", csvb("r3,a,3", "r1,a,1", "r2,a,2"),
     ok('[{"bytes":3,"group":"a","id":"r3"},{"bytes":1,"group":"a","id":"r1"},{"bytes":2,"group":"a","id":"r2"}]')),
    ("r_csv_ascii_escape", "csv", csvb("r1,é,2"), ok('[{"bytes":2,"group":"\\u00e9","id":"r1"}]')),
    ("r_csv_id_128_valid", "csv", csvb(I128 + ",a,1"), ok('[{"bytes":1,"group":"a","id":"%s"}]' % I128)),
    ("r_csv_group_128_valid", "csv", csvb("r1," + I128 + ",1"), ok('[{"bytes":1,"group":"%s","id":"r1"}]' % I128)),
    ("r_json_group_128_valid", "json", ('[{"id":"r1","group":"%s","bytes":1}]' % I128).encode(),
     ok('[{"bytes":1,"group":"%s","id":"r1"}]' % I128)),
    # rejected files
    ("r_csv_over_limit", "csv", csvb("r1,a,5", "r2,a,1000000001"), ERR),
    ("r_csv_leading_zero", "csv", csvb("r1,a,5", "r2,a,01"), ERR),
    ("r_csv_double_zero", "csv", csvb("r1,a,00", "r2,a,5"), ERR),
    ("r_csv_negative", "csv", csvb("r1,a,-1", "r2,a,5"), ERR),
    ("r_csv_plus_and_space", "csv", csvb("r1,a,+5", "r2,a, 5"), ERR),
    ("r_csv_float_text", "csv", csvb("r1,a,1.5", "r2,a,1e3"), ERR),
    ("r_csv_empty_bytes", "csv", csvb("r1,a,", "r2,a,5"), ERR),
    ("r_csv_eleven_digits", "csv", csvb("r1,a,12345678901", "r2,a,5"), ERR),
    ("r_csv_id_129", "csv", csvb(I129 + ",a,1", "r2,a,1"), ERR),
    ("r_csv_group_129", "csv", csvb("r1," + I129 + ",1", "r2,a,1"), ERR),
    ("r_csv_empty_id", "csv", csvb(",a,1", "r2,a,1"), ERR),
    ("r_csv_empty_group", "csv", csvb("r1,,1", "r2,a,1"), ERR),
    ("r_csv_all_invalid", "csv", csvb(",a,5", "r2,,5", "r3,a,01", "r4,a,1000000001"), ERR),
    ("r_csv_first_row_bad_only", "csv", csvb("r1,a,01", "r2,a,5", "r3,a,6"), ERR),
    ("r_csv_last_row_bad_only", "csv", csvb("r1,a,5", "r2,a,6", "r3,a,01"), ERR),
    ("r_csv_precedence_multi_defect", "csv", csvb(",,x", "r2,a,5"), ERR),
    ("r_json_true", "json", b'[{"id":"a","group":"g","bytes":true},{"id":"b","group":"g","bytes":1}]', ERR),
    ("r_json_float_1_0", "json", b'[{"id":"a","group":"g","bytes":1.0},{"id":"b","group":"g","bytes":1}]', ERR),
    ("r_json_string_bytes", "json", b'[{"id":"a","group":"g","bytes":"5"},{"id":"b","group":"g","bytes":1}]', ERR),
    ("r_json_negative", "json", b'[{"id":"a","group":"g","bytes":-1},{"id":"b","group":"g","bytes":1}]', ERR),
    ("r_json_over_limit", "json", b'[{"id":"a","group":"g","bytes":1000000001},{"id":"b","group":"g","bytes":1}]', ERR),
    ("r_json_non_object_row", "json", b'[1,{"id":"b","group":"g","bytes":1}]', ERR),
    ("r_json_missing_key", "json", b'[{"id":"a","group":"g"},{"id":"b","group":"g","bytes":1}]', ERR),
    ("r_json_extra_key", "json", b'[{"id":"a","group":"g","bytes":1,"x":1},{"id":"b","group":"g","bytes":1}]', ERR),
    ("r_json_id_int", "json", b'[{"id":1,"group":"g","bytes":1},{"id":"b","group":"g","bytes":1}]', ERR),
    ("r_json_group_null", "json", b'[{"id":"a","group":null,"bytes":1},{"id":"b","group":"g","bytes":1}]', ERR),
    ("r_json_id_129", "json", ('[{"id":"%s","group":"g","bytes":1},{"id":"b","group":"g","bytes":1}]' % I129).encode(),
     ERR),
]


def _q(i, r):
    return '{"index":%d,"reason":"%s"}' % (i, r)


def _qs(*pairs):
    return ",".join(_q(i, r) for i, r in pairs)


def _rep(groups, quar):
    return '{"groups":{%s},"quarantined":[%s]}' % (groups, quar)


def _jf(*rows):
    """JSON file text from hand-written row texts (non-canonical spacing)."""
    return "[ " + " , ".join(rows) + " ]"


def _row(i, g, b):
    return '{"id":"%s","group":"%s","bytes":%s}' % (i, g, b)


C_FIXTURES = [
    ("c_all_valid_csv", [("csv", HDR + "r1,a,5\nr2,b,1\n"), ("csv", HDR + "r1,a,7\n")],
     _rep('"a":{"bytes":12,"count":2},"b":{"bytes":1,"count":1}', "")),
    ("c_invalid_first_file", [("csv", HDR + "r1,a,5\nr2,a,01\n"), ("csv", HDR + "r1,a,3\n"), ("csv", HDR + "r2,a,4\n")],
     _rep('"a":{"bytes":7,"count":2}', _qs((0, R4)))),
    ("c_invalid_middle_file", [("csv", HDR + "r1,a,1\n"), ("csv", HDR + "r1,a,2\n,a,9\n"), ("csv", HDR + "r1,a,4\n"),
                               ("csv", HDR + "r1,a,8\n")],
     _rep('"a":{"bytes":13,"count":3}', _qs((1, R2)))),
    ("c_invalid_last_file", [("csv", HDR + "r1,a,1\n"), ("csv", HDR + "r1,b,2\n"), ("csv", HDR + "r1,a,5\nr2,,5\n")],
     _rep('"a":{"bytes":1,"count":1},"b":{"bytes":2,"count":1}', _qs((2, R3)))),
    ("c_all_invalid", [("csv", HDR + "r1,a,5\nr2,a,x\n"), ("csv", HDR + ",a,5\nr2,a,5\n"),
                       ("csv", HDR + "r1,a,5\nr2,a,2000000000\n")],
     _rep("", _qs((0, R4), (1, R2), (2, R5)))),
    ("c_first_failing_row_order", [("csv", HDR + "r1,a,2000000000\n,a,5\n"), ("csv", HDR + ",a,5\nr2,a,2000000000\n"),
                                   ("csv", HDR + "r1,c,1\n")],
     _rep('"c":{"bytes":1,"count":1}', _qs((0, R5), (1, R2)))),
    ("c_row_precedence", [("csv", HDR + ",,x\nr2,a,5\n"), ("csv", HDR + "r1,,x\nr2,a,5\n"), ("csv", HDR + "r1,a,x\nr2,a,5\n"),
                          ("csv", HDR + "r1,a,5\n")],
     _rep('"a":{"bytes":5,"count":1}', _qs((0, R2), (1, R3), (2, R4)))),
    ("c_json_every_category", [
        ("json", _jf('[1]', _row("b", "g", 1))),
        ("json", _jf(_row("a", "g", 1), '{"id":"","group":"g","bytes":1}')),
        ("json", _jf('{"id":"a","group":5,"bytes":1}', _row("b", "g", 1))),
        ("json", _jf('{"id":"a","group":"g","bytes":true}', _row("b", "g", 1))),
        ("json", _jf(_row("a", "g", 2), _row("b", "h", 3)))],
     _rep('"g":{"bytes":2,"count":1},"h":{"bytes":3,"count":1}', _qs((0, R1), (1, R2), (2, R3), (3, R5)))),
    ("c_boundaries_csv", [("csv", HDR + "r1,a,0\nr2,a,1000000000\n"), ("csv", HDR + "r1,a,5\nr2,a,1000000001\n"),
                          ("csv", HDR + "r1,a,5\nr2,a,01\n"), ("csv", HDR + I128 + ",a,1\n")],
     _rep('"a":{"bytes":1000000001,"count":3}', _qs((1, R5), (2, R4)))),
    ("c_json_true_and_float", [
        ("json", _jf(_row("a", "g", 1), '{"id":"b","group":"g","bytes":true}')),
        ("json", _jf(_row("a", "g", 1), '{"id":"b","group":"g","bytes":1.0}')),
        ("json", _jf(_row("a", "g", 4)))],
     _rep('"g":{"bytes":4,"count":1}', _qs((0, R5), (1, R5)))),
    ("c_same_ids_across_files", [("csv", HDR + "r1,a,1\nr2,a,2\n"), ("csv", HDR + "r1,a,10\nr2,b,20\n")],
     _rep('"a":{"bytes":13,"count":3},"b":{"bytes":20,"count":1}', "")),
    ("c_ascii_group_escape", [("csv", HDR + "r1,é,2\n"), ("json", _jf(_row("r1", "é", 3)))],
     _rep('"\\u00e9":{"bytes":5,"count":2}', "")),
    ("c_id_group_lengths", [("csv", HDR + I128 + ",a,1\n"), ("csv", HDR + I129 + ",a,1\nr2,a,1\n"),
                            ("csv", HDR + "r1," + I129 + ",1\nr2,a,1\n"), ("csv", HDR + "r1," + I128 + ",2\n")],
     _rep('"a":{"bytes":1,"count":1},"%s":{"bytes":2,"count":1}' % I128, _qs((1, R2), (2, R3)))),
    ("c_mixed_formats_valid", [("csv", HDR + "r1,a,5\n"), ("json", _jf(_row("r1", "a", 6)))],
     _rep('"a":{"bytes":11,"count":2}', "")),
    ("c_json_schema_variants", [
        ("json", _jf('{"id":"a","group":"g"}', _row("b", "g", 1))),
        ("json", _jf('{"id":"a","group":"g","bytes":1,"x":1}', _row("b", "g", 1))),
        ("json", _jf('"x"', _row("b", "g", 1))),
        ("json", _jf(_row("b", "g", 9)))],
     _rep('"g":{"bytes":9,"count":1}', _qs((0, R1), (1, R1), (2, R1)))),
]


def c_envelope(files):
    return json.dumps({"files": [{"format": f, "text": t} for f, t in files]}, ensure_ascii=False,
                      separators=(",", ":")).encode("utf-8")


def r_wrong_outputs():
    """Deliberately wrong outputs (fixture name, output). The oracle must reject each."""
    e = {n: x for n, _, _, x in R_FIXTURES}
    v = e["r_csv_valid"]
    return [
        ("r_csv_valid", v.replace('{\\"bytes\\":5', '{\\"bytes\\": 5')),                       # wrong converted text (spacing)
        ("r_csv_valid", v.replace('\\"bytes\\":5', '\\"bytes\\":\\"5\\"')),                    # CSV integer left as a string
        ("r_csv_valid", v.replace('[{', '[{\\"x\\":1},{', 1)),                                   # extra row
        ("r_csv_valid", ok('[{"bytes":5,"group":"a","id":"r1"}]')),                             # dropped row
        ("r_csv_valid", ok('[{"bytes":0,"group":"b","id":"r2"},{"bytes":5,"group":"a","id":"r1"}]')),  # reordered rows
        ("r_csv_valid", '{"converted":[{"bytes":5,"group":"a","id":"r1"},{"bytes":0,"group":"b","id":"r2"}],"quarantined":[]}'),
        ("r_csv_valid", ERR),                                                                    # valid file rejected
        ("r_csv_valid", csvb("r1,a,5", "r2,b,0").decode()),                                      # identity output
        ("r_csv_over_limit", ok('[{"bytes":5,"group":"a","id":"r1"}]')),                         # row-quarantine variant
        ("r_csv_over_limit", '{"converted":"[]","quarantined":[{"index":1,"reason":"%s"}]}' % R5),
        ("r_csv_leading_zero", '{"error":"source_rejected","reason":"%s"}' % R4),               # reason is not part of the output
        ("r_csv_leading_zero", ok('[{"bytes":5,"group":"a","id":"r1"},{"bytes":1,"group":"a","id":"r2"}]')),  # invalid converted
        ("r_json_ws_unsorted_cafe", ok('[{"bytes":7,"group":"caf\\u00e9","id":"r1"},{"bytes":0,"group":"b","id":"r2"}]')
         .replace("\\\\u00e9", "é")),                                                        # literal non-ASCII in text
        ("r_json_ws_unsorted_cafe", ok('[{"id":"r1","group":"caf\\u00e9","bytes":7},{"id":"r2","group":"b","bytes":0}]')),  # unsorted keys
        ("r_json_already_canonical", '[{"bytes":1,"group":"a","id":"r1"}]'),                    # bare canonical bytes, not wrapped
        ("r_json_true", '{"converted":"[]","quarantined":[]}'),
    ]


def c_wrong_outputs():
    e = {n: x for n, _, x in C_FIXTURES}
    return [
        ("c_boundaries_csv", e["c_boundaries_csv"].replace(R5, R4, 1)),                          # wrong reason
        ("c_invalid_middle_file", e["c_invalid_middle_file"].replace('"index":1', '"index":2')),  # wrong index
        ("c_invalid_middle_file", e["c_invalid_middle_file"].replace('"index":1', '"index":0')),
        ("c_invalid_first_file", e["c_invalid_first_file"].replace('"index":0', '"index":1')),   # 1-based style
        ("c_all_invalid", e["c_all_invalid"].replace("," + _q(2, R5), "")),                      # dropped file
        ("c_all_valid_csv", e["c_all_valid_csv"].replace('"bytes":12', '"bytes":13')),            # wrong sum
        ("c_all_valid_csv", e["c_all_valid_csv"].replace('"count":2', '"count":3', 1)),           # wrong count
        ("c_all_valid_csv", e["c_all_valid_csv"].replace(",", ", ")),                            # non-canonical text
        ("c_invalid_first_file", _rep('"a":{"bytes":12,"count":3}', _qs((0, R4)))),               # invalid file's valid row kept
        ("c_invalid_first_file", _rep('"a":{"bytes":7,"count":2}', "")),                         # quarantine omitted
        ("c_first_failing_row_order", e["c_first_failing_row_order"].replace(R5, R2, 1)),        # lowest-priority-first reason
        ("c_first_failing_row_order", _rep('"c":{"bytes":1,"count":1}', _qs((0, R2), (1, R2)))), # wrong first-failing reason
        ("c_row_precedence", e["c_row_precedence"].replace(R2, R3, 1)),                           # wrong precedence
        ("c_all_valid_csv", '{"error":"source_rejected"}'),                                      # whole-batch failure
        ("c_invalid_last_file", e["c_invalid_last_file"].replace('"quarantined":[', '"quarantined":[{"index":0,"reason":"%s"},' % R3)),
    ]
