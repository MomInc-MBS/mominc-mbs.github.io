"""Coop pilot coverage (EVALUATOR-ONLY; run AFTER the pilot, never during it, never from the runtime).

  python evaluator/coop/coverage.py --rows PILOT/rows.jsonl --out EVALUATOR_PRIVATE_DIR

For every pilot run row, judges EVERY distinct candidate body (discovery/<exp>/cand-<sha>.py) on that experiment's sealed hidden set with the existing
evaluator (hive.discovery._evaluate, i.e. evaluator/g2/evaluate.py launched exactly as the runtime launches it), and writes ONLY under --out:
  <out>/<run>/<exp>/receipt-candidate-*.json   the evaluator receipts
  <out>/coverage.jsonl                         per run: any_candidate_passes (coverage), selected_passes, per-candidate hidden pass counts
Refuses an --out inside any store, the inputs root, the runtime's private/allowed roots or the repo's .hive folder. The hidden numbers it produces must not be fed back to a proposer."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))
from hive import discovery as D  # noqa: E402
from hive.storage import Store  # noqa: E402


def inside(p, q):
    return Path(p).resolve() == Path(q).resolve() or Path(p).resolve().is_relative_to(Path(q).resolve())


def judge_run(row, out):
    res = {"run": row["run"], "cap": row["cap"], "recipe": row["recipe"], "repeat": row["repeat"], "state": row["state"], "candidates": []}
    for exp_id in row.get("exp_ids", []):
        s = Store(row["store"])
        try:
            rec = s.get(D.KEY + exp_id)
        finally:
            s.close()
        sel = (rec.get("coop") or {}).get("selected") or rec.get("candidate_sha256") or next((p["sha256"] for p in rec["proposals"] if p.get("acceptance")), None)
        (out / row["run"] / exp_id).mkdir(parents=True, exist_ok=True)
        for body in sorted((Path(row["store"]) / "discovery" / exp_id).glob("cand-*.py")):
            sha = body.stem[len("cand-"):]
            c = {"exp_id": exp_id, "sha256": sha, "selected": sha == sel, "pass_count": None, "n": None, "error": None}
            try:
                r, _ = D._evaluate(rec, out / row["run"] / exp_id, body, "candidate", row["private"])
                c.update(pass_count=r["pass_count"], n=r["n"])
            except Exception as e:  # one unjudgeable candidate must not hide the others
                c["error"] = f"{type(e).__name__}: {str(e)[:200]}"
            res["candidates"].append(c)
    ok = [c for c in res["candidates"] if c["pass_count"] is not None]
    res.update(any_candidate_passes=any(c["pass_count"] == c["n"] for c in ok), selected_passes=any(c["selected"] and c["pass_count"] == c["n"] for c in ok))
    return res


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--rows", required=True, help="the pilot's rows.jsonl")
    ap.add_argument("--out", required=True, help="evaluator-private output dir (outside every store and the runtime's allowed roots)")
    a = ap.parse_args(argv)
    rows = [json.loads(x) for x in Path(a.rows).read_text(encoding="utf-8").splitlines() if x.strip()]
    out = Path(a.out).resolve()
    forbidden = [D.PRIVATE, ROOT / ".hive"] + [r[k] for r in rows for k in ("store", "inputs_root") if r.get(k)]
    if any(inside(out, f) or inside(f, out) for f in forbidden):
        raise SystemExit(f"refusing --out {out}: it must not be inside (or contain) a store, the inputs root, or the runtime's private/allowed roots")
    out.mkdir(parents=True, exist_ok=True)
    with open(out / "coverage.jsonl", "a", encoding="utf-8", newline="\n") as f:
        for row in rows:
            res = judge_run(row, out) if row.get("exp_ids") else {"run": row["run"], "cap": row["cap"], "recipe": row["recipe"], "repeat": row["repeat"], "state": row["state"], "candidates": [],
                                                                   "any_candidate_passes": None, "selected_passes": None}
            f.write(json.dumps(res, sort_keys=True) + "\n")
            f.flush()
            print(res["run"], "coverage", res["any_candidate_passes"], "selected", res["selected_passes"], flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
