"""Sealed-final scoring for the public_feedback_sealed_final_v1 policy (EVALUATOR-ONLY; never imported by the runtime, run as its own process).

  python -I evaluator/coop/sealed_final.py prepare --block ID --cap CAP --private DIR [--seed N]   -> {"manifest_id", "manifest_sha256", ...}  (BEFORE any generation)
  python -I evaluator/coop/sealed_final.py score   --batch BATCH.json --private DIR --public-out FILE                                       (AFTER every final receipt exists)

prepare builds ONE hidden fixture set per capability x repeat block from the capability's own private generator, under DIR/<block>/ (contents stay there; only an opaque id and
the manifest sha256 come back). The seed derives from the block id and capability only (never an exp_id) and is above every proposer / pilot seed. A block is prepared once:
asking again returns the same public identity and never regenerates.
score refuses until EVERY campaign in the batch has a frozen final receipt (or is declared incomplete), whose sha256 matches the batch's and whose manifest matches the block's.
It then scores at most ONE final per campaign against its block manifest (both backends of a block see the identical manifest hash), and only afterwards judges every distinct candidate
(coverage). Hidden numbers go only under DIR/_results/; the public file has pass/fail counts and manifest hashes only. It never calls a model and never replaces a candidate."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))
from hive import capcontract as CC, discovery as D  # noqa: E402
from hive.bounded import run_bounded  # noqa: E402
from hive.storage import Store  # noqa: E402

POLICY = D.SEALED
SEED_FLOOR = 7_000_000_000  # above every proposer seed (2026300000 + seed_base + ...) and campaign seed_base (10000 * repeat)
SEED_CEIL = 2 ** 62


def sha(x):
    return hashlib.sha256(x if isinstance(x, bytes) else str(x).encode("utf-8")).hexdigest()


def canon(o):
    return json.dumps(o, sort_keys=True, separators=(",", ":"))


def derive_seed(block_id, cap):
    return SEED_FLOOR + int(sha(f"{POLICY}|seed|{block_id}|{cap}")[:8], 16)


def manifest_sha(m):
    return sha(canon({k: m[k] for k in ("block_id", "cap", "set_sha256", "n", "contract_sha256")}))


def public(m):
    return {"manifest_id": "m-" + m["manifest_sha256"][:16], "manifest_sha256": m["manifest_sha256"], "block_id": m["block_id"], "cap": m["cap"]}


def prepare(block_id, cap, seed, private_dir):
    """One hidden fixture/expectation set for the block, from the capability's existing private generator. -> public identity (id + sha256)."""
    if not block_id or any(ch in block_id for ch in "/\\:") or block_id in (".", "..", "_results"):
        raise SystemExit(f"bad block id {block_id!r}")
    d = Path(private_dir) / block_id
    if (d / "manifest.json").is_file():  # one manifest per block: never regenerated, never replaced
        m = json.loads((d / "manifest.json").read_text(encoding="utf-8"))
        if m["cap"] != cap or manifest_sha(m) != m["manifest_sha256"]:
            raise SystemExit(f"block {block_id!r} is already prepared for another capability or its manifest was altered")
        return public(m)
    c = CC.get(cap)
    seed = derive_seed(block_id, cap) if seed is None else int(seed)
    if not SEED_FLOOR <= seed < SEED_CEIL:
        raise SystemExit(f"seed must be in [{SEED_FLOOR}, 2**62): lower values collide with the proposer / pilot seeds")
    rc, out, _, timed_out = run_bounded([sys.executable, "-I", str(CC.ROOT / c["verification"]["gen_private"]), "--out", str(d), "--seed", str(seed)], timeout=120)
    if rc or timed_out:
        raise SystemExit("the hidden fixture generator failed")
    acc = json.loads(out.strip().splitlines()[-1])
    m = {"block_id": block_id, "cap": cap, "set_sha256": acc["set_sha256"], "n": acc["n"], "contract_sha256": CC.sha(c)}
    m["manifest_sha256"], m["seed_sha256"], m["prepared_at"] = manifest_sha(m), sha(seed), time.strftime("%Y-%m-%dT%H:%M:%S%z")
    (d / "manifest.json").write_text(json.dumps(m, sort_keys=True, indent=1), encoding="utf-8", newline="\n")
    return public(m)


def _inside(p, q):
    p, q = Path(p).resolve(), Path(q).resolve()
    return p == q or p.is_relative_to(q)


def _receipt_path(store, cap):
    return Path(store) / "campaign" / cap / "final-receipt.json"


def _eval(store, receipt, private_block, man, body, label, outdir):
    """One independent evaluation through the existing discovery evaluator launch, on the BLOCK's manifest (never the experiment's own)."""
    s = Store(store)
    try:
        rec = s.get(D.KEY + receipt["exp_id"])
    finally:
        s.close()
    rec = dict(rec, frozen=dict(rec["frozen"], acceptance={"set_sha256": man["set_sha256"], "n": man["n"]}))
    Path(outdir).mkdir(parents=True, exist_ok=True)
    r, _ = D._evaluate(rec, outdir, body, label, private_block)
    return {"pass_count": r["pass_count"], "n": r["n"], "verdict": r["verdict"], "receipt_sha256": r["receipt_sha256"], "run_error": r["run_error"]}


def check_batch(batch, private_dir):
    """Every reason scoring must be refused (empty = every campaign is frozen and consistent). Nothing is scored by this."""
    bad, mans = [], {}
    for c in batch["campaigns"]:
        cid = c["campaign_id"]
        try:
            m = json.loads((Path(private_dir) / c["block_id"] / "manifest.json").read_text(encoding="utf-8"))
            if manifest_sha(m) != m["manifest_sha256"]:
                raise ValueError("altered")
            mans[c["block_id"]] = m
        except (OSError, ValueError, KeyError):
            bad.append(f"{cid}: block manifest missing or altered")
            continue
        if c.get("status") == "incomplete":
            continue
        rp = _receipt_path(c["store"], c["cap"])
        try:
            r = json.loads(rp.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            bad.append(f"{cid}: no frozen final receipt")
            continue
        if r.get("receipt_sha256") != sha(canon({k: v for k, v in r.items() if k != "receipt_sha256"})) or r["receipt_sha256"] != c.get("receipt_sha256"):
            bad.append(f"{cid}: receipt sha256 differs from the recorded one")
        if (r.get("manifest") or {}).get("sha256") != mans[c["block_id"]]["manifest_sha256"]:
            bad.append(f"{cid}: receipt was frozen against another manifest")
    return bad, mans


def score(batch_path, private_dir, public_out, coverage=True):
    batch = json.loads(Path(batch_path).read_text(encoding="utf-8"))
    private, res = Path(private_dir), Path(private_dir) / "_results"
    if _inside(public_out, private) or any(_inside(public_out, c["store"]) for c in batch["campaigns"]):
        raise SystemExit("refusing --public-out inside the private dir or a store")
    bad, mans = check_batch(batch, private)
    if bad:
        raise SystemExit("refused: " + "; ".join(bad))
    res.mkdir(parents=True, exist_ok=True)
    outcome = {}
    for c in batch["campaigns"]:  # 1. ONE final per campaign
        cid, done = c["campaign_id"], res / c["campaign_id"] / "final.json"
        if c.get("status") == "incomplete":
            outcome[cid] = "INCOMPLETE"
            continue
        r = json.loads(_receipt_path(c["store"], c["cap"]).read_text(encoding="utf-8"))
        if done.is_file():  # scored already: never scored twice
            outcome[cid] = json.loads(done.read_text(encoding="utf-8"))["outcome"]
            continue
        if r["final_sha256"] is None:
            row = {"outcome": "UNRESOLVED"}
        else:
            body = Path(c["store"]) / r["body_path"]
            if D._sha(D._read_lf(body)) != r["final_sha256"]:
                raise SystemExit(f"{cid}: the frozen final body no longer matches its receipt")
            g = _eval(c["store"], r, private / c["block_id"], mans[c["block_id"]], body, "sealed_final", res / cid)
            row = {"outcome": "PASS" if g["verdict"] == "PASS" else "FAIL", **g}
        row.update(campaign_id=cid, receipt_sha256=r["receipt_sha256"], finalized_at=r["finalized_at"], scored_at=time.strftime("%Y-%m-%dT%H:%M:%S%z"))
        (res / cid).mkdir(parents=True, exist_ok=True)
        done.write_text(json.dumps(row, sort_keys=True, indent=1), encoding="utf-8", newline="\n")
        outcome[cid] = row["outcome"]
    if coverage:  # 2. only now: every distinct candidate of every campaign, privately
        with open(res / "coverage.jsonl", "a", encoding="utf-8", newline="\n") as f:
            for c in batch["campaigns"]:
                if c.get("status") == "incomplete":
                    continue
                r = json.loads(_receipt_path(c["store"], c["cap"]).read_text(encoding="utf-8"))
                for exp in r["experiments"]:
                    for body in sorted((Path(c["store"]) / "discovery" / exp).glob("cand-*.py")):
                        row = {"campaign_id": c["campaign_id"], "exp_id": exp, "sha256": body.stem[5:], "final": body.stem[5:] == r["final_sha256"]}
                        try:
                            row.update(_eval(c["store"], dict(r, exp_id=exp), private / c["block_id"], mans[c["block_id"]], body, "coverage", res / c["campaign_id"] / exp))
                        except Exception as e:  # one unjudgeable candidate must not hide the others
                            row["error"] = f"{type(e).__name__}: {str(e)[:200]}"
                        f.write(json.dumps(row, sort_keys=True) + "\n")
    by = {}  # 3. the public aggregate: pass/fail counts and manifest hashes only
    for c in batch["campaigns"]:
        t = by.setdefault(c["backend"], {"pass": 0, "fail": 0, "incomplete": 0})
        o = outcome[c["campaign_id"]]
        t["pass" if o == "PASS" else "incomplete" if o == "INCOMPLETE" else "fail"] += 1
    blocks = {}
    for c in batch["campaigns"]:
        b = blocks.setdefault(c["block_id"], {"block_id": c["block_id"], "cap": c["cap"], "manifest_sha256": mans[c["block_id"]]["manifest_sha256"], "results": {}})
        b["results"][c["backend"]] = outcome[c["campaign_id"]]
    pub = {"schema": "hive-sealed-final-public-v1", "policy": POLICY, "batch_id": batch.get("batch_id"), "by_backend": by, "blocks": list(blocks.values())}
    Path(public_out).parent.mkdir(parents=True, exist_ok=True)
    Path(public_out).write_text(json.dumps(pub, sort_keys=True, indent=1), encoding="utf-8", newline="\n")
    return pub


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("--block", required=True)
    p.add_argument("--cap", required=True)
    p.add_argument("--private", required=True)
    p.add_argument("--seed", type=int)
    q = sub.add_parser("score")
    q.add_argument("--batch", required=True)
    q.add_argument("--private", required=True)
    q.add_argument("--public-out", required=True)
    q.add_argument("--no-coverage", action="store_true")
    a = ap.parse_args(argv)
    print(json.dumps(prepare(a.block, a.cap, a.seed, a.private) if a.cmd == "prepare" else score(a.batch, a.private, a.public_out, not a.no_coverage), sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
