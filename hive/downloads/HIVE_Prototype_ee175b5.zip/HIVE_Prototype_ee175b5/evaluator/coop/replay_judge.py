"""Replay judge (EVALUATOR-ONLY, private-label side): reads the FROZEN build/coop/replay/selections.json plus the private coverage records and writes
build/coop/replay/judged.json and REPLAY_REPORT.md (public aggregates only: no hidden cases, answers or per-candidate scores). Refuses if selections.json
no longer matches the sha256 recorded when it was frozen.

  python evaluator/coop/replay_judge.py [--private-root C:/hive-work/eval-private]"""
import argparse
import collections
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPLAY = ROOT / "build" / "coop" / "replay"
BATCH_COV = {"57f6a94": "coop-cov-57f6a94", "04fe137": "coop-cov-04fe137", "c3x-fbc2ddb": "coop-cov-c3x-fbc2ddb"}
KNOWN = {("57f6a94", "site.ref-resolve.diverse3.r3"), ("c3x-fbc2ddb", "site.ref-check.maskrand3.r6")}
VARS = ["S0", "S1", "S2", "S3"]


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--private-root", default="C:/hive-work/eval-private")
    a = ap.parse_args(argv)
    raw = (REPLAY / "selections.json").read_bytes()
    if hashlib.sha256(raw).hexdigest() != (REPLAY / "selections.sha256").read_text(encoding="utf-8").strip():
        raise SystemExit("refusing: selections.json changed after it was frozen (sha256 mismatch)")
    sel = json.loads(raw)
    label = {}  # (batch, run, exp, sha) -> correct
    for b, d in BATCH_COV.items():
        for line in (Path(a.private_root) / d / "coverage.jsonl").read_text(encoding="utf-8").splitlines():
            if line.strip():
                r = json.loads(line)
                for c in r["candidates"]:
                    label[(b, r["run"], c["exp_id"], c["sha256"])] = c["pass_count"] is not None and c["pass_count"] == c["n"]
    agg = {v: collections.Counter() for v in VARS}
    loss_pools, known = [], {k: {v: [0, 0] for v in VARS} for k in KNOWN}  # known losses: [loss pools, recovered]
    for p in sel["pools"]:
        key = (p["batch"], p["run"], p["exp_id"])
        correct = {h for h in p["eligible"] if label.get((*key, h))}
        has = bool(correct)
        s0_ok = p["S0"]["selected"] in correct
        for v in VARS:
            s, c = p[v]["selected"], agg[v]
            ok = s in correct
            c["pools"] += 1
            c["no_correct_candidate"] += not has
            c["correct"] += ok
            c["loss_pools"] += has and not s0_ok  # S0 lost although a correct candidate existed
            c["recovered"] += has and not s0_ok and ok
            c["unresolved"] += has and not s0_ok and not ok
            c["regressions"] += s0_ok and not ok
            c["ineligible_winners"] += bool(s is not None and (s not in p["eligible"] or (p["dev_pass_shas"] and s not in p["dev_pass_shas"])))
            if (p["batch"], p["run"]) in KNOWN and has and not s0_ok:
                known[(p["batch"], p["run"])][v][0] += 1
                known[(p["batch"], p["run"])][v][1] += ok
        if has and not s0_ok:
            loss_pools.append(key[:2])
    out = {"selections_sha256": hashlib.sha256(raw).hexdigest(), "pools": len(sel["pools"]), "incumbent_not_applicable": sel["incumbent_experiments_not_applicable"],
           "container_runs": sel["container_runs"], "hive_model_calls": sel["hive_model_calls"], "variants": {}}
    for v in VARS:
        c = agg[v]
        both = all(k[v][0] > 0 and k[v][0] == k[v][1] for k in known.values())
        out["variants"][v] = dict(c, version=sel["variants"][v], known_losses_recovered=both,
                                  gate_pass=bool(v != "S0" and both and c["regressions"] == 0 and c["ineligible_winners"] == 0))
    out["known_losses"] = {f"{b}/{r}": {v: {"loss_pools": k[v][0], "recovered": k[v][1]} for v in VARS} for (b, r), k in known.items()}
    out["s0_loss_pool_runs"] = sorted({f"{b}/{r}" for b, r in loss_pools})
    passing = [v for v in VARS[1:] if out["variants"][v]["gate_pass"]]
    out["minimal_passing_variant"] = passing[0] if passing else "none: keep S0"
    (REPLAY / "judged.json").write_text(json.dumps(out, indent=1, sort_keys=True) + "\n", encoding="utf-8", newline="\n")
    cols = ["pools", "correct", "loss_pools", "recovered", "unresolved", "regressions", "no_correct_candidate", "ineligible_winners"]
    md = ["# Coop selector replay report (development evidence)", "",
          f"selections.json sha256 `{out['selections_sha256']}`; {out['pools']} coop pools ({out['incumbent_not_applicable']} incumbent experiments not applicable); "
          f"container runs {out['container_runs']} (cap {sel['container_run_cap']}); HIVE model calls {out['hive_model_calls']}.", "",
          "| variant | " + " | ".join(cols) + " | known 2 losses recovered | repair gate |", "|---|" + "---|" * (len(cols) + 2)]
    for v in VARS:
        d = out["variants"][v]
        md.append(f"| {v} ({d['version']}) | " + " | ".join(str(d[x]) for x in cols) + f" | {d['known_losses_recovered']} | {'PASS' if d['gate_pass'] else 'no'} |")
    md += ["", "Known losses (loss pools in that campaign / recovered), per variant:"]
    md += [f"- {k}: " + ", ".join(f"{v} {x['loss_pools']}/{x['recovered']}" for v, x in d.items()) for k, d in out["known_losses"].items()]
    md += ["", f"Campaigns with an S0 loss pool: {', '.join(out['s0_loss_pool_runs']) or 'none'}", "", f"Minimal passing variant: **{out['minimal_passing_variant']}**", ""]
    (REPLAY / "REPLAY_REPORT.md").write_text("\n".join(md), encoding="utf-8", newline="\n")
    print("\n".join(md))
    return 0


if __name__ == "__main__":
    sys.exit(main())
