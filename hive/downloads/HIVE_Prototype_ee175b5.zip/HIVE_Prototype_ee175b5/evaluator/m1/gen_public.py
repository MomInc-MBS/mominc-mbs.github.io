"""M1 data generator core + public partitions F-dev (G1-G2) and F-sel (G3).

F-sel is score-only for the proposer; its expected outputs are written here
(the proposer is a deterministic enumerator, so it cannot learn from them).
"""
import base64
import csv
import hashlib
import io
import json
import os
import random
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import oracle  # noqa: E402

# Category 1 / 4 weighted up so every applicable category stays >= 10% of defective rows.
CYCLES = {"json": [1, 2, 3, 5, 1], "csv": [4, 2, 3, 5, 4]}
CSV_BAD_BYTES = ["01", "-1", "1.5", "abc", "", "12345678901", " 5", "1e3", "+5", "00", "0x10"]
JSON_BAD_BYTES = [True, False, 1.0, 2.5, "5", -1, 10**9 + 1, 10**12, None]

VOCAB_A = ["media", "docs", "logs", "cache", "builds", "backups", "mail", "photos", "café"]
STYLE_A = dict(groups=VOCAB_A, idf=lambda i: "row-%04d" % i, n=(3, 30), rate=None, shuffle=False)


def _pad(s, n):
    return s + "z" * (n - len(s)) if len(s) < n else s


def _bad_name(rng, base, used_empty):
    if not used_empty[0] and rng.random() < 0.5:
        used_empty[0] = True
        return ""
    return _pad(base, 129 + rng.randint(0, 20))


def make_case(rng, fmt, defective, style, ptr):
    lo, hi = style["n"]
    n = rng.randint(max(lo, 2 if defective else 1), hi)
    bad = {}
    if defective:
        rate = style["rate"]
        klo = max(1, -(-int(rate[0] * 100) * n // 100)) if rate else 1
        khi = min(n // 2, int(n * rate[1]) if rate else n // 2)
        for idx in rng.sample(range(n), rng.randint(klo, max(klo, khi))):
            cyc = CYCLES[fmt]
            bad[idx] = cyc[ptr[fmt] % len(cyc)]
            ptr[fmt] += 1
    used_id, used_grp = [False], [False]
    recs, vals = [], []
    for i in range(n):
        g, sid, b = rng.choice(style["groups"]), style["idf"](i), None
        if rng.random() < 0.05:
            sid = _pad(sid, 128)  # valid boundary id
        b = rng.choice([0, 10**9, rng.randint(1, 5000), rng.randint(1, 10**9)])
        cat = bad.get(i, 0)
        extra = rng.random() < 0.35  # also break lower-priority fields, to exercise precedence
        gid, gg, bb = sid, g, (str(b) if fmt == "csv" else b)
        if cat == 1:
            kind = rng.choice(["scalar", "list", "null", "missing", "extra", "rename"])
            out = {"scalar": 7, "list": [sid, g, b], "null": None,
                   "missing": {"id": sid, "group": g},
                   "extra": {"id": sid, "group": g, "bytes": b, "note": "x"},
                   "rename": {"id": sid, "grp": g, "bytes": b}}[kind]
        else:
            if cat == 2:
                gid = _bad_name(rng, sid, used_id) if fmt == "csv" else rng.choice(
                    [_bad_name(rng, sid, used_id), None, 5, [1]])
            if cat == 3 or (cat == 2 and extra):
                gg = _bad_name(rng, g, used_grp) if fmt == "csv" or rng.random() < 0.6 else rng.choice([None, 3, ["a"]])
            if cat == 4 or (fmt == "csv" and cat in (2, 3) and extra):
                bb = rng.choice(CSV_BAD_BYTES)
            elif fmt == "csv" and cat == 5:
                bb = str(rng.choice([10**9 + 1, 9999999999, rng.randint(10**9 + 1, 9999999999)]))
            elif fmt == "json" and (cat == 5 or (cat in (2, 3) and extra)):
                bb = rng.choice(JSON_BAD_BYTES)
            out = [gid, gg, bb] if fmt == "csv" else {"id": gid, "group": gg, "bytes": bb}
            if fmt == "json" and style["shuffle"]:
                ks = list(out)
                rng.shuffle(ks)
                out = {k: out[k] for k in ks}
        vals.append(out)
        recs.append({"cat": cat, "group": g if cat == 0 else None, "bytes": b if cat == 0 else None})
    if fmt == "csv":
        buf = io.StringIO(newline="")
        w = csv.writer(buf, lineterminator="\n")
        w.writerow(["id", "group", "bytes"])
        w.writerows(vals)
        data = buf.getvalue().encode("utf-8")
    else:
        data = json.dumps(vals, ensure_ascii=False).encode("utf-8")
    exp = oracle.admit(fmt, data, recs)
    cats = {}
    for r in recs:
        if r["cat"]:
            cats[str(r["cat"])] = cats.get(str(r["cat"]), 0) + 1
    return {"format": fmt, "data": data, "expected": exp, "defective": defective,
            "counts": {"rows": n, "defective": sum(cats.values()), "cats": cats}}


def build_partition(seed, prefix, specs, style_for):
    """specs: list of (fmt, defective)."""
    rng = random.Random(seed)
    order = list(specs)
    rng.shuffle(order)
    ptr = {"csv": 0, "json": 0}
    out = []
    for j, (fmt, dfl) in enumerate(order):
        c = make_case(rng, fmt, dfl, style_for(fmt), ptr)
        c["case_id"] = "%s-%02d" % (prefix, j)
        out.append(c)
    return out


def check_balance(cases):
    tot = {}
    for c in cases:
        for k, v in c["counts"]["cats"].items():
            tot[k] = tot.get(k, 0) + v
    d = sum(tot.values())
    fmts = {c["format"] for c in cases if c["defective"]}
    need = {"2", "3", "5"} | ({"1"} if "json" in fmts else set()) | ({"4"} if "csv" in fmts else set())
    for k in need:
        assert tot.get(k, 0) >= 0.1 * d, ("category share", k, tot, d)
    for c in cases:
        n, dd = c["counts"]["rows"], c["counts"]["defective"]
        ok = (n >= 2 and 1 <= dd <= n * 0.5) if c["defective"] else (dd == 0 and 1 <= n <= 60)
        assert ok, c["case_id"]
    return dict(sorted(tot.items()))


def to_line(c):
    return json.dumps({"case_id": c["case_id"], "format": c["format"],
                       "source": base64.b64encode(c["data"]).decode(),
                       "expected": c["expected"], "counts": c["counts"]}, sort_keys=True) + "\n"


def write_jsonl(path, cases):
    blob = "".join(to_line(c) for c in cases)
    with open(path, "w", newline="\n", encoding="utf-8") as f:
        f.write(blob)
    return hashlib.sha256(blob.encode()).hexdigest()


def log_exposure(path, partition, action, count, purpose):
    with open(path, "a", newline="\n", encoding="utf-8") as f:
        f.write(json.dumps({"ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "who": "evaluator",
                            "partition": partition, "action": action, "count": count, "purpose": purpose}) + "\n")


SEEDS = {"f_dev": 710001, "f_sel": 710002}


def f_dev():
    return build_partition(SEEDS["f_dev"], "dev", [("csv", d) for d in [False] * 6 + [True] * 18], lambda f: STYLE_A)


def f_sel():
    return build_partition(SEEDS["f_sel"], "sel", [("json", d) for d in [False] * 4 + [True] * 16], lambda f: STYLE_A)


if __name__ == "__main__":
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
    d = os.path.join(root, "build", "m1", "data")
    os.makedirs(d, exist_ok=True)
    res = {}
    for name, fn in (("f_dev", f_dev), ("f_sel", f_sel)):
        cs = fn()
        res[name] = {"sha256": write_jsonl(os.path.join(d, name + ".jsonl"), cs), "cases": len(cs),
                     "categories": check_balance(cs), "seed": SEEDS[name]}
    print(json.dumps(res, indent=1))
