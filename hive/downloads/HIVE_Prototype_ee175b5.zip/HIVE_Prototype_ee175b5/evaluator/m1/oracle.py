"""M1 oracle, written from docs/M1_PROTOCOL.md section 2 only. Stdlib only."""
import csv
import io
import json

R1 = "source row does not match the pinned schema"
R2 = "row IDs must be unique nonempty strings of at most 128 characters"
R3 = "inventory groups must be nonempty strings of at most 128 characters"
R4 = "bytes must be a canonical nonnegative decimal integer"
R5 = "bytes must be an integer between 0 and 1,000,000,000"
REASON = {1: R1, 2: R2, 3: R3, 4: R4, 5: R5}
LIMIT = 10**9


def canonical(groups, quarantined):
    return json.dumps({"groups": groups, "quarantined": quarantined},
                      sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def _is_csv_canon(s):
    if s == "0":
        return True
    return 1 <= len(s) <= 10 and s[0] in "123456789" and all(c in "0123456789" for c in s)


def _name_ok(v):
    return isinstance(v, str) and 0 < len(v) <= 128


def _classify(fmt, row):
    """Return (cat, group, bytes): cat 0 means valid."""
    if fmt == "json":
        if not isinstance(row, dict) or set(row) != {"id", "group", "bytes"}:
            return 1, None, None
        i, g, b = row["id"], row["group"], row["bytes"]
    else:
        i, g, b = row
    if not _name_ok(i):
        return 2, None, None
    if not _name_ok(g):
        return 3, None, None
    if fmt == "csv":
        if not _is_csv_canon(b):
            return 4, None, None
        b = int(b)
    if type(b) is not int or not 0 <= b <= LIMIT:
        return 5, None, None
    return 0, g, b


def _rows_from_bytes(fmt, data):
    if data.startswith(b"\xef\xbb\xbf"):
        raise ValueError("bom")
    text = data.decode("utf-8")
    if fmt == "csv":
        rows = list(csv.reader(io.StringIO(text, newline="")))
        if not rows or rows[0] != ["id", "group", "bytes"]:
            raise ValueError("header")
        return rows[1:]

    def no_dups(pairs):
        d = {}
        for k, v in pairs:
            if k in d:
                raise ValueError("dup key")
            d[k] = v
        return d

    def bad(c):
        raise ValueError("non-finite")

    rows = json.loads(text, object_pairs_hook=no_dups, parse_constant=bad)
    if not isinstance(rows, list):
        raise ValueError("not array")
    return rows


def derive_from_bytes(fmt, data):
    """Independent re-derivation of the canonical output from source bytes."""
    groups, quarantined = {}, []
    for idx, row in enumerate(_rows_from_bytes(fmt, data)):
        cat, g, b = _classify(fmt, row)
        if cat:
            quarantined.append({"index": idx, "reason": REASON[cat]})
        else:
            e = groups.setdefault(g, {"bytes": 0, "count": 0})
            e["bytes"] += b
            e["count"] += 1
    return canonical(groups, quarantined)


def expected_from_record(rows):
    """rows: generator record, list of {"cat": 0..5, "group": str|None, "bytes": int|None}."""
    groups, quarantined = {}, []
    for idx, r in enumerate(rows):
        if r["cat"]:
            quarantined.append({"index": idx, "reason": REASON[r["cat"]]})
        else:
            e = groups.setdefault(r["group"], {"bytes": 0, "count": 0})
            e["bytes"] += r["bytes"]
            e["count"] += 1
    return canonical(groups, quarantined)


def admit(fmt, data, record_rows):
    """Both derivations must agree; returns the expected canonical string."""
    a, b = expected_from_record(record_rows), derive_from_bytes(fmt, data)
    if a != b:
        raise AssertionError("record/bytes disagree:\n%s\n%s" % (a, b))
    return a


def accepts(fmt, data, output):
    """True only if output is byte-for-byte the oracle's canonical output."""
    return output == derive_from_bytes(fmt, data)
