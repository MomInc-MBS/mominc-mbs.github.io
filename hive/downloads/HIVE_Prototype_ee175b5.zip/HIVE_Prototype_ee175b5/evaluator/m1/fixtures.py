"""Hand-checked validation fixtures: (name, format, source bytes, hand-written expected output)."""
from oracle import R1, R2, R3, R4, R5

I128, I129 = "a" * 128, "a" * 129
_R = dict(zip("12345", ('"reason":"%s"' % r for r in (R1, R2, R3, R4, R5))))


def q(i, k):
    return '{"index":%d,%s}' % (i, _R[k])


def qs(*pairs):
    return ",".join(q(i, k) for i, k in pairs)


FIXTURES = [
    ("csv_all_valid", "csv", b"id,group,bytes\nr1,a,5\nr2,a,7\nr3,b,0\n",
     '{"groups":{"a":{"bytes":12,"count":2},"b":{"bytes":0,"count":1}},"quarantined":[]}'),
    ("csv_all_invalid", "csv", b"id,group,bytes\n,a,5\nr2,,5\nr3,a,01\nr4,a,1000000001\n",
     '{"groups":{},"quarantined":[%s]}' % qs((0, "2"), (1, "3"), (2, "4"), (3, "5"))),
    ("csv_boundaries", "csv", b"id,group,bytes\nr1,a,0\nr2,a,1000000000\nr3,a,1000000001\nr4,a,01\nr5,a,00\n",
     '{"groups":{"a":{"bytes":1000000000,"count":2}},"quarantined":[%s]}' % qs((2, "5"), (3, "4"), (4, "4"))),
    ("csv_noncanonical_forms", "csv",
     b"id,group,bytes\nr1,a,-1\nr2,a,1.5\nr3,a,\nr4,a,12345678901\nr5,a,+5\nr6,a, 5\nr7,a,9999999999\n",
     '{"groups":{},"quarantined":[%s]}' % qs((0, "4"), (1, "4"), (2, "4"), (3, "4"), (4, "4"), (5, "4"), (6, "5"))),
    ("csv_id_length", "csv", ("id,group,bytes\n%s,a,1\n%s,a,1\n" % (I128, I129)).encode(),
     '{"groups":{"a":{"bytes":1,"count":1}},"quarantined":[%s]}' % qs((1, "2"))),
    ("csv_group_length", "csv", ("id,group,bytes\nr1,%s,1\nr2,%s,1\n" % (I128, I129)).encode(),
     '{"groups":{"%s":{"bytes":1,"count":1}},"quarantined":[%s]}' % (I128, qs((1, "3")))),
    ("csv_precedence", "csv", b"id,group,bytes\n,,x\nr2,,x\nr3,a,x\nr4,a,5000000000\n",
     '{"groups":{},"quarantined":[%s]}' % qs((0, "2"), (1, "3"), (2, "4"), (3, "5"))),
    ("csv_quoted_and_ascii", "csv", 'id,group,bytes\n"r,1","café, x",3\n'.encode(),
     '{"groups":{"caf\\u00e9, x":{"bytes":3,"count":1}},"quarantined":[]}'),
    ("json_all_valid", "json", b'[{"id":"r1","group":"a","bytes":1},{"group":"a","bytes":2,"id":"r2"}]',
     '{"groups":{"a":{"bytes":3,"count":2}},"quarantined":[]}'),
    ("json_schema_category", "json",
     b'[1,"x",null,[],{"id":"a","group":"g"},{"id":"a","group":"g","bytes":1,"x":1},{"id":"a","group":"g","byte":1}]',
     '{"groups":{},"quarantined":[%s]}' % qs(*[(i, "1") for i in range(7)])),
    ("json_id_group_types", "json",
     b'[{"id":1,"group":"a","bytes":1},{"id":null,"group":"a","bytes":1},{"id":"","group":"a","bytes":1},'
     b'{"id":"r","group":5,"bytes":1},{"id":"r2","group":"","bytes":1}]',
     '{"groups":{},"quarantined":[%s]}' % qs((0, "2"), (1, "2"), (2, "2"), (3, "3"), (4, "3"))),
    ("json_bytes_types", "json",
     b'[{"id":"a","group":"g","bytes":true},{"id":"b","group":"g","bytes":1.0},{"id":"c","group":"g","bytes":"5"},'
     b'{"id":"d","group":"g","bytes":-1},{"id":"e","group":"g","bytes":1000000001},'
     b'{"id":"f","group":"g","bytes":1000000000},{"id":"h","group":"g","bytes":0}]',
     '{"groups":{"g":{"bytes":1000000000,"count":2}},"quarantined":[%s]}' % qs(*[(i, "5") for i in range(5)])),
    ("json_precedence_mixed", "json",
     b'[{"id":"","group":"","bytes":true},{"id":"a","group":"","bytes":true},{"id":"b","group":"g","bytes":true},{"id":"c","extra":1}]',
     '{"groups":{},"quarantined":[%s]}' % qs((0, "2"), (1, "3"), (2, "5"), (3, "1"))),
    ("json_id_group_128_129", "json",
     ('[{"id":"%s","group":"%s","bytes":1},{"id":"%s","group":"g","bytes":1},{"id":"x","group":"%s","bytes":1}]'
      % (I128, I128, I129, I129)).encode(),
     '{"groups":{"%s":{"bytes":1,"count":1}},"quarantined":[%s]}' % (I128, qs((1, "2"), (2, "3")))),
    ("json_ensure_ascii", "json", '[{"id":"r","group":"é中","bytes":2}]'.encode(),
     '{"groups":{"\\u00e9\\u4e2d":{"bytes":2,"count":1}},"quarantined":[]}'),
]


def wrong_outputs():
    """Deliberately wrong outputs (fixture name, output). The oracle must reject each."""
    d = {n: e for n, _, _, e in FIXTURES}
    inv = d["csv_all_invalid"]
    return [
        ("csv_all_invalid", inv.replace("," + q(3, "5"), "")),                                   # dropped row
        ("csv_boundaries", d["csv_boundaries"].replace(R5, R4, 1)),                              # wrong reason
        ("csv_all_valid", d["csv_all_valid"].replace('"bytes":12', '"bytes":13')),               # wrong sum
        ("json_all_valid", d["json_all_valid"].replace(",", ", ")),                              # non-canonical text
        ("json_all_valid", '{"error":"source_rejected"}'),                                       # whole-source failure
    ]
