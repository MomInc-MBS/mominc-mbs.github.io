"""G2 shared harness (stdlib only): the static check for proposed code and the wrapper that batches many cases into ONE
container run. The container runner calls apply(text, checks); here text is a JSON list of envs, the reply a JSON list of results."""
import ast
import json

# Builtins that open files, run code, or reach any object by a computed name.
FORBID = {"open", "exec", "eval", "compile", "__import__", "globals", "locals", "vars", "input", "breakpoint", "getattr", "setattr", "delattr", "type",
          "memoryview", "help", "exit", "quit"}
# Modules that give file, process, network, loader, serialisation or reflection access. They may never be imported, named, or reached as an
# attribute of anything (json.codecs, pkg.os, operator.attrgetter ...), whatever the caller's allowed list says.
DANGEROUS = {"os", "sys", "subprocess", "socket", "ctypes", "importlib", "builtins", "shutil", "codecs", "pathlib", "tempfile", "glob", "fileinput", "pty",
             "signal", "multiprocessing", "threading", "asyncio", "http", "urllib", "ftplib", "smtplib", "ssl", "select", "selectors", "mmap", "pickle",
             "marshal", "shelve", "sqlite3", "runpy", "code", "codeop", "imp", "pkgutil", "zipimport", "inspect", "gc", "site", "sysconfig", "platform",
             "webbrowser", "posix", "nt", "_thread", "resource", "fcntl", "termios", "tty", "pwd", "grp", "dbm", "zipfile", "tarfile", "gzip", "bz2", "lzma",
             "shlex", "pdb", "atexit", "faulthandler", "ensurepip", "venv", "types", "operator", "copyreg", "weakref"}
# `open` stays reachable as an attribute (Image.open, io.open on the read-only input): the container, not this check, is the file boundary.
ATTR_FORBID = (FORBID - {"open"}) | DANGEROUS


def static_problems(body, allowed=("json",)):
    """Why `body` may not run (empty = ok): must parse, define run(env), import only the `allowed` top-level modules (the contract's stdlib list
    plus the staged packages, decided by the trusted caller; DANGEROUS modules are never allowed), no star-import, no forbidden builtin or
    dangerous-module name, no attribute that is one of those (or a dunder), no dunder name."""
    ok = {m for m in allowed if m not in DANGEROUS and m not in FORBID}
    try:
        tree = ast.parse(body)
    except (SyntaxError, ValueError, RecursionError, MemoryError) as e:
        return [f"does not parse: {type(e).__name__}"]
    bad = []
    try:
        nodes = list(ast.walk(tree))
    except RecursionError:
        return ["too deeply nested"]
    for n in nodes:
        if isinstance(n, ast.Import) and any(a.name.split(".")[0] not in ok for a in n.names):
            bad.append("import outside the allowed modules")
        elif isinstance(n, ast.ImportFrom):
            if n.level or (n.module or "").split(".")[0] not in ok or any(a.name == "*" or a.name in ATTR_FORBID or a.name.startswith("__") for a in n.names):
                bad.append("import outside the allowed modules")
        # A bare name equal to a DANGEROUS module (e.g. a local `grp`) can only be a local: every import path to such a module is refused above
        # and as an attribute below, so naming it is not access. Builtins in FORBID and dunders stay refused.
        elif isinstance(n, ast.Name) and (n.id in FORBID or n.id.startswith("__")):
            bad.append(f"forbidden name {n.id}")
        elif isinstance(n, ast.Attribute) and (n.attr in ATTR_FORBID or n.attr.startswith("__")):
            bad.append(f"forbidden attribute {n.attr}")
    if not any(isinstance(n, ast.FunctionDef) and n.name == "run" and len(n.args.args) == 1 for n in tree.body):
        bad.append("no top-level def run(env)")
    return sorted(set(bad))


_WHY = (
    "def _why(_ex):\n"
    "    _s = type(_ex).__name__ + ': ' + str(_ex)[:160]\n"
    "    for _f in reversed(_tb.extract_tb(_ex.__traceback__)):\n"
    "        if _f.filename == 'candidate':\n"
    "            _n = _f.lineno - _OFF\n"
    "            return (_s + ' (adapter line %d: %s)' % (_n, (_B[_n - 1].strip() if 0 < _n <= len(_B) else '')[:100]))[:300]\n"
    "    return _s[:300]\n")


def wrap_dev(body):
    """Like wrap, for the PUBLIC dev cases only: the reply is {"out": [...], "err": [...]} where err[i] is, for a case that raised or returned a
    non-text value, the exception type and message plus the last traceback line inside the adapter (line number and source, truncated).
    The hidden-case evaluator and retained execution use wrap, which reveals nothing."""
    pre = "import json as _hj\nimport traceback as _tb\n_B = " + repr(body.split("\n")) + "\n"
    # no %-formatting here: the body (inside pre) may contain % characters. Offset = lines before the body: header + _OFF line + the _why helper
    head = pre + "_OFF = " + str(pre.count(chr(10)) + 1 + _WHY.count(chr(10))) + "\n"
    return (head + _WHY + body + "\n\ndef apply(_t, _c):\n    _o, _x = [], []\n    for _e in _hj.loads(_t):\n        try:\n"
            "            _r = run(_e)\n            _o.append(_r if isinstance(_r, str) else None)\n"
            "            _x.append(None if isinstance(_r, str) else 'run returned ' + type(_r).__name__ + ', not text')\n"
            "        except Exception as _ex:\n            _o.append(None)\n            _x.append(_why(_ex))\n"
            "    return _hj.dumps({'out': _o, 'err': _x})\n")


def wrap(body):
    """Container source: the candidate body plus apply(). A case that raises or returns a non-str yields null (never a pass)."""
    return ("import json as _hj\n" + body + "\n\ndef apply(_t, _c):\n    _o = []\n    for _e in _hj.loads(_t):\n        try:\n"
            "            _r = run(_e)\n            _o.append(_r if isinstance(_r, str) else None)\n        except Exception:\n"
            "            _o.append(None)\n    return _hj.dumps(_o)\n")
