"""Real-holdout gate: a candidate is run ONCE over a sealed, owner-approved, independently labelled real-data set; the labels decide, not the oracle.
Run as its own process: python -I evaluator/g2/real_holdout.py --suite DIR --store S --candidate-file F --candidate-sha H [--real-dir D] ...
The set lives outside the repo (directory named by the contract's verification.real_holdout.dir_env): APPROVAL.json {"files": {relpath: sha256}} and,
per case, labels.json {"schema":"p3-real-labels-v1","case","groups":[[names]],"singletons":[names]} beside the files it names. The gate checks
sha256(APPROVAL.json) against the contract's pin and every listed file against APPROVAL, runs the candidate on each case through the SAME container
path the hidden suite uses (evaluate.container_runner), builds the expected manifest from the labels with the suite's oracle.render and passes only if
every case is byte-exact. The receipt (stored in the store, and printed as verdict + sha only) holds hashes, counts and per-case pass/fail: no labels,
no expected output, no file names. A second opening for the same (store, capability, approval sha) is refused, whatever the first result was."""
import argparse
import base64
import importlib.util
import json
import os
import sys
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, os.path.join(ROOT, "src"))
_spec = importlib.util.spec_from_file_location("hive_g2_evaluate", os.path.join(HERE, "evaluate.py"))  # by path: "evaluate" is a bare name other suites share
EV = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(EV)

SCHEMA, LABELS = "hive-real-holdout-receipt-v1", "p3-real-labels-v1"
CRLF, LF = b"\r\n", b"\n"


def _read(path):
    with open(path, "rb") as f:
        return f.read()


def load_cases(real_dir, approval_pin):
    """[(envs-ready (names, raw bytes, groups, singletons))] after every hash check. SystemExit with a reason when anything does not match."""
    raw = _read(os.path.join(real_dir, "APPROVAL.json"))
    if EV.sha(raw) != approval_pin:
        raise SystemExit("real holdout refused: APPROVAL.json does not match the contract's approval pin")
    files = json.loads(raw)["files"]
    for rel, want in files.items():
        p = os.path.join(real_dir, *rel.split("/"))
        if not os.path.isfile(p) or EV.sha(_read(p)) != want:
            raise SystemExit("real holdout refused: a file does not match its approved hash")
    cases = []
    for rel in sorted(r for r in files if r.split("/")[-1] == "labels.json"):
        d = rel[:-len("labels.json")]
        lab = json.loads(_read(os.path.join(real_dir, *rel.split("/"))))
        groups, singles = lab.get("groups"), lab.get("singletons")
        if lab.get("schema") != LABELS or not isinstance(groups, list) or not isinstance(singles, list):
            raise SystemExit("real holdout refused: labels.json is not a p3-real-labels-v1 file")
        names = [n for g in groups for n in g] + list(singles)
        listed = sorted(r[len(d):] for r in files if r.startswith(d) and "/" not in r[len(d):] and r != rel)
        if sorted(names) != listed or len(set(names)) != len(names) or any(len(g) < 2 for g in groups):
            raise SystemExit("real holdout refused: labels and approved files disagree")
        cases.append(({n: _read(os.path.join(real_dir, *(d + n).split("/"))) for n in names}, groups, singles))
    if not cases:
        raise SystemExit("real holdout refused: no labelled case")
    return cases



def container_runner(a):
    """ONE isolated container run with the trusted caller's image, limits and import staging (the same EC.run_isolated path evaluate.py uses).
    Kept here so evaluate.py stays byte-identical: it is a pin file of every g2-evaluated capability."""
    sys.path.insert(0, os.path.join(ROOT, "src"))
    from hive import experiment_compare as EC

    kw = {}
    if getattr(a, "inputs", None):
        kw["inputs"] = a.inputs
    if a.image_id:
        kw["image"] = {"id": a.image_id}
    if a.memory_mb:
        kw["limits"] = {"memory_mb": a.memory_mb, "cpu_count": a.cpus, "pids": a.pids, "tmpfs_mb": a.tmpfs_mb}

    def run_container(src, text):
        return EC.run_isolated(src, text, {}, timeout=a.timeout, backend="container", operator_class="generated", **kw)
    return run_container

def open_holdout(a, run_container=None):
    suite = os.path.abspath(a.suite)
    contract = json.loads(_read(os.path.join(suite, os.pardir, "contract.json")))
    cap, h = contract["capability_id"], (contract["verification"].get("real_holdout") or {})
    if not h:
        raise SystemExit("real holdout refused: the contract declares none")
    real_dir = a.real_dir or os.environ.get(h["dir_env"])
    if not real_dir:
        raise SystemExit(f"real holdout refused: set {h['dir_env']}")
    cases = load_cases(real_dir, h["approval_sha256"])
    sys.path[:0] = [HERE, suite]
    import harness
    import oracle
    from hive import capcontract as CC
    from hive.storage import Store
    body = _read(a.candidate_file).decode("utf-8")
    allowed = [m for m in (a.imports or "json").split(",") if m]
    if EV.sha(body) != a.candidate_sha or harness.static_problems(body, allowed):
        raise SystemExit("candidate hash mismatch or static check failed")
    # Global single use: an append-only log beside the sealed key, so a fresh or copied store cannot reopen it.
    log = os.path.join(real_dir, "OPENINGS.jsonl")
    tag = {"capability_id": cap, "approval_sha256": h["approval_sha256"]}
    prior = [json.loads(l) for l in (open(log, encoding="utf-8").read().splitlines() if os.path.exists(log) else []) if l.strip()]
    if any({k: p.get(k) for k in tag} == tag for p in prior):
        raise SystemExit("real holdout refused: this sealed key was already opened for this capability (any store)")
    with open(log, "a", encoding="utf-8", newline="\n") as fh:
        fh.write(json.dumps(dict(tag, candidate_sha256=a.candidate_sha, store=os.path.abspath(a.store),
                                 at=datetime.now(timezone.utc).isoformat(timespec="seconds")), sort_keys=True) + "\n")
        fh.flush()
        os.fsync(fh.fileno())
    s = Store(a.store)
    try:
        s.db.execute("BEGIN IMMEDIATE")  # the opening is spent before the candidate runs: a crash or a FAIL never allows a retry
        try:
            key = CC.HOLDOUT_OPEN + cap + "/" + h["approval_sha256"]
            if s.get(key) is not None:
                s.db.execute("ROLLBACK")
                raise SystemExit("real holdout refused: already opened for this store, capability and approval")
            s.set(key, {"at": datetime.now(timezone.utc).isoformat(timespec="seconds")})
            s.db.execute("COMMIT")
        except BaseException:
            if s.db.in_transaction:
                s.db.execute("ROLLBACK")
            raise
        envs = [{"files": [{"name": n, "format": "base64", "data": base64.b64encode(raws[n]).decode("ascii")} for n in sorted(raws)]} for raws, _, _ in cases]
        want = [oracle.render(list(g) + [[n] for n in sg], {n: len(r) for n, r in raws.items()}) for raws, g, sg in cases]
        try:
            got = json.loads((run_container or container_runner(a))(harness.wrap(body), json.dumps(envs)))
            assert isinstance(got, list) and len(got) == len(cases)
        except Exception:  # a crashed or timed-out run passes nothing
            got = [None] * len(cases)
        ok = [g == w for g, w in zip(got, want)]
        r = {"schema": SCHEMA, "capability_id": cap, "candidate_sha256": a.candidate_sha, "approval_sha256": h["approval_sha256"],
             "evaluator": {"path": "evaluator/g2/real_holdout.py", "pin": EV.pin(suite), "script_sha256": EV.sha(_read(os.path.abspath(__file__)).replace(CRLF, LF))}, "n": len(cases), "case_pass": ok, "pass_count": sum(ok),
             "verdict": "PASS" if all(ok) else "FAIL", "at": datetime.now(timezone.utc).isoformat(timespec="seconds")}
        r["receipt_sha256"] = CC.holdout_receipt_sha(r)
        s.set(CC.HOLDOUT_RECEIPT + cap + "/" + a.candidate_sha, r)
        return r
    finally:
        s.close()


def main(argv=None, run_container=None):
    ap = argparse.ArgumentParser()
    for k in ("suite", "store", "candidate-file", "candidate-sha"):
        ap.add_argument("--" + k, required=True)
    ap.add_argument("--real-dir")
    ap.add_argument("--timeout", type=int, default=120)
    ap.add_argument("--image-id")
    ap.add_argument("--inputs", choices=("read-only",))
    ap.add_argument("--imports")
    ap.add_argument("--memory-mb", type=int, default=0)
    ap.add_argument("--cpus", type=int, default=1)
    ap.add_argument("--pids", type=int, default=32)
    ap.add_argument("--tmpfs-mb", type=int, default=16)
    a = ap.parse_args(argv)
    r = open_holdout(a, run_container)
    print(json.dumps({"verdict": r["verdict"], "pass_count": r["pass_count"], "n": r["n"], "receipt_sha256": r["receipt_sha256"]}))
    return 0 if r["verdict"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
