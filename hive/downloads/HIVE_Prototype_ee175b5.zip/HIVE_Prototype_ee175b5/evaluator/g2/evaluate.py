"""G2 generic independent evaluator (G1 plus a staged image, an import policy and resource limits passed by the trusted caller). Run as its own process: python -I evaluator/g1/evaluate.py --suite DIR ...
Task knowledge comes only from the suite folder DIR (oracle.py with expected(env), gen_private.py with set_sha(cases)); nothing here names a task.
Loads a candidate body by sha256, runs it over the private acceptance cases in ONE container run, compares with the oracle answers
and writes a receipt (same fields as the C3 evaluator). It never prints or stores an answer; per-case results are hashes.
Pin = sha over `name:sha\n` of evaluate.py, oracle.py, harness.py, gen_private.py, gen_public.py (LF-normalised), the order capcontract.pin uses."""
import argparse
import hashlib
import json
import os
import sys
import threading

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))
SCHEMA = "hive-c3-evaluation-receipt-v1"
CRLF, LF = bytes([13, 10]), bytes([10])
OWN, SUITE = ("evaluate.py", "harness.py"), ("oracle.py", "gen_private.py", "gen_public.py")
PIN_ORDER = ["evaluate.py", "oracle.py", "harness.py", "gen_private.py", "gen_public.py"]


def sha(b):
    return hashlib.sha256(b if isinstance(b, bytes) else b.encode()).hexdigest()


def pin(suite):
    return sha("".join(f"{n}:{sha(open(os.path.join(HERE if n in OWN else suite, n), 'rb').read().replace(CRLF, LF))}{chr(10)}" for n in PIN_ORDER))


def receipt_sha(r):
    return sha(json.dumps({k: v for k, v in r.items() if k != "receipt_sha256"}, sort_keys=True, separators=(",", ":")))


def evaluate(a, run_container=None):
    from datetime import datetime, timezone
    suite = os.path.abspath(a.suite)
    sys.path[:0] = [HERE, suite]
    import harness
    if run_container is None:
        sys.path.insert(0, os.path.join(ROOT, "src"))
        from hive import experiment_compare as EC

        kw = {}
        if getattr(a, "inputs", None):
            kw["inputs"] = a.inputs
        if a.image_id:
            kw["image"] = {"id": a.image_id}
        if a.memory_mb:
            kw["limits"] = {"memory_mb": a.memory_mb, "cpu_count": a.cpus, "pids": a.pids, "tmpfs_mb": a.tmpfs_mb}

        def run_container(src, text):
            return EC.run_isolated(src, text, {}, timeout=a.timeout, backend="container", operator_class="generated", **kw)
    body = open(a.candidate_file, "rb").read().decode("utf-8")
    allowed = [m for m in (a.imports or "json").split(",") if m]
    if sha(body) != a.candidate_sha or harness.static_problems(body, allowed):
        raise SystemExit("candidate hash mismatch or static check failed")
    cases = json.load(open(os.path.join(a.private, a.set, "cases.json"), encoding="utf-8"))
    from gen_private import set_sha
    if set_sha(cases) != a.set:
        raise SystemExit("acceptance set does not match its hash")
    import oracle
    want = [oracle.expected(c["env"]) for c in cases]
    err = None
    try:
        got = json.loads(run_container(harness.wrap(body), json.dumps([c["env"] for c in cases])))
        assert isinstance(got, list) and len(got) == len(cases)
    except Exception as e:  # a crashed or timed-out run passes nothing
        got, err = [None] * len(cases), f"{type(e).__name__}: {str(e)[:200]}"
    ok = [g == w for g, w in zip(got, want)]
    r = {"schema": SCHEMA, "label": a.label, "exp_id": a.exp, "frozen_sha": a.frozen_sha, "candidate_sha256": a.candidate_sha,
         "evaluator": {"path": "evaluator/g2/evaluate.py", "pin": pin(suite), "process": "separate python -I"}, "environment_id": a.image_id or None,
         "imports": sorted(allowed), "acceptance_set_sha256": a.set,
         "n": len(cases), "pass_count": sum(ok), "case_result_sha256": [sha(g if isinstance(g, str) else "null") for g in got],
         "container_runs": 1, "run_error": err, "verdict": "PASS" if all(ok) else "FAIL", "at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
         "baselines": {"unchanged_hive": "0/n: no registered capability produces the deliverable (planner refuses; measured by discovery)"}}
    if a.baseline_receipt:
        b = json.load(open(a.baseline_receipt, encoding="utf-8"))
        if b.get("receipt_sha256") != receipt_sha(b) or b.get("exp_id") != a.exp or b.get("label") != "scripted_baseline":
            raise SystemExit("baseline receipt invalid")
        r["baselines"]["scripted_hand_written"] = {k: b[k] for k in ("candidate_sha256", "n", "pass_count", "receipt_sha256")}
    r["receipt_sha256"] = receipt_sha(r)
    with open(a.out, "w", encoding="utf-8", newline="\n") as f:
        json.dump(r, f, sort_keys=True, indent=1)
    return r


def main(argv=None, run_container=None):
    ap = argparse.ArgumentParser()
    for k in ("suite", "exp", "frozen-sha", "candidate-file", "candidate-sha", "private", "set", "out", "label"):
        ap.add_argument("--" + k, required=True)
    ap.add_argument("--baseline-receipt")
    ap.add_argument("--timeout", type=int, default=120)
    ap.add_argument("--image-id")
    ap.add_argument("--inputs", choices=("read-only",))
    ap.add_argument("--imports")
    ap.add_argument("--memory-mb", type=int, default=0)
    ap.add_argument("--cpus", type=int, default=1)
    ap.add_argument("--pids", type=int, default=32)
    ap.add_argument("--tmpfs-mb", type=int, default=16)
    a = ap.parse_args(argv)
    if run_container is None:  # standalone process: die at the deadline even if the parent is gone (a daemon timer, never in tests' in-process calls)
        t = threading.Timer(a.timeout + 30, lambda: os._exit(3))
        t.daemon = True
        t.start()
    r = evaluate(a, run_container)
    print(json.dumps({"verdict": r["verdict"], "pass_count": r["pass_count"], "n": r["n"], "receipt_sha256": r["receipt_sha256"]}))


if __name__ == "__main__":
    main()
