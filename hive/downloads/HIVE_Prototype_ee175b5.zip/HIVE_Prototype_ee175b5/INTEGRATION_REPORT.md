# HIVE Unified Integration Result — 22 November 2026

Status: **ENGINEERING_INTEGRATION (INTEGRATION_TESTED)**. This report covers no new model calls, no Level A acceptance and no learning claim.

- **Authoritative repo / baseline / commits:**
  - Repo `D:/Repos/hive-ai`, branch `build/working-prototype`.
  - Baseline `59d9b5e`, the live-demo record from earlier the same day.
  - Campaign commits: `fac5586` (DecisionGateway + sources lock), `7de5957` (UsageLedger), `e3bc72b` (audit + gap map), `caa0ebe` (OFF adapters + runbook), `6e67d49` (roles + run state), `b5a025c` (repo_intel), `21c3e96` (OODA), `32afa0e` (dispatch gate + review-gated promote), `a6952cf` (ADR + loop docs), `25f19b2` (wave-3 wiring).
- **dev4/dev6 mapping:** unchanged from `docs/CURRENT_STATE.md`. Version is 0.4.0.dev1, dev6 and dev4 artifacts are untouched, and P0 governs with P2 quarantined.
- **Commands:** full suite `python -m pytest tests -q --basetemp D:/tmp/<short> -p no:cacheprovider`. A short basetemp is required because long paths hit Windows MAX_PATH. Operator commands are in `docs/runbooks/hive-local-operator.md`.
- **Test counts:**
  - Reported prior: 488 passed, 3 skipped.
  - Conductor-run at `32afa0e`: **661 passed, 3 skipped, 0 failed** (24:00, log `D:/tmp/full-32afa0e.log`).
  - Worker-run at `25f19b2`: **689 passed, 3 skipped, 0 failed** (36:52). The conductor re-ran the 86 focused wave-3 tests, and they pass.
- **Modules extended, not duplicated:**
  - `OllamaAdapter.generate` is the only point that issues a real model request. It now calls `DispatchGate`, which runs `ContextPolicy.preflight` (fail-closed) before the request and appends to the `UsageLedger` after it.
  - `Executor` records `RunStates` transitions in the existing Store SQLite.
  - `Checkpoints.promote` requires a passing `review_gate` verdict.
  - New standalone modules that reuse the Store: `decision_gateway`, `roles`, `run_state`, `repo_intel`, `ooda`.
  - No second coordinator, daemon or database was added.
- **O1–O10 gate table:** unchanged from `build/prototype-v04/public/release-decision.json` and the live demo `build/prototype-v04/live-demo-20261122/REPORT.md` (O5 PASS). This campaign adds governance plumbing and changes no operator outcome.
- **Approved local-model calls this campaign:** **0**. The live-demo allocation stays at 5/24 requests used.
- **Data-to-Repair / subsequent task / policy lineage:** unchanged from the live demo. P0 incumbent; candidate REJECTED; P2 quarantined. Tests assert that no production code promotes the governing checkpoint.
- **H01–H11; Level A / Level B:** Level A **NOT ACCEPTED**. It needs six unused data sources and six unused Python snapshots, with at least 10 of 12 accepted. Level B is **UNTESTED** and needs at least 24 source-disjoint holdouts. Neither was attempted here.
- **Coding workers and review separation:**
  - Opus conducted, integrated and committed.
  - Sonnet built the DecisionGateway, roles/run state, dispatch wiring and wave-3 wiring.
  - Nemotron 3.5 Super built the sources lock, UsageLedger, repo_intel and OODA.
  - Haiku wrote the audit, OFF adapters, runbook, ADR and loop docs.
  - Grok was removed mid-campaign because it stalls on larger context. Fable was not used.
  - The conductor reviewed every patch before commit and fixed the following:
    - sources-lock wrong repos (go-bot, Qwen, El Remoto, Jev)
    - ledger chain race
    - repo_intel remote transport and `-C` bug
    - OODA missing-verifier hole
    - request-cap key bug
    - audit's wrong store path
- **Token/cost:** the HIVE runtime spent zero tokens and $0. Worker-agent token spend was **not measured** by HIVE; the UsageLedger governs HIVE runtime only.
- **Context A/B:** not run in this campaign. The prior figures are in `docs/CONTEXT_GOVERNANCE_BASELINE_VS_AFTER.md`.
- **Upstream decisions:** see `integrations/sources.lock.json` and `docs/adr-hive-unified-integration.md`.
  - Every upstream is pattern-only and no code was imported.
  - El Remoto is GPL-3.0, so no code may be copied.
  - RunAnywhere and Jev are NOASSERTION, and Qwen has no SPDX license; each needs a license review first.
- **Security / rollback evidence:**
  - Preflight blocks with zero usage.
  - Role deny, path traversal, repo-transport and binary/oversize guards are in place.
  - Hash-chain tamper detection covers the ledger, run events and OODA steps.
  - Rollback is allowed only to a previously promoted checkpoint.
  - All of the above are tested.
- **Experiments:** no new accepted, rejected or inconclusive experiments. OODA has no production driver yet.
- **Optional adapters:** RunAnywhere and Obscura are **OFF**. Both refuse to run even when enabled.
- **Remaining blockers / next item:**
  1. Wire DecisionGateway `MODEL_ROUTE` at dispatch as an explicit, reviewed route change.
  2. Add a cross-process file lock to the UsageLedger.
  3. Add an OODA driver for one bounded experiment, using repo_intel as the first real use.
  4. Record written license reviews.
  5. Level A needs Ian to supply 12 unused, approved sources (`docs/LEVEL_A_OPERATOR_INTAKE.md`).

## Compact checkpoint

Branch `build/working-prototype` @ `25f19b2`, with the full suite green: 689 passed, 3 skipped. Dispatch is centrally gated, usage is recorded and run states are durable. Promotion is review-gated, and no production path promotes. There were zero model calls; P0 governs, P2 is quarantined, and learning is unproven. The next authorized engineering item is the explicit `MODEL_ROUTE` wiring. Level A is blocked on Ian's sources.
