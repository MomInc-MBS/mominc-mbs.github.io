# HIVE quickstart (draft)

HIVE turns a goal into a typed plan, finds the missing capability if there is one, evaluates a candidate with an independent evaluator, admits it with a
signed statement, and then runs it again with zero model calls. Everything below is a command that exists on this branch. `--json` prints machine
output; without it each command prints a short table. All commands take `--store DIR` BEFORE `operator` (default `.hive`).

## 1. Install and start

```
python -m pip install -e .          # optional: gives the short `hive` command; otherwise use `python -m hive`
python -m hive --store .hive/operator operator import        # idempotent: loads the retained M2 capabilities (convert, merge)
python -m hive --store .hive/operator operator readiness     # docker image, evaluator pin, disk
python -m hive --store .hive/operator operator launch --allowed-root <inputs folder>    # optional local console
```

One-time admission key (kept OUTSIDE the repo and the store; the runtime only verifies):

```
python scripts/hive_admission.py init            # writes %USERPROFILE%\.hive-admission and configs/admission_signers
```

## 2. Submit a goal

```
hive --store S operator goal "Compare the before and after inventories" before.csv after.csv --allowed-root DIR [--deliverable inventory_diff] [--allow-discovery]
```

Without `--allow-discovery` a missing capability ends the goal `UNRESOLVED` and nothing else runs. With it, ONE bounded discovery experiment is queued;
run it with `hive --store S operator discover run EXP_ID`, then the key holder admits it:
`python scripts/hive_admission.py admit --store S --exp EXP_ID`.

## 3. Show the plan and the receipt

```
hive --store S operator plan ...             # added by planner work: show the typed plan without running it
hive --store S operator run-plan GOAL_ID     # added by planner work: run a stored plan
hive --store S operator receipt GOAL_ID      # plan, capability versions used, verdict, model calls, elapsed, artifacts (a unique id prefix works)
hive --store S operator overview             # store, capability counts, last goals/runs, budget and ledger line
hive --store S operator acquisitions         # acquisition runs and discovery/improve experiments: discovered -> inspected -> acquired -> admitted | rejected
```

## 4. List capabilities and read the signed history

```
hive --store S operator cap list             # id, kind (m2|discovered), version, lifecycle (active|revoked|superseded|candidate), provenance, evaluation receipt id, admitted_at
hive --store S operator cap show CAP_ID      # every event of the signed chain; `chain OK` means every signature and hash link verified
```

## 5. Revoke and roll back (signed)

Both go through `scripts/hive_admission.py`, the only signer. There is no unsigned path; the key must be outside the repo and the store.

```
hive --store S operator cap revoke CAP_ID --reason "why" [--version N] [--key PATH]    # default version = the active one; a revoked current version cannot execute
hive --store S operator cap rollback CAP_ID [--key PATH]                               # back to the previous admitted, unrevoked version
```

## 6. Improve an admitted capability

An explicit, authorised request for a new version of a capability that is already admitted. It opens one bounded experiment (same budgets and
M2 approval caps as acquisition; they are never raised). The proposer sees the spec, the current admitted code and a declared objective, never the hidden
holdout. The candidate must pass the same pinned evaluator on a FRESH hidden holdout, keep every public regression fixture, and improve the objective.
Only then does the admission authority sign version N+1; otherwise the result is `REJECTED`, the evidence stays, and the current version stays active.

```
hive --store S operator cap improve CAP_ID --objective failure_class:wrong_output|failure_class:run_error [--key PATH]
```

The objective is an enum value or a number, never free text. The result carries a comparison receipt (old vs new holdout counts, timings, regression
fixtures, evaluator pin, version numbers); it is a store artifact referenced from the result and kept at `operator/improve/<experiment id>`.
This command calls the local model (`openai/gpt-oss-20b` through the dispatch and approval path), so check `operator readiness` and the GPU first.
If the key is not available the experiment still runs and ends `ADMISSION_REFUSED`; admit it later with `hive_admission.py admit --exp EXP_ID`.
