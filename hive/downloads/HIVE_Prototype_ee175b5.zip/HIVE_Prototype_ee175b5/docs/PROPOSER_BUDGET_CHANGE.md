# Proposer output budget change (declared, generic)

**Change:** per-call proposer output cap 2000 -> 4096 tokens, for every capability and every campaign (no per-gap special case).

| Where | Old | New |
|---|---|---|
| `src/hive/discovery.py` BUDGET `max_tokens_per_call` | 2000 | 4096 |
| `src/hive/discovery.py` BUDGET `out_tokens` | 6000 | 6000 (unchanged: owner-signed c3 approval caps output_tokens at 6000 per experiment) |
| `src/hive/acquire.py` BUDGET `max_out_tokens` (in-run `out_tokens` = 3 x this) | 2000 | 4096 |
| `scripts/g3_qualify.py` EXP_BUDGET `max_tokens_per_call` / `out_tokens` | 2000 / 6000 | 4096 / 6000 |

**Evidence (measured):** live store `C:/hive-work/demo/s1/discovery/`, experiments `d-aab5652e07a9a04fd7a6` and `d-ab74f5395b7be8bebc15`
(`model/model_calls.jsonl`): 4 of 6 calls ended `finish_reason: "length"`, hidden reasoning 1,199-1,997 of the 2,000 tokens, and the
`reply-*.txt` files stop mid-function. Result: no candidate or 0/6 dev passes. gpt-oss-20b ("Reasoning: low") spends most of the cap thinking.

**Caps still hold** (`build/m2/operator_inference_approval.json`, unchanged: tokens_total 900000, model_calls 64, proposals_total 48):
- worst case per call = 6000 prompt + 4096 out = 10,096 tokens; 64 calls x 10,096 = 646,144 <= 900,000.
- one experiment = 36,000 + 12,288 = 48,288 tokens; 48 proposals / 3 = 16 experiments x 48,288 = 772,608 <= 900,000.
- calls and proposals per experiment (6 / 3) are unchanged.
- `call_timeout_s` 240: 4,096 tokens at ~150 tok/s is ~27 s, so the timeout still covers it.

**Open owner item:** `build/c-series/c3_inference_approval.json` (the C3 discovery approval) still records `output_tokens: 6000`. That file is
only compared for equality with `discovery.APPROVAL_CAPS`, not enforced against the budget, so nothing fails, but the experiment now plans
12,288 output tokens. The owner should re-sign it (and `APPROVAL_CAPS` with it) if the C3 file is meant to bound output.

Tests: `tests/test_p_fix_model2.py` (new); `tests/test_discovery.py::test_approval_gate_and_caps` kept at out_tokens 6000.

## Conductor correction (26 Nov)
The per-experiment output total stays at 6000 tokens, because `build/c-series/c3_inference_approval.json` is an owner-signed artifact that states `output_tokens: 6000`, and the conductor may not raise an owner cap. The acquisition path takes `min(3 x max_out_tokens, 6000)`. Only the per-call ceiling rises to 4096, so the first call can finish its code. A later call gets what is left of the 6000 total. If the owner re-signs the approval with a higher output total, raise `out_tokens` to match.
