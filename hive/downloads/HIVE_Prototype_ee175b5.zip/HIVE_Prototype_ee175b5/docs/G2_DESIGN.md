# G2 design: GitHub-to-capability bridge (build/compounding @ 456873b)

Design only; no code written. Repo text was treated as data. Line numbers at 456873b. G1 is already implemented (capcontract, v2 statements, bounded runner), so G2 extends it.

## 1. Survey of seams

| Seam | file:line | Fact that shapes G2 |
|---|---|---|
| Contract schema ceilings | `schemas/capability-contract-v1.json` | `envelope` enum `files-v1`; `permissions.imports` const `["json"]`; memory<=128, cpus 1, pids<=32; `environment_ref` = image+digest; arity max 20 |
| Pinned-image check | `capcontract.py:124`, `:288` | contract and `recheck` equal `PINNED_IMAGE`: single-image assumption #1 |
| Env building | `capcontract.py:203-214` | `build_env` is text only, `{"format","text"}`; `_run_discovered` decodes every input as UTF-8 (`goal_runner.py:344`) |
| Gap match | `capcontract.py:175`, `goal_runner.py:278-298` | `contract_for_gap`, `missing_step` already generic; typed gap -> contract |
| Discovery freeze | `discovery.py:103-157` | one experiment = frozen protocol + budget (3 proposals, 12 container runs); `check` caps **2 experiments per gap** (`:112`) |
| Proposer prompt | `discovery.py:36`, `:199` | SYSTEM hardcodes "only json"; `prompt()` = behaviour spec + dev cases; dispatch class from contract (`:386`) |
| Static check | `evaluator/g1/harness.py:10-30` | imports allowed: `json` only; shared by evaluator pin |
| Dev + evaluator run | `discovery.py:216`, `:245-268`, `evaluator/g1/evaluate.py:34-44` | both call `run_isolated(..., backend="container")` with the default image; evaluator is `python -I`, pinned by sha |
| Container exec | `experiment_compare.py:138-162`, `isolation.py:90-160` | limits hardcoded 128m/1cpu/32 pids (`:148`); `inspect` demands a `RepoDigests` entry (`isolation.py:48`), so a locally built image fails closed: single-image assumption #2; `in.json` mounted read-only; offline; cap-drop; in-container KILL watchdog |
| Admission | `hive_admission.py:60-90`, `:97-127` | v2 statement; `recheck` re-runs evaluator; signs with external key |
| Registry recheck | `capcontract.py:273-292` | per-use recomputation of body, contract, harness, pin, image |
| repo_intel | `repo_intel.py:60-82`, `:134-272` | `resolve_ref` (https only), `ContentCache`, `SelectiveFetcher(repo_path,...)` reads blobs from an **existing local git repo**; no fetch/clone function, no capability coupling |
| Dispatch | `model_dispatch.py:38-70`, `configs/model_dispatch.json` | per-class mode/canary; only `c3-proposal`; unqualified model refused |
| Journal pattern | `discovery.py:99-196`, `:280-330`, `:444` | record in Store with `stages` list, `pid` + `_alive` guard, STOP file via `_gate`, `INTERRUPTED` (resumable) vs terminal states, `recover()`. `run_state.py` has a fixed lifecycle table: not reused |

Gaps G2 must close: (a) no search/card/stage code; (b) two single-image assumptions; (c) text-only envelope; (d) json-only static check and fixed proposer system prompt; (e) 2-experiments-per-gap cap; (f) no place for a tool's provenance in the admission statement.

## 2. State machine

States: `GOAL, PLAN, MISSING_CAPABILITY, SEARCH, INSPECT, SELECT, STAGE, ADAPT, VERIFY, ADMIT, EXECUTE, RECORD_OUTCOME`. GOAL/PLAN/MISSING_CAPABILITY are existing `make_contract`/`plan_goal`/`missing_step`+`record_gap`; the new driver `acquire.run(store, gap_key)` starts at SEARCH and a goal hands over only when `missing_step` returns a gap and the goal budget allows acquisition.

```
SEARCH -> INSPECT -> SELECT -> STAGE -> ADAPT -> VERIFY -> ADMIT -> EXECUTE -> RECORD_OUTCOME(DONE)
  ^           |         |         |        |         |        |
  +-----------+---------+---------+--------+---------+--------+--> RETRY (attempt+1 < 3, next-ranked candidate)
any state --> RECORD_OUTCOME(terminal reason)
```

- **SEARCH** tiers in order, each recorded even if empty: (1) retained capabilities (`CR.eligible_discovered`, re-planned; a hit exits to EXECUTE via the normal planner), (2) installed tools (previously carded repos in the store plus the trusted wheelhouse cache: card keywords vs gap), (3) GitHub. `--require-new-external` (gate run) records tiers 1-2 but cannot select from them.
- **INSPECT** per candidate, no model: resolve to a 40-hex revision, build a card (section 3), license gate. Reject = record reason, next candidate.
- **SELECT** deterministic score (interface fit from card vs contract types, license, dep count, wheels-only deps, last-push age, size, platform), popularity ignored except as a tie-break. Takes the best not-yet-tried candidate; at most 3 attempts per run.
- **STAGE** trusted staging runner (section 3) -> image ID or rejection.
- **ADAPT** proposer: one call, plus one repair call using public dev-case feedback only. Static check, then dev run in the staged image.
- **VERIFY** existing discovery evaluator path: separate `python -I` evaluator, hidden private set, receipt re-check, scripted baseline measured once per run.
- **ADMIT** `hive_admission.admit` (independent re-run, signs with the external key). The driver cannot sign; admission is a separate process invocation by the operator/conductor key holder, or the qualification script calls it with the key path.
- **EXECUTE** `run_goal` on the goal; retained path re-verifies (`recheck`) and runs in the staged image; oracle checks the output. A failed EXECUTE after admission is not a retry (admitted capability stays, outcome recorded FAILED_EXECUTE).
- **Terminal reasons**: `DONE`, `NO_CANDIDATE` (search empty / all rejected), `CANDIDATES_EXHAUSTED` (3 attempts), `BUDGET_EXHAUSTED`, `STOPPED`, `MODEL_UNAVAILABLE`, `SANDBOX_UNAVAILABLE`, `NETWORK_UNAVAILABLE`, `ADMISSION_REFUSED`, `FAILED_EXECUTE`. Non-terminal: `INTERRUPTED` (resumable).
- **Never admit unverified**: ADMIT is reachable only from a VERIFY record with `verdict PASS` whose receipt re-checks against the frozen sha, the contract sha and the staged image ID; `admit` re-derives that itself.
- **Budgets** (frozen in the run record, enforced by a `_gate` like `discovery.py:184`): attempts 3, model calls 6, repair 1 per attempt, builds 3, container runs 18, GitHub requests 30, wall 40 min, prompt <=8,000 input tokens, <=2,000 output tokens/call. Local model => $0, but ledger keeps tokens, calls, wall, `cost_usd` 0.0.
- **Persistence**: record `operator/acq/<run_id>` in the Store: `{state, attempt, candidates[], ledger, stages[]}`; every stage appends `{stage, at, artifact_sha}`; large outputs (search cache, cards, lock, wheelhouse manifest, image tar, replies) are files under `<store>/acquisition/<run_id>/` hashed in the record. Resume: re-enter the first stage whose artifact is missing or hash-mismatched; `pid`+`_alive` guard, STOP file checked in every `_gate`, `recover()` flips a dead RUNNING run to INTERRUPTED. Idempotent: SEARCH reads its query cache, INSPECT its card cache by (repo, revision), STAGE reuses an existing image whose ID matches the recorded one, ADAPT never re-calls the model for an existing reply file. Per-attempt discovery experiments (below) carry their own ledgers; the run ledger sums them.
- **Experiments**: each attempt opens one discovery experiment through `open_experiment(..., acq=run_id)`. The 2-per-gap cap becomes "2 per gap for human-opened, 3 per acquisition run"; a gap can have at most 2 acquisition runs.

## 3. Modules (kernel vs proposer)

Trusted kernel (no model output enters it unvalidated): 
- `src/hive/acq_github.py` search adapter: urllib to `https://api.github.com/search/repositories` only; builds the URL itself; unauthenticated, optional `HIVE_GITHUB_TOKEN` read from env at call time (never stored, logged or put in cache keys, request log redacts headers); honours `X-RateLimit-Remaining/Reset`, `Retry-After`, backs off on 403/429 (max 2 retries then NETWORK_UNAVAILABLE); cache by `sha256(query)` with 24 h TTL; response <=1 MB; no redirects to other hosts; HTTP injectable (`transport=`) for tests. Queries come from the contract (keywords from the type row, purpose) and optionally 3 model-suggested queries validated by `[A-Za-z0-9 _.-]{1,60}`.
- `repo_intel.clone_pinned(url, sha, dest)` (one small addition): `git init` + `fetch --depth 1 --filter=blob:none origin <sha>` with `protocol.allow=never protocol.https.allow=always`, `core.hooksPath=NUL`, `GIT_LFS_SKIP_SMUDGE=1`, no checkout, size and time caps; revision from `resolve_ref`, never a branch name after this point. Blobs then read by the existing `SelectiveFetcher`+`ContentCache`.
- `src/hive/acq_card.py`: deterministic card, no model. Fields: repo, revision, purpose (README first paragraph, <=600 chars), interfaces (AST scan of declared entry points: public function signatures + docstring first line, <=40), I/O hints, SPDX license, deps (parsed from `pyproject.toml`/`setup.cfg`/`requirements*.txt`, names + specifiers only), platform (pure Python? classifiers), known failures (open issue count only; never issue text), evidence pointers (path@blob sha). `card_sha256` over canonical JSON; cached by (repo, revision, content hash).
- `src/hive/acq_stage.py`: staging runner (below). `src/hive/acq_policy` data in `configs/acquisition_policy.json`: license allowlist (MIT, BSD-2/3-Clause, Apache-2.0, ISC, PSF-2.0; conductor decides HPND/MIT-CMU for Pillow), dep limits, byte limits, wheel-only rule.
- `src/hive/acquire.py`: the driver/journal. It calls the proposer through one function and treats its return as bytes.
- Changed: `capcontract.py` (schema v2, `derived` env, envelope v2), `isolation.py` (`execute` accepts `image={"id":...}` local-ID kind and per-call limits), `experiment_compare._run_container`/`run_isolated` (new optional `image=`, `limits=` args; defaults unchanged), `discovery.py` (contract-driven SYSTEM prompt and harness imports, frozen `environment`, `acq` experiments), `capability_registry.py` + `hive_admission.py` (v3 statement), `goal_runner._run_discovered` (v2 envelope, staged image), `configs/model_dispatch.json` (`acq-proposal` class, same qualified model).
- New evaluator `evaluator/g2/{evaluate.py,harness.py}` (copy of g1 with an image argument and an import policy argument). g1 bytes untouched, so admitted G1 pins stay valid.

Proposer (no kernel authority): `src/hive/acq_propose.py`: prompt builder (contract behaviour spec + public dev cases + card excerpt <=3,000 tokens: README paragraph, manifest, <=12 signatures, wrapped in a fenced `UNTRUSTED REPOSITORY DATA` block and control-char stripped), `extract_code` (reuse). Never receives: hidden fixtures, keys, permissions block, admission policy, evaluator path.

**STAGE detail** (trusted, offline at run time):
1. Vendor the tool: copy the importable package directory (from the tree index, selective fetch, size <= 2 MB, text only) from the pinned revision into a staging dir; hash the tree (`vendored_tree_sha256`). No `setup.py`, no build backend is ever executed.
2. Dependency set from the card, validated (name regex, <= 8 dists, index = pypi.org only). A throwaway container with network (no mounts except the output dir, no secrets, memory/pids limits) runs `pip download --only-binary=:all: --no-deps`/resolver to a wheelhouse; the host hashes each wheel and writes the lock (`name==ver --hash=sha256:...`). Wheels are scanned: no `.pth`, no path traversal, license from METADATA in allowlist, total <= 150 MB.
3. `docker build --network=none` of a Dockerfile **the runner generates** (FROM the pinned digest; COPY wheelhouse; `pip install --no-index --no-deps --require-hashes -r lock`; COPY vendored tree into site-packages, because `python -I` ignores PYTHONPATH). No repo-supplied Dockerfile.
4. Record image ID (`docker image inspect --format {{.Id}}`); `docker save` to the store, hash the tar. Reuse path: if the ID is missing locally, `docker load` from the verified tar (same ID), never rebuild (a rebuild changes the ID and would invalidate the statement).
5. Smoke: in the staged image, `import` each declared package as non-root offline.

## 4. Contract extensions (v1 stays valid)

New `schemas/capability-contract-v2.json`; `capcontract.validate` selects by the `schema` field, v1 files and checks unchanged. v2 differences:
- `execution.environment_ref`: `{"kind":"pinned","image","digest"}` (equals v1 semantics, so existing caps need no change) or `{"kind":"derived","base":{"image","digest"},"stage_policy":"configs/acquisition_policy.json"}`. The derived image ID is unknown at authoring time; it is produced at STAGE and bound in the statement.
- `permissions`: `imports: {"stdlib": [<safe list: json, io, base64, hashlib, math, itertools, collections, struct, re>], "staged": true}`. **Deviation from the brief:** the contract cannot list packages of a tool nobody has discovered yet; `staged:true` means "the top-level import names of the packages staged for this attempt". The resolved list is written into the frozen record and the v3 statement (`environment.packages`), and the evaluator harness gets it as an argument. `network` false, `filesystem` none, `secrets` false stay constants.
- `inputs.envelope: "files-v2"`: `{"files":[{"name","format":"text"|"base64","text"|"data"}]}`; `inputs.limits`: `max_files` (<=64), `max_file_bytes` (<=1 MiB), `max_total_bytes` (<=8 MiB); arity max raised to 64. `build_env` takes `(name, bytes)` pairs and rejects over-limit input before any run. In `in.json` (mounted read-only, no extra filesystem mount) base64 inflates by 4/3: 8 MiB cap is far inside Docker limits.
- `execution.resources` ceilings: 512 MB, 2 cpus, 64 pids; tmpfs raised to 64m for decoded images, still `noexec`; `timeout_seconds` <=900, `max_output_bytes` unchanged.
- Admission **v3** (`hive-capability-admission-v3`): v2 fields + `environment {id, base, lock_sha256, wheelhouse_manifest_sha256, image_tar_sha256, packages[]}`, `tool {repo, revision, license_spdx, vendored_tree_sha256, card_sha256}`, `acquisition {run_id, attempts[]}`. `recheck` for v3: image ID inspect (or `docker load` after tar hash check), then the v2 checks with the pinned-image test replaced by "base equals PINNED_IMAGE and ID equals admitted ID". v1/v2 events keep verifying; chain may mix versions (G1 rule).
- The evaluator receipt gains `environment_id`; `receipt_problems` checks it equals the frozen one.
- Core grep test (G1) extended to `acq_*.py`, `acquire.py` and evaluator g2: no `image`, `pillow`, `PIL`, `perceptual`, `manifest`, `imagehash` literals; the task lives only in `capabilities/image.asset-match/` and `configs/capability_types.json`.

## 5. Security analysis

| Boundary | Threat | Control |
|---|---|---|
| GitHub JSON | hostile names/descriptions, huge responses, SSRF, token leak | URL built from fixed host + validated `owner/name` regex; body <=1 MB; descriptions only used as ranking text, never as instructions or paths; token env-only, redacted, absent from cache keys, manifest and logs |
| Repo content | prompt injection in README/code, path traversal, giant/binary blobs, LFS, hooks | `SelectiveFetcher` (path validation, `max_bytes`, binary refusal, blob-sha check); clone without checkout, no hooks, LFS skipped; card extracted deterministically; model sees only bounded fenced excerpt; selection and license decisions are not model-made |
| Licenses | wrong SPDX claim | API spdx AND LICENSE text pattern must agree; else `unknown` => reject; dep licenses from wheel METADATA |
| pip | typosquat, sdist build-time code, `.pth` startup code, hash drift | wheels only, pypi.org only, name regex + count cap, trusted-generated lock, `--require-hashes --no-deps --no-index` on install, `.pth` scan, size caps; downloader container has network but no secrets/mounts; residual: a malicious wheel's runtime code, contained by the same sandbox as the adapter |
| Docker build | RUN executes repo code, daemon abuse | runner-generated Dockerfile, `--network=none`, only COPY + pip-install-of-wheels; no socket mount; `docker` only invoked by argv list; digest-pinned FROM |
| Model output | forbidden imports/builtins, exfil via output, test-set learning | AST static check (extended harness: imports = stdlib safe list + staged names, no star-imports, dunder ban, forbidden names); run offline/read-only/non-root/cap-drop with KILL watchdog; hidden set never in prompt; feedback from public cases only; evaluator in separate pinned process |
| Admission | proposer influencing authority | proposer returns text only; contract/evaluator/limits/output name from signed repo contract; admit re-runs evaluator; key outside repo and store |
| Store tampering | edited run record | records are working state; admission recomputes everything from files (G1 rule) |

## 6. Qualification capability: `image.asset-match`

**Contract** (`capabilities/image.asset-match/contract.json`, schema v2): inputs arity [2,64], type `image_file` (type-table `accepts_formats` png, jpg, jpeg), envelope files-v2 base64, limits 64 files / 512 KiB each / 8 MiB; output type `image_match_manifest`, media `application/json`, artifact `manifest.json`; `environment_ref` derived over `python:3.11-slim`; timeout 120 s, 512 MB, tmpfs 64m. `capability_types.json` gains `image_file`, `image_match_manifest` (keywords "duplicate images|match images|near-duplicate|rename"), deliverable entry, `behaviour_spec`.

**Manifest (canonical)**: one JSON text `{"schema":"image-match-manifest-v1","groups":[{"id":"g001","members":[name,...],"keeper":name}],"singletons":[name,...]}`. Every input name appears exactly once; members sorted by name (code points); `keeper` = largest pixel area, ties by larger byte size then name; groups sorted by their first member; ids `g%03d` in that order; singletons sorted; `json.dumps(sort_keys=True, separators=(",",":"))`. Match = same underlying base picture despite rename, resize, JPEG re-encode, <=8% border crop, brightness shift <=15%; distinct pictures never grouped.

**Fixtures** (independent fixture author = a conductor-side agent, disclosed in the manifest as `fixture_author: conductor-agent, not Ian`; it never sees any adapter or repo card): `suite/gen_public.py` (6 dev cases, committed), `suite/gen_private.py --out DIR --seed S` (24 cases, written only to the private dir, prints `{set_sha256,n}`, `set_sha` over cases, seed-hashed exactly like `capabilities/text.interval-merge/suite/gen_private.py:65`). Generator: deterministic Pillow, base pictures are seeded synthetic scenes (gradient + random shapes + text block) so any two bases differ strongly; variants = transform chain from the list above with random filenames (renames cross extensions, mixed case, unicode); distractors = unrelated bases plus **hard negatives** (same palette, different layout; flipped/rotated bases are NOT matches, stated in the spec). Ground truth by construction (variant -> base id). Each generated case asserts `oracle.expected(env) == truth` before being written; a generator whose oracle disagrees fails.

**Independent oracle** (`suite/oracle.py#expected(env)`, host side, Pillow + stdlib, runs in separate `python -I`): normalise each image (decode, drop alpha, resize 32x32 grayscale, per-image mean/std normalise, 1-D edge-trim of <=10% borders by cropping comparison at two scales), distance = mean absolute difference; union-find at threshold chosen by the generator's measured gap (inter-class minimum vs intra-class maximum must differ >= 2x or generation aborts). It is deliberately a different algorithm than a hash library would be, and it needs only env, so the same oracle verifies reuse on unseen inputs. Scripted baseline `suite/baseline.py` = pure-stdlib "group by identical sha256" (expected to fail near-duplicates: shows value). Unseen reuse inputs = a third seed, generated after admission, hash recorded, never used in the run.

**Qualification flow**: run A without `--require-new-external` (installed-first ordering shown); run B with it: HIVE's own search must discover and stage a GitHub tool (candidates are not named anywhere in repo or prompts); gate B only counts if the selected candidate is a GitHub tier-3 hit whose vendored tree is non-empty and imported by the adapter (check by static scan of body imports vs `environment.packages`).

## 7. Slices, tests, commands

All test commands: `python -m pytest <files> -q --basetemp C:/t/<name>`; Docker-gated tests `skipif` no docker like `tests/test_experiment_container.py:14`. The full suite is not run by this design.

**S1 kernel: contract v2, envelope v2, image/limits plumbing, v3 admission, fixture suite.**
Files: capcontract, isolation, experiment_compare, discovery (prompt/harness hooks), capability_registry, hive_admission, goal_runner, `schemas/capability-contract-v2.json`, `evaluator/g2/*`, `capabilities/image.asset-match/*` (fixture author, parallel), types rows.
Tests (`tests/test_g2_kernel.py`, `tests/test_g2_fixture.py`): v1 contracts and an admitted v1+v2 store still load and execute unchanged; v2 schema rejects network true / oversized limits / unknown env kind; `build_env` base64 limits; local-ID image inspect fail-closed (fake docker runner); harness policy permits staged names, refuses star-import/`os`; v3 statement sign/recheck round trip with fake docker (ID mismatch -> Refused); fixture generator determinism, ground truth == oracle for 30 seeds, scripted baseline < n, private dir not in repo; core grep test.
`python -m pytest tests/test_g2_kernel.py tests/test_g2_fixture.py tests/test_capcontract.py tests/test_g1_fix.py tests/test_capability_admission.py -q --basetemp C:/t/g2s1`
Risks: touching `run_isolated` signature (keep defaults); v1 pins must not move (do not edit evaluator/c3 or g1).

**S2 search + card.** `acq_github.py`, `repo_intel.clone_pinned`, `acq_card.py`, `acq_policy`, ranking, search tiers 1-2.
Tests (`tests/test_g2_search.py`, fake `transport`): 403/429 backoff then NETWORK_UNAVAILABLE; cache hit makes no request; token never in cache key/log (grep captured logs); malformed JSON, oversized body, bad `owner/name` refused; card from a local fixture git repo (real git, no network) is deterministic, license mismatch -> unknown -> rejected; hostile README never leaves the fenced excerpt; ranking ignores stars; tier order and `--require-new-external`.
`python -m pytest tests/test_g2_search.py tests/test_repo_intel.py -q --basetemp C:/t/g2s2`
Risks: unauthenticated search is 10 req/min; ~30 requests/run budget with 7 s spacing; clone size cap may reject large repos.

**S3 staging.** `acq_stage.py`.
Tests (`tests/test_g2_stage.py`): lock generation from a local wheel dir (fake downloader); `.pth`/traversal/license/size refusals; Dockerfile text snapshot (no network, no RUN beyond pip install); docker-gated: build offline from a tiny local wheel, ID recorded, `docker save`/`rmi`/`docker load` restores identical ID, import smoke as non-root offline, `docker ps -a` shows no leftovers.
`python -m pytest tests/test_g2_stage.py -q --basetemp C:/t/g2s3`
Risks: image tar size (Pillow+numpy ~150-250 MB) on D:; Windows Docker path quoting; some tools only ship sdists (rejected by policy: record, next candidate).

**S4 state machine, proposer, qualification.** `acquire.py`, `acq_propose.py`, goal hook, dispatch class, `scripts/g2_qualify.py`.
Tests (`tests/test_g2_acquire.py`, fake transport + stub model endpoint `m2_stub_server.py` + fake stager): every transition incl. each terminal reason; max 3 attempts then CANDIDATES_EXHAUSTED; kill/restart at each stage resumes without a second model call or build (call counters); STOP honoured; unverified candidate cannot reach ADMIT; admission refusal path; manifest lists all attempts with reason and `cost_usd` 0.
Real script, live: `python scripts/g2_qualify.py --phase run --store C:/t/g2store --seed-private <S> --require-new-external --model openai/gpt-oss-20b --out build/g-series/g2/run-<id>` (live GitHub, local LM Studio, Docker), then `python scripts/hive_admission.py admit --store C:/t/g2store --exp <id> --key <external key>`, then in a **fresh process** `python scripts/g2_qualify.py --phase reuse --store C:/t/g2store --unseen-seed <T>` which optionally `docker rmi`s the staged image first to prove tar reload, runs `run_goal`, and checks oracle PASS and replay/receipt hashes. Writes `manifest.json` (schema `hive-g2-run-v1`): goal, contract sha, search queries + result digests, every attempt {repo, revision, license, card sha, rejection reason or receipt}, adapter sha, image ID/tar sha, dev + acceptance results, model id, calls/tokens/wall, `cost_usd`, fixture author disclosure, commit and command lines.
Risks: gpt-oss-20b may not produce a working adapter for a given tool in 3 attempts (honest terminal result, no gate); GitHub may return nothing usable (NETWORK/NO_CANDIDATE are valid outcomes); GPU/OBS contention (check coordination file first).

## Decisions needed from the conductor

1. Staged-package declaration is `staged:true` plus a resolved list in the statement, not names in the contract (section 4). OK?
2. Derived images are bound by local image ID plus `docker save` tar kept in the store (no registry). OK?
3. Vendored-source tool install (no repo build step; wheels-only deps) means tools needing compiled extensions or sdists are rejected. Acceptable?
4. License allowlist: add HPND/MIT-CMU (Pillow) or restrict deps to allowlist strictly.
5. Oracle and evaluator need host Pillow 12.3.0 (installed); record its version in receipts.
