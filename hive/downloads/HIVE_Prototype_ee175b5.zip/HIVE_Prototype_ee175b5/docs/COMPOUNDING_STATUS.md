# HIVE Compounding build: status and next action (26 Nov 2026)

Branch `build/compounding` (local only; worktree `C:/hive-work/cmp`, fix worktree `C:/hive-work/cmp-fix`). Nothing is published; the published runtime is still `033089b`.

| Gate | Status | Checkpoint |
|---|---|---|
| G0 baseline | PASS | `docs/CHECKPOINT_G0_G1.md` |
| G1 general capability contract | PASS | `docs/CHECKPOINT_G0_G1.md` |
| G2 GitHub-to-capability bridge | PASS | `docs/CHECKPOINT_G2.md` |
| G3 capability composition | PASS | `docs/CHECKPOINT_G3.md` |
| G4 compounding learning | NOT STARTED (budget) | pre-registration draft below |
| G5 interchangeable brains | NOT STARTED | |
| G6 bounded self-teaching queue | NOT STARTED | |

The milestone is **partially complete**. General acquisition, restart reuse and composition are demonstrated. Measured compounding, cross-model transfer and bounded self-teaching are not.

## Spend
Owner ceiling $220 (raised from $120 on 25 Nov). Coding agents at this checkpoint: about $200 cumulative (this session about $84 list price). Paid inference $0; every model call was local gpt-oss-20b.

## G4 pre-registration (draft; freeze before running)
- **Bottleneck observed in G2 (evidence: gate runs 1–12):** turning a repository into a working adapter took most attempts. Candidate choice was the other cost: reading the tool's callable interface and its runtime needs (file paths, optional imports, removed APIs).
- **Helper to acquire through the same lifecycle:** `repo.interface-summary`. Input: a pinned vendored tree. Output: a typed summary of callables, their argument kinds (path, bytes or PIL image), optional runtime dependencies, and a minimal working call checked in the staged image. It has its own contract, independent fixtures (synthetic tool trees with known interfaces) and its own evaluator. Kernel and admission stay untouched.
- **Arms:** A, no helper; B, helper admitted and its summary placed in the proposer prompt; C, the same code as B with the helper disabled. Each arm gets an isolated store snapshot and caches, and the same model, seed, budgets and hardware.
- **Task set:** at least 12 held-out acquisition tasks (new contracts and fixture suites, each solvable by at least one MIT/BSD/Apache pure-Python tool), with no repository used in G2/G3. If fewer than 12, the limitation is stated up front.
- **Decision rule:** compounding is claimed only if B shows no loss of success versus A and C, and a median reduction of at least 20% in acquisition tokens or wall time versus both. Cumulative cost includes creating the helper. Otherwise the result is reported as negative or inconclusive.
- **Estimated cost:** authoring 12 contracts and suites plus the helper and the harness is roughly $35–50 of coding agents; the runs are local at $0. This exceeds the remaining roughly $20, so it **needs the owner's decision**.

## Exact next action
Owner decision on G4 budget. If yes: freeze the pre-registration above as `docs/G4_PROTOCOL.md` (hash-pinned), author the 12 held-out tasks and the helper contract on `build/compounding`, then run the three arms with `scripts/g2_qualify.py`-style drivers on isolated store copies.
