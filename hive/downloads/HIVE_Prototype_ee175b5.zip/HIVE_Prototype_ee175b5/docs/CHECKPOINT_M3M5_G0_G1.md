# HIVE M3–M5 completion plan: G0 + G1 checkpoint (26 Nov 2026)

Plan: owner handoff `HIVE_M3M5_Prototype_Completion_and_Compounding_Learning_Build_Plan_2026-11-26.md` (G0–G8). Branch `build/prototype` (`C:/hive-work/cmp`, local only, never pushed). Base `4c0afa5` (code last tested at `73515df`; doc-only commits since). Head `2acd268` plus this doc.

## Verdict
- **G0: PARTIAL.** Code, gates and budget reconciled below. Provider-side billing is not reconciled (owner side). Dispatch, isolation and budget controls rely on existing test evidence and were not re-audited.
- **G1: PASS on the core gate.**
  - A raw site snapshot folder runs end to end through `hive operator goal` with no prepared export.
  - The result is byte-identical to the sealed evaluator answer on an unseen release.
  - Two prerequisites, `site.ref-extract` and `site.ref-resolve`, are **operator-authored**. They are labelled and signed that way and are not counted as learned. Local gpt-oss still cannot learn them; that negative result is kept.

## G0 reconciliation
| Requirement | Actual path / evidence | Status | Smallest next patch |
|---|---|---|---|
| Current code and branch | `build/prototype` @ `2acd268`; worktrees p-a..p-e and cmp-fix untouched; run worktree `C:/hive-work/g1run` detached at head | DONE | – |
| T01 regression | 1855/6/0 @ `73515df`. Rerun on `2acd268`, real Docker, in the clean worktree `g1run`: **1868 passed / 11 skipped / 2 failed** in 24 min (`C:/hive-work/g1-full-suite-2acd268.log`). Both failures need private data that is absent from a fresh worktree: `.hive/c3-private` for `test_capability_admission::test_real_container_end_to_end`, and gitignored `build/m2/data` for `test_m2_harness::test_integration_proof_on_public_data`. Both **pass** in `C:/hive-work/cmp` on the same code. The first also fails in a fresh worktree at the old base `4c0afa5`, so it predates this session. The extra 5 skips are M2 evaluator tests that skip without the private area. | PASS (environment caveat) | make both tests create their own private data in a temp store |
| Dispatch, retries and fallback governed; atomic budget; STOP; isolation (G0.4–5) | T07–T09, T16, T17, T19 PASS (test), `docs/CHECKPOINT_PROTOTYPE.md`. No new dispatch path this session: the authored route makes 0 model calls and spends only container runs from its own frozen budget | PARTIAL (carry-over) | independent re-audit before any paid dispatch |
| Spend (G0.6) | Owner ceiling $400 cumulative (`.hive/agent-budget.json`, `hard_ceiling_raise_2026_11_26`), alert $350, reserve $50. Before this session about $286 (estimate). This session: **$11.48** list price (Opus $7.65, Sonnet $3.83, `agent_usage_tally` over session + subagents). Runtime paid inference 0; NIM 0 calls; local gpt-oss about 80 proposals at $0 | PARTIAL | the owner compares Anthropic/NIM billing; about 10 earlier NIM diagnostic calls are off-ledger (under $1) |
| Gate map | G1 → T05, T12/T13 prerequisites, T20 demo A on raw input. G2 → T05, T06. G3 → T18. G4 → T02, T10, T12–T15. G5 → T20 + package | DONE | – |

## G1: what changed
| Commit | Change |
|---|---|
| `39ede89` | Root cause of the unlearnable extract: dev feedback showed `expected[:300]` and `got[:300]`, which are identical for sorted-JSON outputs. It now shows the first differing row whole. The system prompt now says `re.compile`-style attributes are refused (one call had been wasted on it). |
| `f344431` | Ingestion: a raw folder plus a `site-scope-v1` input become `site_pages` / `site_manifest` as builtin **packing** steps inside the goal run. They reuse `export_site_inputs.export()` and do no extraction or resolution. `committed_at` must come from the operator and is never invented. `walk()` no longer follows symlinks or junctions out of the snapshot. |
| `b846961` | A stub (the same output for every dev case) and an exact repeat proposal now get explicit feedback. Before, a repeat replayed an unchanged prompt. |
| `743972c` | The dev split now covers every hidden error class for extract (`two-files`) and resolve (`bad-row`, `pages-not-int`). `tests/test_p_dev_split.py` checks this for all suites; the three admitted suites are listed as KNOWN_GAPS until they are requalified. |
| `2acd268` | Operator-authored route `hive operator cap author <cap> <body.py> --author <label>` with the same gates as a proposed candidate: static check, dev cases, a fresh hidden set judged in a separate process, receipt re-check and signed admission. `route` and `author` are signed. Bodies are in `build/g1/authored/`, written from `spec.md` plus public dev cases only, with no oracle access. |

## Live learning campaigns (local gpt-oss-20b, $0, fresh store each)
| Store | ref-check | ref-extract best | ref-resolve best |
|---|---|---|---|
| s9 (`39ede89`) | admitted, 1 call | dev 2/6 (stub replies) | dev 6/6, hidden fail 3/24 |
| s10 (`b846961`) | admitted (stub → code via the new feedback) | dev 6/6, hidden fail 3/24 | dev 6/6, hidden fail 1/24 |
| s11 | admitted | dev 6/6, hidden fail 2–3/24 | dev 6/6, hidden fail 2–3/24 |
| s12 (`743972c`) | admitted | dev 3/7 | dev 8/8, hidden fail 4–6/24 |

Each campaign is 9 + 9 + up to 3 proposals, within the plan's limit of 20. Stopped after four campaigns, as the plan requires; hidden details were never opened. Evidence is under `C:/hive-work/demo/s9..s12`, `o9..o12`.

## G1 gate run (store `C:/hive-work/demo/s12`, evidence `C:/hive-work/demo/o12/evidence/g1/`)
Fresh real input: site release `e3fcce6` (23 Nov; never used by HIVE before). It was made by `git archive` with the same scope rules as before and kept read-only in `D:/HIVE-operator-inputs/mom-site/e3fcce6`. The evaluator answer was made beforehand with the export script (`--derive`) plus the ref-check oracle into `C:/hive-work/eval-private/g1/e3fcce6/`, which is outside the runtime's allowed root.

`hive operator goal "Check the references in this site snapshot against its files and list the broken links." e3fcce6 e3fcce6.scope.json --allowed-root C:/hive-work/demo/g1-inputs`
gives **VERIFIED**:
- Plan: pack-manifest, pack-pages, ref-extract (authored), ref-resolve (authored), ref-check (learned).
- Usage: 0 model calls, 3 container runs.

| Output | vs sealed evaluator answer |
|---|---|
| broken-refs.json (594 refs: **57 broken**, 202 ok, 225 out of scope, 110 not local) | byte-identical |
| ref-table.json, raw-refs.json, manifest, pages | byte-identical |

The same goal on raw release `0b3854a` is VERIFIED with **58 broken** / 664 refs, and every intermediate is byte-identical to the earlier exports. `hive operator receipt` lists `operator-authored steps: site.ref-extract, site.ref-resolve`. `overview` counts `operator-authored: active=2` separately from learned.

## Open limits (not claimed)
- T02 and T12 still count only **learned** capabilities, so the authored pair does not move them. T13 remains BLOCKED.
- When a capability is missing, the raw goal returns "no typed plan" with `gap_ref: null` instead of naming the missing step (G1 precision gap).
- The symlink and junction guard has no Windows test (it needs privilege). Folder intake hashes path and size, not content; the content actually used is bound by the step artifact hashes.
- The authored route allows 12 hidden-gate tries per capability, and every try reveals a pass count.
- Dynamic JavaScript-generated links are outside the spec; external links are classified, not checked online.

## Next (earliest remaining gate)
G2: real-image matcher repair with three evaluator splits, plus an upstream acquisition on a non-site task. G3: governed model selection; the extract/resolve gpt-oss failure is its first routing test case. No paid inference without the owner's go.

## Rollback
`git checkout 4c0afa5` (previous checkpoint). The new route and ingestion are additive; old stores are unaffected.
