# COOP C0 source map (read-only; branch build/prototype @ 8fdc061)

All paths under `C:/hive-work/cmp/src/hive/` unless stated. "absent" = searched and not present.

## 1. Proposal loop (live path)

Live files: `discovery.py` (the loop), `acquire.py` (GitHub-repo route only), `goal_runner.py` (queues only), `cli.py`, `scripts/g3_qualify.py`, `scripts/hive_admission.py`.
NOT on the proposal path: `prototype_learning.py` (orchestrator structured-mission learning; imports `orchestrator`, `structured_data`), `experiment_driver.py` (OODA csv-profile experiment; no model call), `operator_runtime.py` (registry/exec/ledger counters, no proposals).

Chain for local-model learning (what produced demo s9..s12):
1. `hive operator goal` -> `cli.py:209-212` `G.prepare` + `G.run_goal`. With `allow_discovery`, `goal_runner.py:950-953` only QUEUES: `D.open_experiment(s, rec["gap_ref"])` (state DISCOVERY_QUEUED). With `allow_acquisition`, `goal_runner.py:944-947` queues `A.open_run(...)`. Nothing is proposed inline.
2. Run the queued experiment: `hive operator discover run --exp` -> `cli.py:230` `D.run_experiment(...requested_model=args.model, private_blobs=...)`; or `console.py:442`. Demo/campaign driver: `scripts/g3_qualify.py:84-127` `acquire_gap` = `D.open_experiment(..., budget=EXP_BUDGET, acq_run=CAMPAIGN, proposer_model=a.model)` then up to 3x `D.run_experiment` with `seed_best` carry-best between experiments (`g3_qualify.py:107-122`); then `H.admit` (`g3_qualify.py:129`). `prototype_demo.py` calls it (learn-a).
3. Repo route (not the ref-extract route): `acquire.py:380` `run` -> `_drive:418` -> `_attempt:317` -> `D.open_experiment` (`acquire.py:368`, frozen per-attempt budget `ab` at :358-360) -> `_run_exp:375` -> `D.run_experiment`.
4. `discovery.run_experiment:528` -> `_loop:573`.

Inside `_loop` (the "one proposal -> dev check -> next proposal with feedback" cycle, `discovery.py:628-737`):
- :629 stop when `rec["ledger"]["proposals"] >= B["proposals"]` (NO_QUALIFYING_CANDIDATE).
- :630 `msgs = prompt(rec, dev)` (:268) - spec + public dev cases + `rec["feedback"]` + `rec["best"]` body.
- :634 `_gate(... calls=1, proposals=1, in_tokens, out_tokens=256)` pre-checks every allowance.
- :636 `MD.plan(...)` dispatch decision; :648 builds a new `M.Model` per iteration (log dir `<exp>/model/`); :661 `_spend(calls=1)`; :663 `model.call(task_class, msgs, proposer_seed(fz, n))` (seed fn :568: `2026300000 + 100*(attempt-1) + n`).
- :667 `_dispatched` -> `model_dispatch.jsonl` row + `rec["dispatches"]`; :677 `rec["calls"].append({n,status,in_tokens,out_tokens,estimated,has_code})`.
- :680-689 `extract_code`; duplicate sha -> feedback only (:682-688, no proposal charged); else `_spend(proposals=1)` at :689, `rec["proposals"].append(prop)`.
- :704 dev check `_dev_run` (container, public cases) -> `prop["dev"]={n,pass_count}`; :709 `_note_feedback` keeps best-by-dev (`rec["best"]`, `rec["best_feedback"]`, `rec["feedback"]`) (def :797).
- :710 `continue` unless dev is perfect (pass_count == n). So hidden gate runs only for dev-perfect candidates.
- :715 hidden gate `_evaluate` (:413) -> separate process; :719 feedback "failed X of N hidden acceptance cases (details withheld)"; :727-737 PASS -> `rec.update(candidate_sha256, receipt, report)`, `raise _End("CANDIDATE_PASSED")`.
- Admission: `scripts/hive_admission.py:60` `admit(store_root, exp_id, key)` re-runs the evaluator (`_recheck`), signs, appends registry event. `cap_cli.improve:194` / `acquire._admit_and_execute:519` call it via injected `admit`.

Operator-authored route (`discovery.py:741` `open_authored`, `_authored:763`) bypasses the proposer; same gates, 0 model calls.

## 2. Model call

- Sender: `m2_model.Model.call` (`m2_model.py:373`) -> `_reserve:329` -> `_fetch:299` POST `/chat/completions` -> `_settle:359`. Body built by `_body:313` (+`body:278` system_prefix swap, hosted `request_extra`).
- Backend selection: `discovery.py:624-650` `requested` comes only from `requested_model` (CLI `--model`); `MD.plan` (`model_dispatch.py:38`) reads `configs/model_dispatch.json` classes/`qualified`; `M.apply_backend` (`m2_model.py:92`) binds endpoint/pins/approval for a non-default backend (default `openai/gpt-oss-20b`; hosted: nemotron-3.5-super-vl-120b (thinking off via request_extra), kimi-k3.1-pro; qwen3.8-27b unmeasured, DRAFT approval).
- Settable per call: `seed` YES (3rd arg of `call`, also `campaign`, `rnd` params at :373, currently None and logged in `model_calls.jsonl`). `temperature`: NOT per call; it is `pol["sampling"]["temperature"]`, set to 0.2 in `discovery.pol():91`; `_loop:638` already mutates `p["sampling"]["max_tokens"]` per iteration on a fresh `pol()` dict, so a per-call temperature override is the same pattern (m2_model `_body:313-316` reads `s["temperature"]`). `n`: `sampling.n=1` from `configs/m2_campaign_policy.json`; `call` reads only `choices[0]` (:395), so n>1 is unsupported: use separate calls. Messages (recipe instruction) are free via `msgs`.
- Returned: `{content, usage, status, attempts, seed}` (:397); logged row in `<exp>/model/model_calls.jsonl`: `kind, campaign, round, attempt, seed, model, endpoint, request_sha256, usage{prompt_tokens, completion_tokens, completion_tokens_details.reasoning_tokens}, tokens, response_model, latency_s, status, http_status`. Dispatch row (`MD.record`, `discovery._dispatched:807`): `call_id, class, requested/routed/executed_model, mode, reason_codes, reported_model, latency_s, tokens_in, tokens_out, cost_usd, called, error, ts`.

## 3. Budget / caps

- Discovery counters: `discovery.BUDGET:35` `{calls 6, proposals 3, container_runs 12, in_tokens 36000, out_tokens 6000, wall_s 900, max_tokens_per_call 4096}`; frozen per experiment as `frozen.budget` (`open_experiment` :185). `_spend:210` adds to `rec["ledger"]` and the store-wide `operator/discovery_ledger` (`LEDGER` :32) in one txn. `_left:221`, `_gate:239` (STOP, wall, then each allowance; raises `_End`).
- Store-wide cap: only for ad-hoc experiments (no `acq_run`/`authored`/`improve`): `_left:229-230` = `min(frozen - spent, BUDGET - global)`. Campaign/acq/authored experiments skip it (:227-228). Improvement: `IMPROVE_CAP_MULT=2` x BUDGET (:36, :222-226).
- M2 approval cap (owner artifact, must not change): `discovery.APPROVAL_CAPS:37` and `build/c-series/c3_inference_approval.json` `caps = {model_calls 6, proposals 3, container_runs 12, input_tokens 36000, output_tokens 6000, wall_minutes 15}`; enforced by `m2_model.approval_problems:177` (`a.get("caps") != pol["approval_caps"]` -> :214) on every non-stub `Model()`; hosted approvals in `build/prototype/approvals/nim-*.approval.json` carry identical caps. Raising any cap makes the Model refuse. Test `tests/test_discovery.py::test_approval_gate_and_caps:135` pins them.
- Client caps: `discovery.pol():89` `max_model_calls=6`, `max_tokens_total=42000`, `transport_retries=0`; `Model._cap:368` counts rows in `<exp>/model/model_calls.jsonl` (survives the per-iteration Model rebuild). Per call out cap: `_loop:638` `min(max_tokens_per_call 4096, out_tokens left)`; `Model._max_tokens:353`.
- Retry depth: `open_experiment.check:128-147`: 2 experiments per gap ad hoc; campaign (`acq_run`) up to 12 per run / 24 per gap; authored 12.
- Campaign budget used by demos: `scripts/g3_qualify.py:86` `EXP_BUDGET {calls 3, proposals 3, container_runs 10, in_tokens 24000, out_tokens 6000, ...}`; acquire route `acquire.py:358-360` `calls min(3,...)`, `proposals 3`, run-level `acquire.BUDGET:35` `model_calls 16`.
- Round of 3 today: each call is gated as `calls=1, proposals=1` (:634) but `proposals` is only incremented for a distinct code body (:689); a "round" of 3 candidates = 3 calls + 3 proposals = the ENTIRE experiment allowance (proposals 3), leaving no feedback/repair round in that experiment. Also `out_tokens` 6000 total cannot fund three 4096-token replies (observed replies 1.6-2.1k tokens, s10 d-3080a910 out_tokens 5809 for 3 calls). Cap-neutral options: one round = one experiment (3 candidates, then carry-best to the next experiment, as `g3_qualify.acquire_gap` already does); do not raise caps.
- Hosted dollars: `Model._reserve:329` reserves worst-case USD on `UsageLedger` (`usage_ledger.py:128 reserve`, `:107 record` settle, `:141 release`, `:145 outstanding_reserved_usd`) BEFORE the HTTP request; live hosted uses the single `~/.hive-spend/hosted-ledger.jsonl` (`HostedLedger`, budget `configs/model_dispatch.json budget.remaining_usd 5.0`); local/stub use `<exp>/model/usage-ledger.jsonl`. Reservation is per call, so 3 calls = 3 reservations automatically.
- `dispatch_gate.py` (`DispatchGate.begin/finish`), `governor.py`, `model_route.py`: NOT on the discovery proposal path (only `orchestrator.py:157,546` and `experiment_runner.py:7`); `model_route.shadow_route` is called only inside `DispatchGate`. Do not wire C1 through them.

## 4. Existing records that can hold candidate/recipe data (no new schema)

- Experiment record `operator/discovery/<exp_id>` (Store kv, set by `_save:207`; written freely, only `frozen` is hashed into `exp_id`/`frozen_sha`): top keys `baselines, best, best_feedback, calls, completed_at, dispatches, exp_id, feedback, frozen, frozen_sha, gap_key, ledger, opened_at, pid, proposals, reason, stages`.
  - `proposals[]`: `n, sha256, static, dev{n,pass_count,[error]}, dev_ms, acceptance{candidate_sha256,n,pass_count,receipt_sha256,verdict}, feedback`. Extra keys are already added ad hoc (`objective`, `regression`, `duplicate_of` on `calls[]`), so `recipe_id, branch, parent_sha, seed, temperature, failure_category, round` can be added to the same dict.
  - `calls[]`: `n, status, in_tokens, out_tokens, estimated, has_code`; `dispatches[]` rows above (has `latency_s`, `call_id`).
- Files: `<exp>/model/model_calls.jsonl` (already has `campaign`, `round`, `seed`, `request_sha256`), `<exp>/model/usage-ledger.jsonl` (hash-chained; `task_id` = `<kind>#<attempt>`), `<exp>/reply-<n>.txt`, `<exp>/cand-<sha>.py`, `<exp>/receipt-*.json`.
- `frozen` may carry extra keys (admission recomputes hash from the whole `fz`, `scripts/hive_admission.py:113`; `check_frozen` checks only contract/evaluator/environment) - the place to declare recipe set + tie-break when the feature is on. Adding it changes `exp_id` only for feature-on runs.
- `cap_history.py` (`record` :17): executed-step rows only (`v, goal, status, ms, model_calls, fail, at`; closed enums); NOT suitable. `lineage.py` (`register` :19): P2 data_rule/code operators; unused by discovery; NOT suitable. Registry admit statement `lineage{gap_key, proposer_model}` (`hive_admission.py:85`) could take a `recipe` string only if admission is edited (avoid).

## 5. Runtime check vs final evaluator

- Dev check: `discovery._dev_ok:374` via `EC.run_isolated` (container, public cases from `capabilities/<cap>/suite/gen_public.py`, `dev = gen_public.cases()` :577). Static check `_static:319`.
- Hidden gate: `discovery._evaluate:413` -> `_launch:389` -> `run_bounded([sys.executable, "-I", evaluator/g2/evaluate.py, --private <dir>, --set <sha>, ...])`, own process; receipt re-verified by `receipt_problems:396`. Private cases are generated by `gen_private` at `open_experiment` (:134-139) into `.hive/c3-private` (`PRIVATE:31`; demo uses an external dir); only the set hash enters the store. Location notes only: `C:/hive-work/eval-private`, `.hive/c3-private`, `.hive/m1-private`, `.hive/m2-private` (not opened).
- Proposer/selector isolation: `prompt()` (:268) takes only the frozen spec, public dev cases, feedback, best body; `tests/test_discovery.py::test_proposer_inputs_contain_no_private_bytes:243` asserts no private bytes in requests/store and that discovery.py never names `cases.json`/`oracle.expected`. Hosted calls additionally pass `data_problem` (`m2_model.py:58`).
- Known leaks: (a) feedback text at `discovery.py:719` reveals hidden fail count per hidden-gate try; (b) the store `proposals[].acceptance.pass_count` and `rec["receipt"]` hold the hidden pass count, readable by any code with Store access - a C1 selector must not read `acceptance` of non-selected candidates, and must not run the gate for more than one candidate per round; (c) a differential run on extra inputs must use only public/spec-derived inputs (new generator), never gen_private. Same-OS-user filesystem access to the private dir is not sandboxed (process/argument separation only).

## 6. Smallest patch points

1. `discovery._loop` single-call block (:630-689): wrap "build msgs -> gate -> model.call -> extract code" into a helper called once (feature off) or up to 3 times (feature on) per round, each call independent (same `msgs` from `prompt(rec, dev)` before any candidate is recorded; recipes only vary seed/temperature/extra instruction line). Must keep `_gate(calls=1, proposals=1)` + `_spend(calls=1)` before EACH call so the ledger/Model reservation charge before dispatch.
2. `discovery._loop` after :709 (dev result): collect per-candidate `prop` (add `recipe_id, branch, seed, temperature, parent, latency_s, tokens, failure_category`), then a pure `select(candidates)` (dev pass desc, declared tie-break e.g. lower `dev_ms` then sha) and call the existing hidden gate :715-737 for ONE candidate only; feedback via `_note_feedback` stays the same.
3. `discovery.proposer_seed:568` / `pol():86`: add recipe-aware seed and a per-call temperature override (copy of `p["sampling"]`, as :638 already does).
4. `discovery.open_experiment` frozen dict (:181-186): add optional `"coop": {...}` key only when enabled (default off = byte-identical frozen, same `exp_id`). Flag plumbed from `cli.py:230` / `scripts/g3_qualify.acquire_gap:105`.
Optional: `_dispatched:807` to take `recipe_id`/`branch` extras (`MD.record(**extra)` already accepts them).

Tests covering this path (all stub endpoint + faked containers except one):
- `tests/test_discovery.py` (16 tests: budget, dedup, resume, private-bytes, forged verdict, approval caps), `tests/test_g2_carry_best.py`, `tests/test_g2_proposal_fixes.py` (incl. 3 proposals/attempt, 16-call run budget :159), `tests/test_p_feedback.py`, `tests/test_p_model.py`, `tests/test_p_hosted_backend.py`, `tests/test_p_fix_hosted.py`, `tests/test_usage_ledger.py`, `tests/test_model_dispatch.py`, `tests/test_g3_gate.py`, `tests/test_p_improve.py`, `tests/test_operator_authored.py`.
- Command (from `C:/hive-work/cmp`, pyproject sets `pythonpath=["src"]`):
  `python -m pytest -q --basetemp D:/tmp/c0 tests/test_discovery.py tests/test_g2_carry_best.py tests/test_g2_proposal_fixes.py tests/test_p_feedback.py tests/test_p_model.py tests/test_usage_ledger.py tests/test_model_dispatch.py`
  Stub server: `scripts/m2_stub_server.py` (test_discovery.py:20).

## 7. Baseline evidence on disk (`C:/hive-work/demo`)

- `s9..s12` are Stores (sqlite `hive.sqlite3`, kv `operator/discovery/<exp_id>`) + `discovery/<exp_id>/` dirs. Every row below is model `openai/gpt-oss-20b` (all `frozen.proposer.model`); 7 experiments per store (3 ref-extract, 3 ref-resolve, 1 ref-check) in s9/s10/s11; s12 has 9 (adds operator-authored extract/resolve, 0 calls).
- Per proposal: `proposals[].dev.pass_count/n`, `dev_ms`, `acceptance.pass_count/n/verdict` (hidden; do not use as selector input), `calls[].in_tokens/out_tokens`, `dispatches[].latency_s/tokens_in/tokens_out`, `model_calls.jsonl` `seed` and `usage.completion_tokens_details.reasoning_tokens`; budget in `frozen.budget` (calls 3, proposals 3, out_tokens 6000, from `EXP_BUDGET`).
- Examples (dev passes / n -> hidden): s10 d-3080a910 ref-extract att3: 6/6 on 3 proposals, hidden 21/24 each, 3 calls, 5809 out tokens; s11 d-4e890c88 ref-extract att3: dev 4/6 then 6/6 -> hidden 14/24; s9/s10 ref-extract att1: dev 2-3/6 only. ref-resolve: dev-perfect proposals score hidden 18-23/24. ref-check passes 24/24 by attempt 1-2 (CANDIDATE_PASSED in all four stores). Several runs end BUDGET_EXHAUSTED with `calls 3, proposals 1-2` (duplicates / no-code replies burn calls). Latency example 13 s per call, 2.1k out tokens (reasoning ~1k).
- `o9..o12`: demo operator evidence dirs (`evidence/learn-a/acquire-L1-site.ref-extract.json` etc.: `attempts[]`, `cost{calls, proposals, container_runs, in_tokens, out_tokens, wall_s}`, `state`), plus `receipts/`, `commands.log`. o12 also has `evidence/g1`.
- Evaluator-private data: not opened (`C:/hive-work/eval-private`, `.hive/*-private`).

## Risks / unknowns

1. 3 candidates per round consume the whole per-experiment `proposals 3` / `calls 3-6` allowance (approval-pinned): C1 needs one round per experiment (carry-best across experiments) or the brief must accept zero in-experiment repair; do not raise caps.
2. `out_tokens 6000` (in `BUDGET`, approval-pinned) cannot fund 3 replies at 4096; works only because replies are ~2k; thinking-on hosted models (nemotron, 4096 reasoning tokens) will starve it.
3. Hidden-pass counts sit in the same store record and in feedback text; a selector can leak them unless it is restricted to `prop["dev"]` and new public differential inputs, and the gate is called once per round.
4. Per-call temperature is not a parameter of `Model.call`; only `pol["sampling"]` is (a copy-and-override in `_loop` is assumed safe, but `Model.pol` is shared when `apply_backend` returns `pol` itself for the default backend - untested).
5. Not verified by execution: no tests were run; `hive operator discover run` budget default for ad-hoc experiments applies the store-wide `BUDGET` total (6 calls ever), unlike campaign runs - confirm which launch path C1 targets.
