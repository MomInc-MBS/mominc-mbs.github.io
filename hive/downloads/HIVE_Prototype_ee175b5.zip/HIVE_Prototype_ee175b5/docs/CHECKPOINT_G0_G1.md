# HIVE Compounding build: checkpoint G0 + G1 (25 Nov 2026)

Plan: `docs/COMPOUNDING_BUILD_PLAN.md`. Branch `build/compounding` (local only, worktree `C:/hive-work/cmp`, `.hive` junctioned to `D:/Repos/hive-ai/.hive`). Machine-readable manifest: `build/g-series/g1/manifest.json`.

## G0 baseline: PASS
- Source `626b2ec` (published runtime `033089b`; 626b2ec adds docs and logs only).
- Full suite, fresh run: **1114 passed / 3 skipped / 0 failed** in 35 min (`build/g-series/g0/full-suite.log`).
- Published inventory acquisition + fresh-process reuse (C6 journey, local `openai/gpt-oss-20b`, 1 call, $0): **13/13 PASS** (`build/g-series/g0/c6-summary.json`).
- Budget: the $120 ceiling (about $116.50 spent) was raised by the owner to **$220** for this plan ("Raise limit, full plan", 25 Nov). Recorded in `.hive/agent-budget.json`.

## G1 general capability contract: PASS
Commits `db64c3a`, `fa24ddc`, `456873b`, `74a97c0`. Design `docs/G1_DESIGN.md`. Review `build/g-series/g1/REVIEW.md`.
- A versioned contract (`schemas/capability-contract-v1.json`, `capabilities/<id>/contract.json`, `src/hive/capcontract.py`) drives discovery, admission (v2 statements embed the contract), registry recheck and retained execution. v1 statements still load and execute unchanged.
- Inventory knowledge lives in `capabilities/inventory-diff/contract.json` + the byte-unchanged `evaluator/c3`; core modules carry no task identifiers (enforced by a test).
- Second fixture `text.interval-merge` (arity 1, plain text, property oracle) runs through the same core path as inventory-diff, including signed admission and reuse from a fresh process (`tests/test_g1_fixture.py`, real Docker).
- Host-side evaluator, oracle and verifier launches kill the whole process tree on timeout (`src/hive/bounded.py`); every step is clamped to one goal deadline; the planner keeps the old first-match plan and only searches wider when that finds none.
- Gate evidence on `74a97c0`: full suite **1197 passed / 3 skipped / 0 failed**; C6 journey **14/14 PASS** (`build/g-series/g1/c6-summary.json`).
- Behaviour change found by the real-path journey: a gap no contract declares (`inventory_file x2 -> inventory_diff` on a store without imported capabilities) is now refused before any model call; before G1 it opened the hard-coded inventory experiment. Step 9e now imports the bundle like the main store; the new step 9f asserts the refusal. The first, failing run is kept in `build/g-series/g1/c6-run.log`.
- Independent review: Opus found a HIGH hole at `fa24ddc` (a store writer could choose the evaluator run during admission; proof of concept confirmed). Fixed in `456873b` (evaluator path and suite only from the contract, refusal before launch, real-launch tests). The re-check found a planner regression (N1), fixed in `74a97c0` (300-mix sweep: new plan == old plan wherever the old planner found one).

## Limits (not claimed)
- G1 proves generalization of the core path, not autonomous acquisition: the fixture's proposer is a stub that returns a checked-in adapter.
- Windows Job Object assignment has a start-up race (stdlib has no suspended start); a failed assignment kills and fails closed.
- v1 statements take `artifact_name`/`format` from the unsigned repo contract; both are validated and fail closed.

## Cost
Coding agents (list price, conductor + subagent transcripts): this session $29.37 to G1 close, cumulative about $145.87 of $220. Paid inference $0.

## Rollback
`git checkout 626b2ec` (or use the published `033089b` package). The branch is local and nothing was published.
