# Prototype domain: the public MOM Inc website (site.* capabilities)

Branch `build/p-b`, base `60a2474`. Fixture author: Sol-B (a conductor-side agent, not Ian). This adds a real-data domain for the three prototype demonstrations
(`docs/PROTOTYPE_PLAN_M3_M5.md` 3.1; preflight T02, T13, T20). It adds contracts, independent suites and type rows only. There is no adapter anywhere in the repo:
the local model writes each adapter later through the normal discovery path, and the hidden fixtures decide admission.

## 1. Real inputs and the export script

Source: two releases of the public site, read-only, in `D:/HIVE-operator-inputs/mom-site/` (`2633d9b` is older, `0b3854a` newer; scope, excluded sections and
over-5 MB files in `<commit>.SCOPE.json`). `scripts/export_site_inputs.py <snapshot_dir> <scope_json> <out_dir> [--committed-at ISO] [--derive]` writes, byte-for-byte
deterministically (sorted keys, LF, no timestamps of its own), nothing synthetic:

| File | Schema tag | Content |
|---|---|---|
| `site-manifest-<commit>.json` | `site-manifest-v1` | `commit`, `committed_at` (UTC, from `git log` of the site repo), `excluded_prefixes` (the scope's excluded top-level sections as `name/`, plus the two over-5 MB files by path), `files:[{path,bytes,sha256}]` for every file on disk |
| `site-pages-<commit>.json` | `site-pages-v1` | `commit`, `subset`, `pages:[{path,text}]` for every `.html`, `.htm`, `.css` file |
| `raw-reference-table-<commit>.json` (`--derive`) | `raw-ref-table-v1` | the `site.ref-extract` oracle run over the pages: the direct input of the `site.ref-resolve` learning goal |
| `reference-table-<commit>.json` (`--derive`) | `ref-table-v1` | the `site.ref-resolve` oracle run over that raw table: the direct input of the "check these references" goal |

Names carry the commit so two releases can be selected together (input names must be unique). Subset rule: all pages are kept; only if the serialised file would exceed
1,900,000 bytes are whole top-level sections dropped, largest first, and listed in `subset.dropped_sections` (undecodable files go to `subset.undecodable`). Neither real
snapshot needed it. Exports are in `D:/HIVE-operator-inputs/mom-site/exports/<commit>/` (outside git):

| Commit | manifest | pages | raw reference table | reference table | files / pages / refs |
|---|---|---|---|---|---|
| `2633d9b` (2026-11-25T21:42:32Z) | 53,569 B | 313,475 B | 52,930 B | 81,983 B | 390 / 72 / 649 |
| `0b3854a` (2026-11-26T07:25:30Z) | 68,803 B | 370,479 B | 54,349 B | 84,179 B | 501 / 77 / 664 |

All are far under the 2 MiB input limit. The two real snapshots use only quoted attribute values, so the simplified grammar of section 2 gives byte-identical reference tables to the old full grammar (checked). Real results (by the oracle, for later comparison with the adapters): `2633d9b` 57 broken, 250 ok, 232 out of scope, 110 not local;
`0b3854a` 58 broken, 262 ok, 232 out of scope, 112 not local; release diff older `2633d9b` to newer `0b3854a`: 111 added, 0 removed, 45 modified, 345 unchanged, +10,528,859 bytes.

## 2. The capabilities (all genuine gaps: nothing admitted produces their output type)

| Capability | Inputs (types, arity) | Output type | Artifact | Spec |
|---|---|---|---|---|
| `site.ref-extract` | `site_pages`, 1 | `raw_reference_table` (`raw-ref-table-v1`: page, kind, raw) | `raw-refs.json` | 2,527 B |
| `site.ref-resolve` | `raw_reference_table`, 1 | `reference_table` (`ref-table-v1`, unchanged) | `ref-table.json` | 2,534 B |
| `site.ref-check` | `reference_table` + `site_manifest`, 2 (typed slots, told apart by `schema`) | `broken_ref_report` | `broken-refs.json` | 3,320 B (unchanged, already admitted live) |
| `site.release-diff` | `site_manifest`, 2 (older/newer decided by `committed_at`, never by order or name) | `release_change_report` | `release-changes.json` | 2,815 B (unchanged; oracle 56 lines: not clearly over) |
| `site.ref-check-alt` | identical interface to `site.ref-check`, own id and artifact name | `broken_ref_report` | `broken-refs-alt.json` | shares ref-check's suite |

Each has `contract.json` (v2, pinned image, stdlib `json`/`base64`/`re` only, no network, 60 s, 1 MiB output; the contract schema allows no other stdlib module, so `urllib.parse` and `posixpath` are not
permitted) and `suite/` with `spec.md` (the only thing the proposer sees; complete grammar, no hidden data), `oracle.py` (independent, needs only the input env), `gen_public.py` (6 dev cases, the first a
hand-written worked case with the expected rows written out by hand, plus the shared builder), `gen_private.py` (hidden set from a seed, hash-only output, 24 cases, about 30% ERROR cases), `baseline.py`
(hand-written weak baseline that fails acceptance). Truth is by construction: pages are written from known raw values and spellings, a site tree is built before its references, the newer manifest is
derived by recorded edits. The oracle is checked against that truth over hundreds of seeds.

**Negative result kept: the first `site.ref-extract` was not acquirable.** The first design was one capability, `site_pages` to a classified `ref-table-v1`, with a 5.6 KB spec that asked for a complete
hand-written HTML tokenizer (unquoted values, bare attributes, `<` edge cases) plus URL resolution. In the live demo (`C:/hive-work/demo/s1/discovery/d-74b5b1d89e3fb9eb7f77/`, `reply-*.txt`,
`model/model_calls.jsonl`) the local proposer (openai/gpt-oss-20b, "Reasoning: low", at most 2,000 output tokens per call, 3 calls per experiment) returned `def run(env): return "ERROR"` three times:
the answer cannot fit in one 2,000-token reply. `site.ref-check` (3.3 KB, small oracle) was admitted on its first attempt (1 call), so the fix is to size the work, not the model. That evidence stays as it is.
The git history keeps the original suite (`a62f671` and before).

The split: each half has a spec of at most about 2.5 KB and an oracle core of at most about 80 lines (tested: `test_split_capabilities_fit_one_small_proposal`).
- `site.ref-extract` is the scan only. Simplified grammar a short regex function can do: `href`/`src`/`srcset`/`style` attributes written with double or single quotes, `<style>` blocks and CSS pages
  (`url()` quoted or not), comments and `<script>` bodies skipped, no entity decoding, no unquoted attribute values, values never contain `>`. The output keeps the raw text.
- `site.ref-resolve` is classification (anchor, external, scheme, escapes-root, local), query/fragment cut, percent-decoding (UTF-8, stray `%` kept) and path resolution (`.`, `..`, `//`, `/` root,
  directory targets end in `/`). Its output is byte-compatible with the old extract output: the new oracle was compared with the old one over 150 seeds (3,388 rows) and over both real snapshots.
Edge-case depth of the hidden fixtures is kept inside the simplified rules: case-sensitive paths, `../` beyond the root, `%2e%2e` and `%20`/UTF-8, srcset descriptors and stray commas, `url()` quoting and
spacing, duplicates (one row each), empty pages, comments, scripts and `<style>` comments that must not be read, uppercase and single-quoted attributes, `data-src`, query and fragment stripping, directory
references, schema/commit/pages/row validation errors. For `site.ref-check`: out-of-scope prefixes, commit mismatch, duplicate manifest paths. For `site.release-diff`: equal timestamps.
`site.ref-check-alt` points at the same suite as `site.ref-check` (with its own `artifact_name` because `capcontract` rejects two contracts that share one).

## 3. Type rows (`configs/capability_types.json`, new rows only)

Input types `site_pages` (`site-pages-v1`) and `site_manifest` (`site-manifest-v1`) are typed by their `schema` tag. Deliverables: `raw_reference_table` (`raw-ref-table-v1`, keywords
`raw reference|reference scan`), `reference_table` (`ref-table-v1`, keyword `reference table`, input type `raw_reference_table`), `broken_ref_report` (`broken-refs-v1`,
`broken ref|broken link|dead link|missing link`), `release_change_report` (`release-changes-v1`, `release change|release delta|what changed in the release`). The keywords are disjoint
(checked in `tests/test_p_site.py`; a goal that says "raw reference table" would match both of the first two, so the sentences below avoid it); existing mapping is unchanged.
`tests/test_goal_runner.py` listed the deliverables literally; its expected set now has the eleven.
A top-level `held_out_workflows` list declares H1 to H3 (metadata only; the planner ignores it).

## 4. Learning goals (direct single-step; each is a typed gap that names exactly its contract)

Input files are under `D:/HIVE-operator-inputs/mom-site/`.

| Goal | Sentence | Input files |
|---|---|---|
| L1 (site.ref-extract) | "Scan the pages of this site for every raw reference." | `exports/2633d9b/site-pages-2633d9b.json` |
| L1b (site.ref-resolve) | "Resolve these scanned page references into a reference table." | `exports/2633d9b/raw-reference-table-2633d9b.json` |
| L2 (site.ref-check) | "Check these references against the site manifest and list the broken links." | `exports/2633d9b/reference-table-2633d9b.json`, `exports/2633d9b/site-manifest-2633d9b.json` |
| L3 (site.release-diff) | "Produce the release change report for these two site manifests." | `exports/2633d9b/site-manifest-2633d9b.json`, `exports/0b3854a/site-manifest-0b3854a.json` |

The raw and resolved tables were produced by the oracles (evaluator side), not by an adapter. Goal B (reuse and extend) can reuse `site.ref-extract` and `site.ref-resolve` on the other release:
with both admitted, the H1 inputs below leave exactly one gap, `site.ref-check` (`missing_step` returns the reference-table plus manifest signature; tested). With only one of the first two admitted,
two steps are missing and `missing_step` names nothing (tested). The prototype's Goal C is H2.

## 5. Held-out workflows (T13): raw inputs, planned by chaining admitted capabilities, zero new code

Run after the capabilities are admitted, in a fresh process. The planner joins by type, so each workflow uses distinct input types (or repeats that feed one n-ary step); nothing
pairs two same-typed inputs across different steps (input order was tested both ways).

| Id | Sentence | Inputs | Expected chain | Why not a learning goal |
|---|---|---|---|---|
| H1 | "Check the references in these site pages against the site manifest and list the broken links." | `exports/0b3854a/site-pages-0b3854a.json`, `exports/0b3854a/site-manifest-0b3854a.json` | `site.ref-extract`, `site.ref-resolve`, `site.ref-check` (3 steps, linear chain then join with the manifest) | gives raw pages, not an intermediate table; only solvable by composing three admitted capabilities |
| H2 | "Write a reconciliation report: which of these pictures are copies, and how much space can I reclaim?" | the 20 pictures in `exports/images/` | `asset.properties`, `image.asset-match` (open-source dhash, G2), `report.reconcile` (3 steps, fan-out then join by type) | needs three capabilities, one of them the open-source one; real site images instead of seeded ones |
| H3 | same sentence | 19 of those pictures (all but `little-boyfriend-app-icons-icon-512.png`) plus `exports/asset-properties-images-19.json` (20 inputs, the goal cap) | `image.asset-match`, `report.reconcile` (2 steps) | a different DAG shape (the property step is skipped) over the same deliverable |

Composite deliverables share the output type of their last step (the planner plans toward a type, not a name), so H1 to H3 are declared as workflows, not as new type rows.

H3 as first declared needed 21 inputs (20 pictures plus the table) but `goal_runner.load_inputs` accepts at most 20. It now uses 19 pictures plus one JSON. The property table is the `asset.properties`
oracle run over exactly those 19 files (derived by the evaluator side, with the same four exact-duplicate pairs), so the table matches the pictures.

Real picture set (Goal C / H2 / H3): 20 PNGs, 1,374,850 bytes total, each at most 256 KB, copied unmodified from `0b3854a` to `exports/images/` with `PROVENANCE.json`
(original path, commit, bytes, sha256; sha256 re-checked against the files). They hold four exact byte-duplicate pairs (the two coach icons at 192 and 512 px in `apps/coach/icons` and `docs/moms-suite`; the pause-squat/slow-squat and
high-incline/low-incline pushup previews) and the same icon at 180/192/512 px for coach, corgi, misinformation, alarm, fuel and little-boyfriend. `asset-properties-images.json` (20 pictures, H2's reference) and
`asset-properties-images-19.json` (19 pictures, H3) are the `asset.properties` oracle run over those files (derived, not fabricated).

## 6. Tests and open risks

`tests/test_p_site.py` (oracles on hand-computed cases, generators vs oracle, baselines fail, contracts validate, evaluator pin equals the contract pin, spec and oracle size, extract then resolve then the
ref-check oracle, export script, goal mapping) and `tests/test_p_site_planner.py` (gaps, chains, the three-step H1, alt candidate, H1 to H3). Run with
`python -m pytest tests/test_p_site*.py tests/test_capcontract.py tests/test_g3_suites.py tests/test_goal_runner.py tests/test_g1_fixture.py -q --basetemp D:/tmp/fb1`.

Risks: (1) the grammar is a deliberately simplified HTML model (quoted attribute values only, no entity decoding, no `<base>`, no `@import`, no `poster`/`data-src`); a faithful model would not match the oracle on odd
real markup, but the spec states every rule, and the two real snapshots give identical tables. (2) Strict URL rules (`%2e%2e` acts like `..`) are an oracle choice, spelled out in `spec.md`.
(3) Prefix matching is plain string prefix; fixtures only use whole-segment prefixes except the stated `tv` rule. (4) Error cases with a wrong file count cannot occur through the goal runner (arity is
checked first); they only test the adapter's own guard. (5) Not yet run: a real model attempt at `site.ref-extract`, `site.ref-resolve` or `site.release-diff`; whether each now fits one 2,000-token answer is
expected from the size proxy, not measured. (6) `committed_at` comes from the site's git history, not from the snapshot directory. (7) `scripts/prototype_demo.py` (not owned here) still treats
`site.ref-extract` as the 2-step producer of the reference table: it needs the extra `site.ref-resolve` acquisition and the 3-step H1 chain, and H3 can use `exports/asset-properties-images-19.json`.
