# Open gap: HIVE should choose its own proposer model (owner note, 26 Nov 2026)

Owner (Ian), 26 Nov 2026: "Make a note that model choosing should be in hives capabilities and this gap needs to be filled".

## What happened
During the prototype demo the conductor picked proposer backends by hand:
- local `openai/gpt-oss-20b` failed `site.ref-extract` and `site.ref-resolve`;
- local `qwen/qwen3.8-27b` was too slow on this GPU (over 10 min per answer);
- hosted `moonshotai/kimi-k3.1-pro` timed out at 240 s per call;
- hosted `nvidia/nemotron-3.5-super-vl-120b-a12b` (thinking off) answered in about 15 s.

HIVE has the pieces but does not make this decision itself:
- a backend list and qualification;
- the spend gate;
- per-capability history (`cap_history`);
- receipts with latency and calls.

## Gap to fill (next milestone)
- Model selection becomes a HIVE capability. For each gap or acquisition, rank the qualified backends from measured outcomes:
  - success per contract class;
  - dev/hidden pass rates;
  - latency and timeouts;
  - cost per admitted capability;
  - remaining budget.
- Escalate along that ranking within the owner's approvals, for example local first, then hosted when local fails or stalls.
- Record the choice and the reason in the experiment's frozen protocol.
- Rules:
  - outcomes stay numbers and enums, never instructions;
  - only qualified backends with active owner approvals are eligible;
  - the spend gate and caps are unchanged;
  - the choice is evaluated on the same frozen fixtures, so it cannot weaken admission.
- Evidence to reuse: demo stores `C:/hive-work/demo/s1`-`s6` (per-call latency, finish reasons, dev/hidden pass counts by model).

## Status 26 Nov (prototype)
Filled, opt-in only:
- Evidence: `scripts/model_evidence.py` derives `build/coop/model_choice_evidence_v1.json` from the public screen files (sealed PASS/FAIL, ledger calls/tokens/wall, probe usd). Numbers and enums only, source sha256s recorded. Hosted usd is a probe per-call estimate (basis enum says so); unknown is null, never 0.
- Ranking: `src/hive/model_choice.py` `eligible` (MD-qualified AND `approval_problems` clean) and `rank` (sealed pass rate, calls/pass, wall/pass, usd/pass, local before hosted; no evidence = default ladder). Read-only CLI: `python scripts/model_evidence.py choose <cap>`.
- Auto mode: `g3_qualify.acquire_gap` with `--model auto` picks the top backend and freezes `model_choice` (backend, reason, rank, evidence sha) in each experiment. Without `auto` the frozen dict and exp_id are byte-identical.
- Escalation hint: a campaign with no dev-perfect public final (or MODEL_UNAVAILABLE) returns `escalate_to` = next ranked backend.

Not filled (owner decision):
- Automatic escalation campaigns: `escalate_to` starts nothing; caps and the spend gate are untouched.
- Changing the default route: gpt-oss stays the default; `auto` is never implied.
- Evidence is two capabilities x two backends x two repeats; kimi has no sealed evidence yet.
