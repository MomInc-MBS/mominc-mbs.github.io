# HIVE Compounding build: checkpoint G3, capability composition (26 Nov 2026)

Plan: `docs/COMPOUNDING_BUILD_PLAN.md` section 5. Code `af574d2` (planner, contracts, suites, script) plus `13be3b7` (campaign budget). Evidence: `build/g-series/g3/run3/manifest.json`.

## Verdict: PASS
| Requirement | Evidence |
|---|---|
| Planner ranks compatible capabilities and validates edges | Typed DAG planner: inputs fan out to several steps, produced types join by type, every edge is checked against the contracts, cycles are refused, plan size and search expansions are capped, and total cost is estimated before the run. Old goals keep their pre-G1 plans (the first-match path runs first; a comparison against HEAD differs only on the new composite goal) |
| Three distinct capabilities, at least one from G2 | `image.asset-match` (G2: `benhoyt/dhash`, statement `b4b129d8…`); `asset.properties` (local model, 1 call, dev 6/6, hidden **24/24**, receipt `3cee9c5e…`, signed admission); `report.reconcile` (1 call, hidden **24/24**, receipt `5ebbd4ff…`, signed admission). The last two came through the discovery lifecycle (local proposal → independent evaluator → signed admission), not GitHub |
| Held-out composite goal, no hard-coded route | Deliverable `reconciliation_report` exists only in the type table and its contract (asserted by test). The planner chose `report.reconcile(image.asset-match(inputs), asset.properties(inputs))` (1 alternative considered, 4 expansions, estimate 3 container runs) |
| Final artifact verified independently | composite: VERIFIED, `final_verified_by_independent_oracles` true (the report oracle applied to the upstream oracle outputs), reconcile.json `967764bf…` |
| Restart and repeat on new data | repeat phase in a **fresh process**, new unseen seed: VERIFIED, independently verified, reconcile.json `351cc14b…` |
| Reuse, model calls, cached vs fresh | Composite and repeat: 0 model calls, 0 proposal calls, 0 new experiments, 3 fresh steps and 0 cached replays each, about 3.5 s |
| Matched no-retention baseline | Same goal on a store with no retained capabilities: UNRESOLVED ("no capability contract declares this gap"), 0 calls. To match it, the store must first acquire all three capabilities, which this build measured at 11 + 1 + 1 = 13 local model calls and about 11 min of acquisition wall time. With retention: 0 calls and about 3.5 s |
| Regression | Full suite **1563 passed / 9 skipped / 0 failed** (`full-suite.log`); C6 journey **14/14** (`c6-g3.log`) |

## Failures and recovery (kept)
- Run 1: every experiment ended BUDGET_EXHAUSTED before any container ran, because the G2 store copy had already spent the store-wide ad-hoc discovery allowance (12 runs). That allowance was left as is. G3 acquisitions now run as a declared campaign (`acq_run = g3-composition-campaign`) with the acquisition-attempt budget: 3 calls, 3 proposals and 10 container runs per experiment, at most 3 carry-best experiments per gap, within the M2 approval caps.
- A misdirected launch of run 2 overwrote `run1.log` before I stopped it; run 1's failure reason is recorded above and in `run1/manifest.json`.
- Run 2: MODEL_UNAVAILABLE (the C6 journey unloads gpt-oss at its end). It failed closed with 0 calls. Run 3 passed after reloading the model.

## Limits
- One composite goal on one workload family. `asset.properties` and `report.reconcile` are simple stdlib capabilities, so composition is demonstrated, not difficulty.
- The `report.reconcile` step has no per-step oracle match flag; its output is verified by the final independent check.
- Fixtures were authored by a conductor-side agent independently of any adapter, not by Ian.

## Rollback
`git checkout 9566ee1` (G2 checkpoint). Nothing was published.
