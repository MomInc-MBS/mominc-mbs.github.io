# G1 review: 626b2ec..fa24ddc (build/compounding)

Reviewer: independent, read-only. Targeted runs only (`--basetemp C:/t/rv`, `-p no:cacheprovider`, no bytecode writes).

## Verdict: BLOCK

The fix is small (finding 1, about 10 lines plus one test). The rest of the change is ACCEPT WITH FIXES quality: the contract, the v1/v2 reader, the signed v2 statement, recheck on every use and the generic g1 evaluator all hold up. The gate also holds. `tests/test_g1_fixture.py -k docker` passed both capabilities (2 passed, 66 s) with real containers, a real `python -I` evaluator process, signed admission and fresh-process reuse. I found no task literals in the added core lines.

## Findings (most severe first)

### 1. HIGH: the store record picks which evaluator runs on the host, and admission trusts its receipt (regression)
- Where: `src/hive/discovery.py:240-241` (`--suite` and `_launch(args, rec["frozen"]["evaluator"]["path"])`), `discovery.py:213` (`CC.ROOT / evaluator`, where an absolute path wins), and `scripts/hive_admission.py:125`, where the admission re-run calls `D._evaluate(rec, ...)` with the store record.
- Admission checks four things: that `frozen_sha` recomputes, the contract sha, the pin value, and the receipt fields. It never checks that `frozen.evaluator.path` or `frozen.evaluator.suite` equals the contract's evaluator. `receipt_problems` only compares the pin string that the evaluator writes itself.
- Scenario: a store writer writes an experiment record with `frozen.evaluator.path` set to an absolute path to a script inside the store. It recomputes `frozen_sha` and `exp_id` and copies in the real pin and contract sha. The operator then runs `hive_admission.py admit`. The script runs as `python -I` on the host, outside any container, with read access to `%USERPROFILE%/.hive-admission/admission_ed25519`. Its forged receipt and per-case hashes match, so the authority signs an arbitrary body.
- Proof of concept: `D._evaluate` with such a record ran a scratch script. The script wrote a side-effect file and its receipt was accepted as `PASS`.
- Before G1 the path was hard-coded as `EVAL_DIR/evaluate.py`. The design doc (§ Admission) says "the re-run uses the same evaluator path from the contract". No test covers this, because `_launch` is monkeypatched everywhere.
- Fix:
  - In `_evaluate`, take the evaluator path and the suite (`suite_ref` when `suite_arg` is set) from `contract_of(rec)["verification"]`, through `CC._rel`.
  - In `_recheck` and `_loop`, refuse when `fz["evaluator"]["path"]` or `fz["evaluator"].get("suite")` differs from the contract.
  - Make `fz["contract"]` mandatory for `hive-c3-frozen-v2` records. Today `if fz.get("contract")` (`hive_admission.py:113`, `discovery.py:304`) lets a writer strip the field and skip the contract-sha check.
  - Add a test that sets a foreign evaluator path and expects Refused.

### 2. MEDIUM: the planner's search grows exponentially and nothing caps it
- Where: `src/hive/goal_runner.py:185-197`.
- The dedupe key `frozenset(items)` includes the depth-numbered labels `step:sN`, so equivalent states do not merge. `O.load_policy()` (a file read) also runs once per enumerated branch (`:189`).
- Measured with the shipped type table, on an unsatisfiable goal with mixed file and folder inputs:

  | Inputs | Old planner | New planner |
  |---|---|---|
  | 5 | under 0.1 s | 3.8 s (12.5k policy reads) |
  | 6 | under 0.1 s | 10.2 s |
  | 7 | under 0.1 s | 23.7 s (66k reads) |

  A sweep up to the allowed 20 inputs did not finish in 600 s. The planner runs synchronously inside `run_goal`, so neither STOP nor the wall budget can interrupt it.
- Fix:
  - Move `load_policy()` out of the loop.
  - Key `seen` on (remaining `input:` refs, sorted multiset of produced types).
  - Add a global expansion cap that returns "no plan" when it is hit.

### 3. MEDIUM-LOW: the wall clamp does not cover verification
- Discovered steps: `goal_runner.py:376` hands `CC.verify` the `left` value computed before the container ran, so the verifier gets the full remaining budget again.
- Registry steps: `run_task` clamps only the container. `independent_verify` still has a fixed 60 s timeout (`operator_runtime.py:328`).
- Scenario: 100 s are left, the container uses 100 s, then the verifier hangs until it is killed. The goal ends 60 s past `wall_s`.
- Fix: pass an absolute monotonic deadline, and clamp each phase to `deadline - now`. Plumb the cap into `independent_verify`.

### 4. LOW: the Windows tree kill can silently fail open
- `experiment_compare.py:129` returns `AssignProcessToJobObject`'s result, and `bounded.py:47` ignores it. If assignment fails (for example access denied under a restrictive parent job), only the direct child is killed.
- There is no suspended start, so a child could spawn a process before it is assigned to the job. This is theoretical for `python -I` children (uncertain, not reproduced).
- The job handle leaks when `Popen` raises (`bounded.py:43`).
- When no job exists, `taskkill /T` after a normal exit cannot find orphans.
- Temp-file output does remove the pipe-hang class, and the grandchild-kill test passes.
- Fix: on a 0 return, raise or fall back to `taskkill /T` before waiting, and close the job in a `finally` that wraps `Popen`.

### 5. LOW: `_rel` lets rooted Windows paths escape the repo
- `capcontract.py:92`. `_rel("/Windows")` passes, and `ROOT / _rel(...)` resolves to `C:\Windows` (verified). The schema patterns allow a leading `/`.
- Contracts are reviewed (v2 ones are also signed), so the impact is small, but the guard claims to fail closed.
- Fix: `if q.anchor or ".." in q.parts`.

### 6. LOW: v1 statements depend on unsigned repo-contract fields
- `capcontract.normalize` (`:240`) takes `outputs.artifact_name` and `inputs.format` from the repo `contract.json`.
- A format change fails closed, because the c3 oracle asserts `json`.
- An `artifact_name` change silently renames the export. `report.json` is allowed by the pattern and is then overwritten by the report (`goal_runner.py:384`).
- One invalid contract makes `contracts()` raise, which disables every v1 capability and all discovery. This fails closed, but across capabilities.
- Fix: reject `report.json` in `validate`, and pin the v1-synthesized fields by a recorded contract sha.

### 7. LOW and pre-existing: plan shape changed, and an ordered-input bug
- With an admitted capability and two folders, the plan changes from `snapshot,snapshot,convert,convert,diff` to `snapshot,convert,snapshot,convert,diff`. The meaning is the same but the plan JSON differs. `test_existing_plans_byte_identical` covers no folder inputs.
- Pre-existing, in both the old and new planner: inputs `[folder, file]` feed the ordered `inventory-diff` as `[input1, input0]`, so before and after are swapped. Outputs are appended in the order they are produced.

## Test edits (`git diff 626b2ec fa24ddc -- tests/`)
I found no weakening. The edits are mechanical:
- `evaluator_pin` became a `CC.pin` patch.
- Field asserts now use the v2 statement fields.
- The fake `_launch` signature changed.
- One extra ambiguity case was added.
- `capability_inventory` was renamed to `capability_catalog` in gap records. The rename has no reader and seems to exist only to pass the literal scan. Old records keep the old key.
