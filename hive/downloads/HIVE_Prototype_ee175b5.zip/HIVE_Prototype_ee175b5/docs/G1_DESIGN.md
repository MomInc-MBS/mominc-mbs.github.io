# G1 design: general capability contract (build/compounding @ 626b2ec)

Design only. No code changed. Repository text was treated as data. Line numbers are at 626b2ec.

## 1. Survey map

| Concern | file:line | What it does today |
|---|---|---|
| Inventory deliverable keywords | `goal_runner.py:19-21` | `KEYWORDS` maps goal text to `canonical_rows/group_summary/inventory_diff` |
| Input typed as inventory | `goal_runner.py:92` | every file input becomes type `inventory_file` |
| Discovered caps join planner | `goal_runner.py:134-137` | `eligible_caps` merges `CR.eligible_discovered` |
| **First-match planning** | `goal_runner.py:158-159` | `take = match[:1] if hi == 1 else match[:hi]` (ponytail comment); BFS at `:149-170` never branches on which item |
| Gap finder is greedy | `goal_runner.py:243-263` | `missing_step` picks first op by name, no backtracking |
| Verifier hardwired to c3 oracle | `goal_runner.py:306-335` | `_VERIFY_DIFF` and `_verify_diff` call `oracle.expected(env)` using `D.evaluator_pin()` |
| Retained execution | `goal_runner.py:338-391` | `_run_discovered`: env `{"files":[{"format":"json",...}]}` (`:348`), harness via `D._load("harness")` (`:367`), outputs named `diff.json` (`:386`) |
| Step kind dispatch | `goal_runner.py:458-461` | `builtin_adapter` / `discovered` / registry |
| **Wall time between steps only** | `goal_runner.py:448` | `time.monotonic()-t0 > wall_s` checked before each step; step timeout is the fixed `st["limits"]["timeout_s"]` (`:367`) |
| Evaluator selected by constant | `discovery.py:28,36` | `EVAL_DIR = evaluator/c3`, `PIN_FILES` (5 files) |
| Proposer system prompt | `discovery.py:37` | fixed `run(env: dict) -> str`, json only |
| Bare-name import shim | `discovery.py:41-66` | `_BARE`, `c3_scope`, `_load` (exists because c3/m1/m2 share module names) |
| Evaluator pin | `discovery.py:68-70` | sha over `name:sha\n` of LF-normalised PIN_FILES |
| Frozen protocol | `discovery.py:125-147` | dev cases from `gen_public`, `gen_private.py` subprocess (`:127`), `behaviour_spec` from `G.types()["types"][out]` (`:135`), inventory envelope text (`:136`), inventory baseline text (`:141-143`) |
| Experiment inputs typed inventory | `discovery.py:314` | `[{"type":"inventory_file"}]*arity` for the unchanged-HIVE baseline |
| Proposal task class | `discovery.py:333,358` | `"c3-proposal"` / `"c3_proposal"`; class lives in `configs/model_dispatch.json` and `model_dispatch.py:38` |
| Dev run timeout | `discovery.py:218` | `run_isolated(..., timeout=60, backend="container")` |
| Evaluator launch | `discovery.py:225` | `subprocess.run([...evaluate.py], timeout=400)`; **direct-child kill only** |
| Registry statement schema | `capability_registry.py:19,137` | `hive-capability-admission-v1`, schema equality check |
| Statement re-check per use | `capability_registry.py:155-171` | `_check_statement` re-reads `D._load("harness")`, `D.EVAL_DIR/harness.py`, `D.evaluator_pin()`, `PINNED_IMAGE`: all c3-specific |
| Eligibility rows | `capability_registry.py:198-212` | `in_type/out_type/arity/verifier.path` from statement |
| **Hardcoded cap id** | `scripts/hive_admission.py:30` (CAP_ID), `:5-6,138,165` | `inventory-diff` used for admit, `_reject` (`:58`), rollback default |
| Statement construction | `scripts/hive_admission.py:78-88` | `arity [2,2]` (`:79`), harness path `evaluator/c3/harness.py` (`:80`), verifier c3 paths (`:84`), `imports:["json"]` (`:82`) |
| Admission rerun | `scripts/hive_admission.py:127-130` | `D._evaluate(..., "admission_rerun")` |
| Evaluator c3 | `evaluator/c3/evaluate.py:77-78,122,125` | `PIN_FILES`, M2_VIEWS text, evaluator path, baseline text; `oracle.py:43` `expected(env)`; `harness.py:6-34` static check + `wrap`; `gen_public.py`, `gen_private.py:62` `set_sha`, `baseline_script.py` |
| Type table | `configs/capability_types.json:10-14,18-23` | `inventory_diff` type with `behaviour_spec`; `capabilities` convert/merge/snapshot |
| CLI/console strings | `cli.py:56`, `console.html:4` | deliverable choices list inventory types |
| Legacy registry ops | `operator_runtime.py:32,216,301-330,441-448` | `operator_policy.json` pins, `resolve`, `independent_verify` (`subprocess.run` timeout 60), convert/merge env shaping |
| **Isolation / kill** | `experiment_compare.py:98,106-129,134,137,165-205` | `_RUNNER`, Windows Job Object `_new_job` (KILL_ON_JOB_CLOSE), `_run_container`, `run_isolated` (process backend: Job Object or `killpg`, `finally` kills tree; generated class forced to container, `:167`) |
| Container deadline | `adapters/isolation.py:41-90,119-160` | `_bounded_process` kills host `docker` proc; **in-container `timeout --signal=KILL`** (`:136`) plus `docker rm --force` and verified-absent check (`:145-153`) |
| repo_intel | `repo_intel.py:21-272` | no capability coupling (ref resolve, tree index, content cache, selective fetch). G2 consumer, untouched in G1 |
| model_dispatch | `model_dispatch.py:19-89` | per-task-class routing; only `c3-proposal` exists. Unchanged in G1 |

Findings that change the design:
- Generated code already runs only in the container (FR-8), with an in-container KILL watchdog. The real deadline gaps are host-side: `subprocess.run(timeout)` at `discovery.py:127,225`, `goal_runner.py:329`, `operator_runtime.py:327` (Windows kills only the direct child; a grandchild holding pipes can orphan or stall), and the step timeout ignoring the remaining wall budget.
- Admitted v1 statements are signed over `canon(st)` (`capability_registry.py:135`) and embed `evaluator/c3` pin + harness sha. They cannot be rewritten, and `evaluator/c3/*` bytes must stay identical or `_check_statement` refuses them.

## 2. Contract

Extend, do not fork. Three existing artifacts grow; the registry stays the signed chain `operator/capreg/<cap_id>`.

1. `configs/capability_types.json` stays the type lattice (types, subtypes, deliverables). Each type row may gain `keywords` (replaces `KEYWORDS`, `goal_runner.py:19`) and `behaviour_spec` (already there). New types for the fixture are added; no existing row changes.
2. New per-capability interface contract at `capabilities/<cap_id>/contract.json`, schema `schemas/capability-contract-v1.json` (beside `structured-task-v1.json`). Hand-reviewed, in git, never written by the proposer.
3. Admission statement `hive-capability-admission-v2` embeds the contract and binds the adapter. v1 statements remain valid (section 4).

Contract (interface, adapter not yet bound):

```json
{
 "schema": "hive-capability-contract-v1",
 "capability_id": "text.interval-merge",
 "version": "1.0.0",
 "purpose": "Merge overlapping integer intervals",
 "inputs":  {"arity": [1,1], "types": ["interval_text"], "schema_ref": "schemas/interval_text.json", "envelope": "files-v1"},
 "outputs": {"type": "merged_intervals", "schema_ref": "schemas/merged_intervals.json", "media_type": "text/plain", "artifact_name": "merged.txt"},
 "execution": {"adapter_ref": null, "adapter_language": "python3-run-env-str",
               "environment_ref": {"image": "python:3.11-slim", "digest": "sha256:07d4..."},
               "timeout_seconds": 30, "max_output_bytes": 1048576,
               "resources": {"memory_mb": 128, "cpus": 1, "pids": 32}},
 "permissions": {"network": false, "filesystem": "none", "imports": ["json"], "secrets": false},
 "verification": {"suite_ref": "capabilities/text.interval-merge/suite",
                  "evaluator": {"path": "evaluator/g1/evaluate.py", "pin_files": ["evaluator/g1/evaluate.py","evaluator/g1/harness.py",
                                 "capabilities/text.interval-merge/suite/oracle.py","...gen_public.py","...gen_private.py"]},
                  "oracle": "capabilities/text.interval-merge/suite/oracle.py#expected",
                  "criterion": "pass_count == n"},
 "proposer": {"task_class": "c3-proposal", "behaviour_spec_ref": "capabilities/text.interval-merge/suite/spec.md"},
 "provenance": {"source_revision": "<git sha>", "license": "Apache-2.0", "authors": ["hive"]},
 "dependencies": [], "compatibility": {"contract_min": "1.0.0", "engine_min": "g1"},
 "revocation": {"authority": "hive-admission", "state_source": "operator/capreg chain"}
}
```

Rules:
- `capability_id` is the planner op name and the chain key. `version` (semver) is the interface version; the admission integer `version` (chain position) is unchanged and orthogonal.
- Everything is bound by hash in the admission statement: `contract_sha256 = sha256(canon(contract))`, `impl_sha256` (adapter body), evaluator `pin` over the listed `pin_files` (same LF-normalised `name:sha\n` formula as `discovery.py:68`), environment digest, receipt shas. `adapter_ref` is null in the repo contract because discovery produces the adapter; for a checked-in fixture adapter it holds `{"path","sha256"}`.
- Validation before any execution (new `src/hive/capcontract.py`, stdlib only): JSON schema subset check, `schema_ref` files exist and hash-match when pinned, `pin_files` recompute to the admitted pin, env digest equals `PINNED_IMAGE`, `permissions` is a subset of what the engine can enforce (`network:false`, no filesystem, imports `["json"]`), `timeout_seconds` and resources within engine ceilings, unknown fields rejected. Fail closed; failure is `Refused`.
- Adapters are untrusted artifacts. They are data bytes (store artifact or file), run only in the container through `run_isolated(..., backend="container", operator_class="generated")`, never imported into the engine, never given authority to choose the evaluator, envelope, limits or output name: those come from the contract the admission authority signed.
- Revocation stays the existing signed `revoke`/`rollback` events; the contract field only names the source of truth.

## 3. Consumer changes

Trusted kernel (contract validation, evaluator launch, receipt checks, signing/verification, hash pins) stays separate from the proposer (prompt, model call, extract code). Nothing the proposer outputs selects any kernel input.

- **Discovery** (`discovery.py`): `open_experiment` finds the contract whose `inputs.types/arity` and `outputs.type` match the gap signature (`contract_for_gap`, in `capcontract.py`) and freezes `contract_sha256`, evaluator pin (from `pin_files`), `behaviour_spec` (from `proposer.behaviour_spec_ref`), envelope text (generated from `inputs.envelope`), and the baseline description from the suite. Replace `EVAL_DIR`/`PIN_FILES`/`_load` literals with the contract's `verification` block (loader keeps `c3_scope` for the legacy dir only). `gen_public`/`gen_private`/harness are loaded from `suite_ref`. Frozen schema becomes `hive-c3-frozen-v2`; `receipt_problems` also checks `contract_sha256`. Unchanged-HIVE baseline (`:314`) uses `contract.inputs.types[0]`. `_dev_run` and `_launch` use `contract.execution.timeout_seconds` and the bounded runner (section 5).
- **Admission** (`hive_admission.py`): `admit` takes the experiment, loads the frozen contract, derives `cap_id` from it (delete `CAP_ID`; `--cap` becomes required for revoke/rollback), builds a v2 statement `{schema v2, cap_id, version, contract, contract_sha256, impl_sha256, body, evaluation, lineage, authority}`. The re-run uses the same evaluator path from the contract. Still signs only with the external key; still re-runs the evaluator rather than trusting receipts.
- **Registry** (`capability_registry.py`): `_state` accepts schemas {v1, v2}. `_check_statement` becomes `capcontract.recheck(st)`: recompute body sha, contract sha, pin over `pin_files`, harness sha (path from contract), env digest, static check via the contract's harness. `eligible_discovered` reads in/out/arity from the contract view (`normalize(st)`) for both versions.
- **Retained execution** (`goal_runner._run_discovered`): builds env by `inputs.envelope` (only `files-v1` today: `{"files":[{"format","text"}]}`; the `format` token comes from the input type's declared media type, so interval text uses `"text"`), runs with limits from the contract, verifies by `capcontract.verify(contract, env, output)`, a generic form of `_VERIFY_DIFF` that loads `oracle#expected(env)` in a separate `python -I` process and compares. Artifact name from `outputs.artifact_name`. Replay key (`:349`) adds `contract_sha256`.
- **Planner**: keywords from the type table; type of file inputs inferred from the extension/format via a type-table `accepts_formats` list instead of the constant `inventory_file` (`:92`); first-match fix in section 5b.
- Legacy registry ops (`convert/merge/snapshot`) keep their path (`run_task`, `operator_policy.json` pins). They get read-only synthesized contract views for planning only.

## 4. Inventory migration

Goal: inventory-specific knowledge lives in data, not in the core, and every existing store still loads.

- Create `capabilities/inventory-diff/contract.json` describing the **same bytes** as today: suite_ref `evaluator/c3`, evaluator path `evaluator/c3/evaluate.py`, `pin_files` = the five c3 files, oracle `evaluator/c3/oracle.py#expected`, envelope `files-v1` with format `json`, types `canonical_rows x2 -> inventory_diff`, artifact name `diff.json`, `behaviour_spec` copied verbatim from the type row. `evaluator/c3/*` is NOT moved or edited, because admitted v1 statements pin its exact bytes (`pin`, harness sha). That directory is the inventory evaluator; the contract is its adapter-side description.
- Versioned reader `capcontract.normalize(st)`: for `schema == hive-capability-admission-v1` it synthesizes the contract view from the statement's own fields (`in_type`, `out_type`, `arity`, `harness.path`, `verifier.*`, `limits`, `env`) plus the repo contract for hints, and checks the synthesized `pin_files` equal the five c3 files. It never rewrites or re-signs the stored event. v1 events keep verifying (`verify_sig` over unchanged `canon(st)`).
- New admissions (any cap, including a re-admission of inventory-diff as v2 of the chain) use schema v2. The chain `operator/capreg/inventory-diff` may legally mix v1 and v2 admits; `versions()`, `rollback_target()` and rollback to a v1 version keep working because they use only `st["version"]`.
- Core files contain no inventory strings afterwards. Enforced by a test (section 6): the listed core modules contain no `inventory`, `canonical_rows`, `interval` literal. The only allowed exceptions are `operator_runtime.py` (the legacy registry ops) and `console.html`/`cli.py` choices, which switch to type-table-driven lists.
- Fixtures for compatibility: keep a committed v1 admitted store snapshot (generate from the existing `tests/test_capability_admission.py` flow) and add `test_v1_statement_still_loads_and_executes`.

## 5. Deadlines

### 5a. Enforcement inside the subprocess/container, tree kill on the host

- New `src/hive/bounded.py` (stdlib): `run_bounded(argv, *, timeout, cwd, input=None, max_out)`; Windows: Popen + Job Object (reuse `_new_job` from `experiment_compare.py:106`, imported, not edited), POSIX: `start_new_session` + `killpg`. On timeout kills the whole tree, always joins, returns `(rc, out, err, timed_out)`. Replace `subprocess.run(..., timeout)` at `discovery.py:127,225`, `goal_runner.py:329`, `operator_runtime.py:327` (verifier/evaluator launches). The evaluator process itself also runs `threading.Timer(deadline, os._exit)` set from `--timeout` so it dies even if its parent is gone.
- Container path keeps its in-container `timeout --signal=KILL` (`isolation.py:136`) and `docker rm --force` + absent check. G1 adds: timeout passed to the container is `min(contract.timeout_seconds, remaining_wall)`.
- Wall budget during a step: `run_goal` computes `remaining = b["wall_s"] - (monotonic - t0)` before each step and passes it down; `remaining <= 0` gives BUDGET_EXHAUSTED; otherwise the step deadline is clamped. Closes the BUILD_CHECKPOINT_C gap.

### 5b. Planner first match (same slice, small)

In `plan_goal` replace `match[:1]`/`match[:hi]` with enumeration: for arity-1 ops one branch per matching item (ordered by item list), for n-ary the combinations of size `lo..hi` capped at a constant (8 branches per op). Dedup queue states by `frozenset(items)` so BFS stays bounded; shortest-plan and op-name tie-break rules are preserved. Not required by the gate fixture but removes a documented gap and keeps old plans identical (first branch is the old choice).

### Tests that prove it

1. `test_bounded_kills_grandchild_tree`: run_bounded on a Python child that spawns a grandchild writing a marker after 5 s; timeout 1 s; assert returns in under 4 s with `timed_out`, wait 7 s, marker absent (mirror of `tests/test_experiment_compare.py:141`).
2. `test_verifier_hang_is_unverifiable_and_tree_killed`: oracle that spawns a sleeper and hangs; `capcontract.verify` returns `UNVERIFIABLE` within the clamp and the sleeper is dead.
3. Docker (skipif no docker, like `tests/test_experiment_container.py:14`): adapter that forks a child and loops; `timeout_seconds=2`; assert `RuntimeError` "timed out", and `docker ps -aq --filter name=hive-code-` empty afterwards (container gone).
4. `test_step_timeout_clamped_to_remaining_wall`: fake `run_isolated` captures `timeout`; contract wall 10 s, 8 s already spent, contract timeout 30; captured timeout is at most 2. With wall exhausted mid-goal, state is BUDGET_EXHAUSTED and no run was started.
5. `test_planner_explores_second_match`: two inputs where the arity-1 op must consume the second to reach the deliverable; old code returns no plan, new code finds it; plus a regression asserting existing 3 plans (convert/convert/diff) are byte-identical.

## 6. Second fixture capability: `text.interval-merge`

Structurally different from the row-based inventory diff:

| | inventory-diff | interval-merge |
|---|---|---|
| input | 2 JSON row files (ordered pair) | 1 plain-text file, one `start-end` integer interval per line, `#` comments, blank lines |
| output | JSON object with 4 keys | one line `a-b,c-d,...` or the sentinel `ERROR line N` |
| keys | id-keyed rows, set difference | no identities; geometric union of ranges |
| arity / planner path | arity 2, two inputs | arity 1 |
| evaluator | exact oracle compare | independent **property** oracle (coverage-set equality via bitmask/sweep, canonical-form regex, plus metamorphic checks: shuffled input gives identical output, output idempotent as input) |

Types added to `configs/capability_types.json`: `interval_text` (accepts `.txt` media type; `keywords: ["merge intervals","ranges"]` on the deliverable `merged_intervals`). Deliverables list gains `merged_intervals` (additive).

Files (all new): `capabilities/text.interval-merge/contract.json`, `suite/{spec.md, oracle.py, gen_public.py, gen_private.py, baseline.py}`, `adapter.py` (hand-written reference adapter, only json import, `def run(env)->str`), tests. Evaluator is the new generic `evaluator/g1/evaluate.py` + `harness.py` (CLI-compatible with c3 evaluate: `--exp --frozen-sha --candidate-file --candidate-sha --private --set --out --label`, plus `--suite DIR`). The suite's `oracle.py` is written independently of `adapter.py` (different algorithm: bitmask/point coverage for small ranges versus the adapter's sort-and-sweep) and contains no code from `src/hive`.

Fixtures: public dev cases (empty, single, touching `1-3,4-6` gives `1-6`), nested, duplicates, adjacent (`1-3,4-6` gives `1-6`; frozen in `spec.md`: adjacent integers merge), reversed endpoints `5-2` (sentinel), non-numeric (sentinel), negatives, 200-line shuffles. Private set: generated by `gen_private.py` with seeds and edge classes, hash-only returned, same as c3.

Gate run (`tests/test_g1_fixture.py`): drive the same path as `tests/test_capability_admission.py` with the stub model endpoint returning `adapter.py` as the proposal: goal with discovery -> gap `interval_text x1 -> merged_intervals` -> `open_experiment` (contract found by signature) -> candidate evaluated by the independent evaluator process -> `admit` with the test key -> `run_goal` on fresh inputs VERIFIED via retained execution -> restart -> replay. Then the **same** test body runs parametrized over `[inventory-diff, text.interval-merge]` to show both go through one code path.

Zero task-specific conditionals: `test_core_has_no_task_literals` greps `goal_runner.py, discovery.py, capability_registry.py, capcontract.py, bounded.py, hive_admission.py` for `inventory`, `interval`, `diff`, `canonical_rows` (case-insensitive, comments stripped) and fails on any hit; plus a test that deletes `capabilities/text.interval-merge` from a copied tree and asserts the engine only loses that capability (no `KeyError`).

## 7. Files, order, commands, risks

### Files

Add: `src/hive/capcontract.py`, `src/hive/bounded.py`, `schemas/capability-contract-v1.json`, `capabilities/inventory-diff/contract.json`, `capabilities/text.interval-merge/**`, `evaluator/g1/{evaluate.py,harness.py}`, `tests/test_capcontract.py`, `tests/test_bounded.py`, `tests/test_g1_fixture.py`.
Change: `src/hive/{goal_runner,discovery,capability_registry,operator_runtime(verify subprocess only)}.py`, `scripts/hive_admission.py`, `configs/capability_types.json` (additive), `src/hive/cli.py:56` and `console.html:4` (derive choices), existing tests (assert unchanged behaviour), `docs/OPERATOR_RUNBOOK.md` (cap flag).

### Must NOT change (byte-pinned)

- `evaluator/c3/*` (pinned by admitted statements: `evaluator_pin`, harness sha), `evaluator/m1/*`, `evaluator/m2/*` (`configs/operator_policy.json` evaluator pin `0c580b0e...`, M2 campaign).
- `docs/M1_PROTOCOL.md` (pinned via `m1_workflow.protocol_sha`), `docs/M2_PROTOCOL.md` (blob `9767b209...` in `configs/m2_campaign_policy.json`, commit `d4b71d2f`), and the other protocol/approval docs the M0/M1/M2 policies cite.
- `configs/operator_policy.json` (accepted genomes, receipt shas, evaluator pin), `configs/m0_campaign_policy.json`, `configs/m1_campaign_policy.json`, `configs/m2_campaign_policy.json` and `configs/m2_prompts/*`, `configs/model_dispatch.json` (qualified model), `configs/admission_signers`.
- `src/hive/experiment_compare.py` primitives whose `inspect.getsource` is pinned (`identity`, `scrub_lowercase`, `scrub_delete`, `_scrub_lowercase_source`), `src/hive/m1_views.py`, `m2_views.py`, `m0_oracle.py`, `m2_workflow.py` source-hashed parts. `src/hive/**` is `-text` (exact bytes); do not reformat. G1 imports `_new_job` instead of editing `experiment_compare.py`.
- `build/**`, `experiments/results/**` receipts.

### Ordered plan (4 slices; each ends green on the inventory regression)

1. **Contract + reader, behaviour unchanged.** `capcontract.py` (load, validate, hash, `normalize`, `recheck`), schema, `capabilities/inventory-diff/contract.json`, registry accepts v1/v2, `_check_statement` routed through `recheck`. Tests: v1 statements load and verify; tampered contract/pin refused.
2. **Core genericity.** discovery/admission/goal_runner consume the contract; `evaluator/g1`; delete `CAP_ID` and c3 constants from core; generic verify and artifact naming; v2 statements. Tests: existing discovery/admission/goal tests unchanged and green; new literal-free test.
3. **Deadlines + planner.** `bounded.py`, replace host `subprocess.run` verifiers, clamp to remaining wall, planner enumeration. Tests in 5.
4. **Second fixture + gate.** `text.interval-merge` capability, parametrized gate test, v1-store snapshot test.

### Test commands (short basetemp; Docker required for the real-container ones)

```
cd C:/hive-work/cmp
python -m pytest tests/test_capability_admission.py tests/test_discovery.py tests/test_goal_runner.py -q --basetemp C:/t/g1a
python -m pytest tests/test_capcontract.py tests/test_bounded.py -q --basetemp C:/t/g1b
python -m pytest tests/test_g1_fixture.py -q --basetemp C:/t/g1c
python -m pytest tests/test_experiment_compare.py tests/test_experiment_container.py tests/test_operator_runtime.py tests/test_m2_evaluator.py -q --basetemp C:/t/g1d
python -m pytest -q --basetemp C:/t/g1full      # final, after slice 4 only (baseline: 1114 passed / 3 skipped)
```

### Risks

- Any byte change to `evaluator/c3/*` silently invalidates admitted capabilities. Mitigation: a test pinning the five c3 file hashes in the new suite.
- Mixed v1/v2 chain: `_state` and `rollback_target` must not assume a schema. Covered by a mixed-chain test.
- Windows Job Object coverage: only `p.kill()` plus `CloseHandle` today; the bounded helper must assign before the child can fork (create suspended is not available in stdlib; race is small but real). Mitigation: assert in test, fall back to `taskkill /T` by pid.
- `c3_scope` bare-name collisions: the new generic evaluator must run only as a separate `python -I` process, never imported into the engine.
- Planner enumeration could change plan choice; keep the old pick as branch 0 and assert old plans equal.
- Proposer prompt (`discovery.py:37`) forbids anything but `json`; a future capability needing other imports must be a contract permission change, reviewed, not a proposer choice.
- The fixture proves generalization, not autonomous acquisition (stub proposer returns a checked-in adapter); report it that way. No paid calls, no model calls in G1 gating.
