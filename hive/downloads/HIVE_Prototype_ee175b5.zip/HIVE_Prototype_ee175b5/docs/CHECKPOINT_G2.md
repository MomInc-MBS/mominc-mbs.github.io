# HIVE Compounding build: checkpoint G2, GitHub-to-capability bridge (26 Nov 2026)

Plan: `docs/COMPOUNDING_BUILD_PLAN.md` section 4. Design `docs/G2_DESIGN.md`. Security review `build/g-series/g2/REVIEW.md`. Branch `build/compounding` (local only).

## Verdict: PASS
HIVE's own search found an external tool, pinned it, adapted it with the local model, verified it independently, admitted it with a signed statement and reused it in a fresh process on unseen inputs.

| Step | Evidence (`build/g-series/g2/run-gate12/`) |
|---|---|
| Goal and gap | `image.asset-match` (contract sha `88c9f5b7…`), `--require-new-external` so retained and installed tiers could not satisfy it |
| SEARCH | GitHub REST search, unauthenticated. 4 keyword queries plus 3 queries suggested by the model (temperature 0, seed 2026400001). No candidate repository is named in the repo or in prompts |
| INSPECT and SELECT | Pre-inspection ranking by query hits, position, term overlap and size; a search-metadata licence gate; then a deterministic card with the licence agreed by API and LICENSE text |
| STAGE | `benhoyt/dhash` @ `b2271b8c3b7d30fc9abdbcaf5988338a7b6bc76e`, MIT, single-module vendored tree `3162ca58…`. Optional dependencies Pillow 13.0.0 and Wand 0.7.3 were found statically (try/except ImportError), hash-locked (`2d2470b6…`) and built offline. Image `sha256:54618c41…`, tar `f554b904…` |
| ADAPT | local `openai/gpt-oss-20b` (LM Studio, $0). Attempt dev passes 2/6 → retry 3, 5 → retry 6/6. Adapter `da1ffe86…`. 11 model calls in the run, 35,030 input / 6,033 output tokens, 651 s |
| VERIFY | independent `evaluator/g2` process, hidden private set (seed hash `dc937b59…`): **24/24 PASS**, receipt `ce266e1c…` |
| ADMIT | signed v3 statement `b4b129d8…` (tool, revision, licence, card, image ID and tar hash bound); tar re-hashed at admission |
| EXECUTE | the goal was VERIFIED through retained execution |
| REUSE | `reuse.json`: **fresh process**, image deleted first then reloaded from the hash-checked tar, unseen seed 303 (`8bd9c0d4…`): VERIFIED, 0 new experiments, 0 model calls |

Regression on `84b9b1d`: full suite **1524 passed / 9 skipped / 0 failed** (`full-suite-g2b.log`); C6 journey **14/14** (`c6-g2.log`).

## How it got there (all evidence kept)
Gate runs 1–11 were honest negatives, and each named a generic defect that was fixed in core with no tool or task names: un-encoded search URL (not the cause; the 403s were rate limits), pip ENOSPC in the 64 MB tmpfs, ranking dominated by keyword noise, single-module tools rejected, 180 s git timeout, dev requirement files treated as runtime dependencies, an over-strict script rule, tools that need file paths (read-only input mount added), optional dependencies not staged, a static-check false positive on a local named `grp`, repair prompts without the previous code (the main fix), and staging rejections that burned an attempt slot. Run 4 hit GitHub's unauthenticated 60/hour core limit; IP addresses are now scrubbed from stored messages.

## Rules kept and disclosed changes
- Hidden fixtures, the evaluator, signing keys and admission policy are unreachable by the proposer. The M2 inference approval caps (3 proposals and 6 calls per experiment) are unchanged.
- Changed and declared before the gate run: run budget 16 local model calls; at most 3 distinct candidates per run; a same-candidate retry (seeded with the best previous code) is allowed only while dev passes strictly improve, at most 3 per repository, and does not count as a new candidate; experiment caps 12 per acquisition run and 24 per gap.
- "No task-specific core changes after G1": core changes in G2 are generic (acquisition machinery, contract v2, input mount). The literal scan in `tests/test_capcontract.py` enforces that no task identifiers are in core.
- Fixtures were authored by a conductor-side agent independently of any adapter or tool, not by Ian.

## Limits
- One acquisition, one tool, one workload. The mechanism is shown, not an advantage over a hand-written baseline.
- The adapter imports the tool, but the static check cannot prove that the tool's functions do the work.
- Unauthenticated GitHub search limits throughput to about 4 runs an hour.
- A store I scrubbed by mistake with `sed` (`C:/t/g2gate4/hive.sqlite3`, the rate-limited run 4) is corrupt. Its manifest and log are kept.

## Cost
Coding agents this session: about $42.70 for G2 (session total $79.59 at this checkpoint, cumulative about $196 of $220). Paid inference $0.

## Rollback
`git checkout 1200b3b` (G1 checkpoint) or `626b2ec` (published baseline). Nothing was published.
