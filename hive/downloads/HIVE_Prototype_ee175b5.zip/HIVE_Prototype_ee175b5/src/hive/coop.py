"""Cooperative round ("coop"): pure helpers. No store, no model, no container; discovery._loop owns every call and every ledger charge.
A recipe fixes how many independent candidates one round samples; selection uses ONLY public dev results and differential agreement on
generator-made inputs (never the hidden acceptance cases, never the proposer)."""
import hashlib
import inspect
import json
import random
import re
from pathlib import Path

DIFF_SEED = 2026500000  # frozen into the experiment; distinct from every proposer seed (2026300000+) and the smoke range
SELECT = "dev>agree>dev_ms>sha"
LINES = {
    "A": "Method A: write the most direct solution that follows the spec section by section.",
    "B": "Method B: before writing code, list every rule and edge case the spec names as comments at the top, then write code that handles each one.",
    "C": ("Method C: use a different technique from the obvious one (for example an explicit character scanner or step-by-step normalization "
          "instead of one big regular expression) and validate every input rule before producing output."),
}
RECIPES = {"sample3": None, "diverse3": [LINES["A"], LINES["B"], LINES["C"]], "maskpos3": None, "maskrand3": None}
MASKED = ("maskpos3", "maskrand3")  # branch 0 intact; branches 1/2 see the behaviour spec with half A / half B of the masked word positions blanked
MASK_DIR = Path(__file__).resolve().parents[2] / "build" / "coop" / "masks"
MASK_SEED = 2026600000
TAGGER = "nltk 3.9.1 averaged_perceptron_tagger_eng"
BLANK = "___"
SIZES = [2, 4, 6, 8, 3, 5, 3, 2]  # pages/rows per differential input; the last three also carry an error kind (mirrors gen_public.cases(): mostly valid, a few errors)


def frozen(recipe, diff_seed=DIFF_SEED, cap=None, spec=None):
    """The dict frozen into the experiment (every value binds the exp_id). A masking recipe also needs the capability id and its live spec text:
    the mask file must exist and match the spec, and its sha is frozen."""
    if recipe not in RECIPES:
        raise ValueError(f"unknown coop recipe {recipe!r} (known: {sorted(RECIPES)})")
    out = {"recipe": recipe, "branches": 3, "temperature": 0.7, "instructions": RECIPES[recipe], "select": SELECT, "diff_seed": diff_seed, "diff_inputs": 8}
    if recipe in MASKED:
        out.update(masks_sha256=load_mask(cap, spec)[1], view="spec-mask")
    return out


def instruction(cp, branch):
    """The one extra final user-message line of this branch, or None."""
    return (cp["instructions"] or [None] * cp["branches"])[branch]


def diff_cases(gen_public, diff_seed, k):
    """k extra input cases [{"env", "expected"}] from the capability's PUBLIC generator case(name, rng, n[, error]). None when it has no such generator."""
    case = getattr(gen_public, "case", None)
    if case is None or "rng" not in inspect.signature(case).parameters:
        return None
    doc = getattr(getattr(gen_public, "build", None), "__doc__", None) or ""
    errors = re.findall(r"'([a-z][a-z-]*)'", doc.partition("error:")[2])
    out = []
    for i in range(k):
        err = errors[i - (k - 3)] if i >= k - 3 and i - (k - 3) < len(errors) else None
        out.append(case(f"diff-{i}", random.Random(diff_seed + i), SIZES[i % len(SIZES)], *([err] if err else [])))
    return out


def diff_envs(gen_public, diff_seed, k):
    """k extra input envs from the capability's PUBLIC generator; `expected` is dropped here. None when it has no such generator."""
    cs = diff_cases(gen_public, diff_seed, k)
    return None if cs is None else [c["env"] for c in cs]


def digest(envs):
    return hashlib.sha256(json.dumps(envs, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def canon(raw, n):
    """Per-input canonical result of one candidate run (the run_isolated JSON): the output string, or the error class when it raised / returned a non-string."""
    out, errs = (raw["out"], raw["err"]) if isinstance(raw, dict) else (raw, [None] * n)
    return [("ERR:" + str(e).split(":")[0]) if e else ("ERR" if o is None else "OUT:" + str(o)) for o, e in zip(out, errs)]


def agreement(outs):
    """{sha: canonical outputs} -> {sha: sum over inputs of how many OTHER distinct candidates gave the identical result}. A crashed run (None) votes for nothing."""
    ok = {h: o for h, o in outs.items() if o is not None}
    return {h: sum(sum(1 for g, p in ok.items() if g != h and p[i] == o[i]) for i in range(len(o))) if h in ok else 0 for h, o in outs.items()}


def key(c):
    return [-c["dev_pass"], -(c.get("agreement") if isinstance(c.get("agreement"), int) else 0), c.get("dev_ms") or 0.0, c["sha"]]


def select(cands):
    """The winner of a round: dev pass desc, agreement desc, dev_ms asc, sha asc. Reads nothing else (no acceptance, no hidden result). None for no candidates."""
    return min(cands, key=key) if cands else None


# ---------------------------------------------------------------- masking arms (C3): spec-only word masks, built offline by scripts/coop_masks.py
STOP = set("not no never none nor without except unless only every each all any both either neither must may should if when than".split())
BE_HAVE_DO = set("be am is are was were been being have has had having do does did doing done".split())
SPANS = re.compile(r"```.*?```|`[^`\n]+`|\"[^\"\n]*\"|(?<!\w)'[^'\n]*'(?!\w)", re.S)
BAD = set("_./:-#?=<>&;@,0123456789")


def _lf(b):
    return b.replace(b"\r\n", b"\n")


def sha_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def split_words(text):
    """[(start, end, word)] over whitespace-delimited tokens with edge markup and trailing sentence punctuation stripped (offsets into the original text)."""
    out = []
    for m in re.finditer(r"\S+", text):
        s, e = m.start(), m.end()
        while s < e and text[s] in "([{*\"'":
            s += 1
        while e > s and text[e - 1] in ")]}*\"'.,;:!?":
            e -= 1
        if e > s:
            out.append((s, e, text[s:e]))
    return out


def classify(text, words, tags):
    """-> (protected, eligible_nv, eligible_any) index lists: inside code/quotes, tokens with a digit or any of _./:-#?=<>&;@, , ALL-CAPS and the stop words are protected."""
    spans = [m.span() for m in SPANS.finditer(text)]
    prot, nv, anyp = [], [], []
    for i, (s, e, w) in enumerate(words):
        if any(a < e and s < b for a, b in spans) or any(ch in BAD for ch in w) or (len(w) >= 2 and w.isupper()) or w.lower() in STOP:
            prot.append(i)
        elif w.isalpha():
            anyp.append(i)
            if tags[i][:2] in ("NN", "VB") and w.lower() not in BE_HAVE_DO:
                nv.append(i)
    return prot, nv, anyp


def build_mask(cap, spec, tag_words, seed=MASK_SEED):
    """The mask record of one spec. `tag_words(list[str]) -> list[str]` is the POS tagger (injected so HIVE itself never imports nltk)."""
    words = split_words(spec)
    tags = list(tag_words([w for _, _, w in words]))
    prot, nv, anyp = classify(spec, words, tags)
    order = list(nv)
    random.Random(seed).shuffle(order)
    h = len(order) // 2
    a, b = sorted(order[:h]), sorted(order[h:])
    pick = random.Random(seed + 1).sample(anyp, len(a) + len(b))
    ra, rb = sorted(pick[:len(a)]), sorted(pick[len(a):])
    n = len(words)
    real = {k: {"masked_words": len(v), "spec_words": n, "rate": round(len(v) / n, 4)} for k, v in
            (("maskpos-A", a), ("maskpos-B", b), ("maskrand-A", ra), ("maskrand-B", rb))}
    return {"schema": "coop-mask-v1", "cap": cap, "spec_sha256": sha_text(spec), "tagger": TAGGER, "seed": seed,
            "words": [[s, e, w, tags[i]] for i, (s, e, w) in enumerate(words)], "protected": prot, "eligible_nv": nv, "eligible_any": anyp,
            "maskpos": {"1": a, "2": b}, "maskrand": {"1": ra, "2": rb}, "realized": real}


def mask_bytes(m):
    return (json.dumps(m, indent=1, ensure_ascii=False) + "\n").encode("utf-8")


def load_mask(cap, spec):
    """-> (mask dict, sha256 of its LF bytes). Refuses (ValueError) when the file is missing or was built for a different spec text."""
    p = MASK_DIR / f"{cap}.json"
    if not p.is_file():
        raise ValueError(f"no mask file for capability {cap!r} ({p.name}); run scripts/coop_masks.py")
    raw = _lf(p.read_bytes())
    m = json.loads(raw.decode("utf-8"))
    if m.get("schema") != "coop-mask-v1" or m.get("cap") != cap or m.get("spec_sha256") != sha_text(spec):
        raise ValueError(f"mask file for {cap!r} does not match the live behaviour spec (spec_sha256 mismatch); rebuild it")
    return m, hashlib.sha256(raw).hexdigest()


def view_of(recipe, branch):
    return "intact" if branch == 0 else f"{'maskpos' if recipe == 'maskpos3' else 'maskrand'}-{'AB'[branch - 1]}"


def render_spec(mask, recipe, branch, spec):
    """The spec text of one branch: the listed word spans replaced by ___ (everything else byte-preserved)."""
    if branch == 0:
        return spec
    out = spec
    for i in sorted(mask["maskpos" if recipe == "maskpos3" else "maskrand"][str(branch)], reverse=True):
        s, e, w = mask["words"][i][:3]
        if spec[s:e] != w:
            raise ValueError("mask word does not match the spec text at its offset")
        out = out[:s] + BLANK + out[e:]
    return out


def render_user(mask, recipe, branch, spec, user):
    """The user message of one branch: ONLY the leading spec text is replaced; refuses when the message does not start with the spec verbatim."""
    if not user.startswith(spec):
        raise ValueError("the behaviour spec is not the exact prefix of the user message: refusing to mask")
    return render_spec(mask, recipe, branch, spec) + user[len(spec):]


def view_info(mask, recipe, branch):
    v = view_of(recipe, branch)
    r = mask["realized"].get(v)
    return {"view": v, "masked_words": r["masked_words"] if r else 0, "mask_rate": r["rate"] if r else 0.0}


# ---------------------------------------------------------------- offline selector replay (zero model calls): frozen variants S0-S3
CHECK_ID = "coop-construct-check-v1"
VARIANTS = {"S0": "S0-v1", "S1": "S1-v1", "S2": "S2-v1", "S3": "S3-v1"}  # S0 recorded; S1 wider voter pool; S2 public construct check; S3 both


def _h(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def receipt(cand, inputs, raw, expected, failure=None):
    """One candidate run over the frozen differential inputs, checked against the generator's `expected` (kept here, never given to the candidate).
    failure = 'timeout' | 'error' when the run itself raised. Per input: answer (sha of the output string, None = abstain: raised / non-string) and match."""
    n = len(expected)
    r = {"checker": CHECK_ID, "cand": cand, "inputs": inputs, "n": n, "failure": failure, "outcome": failure or "ok", "answers": [None] * n, "canon": [None] * n, "match": [None] * n}
    if failure:
        return r
    out, errs = (raw.get("out"), raw.get("err")) if isinstance(raw, dict) else (raw, [None] * n)
    if not (isinstance(out, list) and isinstance(errs, list) and len(out) == len(errs) == n):
        r["outcome"] = "malformed"
        return r
    r["canon"] = [_h(c) for c in canon(raw, n)]
    r["answers"] = [_h(o) if isinstance(o, str) and not e else None for o, e in zip(out, errs)]
    r["match"] = [isinstance(o, str) and not e and o == x for o, e, x in zip(out, errs, expected)]
    return r


def receipt_ok(r, cand, inputs, n):
    """A receipt counts only for the candidate body, input digest and checker version it was made for, and only when the run completed."""
    return isinstance(r, dict) and r.get("checker") == CHECK_ID and r.get("cand") == cand and r.get("inputs") == inputs and r.get("n") == n         and r.get("outcome") == "ok" and all(isinstance(r.get(k), list) and len(r[k]) == n for k in ("answers", "match", "canon"))


def agreement_v1(answers):
    """{sha: per-input answers (None = abstain)} -> {sha: sum over inputs of how many OTHER voters gave the identical answer}. Abstentions give and receive nothing."""
    return {h: sum(sum(1 for g, p in answers.items() if g != h and p[i] == a[i]) for i in range(len(a)) if a[i] is not None) for h, a in answers.items()}


def pool_select(variant, cands, receipts, inputs, n):
    """Replay one round. cands: [{sha, static, dev_pass, dev_ms, agreement (recorded), duplicate_of?}]; receipts: {sha: receipt}. Winner eligibility is S0's: any
    non-static candidate, ranked dev pass first (so a dev-failing voter only wins a pool with no dev pass, and is then never gated). One entry and one vote per body.
    S0/S2 use the recorded agreement (dev-perfect voters only); S1/S3 recompute it over every non-static candidate with a valid run (abstaining on raised/non-string
    outputs). S2/S3 rank by public construct-check matches after dev pass and before agreement; a candidate without a valid check ranks below every candidate with one."""
    seen, pool = set(), []
    for c in sorted(cands, key=lambda c: c["sha"]):
        if not (c.get("static") or c.get("duplicate_of") or c["sha"] in seen):
            seen.add(c["sha"])
            pool.append(c)
    good = {c["sha"]: receipts[c["sha"]] for c in pool if receipt_ok(receipts.get(c["sha"]), c["sha"], inputs, n)}
    wide, chk = variant in ("S1", "S3"), variant in ("S2", "S3")
    if wide:
        agree, voters = agreement_v1({h: r["answers"] for h, r in good.items()}), sorted(good)
        abst = {h: sum(a is None for a in good[h]["answers"]) for h in voters if None in good[h]["answers"]}
    else:
        agree = {c["sha"]: c["agreement"] if isinstance(c.get("agreement"), int) else 0 for c in pool}
        voters, abst = sorted(c["sha"] for c in pool if isinstance(c.get("agreement"), int)), {}

    def k(c):
        h = c["sha"]
        mid = [-sum(good[h]["match"]) if h in good else 1] if chk else []  # no valid check receipt ranks below any valid one (even 0 matches)
        return [-c["dev_pass"]] + mid + [-agree[h] if h in agree else 0, c.get("dev_ms") or 0.0, h]
    win = min(pool, key=k) if pool else None
    return {"selected": win["sha"] if win else None, "key": k(win) if win else None, "voters": voters, "abstentions": abst}
