"""Bounded host-side process runs (G1 deadlines): the whole process tree dies at the deadline, never only the direct child.

Windows: Job Object (reused from experiment_compare, KILL_ON_JOB_CLOSE); POSIX: own session + killpg. Output goes to temp files, not
pipes, so a grandchild that inherited the handles can neither stall the read nor outlive the run. Stdlib only."""
from __future__ import annotations

import os
import subprocess
import tempfile
from pathlib import Path

MAX_OUT = 1 << 20


def _kill_tree(p, job):
    """job = the close function when p is in a job object, else None."""
    if job:
        p.kill()
        job()  # closing the job handle kills every member
    elif os.name == "nt":
        subprocess.run(["taskkill", "/T", "/F", "/PID", str(p.pid)], capture_output=True)  # no job object: fall back to taskkill by pid
    else:
        try:
            os.killpg(p.pid, 9)
        except OSError:
            pass
    p.wait()


def run_bounded(argv, *, timeout, cwd=None, input=None, max_out=MAX_OUT):
    """Run argv; returns (returncode, stdout, stderr, timed_out). On timeout, or any exit, the whole tree is killed and joined.
    Fails closed (OSError, tree killed) when the child cannot be put into its job object."""
    win = os.name == "nt"
    job = None
    if win:
        from .experiment_compare import _new_job
        try:
            job = _new_job()
        except OSError:
            job = None
    p, held = None, False
    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            t = Path(tmp)
            (t / "in").write_bytes((input or "").encode("utf-8"))
            with open(t / "in", "rb") as fi, open(t / "out", "wb") as fo, open(t / "err", "wb") as fe:
                # ponytail: the child starts running before it is assigned to the job (no stdlib suspended start), so a child that
                # spawns within that first instant escapes the job; the trusted `python -I` children do not. Upgrade: CREATE_SUSPENDED via ctypes.
                p = subprocess.Popen(argv, stdin=fi, stdout=fo, stderr=fe, cwd=cwd, start_new_session=not win)
                timed_out = False
                try:
                    if job:
                        if not job[0](p):
                            raise OSError("process could not be assigned to its job object")
                        held = True
                    try:
                        p.wait(max(0.01, timeout))
                    except subprocess.TimeoutExpired:
                        timed_out = True
                finally:
                    _kill_tree(p, job[1] if held else None)
            rd = lambda n: (t / n).read_bytes()[:max_out].decode("utf-8", "replace")
            return p.returncode, rd("out"), rd("err"), timed_out
    finally:
        if job and not held:
            job[1]()  # never leak the job handle (Popen raised, or assignment failed)
