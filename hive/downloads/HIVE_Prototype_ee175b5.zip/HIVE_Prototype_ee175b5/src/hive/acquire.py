"""G2 acquisition driver: a bounded, resumable state machine from a typed capability gap to an admitted, reusable capability.

SEARCH -> INSPECT -> SELECT -> STAGE -> ADAPT -> VERIFY -> ADMIT -> EXECUTE -> RECORD_OUTCOME   (GOAL/PLAN/MISSING_CAPABILITY are goal_runner)
Up to 3 candidate attempts (repo@revision); each is staged, adapted by the proposer and verified by the discovery evaluator path. Only a
CANDIDATE_PASSED experiment can reach ADMIT, and only the signed admission authority admits (this module never signs). The proposer
(acq_propose) returns text only; the staging runner, evaluator launch and admission are the trusted kernel. State lives in one Store record
operator/acq/<run_id> plus hashed files under <store>/acquisition/<run_id>/; every stage is idempotent so a STOP or crash resumes without a
second model call, build or clone. Local model => cost_usd 0.0. Stdlib only; nothing here names a task."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import time
from pathlib import Path

from . import acq_card as AC
from . import acq_github as AG
from . import acq_propose as AP
from . import acq_stage as ST
from . import capability_registry as CR
from . import capcontract as CC
from . import discovery as D
from . import repo_intel as RI
from .adapters.isolation import SandboxUnavailable
from .operator_runtime import Refused, _json, _now, _sha, _txn
from .storage import Store, _alive

KEY = "operator/acq/"
STATES = ("SEARCH", "INSPECT", "SELECT", "STAGE", "ADAPT", "VERIFY", "ADMIT", "EXECUTE", "RECORD_OUTCOME")
TERMINAL = frozenset({"DONE", "NO_CANDIDATE", "CANDIDATES_EXHAUSTED", "BUDGET_EXHAUSTED", "STOPPED", "MODEL_UNAVAILABLE", "SANDBOX_UNAVAILABLE",
                      "NETWORK_UNAVAILABLE", "ADMISSION_REFUSED", "FAILED_EXECUTE"})
# non-terminal waits: INTERRUPTED (crash/transport, resumable) and AWAITING_ADMISSION (the key holder has not admitted yet)
BUDGET = {"attempts": 3, "model_calls": 16, "builds": 3, "container_runs": 24, "github_requests": 30, "wall_s": 2400, "inspect": 8, "stage_rejects": 3,
          "max_prompt_tokens": AP.MAX_PROMPT_TOKENS, "max_out_tokens": 4096}
ATTEMPT_MIN_RUNS = 6  # baseline + dev runs + evaluator runs one attempt needs before it is worth starting
SUGGEST_PARAMS = {"temperature": 0, "seed": 2026400001, "max_tokens": 200}  # the query-suggestion call is deterministic where the endpoint allows
POLICY = Path(__file__).resolve().parents[2] / "configs" / "acquisition_policy.json"


class _End(Exception):
    def __init__(self, state, reason):
        super().__init__(reason)
        self.state, self.reason = state, reason


def policy(path=None):
    return json.loads(Path(path or POLICY).read_text(encoding="utf-8"))


def _zero():
    return {"attempts": 0, "model_calls": 0, "builds": 0, "container_runs": 0, "github_requests": 0, "in_tokens": 0, "out_tokens": 0, "wall_s": 0.0, "cost_usd": 0.0}


def _keys(store):
    return [r["key"] for r in store.db.execute("SELECT key FROM kv WHERE key LIKE ?", (KEY + "%",)).fetchall()]


def runs(store, gap_key=None):
    rows = [store.get(k) for k in _keys(store)]
    return sorted((r for r in rows if gap_key in (None, r["gap_key"])), key=lambda r: r["opened_at"])


def make_suggest(store_root, run_kw):
    """The real query-suggestion call, through the same dispatch/qualification/approval path as the proposer (class from the contract's
    proposer.task_class is c3-proposal). Returns suggest(messages) -> (content, usage); raises when no qualified model can run."""
    from . import m2_model as M
    from . import model_dispatch as MD

    def suggest(messages):
        c3 = "c3-proposal"
        d = MD.plan(store_root, c3, run_kw.get("requested_model") or "openai/gpt-oss-20b", run_kw.get("dispatch_cfg"))
        ex = d["executed_model"]
        if not ex:
            raise RuntimeError("no executable qualified model")
        p = D.pol()
        if ex != p["model"]["id"]: p = M.apply_backend(p, ex, run_kw.get("dispatch_cfg"))  # a non-default backend brings its own pins, endpoint and approval (T18)
        p["sampling"].update(max_tokens=SUGGEST_PARAMS["max_tokens"], temperature=SUGGEST_PARAMS["temperature"])  # deterministic; proposal calls keep theirs
        stub = run_kw.get("stub_endpoint")
        model = M.Model(Path(store_root) / "acquisition" / "suggest-model", stub=bool(stub), endpoint=stub, pol=p, approval_path=D.ROOT / p["approval_path"],
                        dispatch_cfg=run_kw.get("dispatch_cfg"), private_blobs=run_kw.get("private_blobs"))
        if not stub:
            model.check_weights("g2-suggest")
        model.list_models()
        if not model.hosted and MD.loaded(model.endpoint, ex) is False:
            raise RuntimeError(f"{ex} is listed but not loaded")
        res = model.call("c3_proposal", messages, SUGGEST_PARAMS["seed"])
        if res["status"] != "ok":
            raise RuntimeError("transport_failure")
        return res["content"], res["usage"]
    suggest.params = dict(SUGGEST_PARAMS, model=run_kw.get("requested_model") or "openai/gpt-oss-20b")  # recorded in the manifest
    return suggest


def run_dir(store_root, run_id): return Path(store_root) / "acquisition" / run_id


# ---------------------------------------------------------------- open (queue) a run
def open_run(store, gap_key, *, budget=None, require_new_external=False, queries=()):
    """Persist a queued run for a gap that a derived-environment contract declares. Refuses an open/finished-ok run, a third run, or a gap
    with no contract. Starts nothing (goal_runner queues; scripts/g2_qualify.py or any driver process runs it)."""
    gap = store.get(gap_key)
    if not gap or not gap.get("missing_step"):
        raise Refused("not a gap with a minimal missing step")
    ms = gap["missing_step"]
    c = CC.contract_for_gap(ms)
    if c is None or not CC.is_v2(c) or c["execution"]["environment_ref"]["kind"] != "derived":
        raise Refused("no derived-environment capability contract declares this gap")
    bad = [q for q in queries if not AG.valid_query(q)]
    if bad:
        raise Refused("invalid search query")
    frozen = {"gap_key": gap_key, "signature": ms, "contract": {"capability_id": c["capability_id"], "sha256": CC.sha(c)},
              "budget": dict(BUDGET, **(budget or {})), "require_new_external": bool(require_new_external), "extra_queries": list(queries)}
    with _txn(store):
        prior = runs(store, gap_key)
        if any(r["state"] not in TERMINAL or r["state"] == "DONE" for r in prior):
            raise Refused("this gap already has an open or completed acquisition run")
        if len(prior) >= 2:
            raise Refused("retry depth reached: at most 2 acquisition runs per gap")
        frozen["run_no"] = len(prior) + 1
        run_id = "a-" + _sha(_json(frozen))[:20]
        rec = {"run_id": run_id, "frozen": frozen, "gap_key": gap_key, "state": "SEARCH", "reason": None, "opened_at": _now(), "pid": None, "search": None,
               "inspected": [], "queue": [], "reserve": [], "attempts": [], "ledger": _zero(), "stages": [{"stage": "opened", "at": _now()}], "outcome": None}
        store.set(KEY + run_id, rec)
    return rec


def _save(s, rec): s.set(KEY + rec["run_id"], rec)


def _stage(s, rec, stage, **info):
    rec["stages"].append(dict({"stage": stage, "at": _now()}, **info))
    _save(s, rec)


def _file_sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


# ---------------------------------------------------------------- budget gate
def _gate(s, rec, clock, stop_path, **need):
    """Checked before every search, build, attempt and model-bearing step: STOP, wall, then each allowance. Never lets a limit be crossed."""
    now = time.monotonic()
    rec["ledger"]["wall_s"] += now - clock[0]
    clock[0] = now
    if Path(stop_path).exists():
        raise _End("STOPPED", "STOP is set; nothing further ran")
    B, L = rec["frozen"]["budget"], rec["ledger"]
    if L["wall_s"] >= B["wall_s"]:
        raise _End("BUDGET_EXHAUSTED", "wall_s exhausted")
    for k, n in need.items():
        if B[k] - L[k] < n:
            raise _End("BUDGET_EXHAUSTED", f"{k} exhausted (need {n}, {B[k] - L[k]} left)")


def _absorb(rec, exp):
    """Fold a finished discovery experiment's ledger into the run ledger (the experiment ledger is the record of truth for model calls)."""
    e, L = exp["ledger"], rec["ledger"]
    L["model_calls"] += e["calls"]
    L["container_runs"] += e["container_runs"]
    L["in_tokens"] += e["in_tokens"]
    L["out_tokens"] += e["out_tokens"]


# ---------------------------------------------------------------- SEARCH
def _retained(s, sig):
    ok, _ = CR.eligible_discovered(s)
    return [{"cap_id": k, "version": v["version"]} for k, v in sorted(ok.items()) if v["in"] == sig["in"] and v["out"] == sig["out"] and v["arity"][0] <= sig["arity"] <= v["arity"][1]]


def _types():
    return json.loads((CC.ROOT / "configs" / "capability_types.json").read_text(encoding="utf-8"))["types"]


def _suggest(s, rec, hooks, c, T, kwq):
    """One model call per run (counted in the ledger and the model-call budget, prompt capped): up to 3 validated queries, or [] with the reason."""
    if not hooks.get("suggest"):
        return [], "not configured"
    view = {"purpose": c["purpose"], "behaviour_spec": CC.text_ref(c["proposer"]["behaviour_spec_ref"]), "inputs": c["inputs"]["types"], "output": c["outputs"]["type"],
            "media_type": c["outputs"]["media_type"]}
    msgs = AP.query_messages(view)
    if AP.prompt_problems(msgs, rec["frozen"]["budget"]["max_prompt_tokens"]):
        return [], "prompt over the input-token limit"
    L = rec["ledger"]
    if rec["frozen"]["budget"]["model_calls"] - L["model_calls"] < 1:
        return [], "no model-call budget"
    L["model_calls"] += 1  # counted at the start: a failed call is still a call
    L["in_tokens"] += sum(AP.tokens(m["content"]) for m in msgs)
    try:
        content, usage = hooks["suggest"](msgs)
    except Exception as e:
        return [], f"{type(e).__name__}: {str(e)[:120]}"
    L["out_tokens"] += int((usage or {}).get("completion_tokens") or AP.tokens(content or ""))
    return [q for q in AP.parse_queries(content) if q not in kwq], "ok"


def _search(s, rec, hooks, c, clock, stop_path):
    _gate(s, rec, clock, stop_path)
    T = _types()
    c = CC.contract_for_gap(rec["frozen"]["signature"])
    kw = T.get(rec["frozen"]["signature"]["out"], {}).get("keywords", "")
    kwq = AG.queries_for(kw, rec["frozen"]["extra_queries"])[:4]
    if not kwq:
        raise _End("NO_CANDIDATE", "the capability type declares no search keywords")
    mq, mstatus = _suggest(s, rec, hooks, c, T, kwq)
    mparams = getattr(hooks.get("suggest"), "params", None)
    queries = kwq + mq  # keyword queries run first, the model's after
    gh = hooks["github"]
    seen = {}

    def github():
        for q in queries:
            _gate(s, rec, clock, stop_path, github_requests=1)
            before = gh.requests
            try:
                for pos, r in enumerate(gh.search(q)):
                    e = seen.setdefault(r["full_name"], dict(r, queries=[], hits=[]))
                    e["queries"].append(q)
                    e["hits"].append({"q": q, "pos": pos})
            finally:
                rec["ledger"]["github_requests"] += gh.requests - before
        return list(seen.values())
    try:
        res = AG.search_tiers(_retained(s, rec["frozen"]["signature"]), hooks.get("installed") or [], github, rec["frozen"]["require_new_external"])
    except AG.NetworkUnavailable as e:
        rec["network_error"] = {"status": e.status, "detail": e.detail}  # GitHub's own short message; never headers or the token
        raise _End("NETWORK_UNAVAILABLE", str(e)) from None
    digest = lambda items: _sha(_json(sorted(json.dumps(i, sort_keys=True) for i in items)))
    rec["search"] = {"queries": queries, "query_sources": {"keywords": kwq, "model": mq, "model_status": mstatus, "model_params": mparams}, "tiers": [{"tier": t["tier"], "found": len(t["found"]), "selectable": t["selectable"], "digest": digest(t["found"]),
                                                     **({"skipped": t["skipped"]} if "skipped" in t else {})} for t in res["tiers"]],
                     "candidates": [{k: v for k, v in r.items() if k != "tier"} for r in res["selectable"] if r["tier"] == "github"],
                     "retained": [r for r in res["selectable"] if r["tier"] == "retained"]}
    _stage(s, rec, "search", queries=queries, requests=rec["ledger"]["github_requests"])


# ---------------------------------------------------------------- INSPECT / SELECT
def _rmtree(p):
    """Delete a clone (git object files are read-only on Windows: clear the flag and retry)."""
    def fix(fn, path, exc):
        try:
            os.chmod(path, 0o700)
            fn(path)
        except OSError:
            pass
    shutil.rmtree(p, onerror=fix)


def _dir_bytes(p):
    return ST.tree_size(p)


def _ranking_terms(rec):
    """Terms for the pre-inspection ranking: the contract's purpose/types/media/keywords, its behaviour spec and the type descriptions."""
    T, c = _types(), CC.contract_for_gap(rec["frozen"]["signature"])
    desc = " ".join((T.get(t) or {}).get("description", "") for t in c["inputs"]["types"] + [c["outputs"]["type"]])
    spec = CC.text_ref(c["proposer"]["behaviour_spec_ref"])
    return list(dict.fromkeys(AC.wanted_terms(c, T) + AC.text_terms(spec) + AC.text_terms(desc)))


def _inspect(s, rec, hooks, pol, root, clock, stop_path):
    done = {i["repo"] for i in rec["inspected"]}
    admissible = sum(1 for i in rec["inspected"] if not i["rejection"])
    want = rec["frozen"]["budget"]["attempts"] + rec["frozen"]["budget"]["stage_rejects"]  # spare candidates for staging rejections
    ranked, skipped = AG.rank_hits(rec["search"]["candidates"], _ranking_terms(rec), pol["limits"]["max_repo_kb"], pol["licenses"])
    rec["skipped"] = [{"repo": r["full_name"], "reason": why, "pre_score": bd} for r, why, bd in skipped]
    _stage(s, rec, "rank", ranked=[r["full_name"] for r, _ in ranked], skipped=len(skipped))
    for repo, bd in ranked:
        if repo["full_name"] in done:
            continue
        if admissible >= want or len(rec["inspected"]) >= rec["frozen"]["budget"]["inspect"]:
            break
        _gate(s, rec, clock, stop_path)
        row = {"repo": repo["full_name"], "revision": None, "license": None, "card_sha256": None, "rejection": None, "meta": {k: repo[k] for k in ("license_spdx", "stars", "pushed_at", "size_kb")},
               "pre_score": bd}
        try:
            url = AG.clone_url(repo)
            row["revision"] = hooks["resolve"](url, "HEAD")
            dest = root / "repos" / row["revision"]
            if not (dest / "HEAD").exists():
                hooks["clone"](url, row["revision"], dest)
            if _dir_bytes(dest) > pol["limits"]["max_clone_bytes"]:
                _rmtree(dest)
                raise RI.RepoIntelError(f"REPO_TOO_LARGE: clone over {pol['limits']['max_clone_bytes']} bytes")
            card = AC.build_card(dest, row["revision"], repo["full_name"], pol, root / "cards", api_license=repo.get("license_spdx"), open_issues=repo.get("open_issues"))
            row.update(license=card["license"]["spdx"], card_sha256=card["card_sha256"], rejection=AC.admissible(card, pol))
            if row["rejection"] is None:  # cheap local pre-stage checks: a failure here costs an inspection, never one of the attempts
                try:
                    ST.prestage(dest, card, pol, root / "stage-cache")
                except ST.StageRejected as e:
                    row["rejection"] = f"{e.code}: {str(e)[:140]}"
        except Exception as e:  # incl. RecursionError/MemoryError from hostile content: the candidate is rejected, the run goes on
            row["rejection"] = f"INSPECT_FAILED: {type(e).__name__}: {str(e)[:120]}"
        admissible += row["rejection"] is None
        rec["inspected"].append(row)
        _stage(s, rec, "inspect", repo=row["repo"], rejection=row["rejection"])


def _select(s, rec, root, pol):
    """Rank the admissible cards (interface fit first; popularity only breaks exact ties) and queue at most the attempt budget."""
    words = AC.wanted_terms(CC.contract_for_gap(rec["frozen"]["signature"]), _types())
    meta = {c["full_name"]: c for c in rec["search"]["candidates"]}
    ranked = []
    for i in rec["inspected"]:
        if i["rejection"]:
            continue
        card = AC.build_card(root / "repos" / i["revision"], i["revision"], i["repo"], pol, root / "cards", api_license=meta[i["repo"]].get("license_spdx"),
                             open_issues=meta[i["repo"]].get("open_issues"))
        ranked.append((AC.score(card, words, meta[i["repo"]]), i["repo"], i["revision"]))
    ranked.sort(key=lambda r: (r[0], r[1]), reverse=True)
    k = rec["frozen"]["budget"]["attempts"]
    rec["queue"] = [{"repo": r, "revision": v} for _, r, v in ranked[:k]]
    rec["reserve"] = [{"repo": r, "revision": v} for _, r, v in ranked[k:]]  # next in line when a staging rejection refunds a slot
    _stage(s, rec, "select", queue=[q["repo"] for q in rec["queue"]])


# ---------------------------------------------------------------- one attempt: STAGE -> ADAPT/VERIFY
def _attempt(s, rec, hooks, pol, root, store_root, clock, stop_path, n, seed, private_dir, run_kw):
    q = rec["queue"][n]
    a = next((x for x in rec["attempts"] if x["n"] == n), None)
    if a is None:
        rt = q.get("retry_of") is not None  # a retry is the same candidate again: no attempt, no build
        _gate(s, rec, clock, stop_path, container_runs=ATTEMPT_MIN_RUNS, model_calls=1, **({} if rt else {"attempts": 1, "builds": 1}))
        a = {"n": n, "repo": q["repo"], "revision": q["revision"], **({"retry_of": q["retry_of"]} if q.get("retry_of") is not None else {}), "state": "STAGE", "rejection": None, "environment": None, "exp_id": None,
             "card_sha256": next(i["card_sha256"] for i in rec["inspected"] if i["repo"] == q["repo"])}
        rec["attempts"].append(a)
        rec["ledger"]["attempts"] += 0 if rt else 1
        _stage(s, rec, "attempt", n=n, repo=q["repo"])
    meta = next(c for c in rec["search"]["candidates"] if c["full_name"] == q["repo"])
    repo_dir = root / "repos" / q["revision"]
    card = AC.build_card(repo_dir, q["revision"], q["repo"], pol, root / "cards", api_license=meta.get("license_spdx"), open_issues=meta.get("open_issues"))
    prev = next((x for x in rec["attempts"] if x["n"] == q["retry_of"]), None) if q.get("retry_of") is not None else None
    if a["environment"] is None and prev and prev.get("environment"):  # a retry reuses the staged image: no second build or download
        a["environment"], a["state"] = dict(prev["environment"]), "ADAPT"
        _save(s, rec)
    if a["environment"] is None:  # STAGE (a recorded environment is reused on resume: never a second build)
        _gate(s, rec, clock, stop_path, builds=1)
        rec["ledger"]["builds"] += 1
        _save(s, rec)
        try:
            env = hooks["stager"].stage(repo_dir, card, CC.images_dir(store_root), root / "stage-cache")
        except ST.StageRejected as e:
            a.update(state="REJECTED", rejection=e.code + ": " + str(e)[:160])
            _stage(s, rec, "stage_rejected", n=n, code=e.code)
            return "REJECTED"
        except (SandboxUnavailable, FileNotFoundError) as e:  # no docker: nothing to stage with, retrying other candidates cannot help
            a.update(state="FAILED", rejection=f"SANDBOX_UNAVAILABLE: {type(e).__name__}")
            raise _End("SANDBOX_UNAVAILABLE", f"{type(e).__name__}: {str(e)[:160]}") from None
        a["environment"] = dict(env)
        a["state"] = "ADAPT"
        _stage(s, rec, "stage", n=n, image=env["id"], tar_sha256=env["image_tar_sha256"])
    else:
        hooks["stager"].ensure(a["environment"])
    env = a["environment"]
    gap = s.get(rec["gap_key"])
    c = CC.contract_for_gap(gap["missing_step"])
    if a["exp_id"] is None:  # ADAPT: one frozen discovery experiment per attempt, bounded by what is left of the run
        _gate(s, rec, clock, stop_path, container_runs=ATTEMPT_MIN_RUNS, model_calls=1)
        L, B = rec["ledger"], rec["frozen"]["budget"]
        ab = {"calls": min(3, B["model_calls"] - L["model_calls"]), "proposals": 3, "container_runs": min(10, B["container_runs"] - L["container_runs"]),
              "in_tokens": 3 * B["max_prompt_tokens"], "out_tokens": min(3 * B["max_out_tokens"], 6000), "wall_s": int(min(900, B["wall_s"] - L["wall_s"])),
              "max_tokens_per_call": B["max_out_tokens"], "max_prompt_tokens": B["max_prompt_tokens"]}
        sb = None  # a retry is seeded with the best candidate so far on this repo (highest dev_pass, latest on ties) and that experiment's feedback
        for x in rec["attempts"]:
            if x["repo"] == q["repo"] and x.get("exp_id") and x["n"] != n:
                pe = s.get(D.KEY + x["exp_id"])
                if q.get("retry_of") is not None and pe and pe.get("best") and (sb is None or pe["best"]["dev_pass"] >= sb["dev_pass"]):
                    sb = {"body": pe["best"]["body"], "dev_pass": pe["best"]["dev_pass"], "feedback": pe.get("feedback") or ""}
        exp = D.open_experiment(s, rec["gap_key"], private_dir=private_dir, seed=seed, budget=ab, environment=CC.env_record(env), seed_best=sb,
                                card_excerpt=AP.staged_text(card, env, CC.import_policy(c)), acq_run=rec["run_id"], tool_modules=env.get("tool_modules") or [], proposer_model=run_kw.get("requested_model"))
        a["exp_id"] = exp["exp_id"]
        _stage(s, rec, "adapt", n=n, exp_id=exp["exp_id"])
    return "RUN"


def _run_exp(store_root, a, run_kw):
    return D.run_experiment(store_root, a["exp_id"], **run_kw)


# ---------------------------------------------------------------- the driver
def run(store_root, run_id, *, hooks, stop_path=None, private_dir=None, seed=None, run_kw=None, admit=None, execute=None):
    """Run or resume one acquisition to a terminal state (or AWAITING_ADMISSION / INTERRUPTED). `hooks` = {github, resolve, clone, stager[, installed]}
    (all injectable; scripts/g2_qualify.py builds the real ones). run_kw goes to discovery.run_experiment (stub_endpoint, requested_model, ...)."""
    store_root, run_kw = Path(store_root), dict(run_kw or {})
    stop_path = Path(stop_path or store_root / "STOP")
    pol = hooks.get("policy") or policy()
    RI.GIT_TIMEOUT_S = int(pol["limits"]["git_timeout_s"])  # every git call of this process (resolve, fetch, lazy blob reads) uses the policy value
    s = Store(store_root)
    try:
        rec = s.get(KEY + run_id)
        if not rec:
            raise Refused("unknown acquisition run")
        if rec["state"] in TERMINAL:
            return rec
        if rec["state"] == "RUNNING" and isinstance(rec.get("pid"), int) and rec["pid"] != os.getpid() and _alive(rec["pid"]):
            raise Refused("acquisition is running in another process")
        rec.update(state="RUNNING", pid=os.getpid(), reason=None)
        _stage(s, rec, "resume" if len(rec["stages"]) > 1 else "start")
        clock, root, rdir = [time.monotonic()], Path(store_root) / "acquisition" / "cache", run_dir(store_root, run_id)  # caches are shared by every run in the store
        root.mkdir(parents=True, exist_ok=True)
        rdir.mkdir(parents=True, exist_ok=True)
        try:
            _drive(s, rec, hooks, pol, root, store_root, clock, stop_path, private_dir, seed, run_kw, admit, execute)
        except _End as e:
            rec.update(state=e.state, reason=e.reason)
        except (ST.StageRejected, RI.RepoIntelError, OSError, ValueError, KeyError) as e:
            rec.update(state="INTERRUPTED", reason=f"{type(e).__name__}: {str(e)[:300]} (resumable; the ledger is kept)")
        rec["ledger"]["wall_s"] += time.monotonic() - clock[0]
        _stage(s, rec, rec["state"].lower())
        if rec["state"] in TERMINAL:
            rec["completed_at"] = _now()
            _record_outcome(s, rec, rdir)
        _save(s, rec)
        return rec
    finally:
        s.close()


def _drive(s, rec, hooks, pol, root, store_root, clock, stop_path, private_dir, seed, run_kw, admit, execute):
    gap = s.get(rec["gap_key"])
    if not gap or not gap.get("missing_step"):
        raise _End("NO_CANDIDATE", "the gap is gone")
    if rec["search"] is None:
        _search(s, rec, hooks, None, clock, stop_path)
    if rec["search"]["retained"] and not rec["frozen"]["require_new_external"]:
        rec["outcome"] = {"tier": "retained", "capability": rec["search"]["retained"][0]}
        raise _End("DONE", "a retained capability already satisfies the gap (no acquisition needed)")
    if not rec["search"]["candidates"]:
        raise _End("NO_CANDIDATE", "search returned no repositories")
    if not rec["queue"]:
        _inspect(s, rec, hooks, pol, root, clock, stop_path)
        _select(s, rec, root, pol)
    if not rec["queue"]:
        raise _End("NO_CANDIDATE", "no inspected repository was admissible: " + "; ".join(f"{i['repo']}: {i['rejection']}" for i in rec["inspected"])[:300])
    n = -1
    while n + 1 < len(rec["queue"]):
        n += 1
        a = next((x for x in rec["attempts"] if x["n"] == n), None)
        if a and a["state"] in ("REJECTED", "FAILED"):
            if a["state"] == "REJECTED":
                _refund(s, rec, a)
            continue
        if a and a["state"] == "PASSED":
            break
        out = _attempt(s, rec, hooks, pol, root, store_root, clock, stop_path, n, seed, private_dir, run_kw)
        a = next(x for x in rec["attempts"] if x["n"] == n)
        if out == "REJECTED":
            _refund(s, rec, a)
            continue
        _gate(s, rec, clock, stop_path)
        exp = _run_exp(store_root, a, dict(run_kw, stop_path=stop_path, private_dir=private_dir))
        if exp["state"] in D.TERMINAL and not a.get("absorbed"):  # only a finished experiment's ledger is folded in (never twice)
            _absorb(rec, exp)
            a["absorbed"] = True
        a.update(exp_state=exp["state"], results=_results(exp), best_dev=(exp.get("best") or {}).get("dev_pass") or 0)
        if exp["state"] == "CANDIDATE_PASSED":
            a.update(state="PASSED", adapter_sha256=exp["candidate_sha256"])
            _stage(s, rec, "verify", n=n, exp_id=exp["exp_id"], adapter_sha256=exp["candidate_sha256"])
            break
        _stage(s, rec, "verify_failed", n=n, state=exp["state"])
        if exp["state"] == "MODEL_UNAVAILABLE":
            a.update(state="FAILED", rejection=exp.get("reason"))
            raise _End("MODEL_UNAVAILABLE", exp.get("reason") or "")
        if exp["state"] == "BUDGET_EXHAUSTED" and str(exp.get("reason", "")).startswith("prompt exceeds"):  # would repeat for every candidate
            a.update(state="FAILED", rejection=exp.get("reason"))
            raise _End("BUDGET_EXHAUSTED", exp.get("reason") or "")
        if exp["state"] == "STOPPED":
            raise _End("STOPPED", "STOP is set")
        if exp["state"] not in D.TERMINAL:  # INTERRUPTED: resumable
            raise _End("INTERRUPTED", exp.get("reason") or "experiment interrupted")
        a.update(state="FAILED", rejection=f"{exp['state']}: {exp.get('reason')}"[:300])
        q = rec["queue"][n]
        mine = [x for x in rec["attempts"] if x["repo"] == q["repo"]]
        before = max([x.get("best_dev") or 0 for x in mine if x["n"] != n] or [0])
        if a["best_dev"] > before and sum(1 for x in mine if x.get("retry_of") is not None) < 3:
            # strict dev progress on this repo (first run: any pass): queue another retry of the same candidate, seeded with the best so far
            rec["queue"].insert(n + 1, {"repo": q["repo"], "revision": q["revision"], "retry_of": n})
            _stage(s, rec, "retry_queued", n=n, repo=q["repo"])
        _save(s, rec)
    passed = next((x for x in rec["attempts"] if x["state"] == "PASSED"), None)
    if passed is None:
        raise _End("CANDIDATES_EXHAUSTED", f"{len(rec['attempts'])} candidate attempts, none verified")
    _admit_and_execute(s, rec, passed, store_root, clock, stop_path, admit, execute)


def _live(rec, upto=None):
    """Queue entries (the first `upto`) that occupy an attempt slot: neither a refunded staging rejection nor a retry (a retry is the same candidate)."""
    dead = {a["n"] for a in rec["attempts"] if a.get("refunded")}
    return sum(1 for i, q in enumerate(rec["queue"][:upto]) if i not in dead and q.get("retry_of") is None)


def _refund(s, rec, a):
    """A staging rejection before any experiment opened costs no attempt and no build: free the slot for the next ranked repository. Bounded by stage_rejects."""
    if a.get("refunded"):
        return
    a["refunded"] = True
    rec["ledger"]["attempts"] -= 1
    rec["ledger"]["builds"] -= 1
    rejects = sum(1 for x in rec["attempts"] if x.get("refunded"))
    _save(s, rec)
    if rejects > rec["frozen"]["budget"]["stage_rejects"]:
        raise _End("CANDIDATES_EXHAUSTED", f"{rejects} repositories were rejected at staging (stage_rejects {rec['frozen']['budget']['stage_rejects']}); none verified")
    if rec.get("reserve") and _live(rec) < rec["frozen"]["budget"]["attempts"]:
        rec["queue"].append(rec["reserve"].pop(0))
        _save(s, rec)


def _results(exp):
    files = [dict({k: p.get(k) for k in ("n", "sha256", "static", "dev", "acceptance")}, feedback=(p.get("feedback") or "")[:400],
                  files={"cand": f"cand-{p['sha256']}.py", "reply": f"reply-{p['n']}.txt"})
             for p in exp.get("proposals", [])]
    return {"baselines": exp.get("baselines"), "proposals": files,
            "ledger": exp.get("ledger"), "receipt": exp.get("receipt"), "state": exp["state"], "reason": exp.get("reason")}


def _admitted(s, exp_id, cap_id):
    return next((e for e in CR.history(s, cap_id) if e["type"] == "admit" and e.get("exp_id") == exp_id), None)


def _admit_and_execute(s, rec, a, store_root, clock, stop_path, admit, execute):
    cap = CC.get(CC.contract_for_gap(s.get(rec["gap_key"])["missing_step"])["capability_id"])["capability_id"]
    _gate(s, rec, clock, stop_path)
    if _admitted(s, a["exp_id"], cap) is None:
        if admit is None:  # the key holder admits out of band (scripts/hive_admission.py admit); resume afterwards
            rec["reason"] = f"verified; run `python scripts/hive_admission.py admit --store <store> --exp {a['exp_id']} --key <key>`, then resume"
            raise _End("AWAITING_ADMISSION", rec["reason"])
        try:
            res = admit(str(store_root), a["exp_id"])
        except Refused as e:
            a["admission"] = {"refused": str(e)[:240]}
            raise _End("ADMISSION_REFUSED", str(e)[:240]) from None
        a["admission"] = {k: res.get(k) for k in ("cap_id", "version", "statement_sha", "rerun_receipt_sha256")}
        _stage(s, rec, "admit", cap_id=cap, version=res.get("version"))
    else:
        ev = _admitted(s, a["exp_id"], cap)
        a["admission"] = {"cap_id": cap, "statement_sha": ev.get("statement_sha")}
    if execute is None:
        rec["outcome"] = {"tier": "github", "repo": a["repo"], "revision": a["revision"], "exp_id": a["exp_id"], "executed": False}
        raise _End("DONE", "admitted; execution is the goal's next run (reuse)")
    res = execute(str(store_root))
    ok = isinstance(res, dict) and res.get("state") == "VERIFIED"
    rec["outcome"] = {"tier": "github", "repo": a["repo"], "revision": a["revision"], "exp_id": a["exp_id"], "executed": True, "goal_state": (res or {}).get("state")}
    _stage(s, rec, "execute", state=(res or {}).get("state"))
    raise _End("DONE" if ok else "FAILED_EXECUTE", "" if ok else f"goal ended {(res or {}).get('state')}: {str((res or {}).get('reason'))[:200]}")


def _persistence(store_root, rec):
    """For every attempt's experiment: which of its candidate/reply files exist (every call has a reply-N.txt, every distinct proposal a cand-*.py)."""
    out = {}
    for a in rec["attempts"]:
        if not a.get("exp_id"):
            continue
        d = Path(store_root) / "discovery" / a["exp_id"]
        want = []
        for p in (a.get("results") or {}).get("proposals", []):
            want += [p["files"]["cand"], p["files"]["reply"]]
        out[a["exp_id"]] = {"dir": f"discovery/{a['exp_id']}", "expected": len(want), "missing": [w for w in want if not (d / w).is_file()]}
    return out


def _record_outcome(s, rec, root):
    """RECORD_OUTCOME: the run manifest. Counters, attempts and hashes only; nothing the proposer said except through the evaluator's receipts."""
    rec["persistence"] = _persistence(root.parent.parent, rec)
    m = manifest(s, rec)
    p = root / "run-manifest.json"
    p.write_text(json.dumps(m, sort_keys=True, indent=1), encoding="utf-8", newline="\n")
    rec["manifest"] = {"path": p.name, "sha256": _file_sha(p)}
    _stage(s, rec, "record_outcome", manifest_sha256=rec["manifest"]["sha256"])


def _cost(exps):
    """Model and cost of a run from what its dispatch records say was EXECUTED: local = $0; hosted = an estimate (tokens x the configured price table;
    the hosted usage ledger under the user profile is the record of truth). cost_complete is False when a hosted call reported no token counts."""
    from . import m2_model as M
    disp = [d for e in exps for d in e.get("dispatches", []) if d.get("called")]
    ran = [d["executed_model"] for d in disp if d.get("executed_model")]
    hosted = [d for d in disp if M.is_hosted(d.get("executed_model"))]
    out = {"model": ran[-1] if ran else next((e["frozen"]["proposer"]["model"] for e in exps), None), "executed_models": sorted(set(ran))}
    if not hosted:
        return dict(out, cost_usd=0.0, cost_note="local model, no paid calls")
    try: price = M._dispatch_cfg()["pricing"]
    except (OSError, ValueError, KeyError): price = {}
    est, complete = 0.0, True
    for d in hosted:
        p = price.get(d["executed_model"])
        if p is None or d.get("tokens_in") is None or d.get("tokens_out") is None: complete = False; continue
        est += (p["fresh_input"] * d["tokens_in"] + p["output"] * d["tokens_out"]) / 1e6  # cached input priced as fresh: an upper bound
    return dict(out, cost_usd=round(est, 6), cost_complete=complete, cost_note="hosted model, PAID calls: estimate from token counts x configured prices (upper bound); the hosted spend ledger is the record. The query-suggestion call is not included here")


def manifest(s, rec):
    """Machine-readable run manifest (hive-g2-run-v1): every attempt and why it ended, queries, card shas, adapter, image, results, costs."""
    fz = rec["frozen"]
    atts = []
    for a in rec["attempts"]:
        env = a.get("environment") or {}
        atts.append({"n": a["n"], "repo": a["repo"], "revision": a["revision"], "card_sha256": a["card_sha256"], "state": a["state"], "retry_of": a.get("retry_of"), "refunded": bool(a.get("refunded")), "rejection": a.get("rejection"),
                     "license": next((i["license"] for i in rec["inspected"] if i["repo"] == a["repo"]), None), "exp_id": a.get("exp_id"),
                     "adapter_sha256": a.get("adapter_sha256"), "environment": dict({k: env.get(k) for k in ("id", "image_tar_sha256", "lock_sha256", "packages", "vendored_tree_sha256", "optional_skipped")},
                                     optional=[w["name"] + "==" + w["version"] for w in env.get("wheelhouse", []) if isinstance(w, dict) and w.get("optional")]) if env else None,
                     "results": a.get("results"), "admission": a.get("admission")})
    exps = [e for e in D.experiments(s, rec["gap_key"]) if e["frozen"].get("acq_run") == rec["run_id"]]
    return {"schema": "hive-g2-run-v1", "run_id": rec["run_id"], "state": rec["state"], "reason": rec["reason"], "gap_key": rec["gap_key"], "contract": fz["contract"],
            "require_new_external": fz["require_new_external"], "budget": fz["budget"], "search": rec["search"], "inspected": rec["inspected"], "skipped_before_inspection": rec.get("skipped", []), "attempts": atts,
            **_cost(exps), "ledger": rec["ledger"],
            "network_error": rec.get("network_error"), "persistence": rec.get("persistence"), "outcome": rec.get("outcome"), "opened_at": rec["opened_at"], "completed_at": rec.get("completed_at"),
            "fixture_author": "conductor-side agent, not Ian (independent of any adapter and of every candidate tool)",
            "stages": [{k: v for k, v in x.items() if k != "at"} for x in rec["stages"]]}


# ---------------------------------------------------------------- improve (T14)
def improve(store_root, cap_id, objective, *, admit=None, stop_path=None, stub_endpoint=None, private_dir=None, holdout_seed=None, requested_model=None, dispatch_cfg=None, budget=None):
    """An explicit, authorised request for a NEW VERSION of an already-admitted capability (the only bypass of 'one finished run per gap').
    objective = {"kind": "failure_class", "value": "wrong_output"|"run_error"}.
    Opens one bounded experiment (same budgets/caps as acquisition), runs it, and only when every mandatory check passed AND the objective improved asks
    `admit(store_root, exp_id)` (the signed authority, e.g. hive_admission.admit) for version N+1. Otherwise the result is REJECTED, the evidence is kept,
    an unsigned `rejected` event is chained and the current version stays active. Returns {state, cap_id, exp_id, version, active_version, comparison, reason}."""
    s = Store(store_root)
    try:
        rec = D.open_improvement(s, cap_id, objective, private_dir=private_dir, seed=holdout_seed, budget=budget, proposer_model=requested_model)
    finally:
        s.close()
    done = D.run_experiment(store_root, rec["exp_id"], stop_path=stop_path, stub_endpoint=stub_endpoint, private_dir=private_dir, requested_model=requested_model, dispatch_cfg=dispatch_cfg)
    s = Store(store_root)
    try:
        out = {"cap_id": cap_id, "exp_id": done["exp_id"], "version": None, "reason": done.get("reason")}
        if done["state"] not in D.TERMINAL:
            return dict(out, state=done["state"], active_version=_active(s, cap_id))  # interrupted: resumable, nothing decided
        res = None
        if done["state"] == "CANDIDATE_PASSED":
            if admit is None:
                return dict(out, state="AWAITING_ADMISSION", active_version=_active(s, cap_id), reason="verified and improved; the key holder runs hive_admission.py admit --exp " + done["exp_id"])
            s.close()  # the authority opens the store itself
            try:
                res = admit(str(store_root), done["exp_id"])
            except Refused as e:
                s = Store(store_root)
                return dict(out, state="ADMISSION_REFUSED", reason=str(e)[:240], active_version=_active(s, cap_id))
            s = Store(store_root)
            r, ref = D.comparison(s, s.get(D.KEY + done["exp_id"]), admitted=res)
            return dict(out, state="ADMITTED", version=res["version"], active_version=_active(s, cap_id), comparison={"ref": ref, "receipt_sha256": r["receipt_sha256"]})
        r, ref = D.comparison(s, done, reason=done.get("reason") or done["state"])
        CR.append(s, cap_id, "rejected", exp_id=done["exp_id"], reason=f"improvement {done['state']}: {str(done.get('reason'))[:200]}")
        return dict(out, state="REJECTED", active_version=_active(s, cap_id), comparison={"ref": ref, "receipt_sha256": r["receipt_sha256"]})
    finally:
        s.close()


def _active(s, cap_id):
    try:
        return CR.resolve_discovered(s, cap_id)["version"]
    except Refused:
        return None
