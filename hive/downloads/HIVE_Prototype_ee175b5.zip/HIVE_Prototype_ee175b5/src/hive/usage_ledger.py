"""Cache-aware usage + cost accounting append-only JSONL ledger.

Each line stores ``prev_sha256`` = sha256 of the previous line's raw bytes
("" for the first), forming a tamper-evident chain. Costs are computed per
model using a pricing map keyed by model name with per-1M-token USD prices for
``fresh_input``, ``cached_read``, ``cache_write`` and ``output``. Unknown
models raise ``KeyError`` (never zero). Measured and estimated costs are kept
separately.
"""
from __future__ import annotations

import contextlib
import hashlib
import json
import math
import os
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class UsageRecord:
    """A single usage measurement or estimate."""

    run_id: str
    parent_run_id: str | None
    task_id: str
    model: str
    fresh_input_tokens: int
    cached_read_tokens: int
    cache_write_tokens: int
    output_tokens: int
    wall_seconds: float
    measured: bool
    source: str


def _win_api():
    """kernel32 with explicit pointer-sized signatures (HANDLE is 64-bit)."""
    import ctypes
    from ctypes import wintypes as w

    class OVERLAPPED(ctypes.Structure):
        _fields_ = [("Internal", ctypes.c_size_t), ("InternalHigh", ctypes.c_size_t), ("Offset", w.DWORD),
                    ("OffsetHigh", w.DWORD), ("hEvent", ctypes.c_void_p)]

    k = ctypes.WinDLL("kernel32", use_last_error=True)
    H, P, D, B = ctypes.c_void_p, ctypes.POINTER(OVERLAPPED), w.DWORD, w.BOOL
    k.CreateFileW.argtypes = [w.LPCWSTR, D, D, ctypes.c_void_p, D, D, H]
    k.CreateFileW.restype = H
    k.CreateEventW.argtypes = [ctypes.c_void_p, B, B, w.LPCWSTR]
    k.CreateEventW.restype = H
    k.LockFileEx.argtypes = [H, D, D, D, D, P]
    k.LockFileEx.restype = B
    k.UnlockFileEx.argtypes = [H, D, D, D, P]
    k.UnlockFileEx.restype = B
    k.WaitForSingleObject.argtypes = [H, D]
    k.WaitForSingleObject.restype = D
    k.CancelIoEx.argtypes = [H, P]
    k.CancelIoEx.restype = B
    k.GetOverlappedResult.argtypes = [H, P, ctypes.POINTER(D), B]
    k.GetOverlappedResult.restype = B
    k.CloseHandle.argtypes = [H]
    k.CloseHandle.restype = B
    return k, OVERLAPPED


def _win_lock(lock_path: Path, timeout_s: float) -> int:
    """Kernel-queued exclusive lock on byte 0 of the lock file (FIFO-ish, no poll starvation); returns the file handle."""
    import ctypes
    from ctypes import wintypes as w

    k, OVERLAPPED = _win_api()

    def fail():
        return ctypes.WinError(ctypes.get_last_error())

    h = k.CreateFileW(str(lock_path), 0xC0000000, 7, None, 4, 0x40000000, None)  # R|W, share all, OPEN_ALWAYS, OVERLAPPED
    if h is None or h == ctypes.c_void_p(-1).value:
        raise fail()
    ev = k.CreateEventW(None, True, False, None)
    if not ev:
        err = fail()
        k.CloseHandle(h)
        raise err
    ov = OVERLAPPED()
    ov.hEvent = ev
    done = ctypes.c_ulong(0)
    try:
        if not k.LockFileEx(h, 2, 0, 1, 0, ctypes.byref(ov)):  # LOCKFILE_EXCLUSIVE_LOCK
            if ctypes.get_last_error() != 997:  # ERROR_IO_PENDING
                raise fail()
            if k.WaitForSingleObject(ev, max(0, int(timeout_s * 1000))) != 0:
                k.CancelIoEx(h, ctypes.byref(ov))
                if not k.GetOverlappedResult(h, ctypes.byref(ov), ctypes.byref(done), True):
                    if ctypes.get_last_error() == 995:  # ERROR_OPERATION_ABORTED: cancelled before the grant
                        raise TimeoutError(f"timed out waiting for lock on {lock_path}")
                    raise fail()
                # else: granted in the race with the cancel; we hold the lock
            elif not k.GetOverlappedResult(h, ctypes.byref(ov), ctypes.byref(done), True):
                raise fail()
    except BaseException:
        k.CloseHandle(ev)
        k.CloseHandle(h)
        raise
    k.CloseHandle(ev)
    return h


def _win_unlock(h: int) -> None:
    import ctypes

    k, OVERLAPPED = _win_api()
    ov = OVERLAPPED()
    try:
        k.UnlockFileEx(h, 0, 1, 0, ctypes.byref(ov))
    finally:
        k.CloseHandle(h)  # closing the handle releases the lock regardless



class UsageLedger:
    """Append-only JSONL ledger with a hash chain over line bytes."""

    def __init__(self, path: str | Path, pricing: dict[str, dict[str, float]]) -> None:
        self.path = Path(path)
        self.pricing = pricing
        self._lock = threading.RLock()
        self.lock_path = self.path.with_name(self.path.name + ".lock")
        self.lock_fd: int | None = None
        self._depth = 0
        self.lock_timeout_s = 10.0
        self.path.parent.mkdir(parents=True, exist_ok=True)

    # ---- cost computation -------------------------------------------------

    def _price(self, model: str) -> dict[str, float]:
        if model not in self.pricing:
            raise KeyError(f"unknown model: {model}")
        return self.pricing[model]

    def cost_usd(self, rec: UsageRecord) -> float:
        """USD cost of a record using per-1M-token pricing."""
        price = self._price(rec.model)
        for name in ("fresh_input_tokens", "cached_read_tokens", "cache_write_tokens", "output_tokens"):
            v = getattr(rec, name)
            if type(v) is not int or v < 0:  # a negative or non-integer count would buy budget
                raise ValueError(f"{name} must be a non-negative integer, got {v!r}")
        if any(type(v) not in (int, float) or not math.isfinite(v) or v < 0 for v in price.values()):
            raise ValueError(f"price table for {rec.model} must be finite and non-negative")
        return (
            price["fresh_input"] * rec.fresh_input_tokens / 1e6
            + price["cached_read"] * rec.cached_read_tokens / 1e6
            + price["cache_write"] * rec.cache_write_tokens / 1e6
            + price["output"] * rec.output_tokens / 1e6
        )

    # ---- append / read ----------------------------------------------------

    def _read_lines(self) -> list[bytes]:
        if not self.path.exists():
            return []
        with self.path.open("rb") as handle:
            return [line for line in handle.readlines() if line.strip()]

    def _tail(self) -> tuple[str, int]:
        """(sha256 of the last line, line count); caller holds the cross-process lock."""
        lines = self._read_lines()
        return (hashlib.sha256(lines[-1]).hexdigest() if lines else ""), len(lines)

    def append(self, entry: dict[str, Any]) -> None:
        """Append one hash-chained, sequenced JSON line under the cross-process lock."""
        with self.locked():
            if self.path.exists() and self.path.stat().st_size:
                with self.path.open("rb") as handle:
                    handle.seek(-1, os.SEEK_END)
                    if handle.read(1) != b"\n":  # torn tail from a crashed write: never glue onto it
                        raise ValueError(f"usage ledger {self.path} has a torn last line; operator repair required")
            prev, count = self._tail()
            entry["prev_sha256"], entry["seq"] = prev, count
            line = (json.dumps(entry, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode("utf-8")
            with self.path.open("ab") as handle:
                handle.write(line)
                handle.flush()
                os.fsync(handle.fileno())

    def record(self, rec: UsageRecord, reservation_id: str | None = None) -> None:
        """Append a record to the ledger, chaining on the previous line. Settles ``reservation_id`` if given."""
        cost = self.cost_usd(rec)
        entry: dict[str, Any] = {
            "run_id": rec.run_id,
            "parent_run_id": rec.parent_run_id,
            "task_id": rec.task_id,
            "model": rec.model,
            "fresh_input_tokens": rec.fresh_input_tokens,
            "cached_read_tokens": rec.cached_read_tokens,
            "cache_write_tokens": rec.cache_write_tokens,
            "output_tokens": rec.output_tokens,
            "wall_seconds": rec.wall_seconds,
            "measured": rec.measured,
            "source": rec.source,
            "cost_usd": cost,
        }
        if reservation_id:
            entry["reservation_id"] = reservation_id
        self.append(entry)

    def reserve(self, run_id: str, task_id: str, model: str, est_cost_usd: float) -> str:
        """Append an allocation record (estimated cost held against the budget until settled by ``record``).

        Call inside ``locked()`` together with the budget check so check+allocate is one atomic step.
        An interrupted request never settles, so its reservation stays counted (conservative, never refunded).
        """
        if type(est_cost_usd) not in (int, float) or not math.isfinite(est_cost_usd) or est_cost_usd < 0:
            raise ValueError(f"reservation cost must be finite and non-negative, got {est_cost_usd!r}")
        rid = uuid.uuid4().hex
        self.append({"kind": "reservation", "reservation_id": rid, "run_id": run_id, "task_id": task_id,
                      "model": model, "cost_usd": float(est_cost_usd)})
        return rid

    def release(self, reservation_id: str) -> None:
        """Void a reservation whose request never left the process (nothing was spent)."""
        self.append({"kind": "release", "reservation_id": reservation_id})

    def outstanding_reserved_usd(self) -> float:
        """Estimated cost of reservations with no settling usage record."""
        recs = self._iter_all()
        settled = {r["reservation_id"] for r in recs if r.get("kind") != "reservation" and r.get("reservation_id")}  # usage or release
        return sum(r["cost_usd"] for r in recs if r.get("kind") == "reservation" and r["reservation_id"] not in settled)

    @contextlib.contextmanager
    def locked(self):
        """Re-entrant cross-process exclusive lock; raises (never proceeds unlocked) on any lock error."""
        with self._lock:
            if self._depth == 0:
                self._acquire_lock()
            self._depth += 1
            try:
                yield
            finally:
                self._depth -= 1
                if self._depth == 0:
                    self._release_lock()

    def _acquire_lock(self) -> None:
        if os.name == "nt":
            self.lock_fd = _win_lock(self.lock_path, self.lock_timeout_s)
            return
        # ponytail: POSIX flock is still a non-fair poll (10 ms); a queued blocking flock + alarm if starvation shows up there
        import fcntl

        fd = os.open(str(self.lock_path), os.O_CREAT | os.O_RDWR, 0o644)
        deadline = time.monotonic() + self.lock_timeout_s
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                self.lock_fd = fd
                return
            except OSError:
                if time.monotonic() >= deadline:
                    os.close(fd)
                    raise TimeoutError(f"timed out waiting for lock on {self.lock_path}") from None
                time.sleep(0.01)

    def _release_lock(self) -> None:
        fd, self.lock_fd = self.lock_fd, None
        if fd is None:
            return
        if os.name == "nt":
            _win_unlock(fd)
            return
        import fcntl

        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)

    def _iter_all(self) -> list[dict[str, Any]]:
        rows = [json.loads(line.decode("utf-8")) for line in self._read_lines()]
        for r in rows:  # a forged negative (or non-numeric) cost line must never reduce what is counted as spent
            c = r.get("cost_usd", 0)
            if type(c) not in (int, float) or not math.isfinite(c) or c < 0:
                raise ValueError(f"usage ledger line {r.get('seq')} has an invalid cost_usd {c!r}")
        return rows

    def _iter_records(self) -> list[dict[str, Any]]:
        return [r for r in self._iter_all() if r.get("kind") not in ("reservation", "release", "genesis")]

    # ---- totals -----------------------------------------------------------

    def totals(self, run_id: str | None = None, include_children: bool = True) -> dict[str, Any]:
        """Aggregate token/cost totals, optionally rolling up the parent chain."""
        records = self._iter_records()
        selected: list[dict[str, Any]] = []
        for rec in records:
            if run_id is None:
                selected.append(rec)
                continue
            if rec["run_id"] == run_id:
                selected.append(rec)
            elif include_children and self._descends_from(rec, run_id, records):
                selected.append(rec)

        fresh = sum(r["fresh_input_tokens"] for r in selected)
        cached_read = sum(r["cached_read_tokens"] for r in selected)
        cache_write = sum(r["cache_write_tokens"] for r in selected)
        output = sum(r["output_tokens"] for r in selected)
        usd_measured = sum(r["cost_usd"] for r in selected if r["measured"])
        usd_estimated = sum(r["cost_usd"] for r in selected if not r["measured"])
        return {
            "fresh_input_tokens": fresh,
            "cached_read_tokens": cached_read,
            "cache_write_tokens": cache_write,
            "output_tokens": output,
            "usd_measured": usd_measured,
            "usd_estimated": usd_estimated,
        }

    def _descends_from(self, rec: dict[str, Any], ancestor: str, all_records: list[dict[str, Any]]) -> bool:
        by_run: dict[str, dict[str, Any]] = {}
        for r in all_records:
            by_run[r["run_id"]] = r
        seen: set[str] = set()
        current: str | None = rec.get("parent_run_id")
        while current is not None and current not in seen:
            seen.add(current)
            if current == ancestor:
                return True
            parent = by_run.get(current)
            if parent is None:
                return False
            current = parent.get("parent_run_id")
        return False

    # ---- verify chain -----------------------------------------------------

    def verify_chain(self) -> bool:
        """Return True iff every line's prev_sha256 matches the prior line's sha256."""
        lines = self._read_lines()
        prev = ""
        for n, line in enumerate(lines):
            try:
                entry = json.loads(line.decode("utf-8"))
            except (json.JSONDecodeError, UnicodeDecodeError):
                return False
            if entry.get("prev_sha256") != prev or entry.get("seq", n) != n:
                return False
            prev = hashlib.sha256(line).hexdigest()
        return True


class HostedLedger(UsageLedger):
    """The hosted-spend ledger: lives outside the store (configs/model_dispatch.json budget.ledger, under the user profile) and FAILS CLOSED.
    `check()` refuses a missing, emptied, truncated, chain-broken or negative-cost ledger. The ledger starts with a genesis line written only by `init()`
    (scripts/init_hosted_ledger.py); a sidecar `.head` file holds the last (seq, sha256), so cutting lines off the end is detected too.
    ponytail: the head file has the ledger's own trust level (neither is keyed); the threat model puts both out of the store writer's reach."""

    @property
    def head_path(self) -> Path:
        return self.path.with_name(self.path.name + ".head")

    def append(self, entry: dict[str, Any]) -> None:
        with self.locked():
            super().append(entry)
            lines = self._read_lines()
            tmp = self.head_path.with_name(self.head_path.name + ".tmp")
            tmp.write_text(json.dumps({"seq": len(lines) - 1, "sha256": hashlib.sha256(lines[-1]).hexdigest()}), encoding="utf-8")
            os.replace(tmp, self.head_path)

    def init(self) -> None:
        """Create the ledger with its genesis line. Refuses when either file already exists (an existing ledger is never reset)."""
        with self.locked():
            if self.path.exists() or self.head_path.exists():
                raise ValueError(f"hosted ledger {self.path} already exists: never re-initialised")
            self.append({"kind": "genesis", "run_id": "genesis", "cost_usd": 0.0, "created": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})

    def check(self) -> None:
        """Raise ValueError unless the ledger is intact. Call inside `locked()` together with the budget check."""
        lines = self._read_lines()
        if not lines:
            raise ValueError("hosted spend ledger is missing or empty (fail closed; init it with scripts/init_hosted_ledger.py)")
        if not self.verify_chain():
            raise ValueError("hosted spend ledger hash chain is broken")
        if json.loads(lines[0]).get("kind") != "genesis":
            raise ValueError("hosted spend ledger has no genesis line")
        try:
            head = json.loads(self.head_path.read_text(encoding="utf-8"))
            seq, sha = head["seq"], head["sha256"]
        except (OSError, ValueError, KeyError, TypeError):
            raise ValueError("hosted spend ledger head file is missing or unreadable") from None
        if type(seq) is not int or not 0 <= seq < len(lines) or hashlib.sha256(lines[seq]).hexdigest() != sha:
            raise ValueError("hosted spend ledger is truncated or rewritten (head mismatch)")
        self._iter_all()  # also refuses negative costs
