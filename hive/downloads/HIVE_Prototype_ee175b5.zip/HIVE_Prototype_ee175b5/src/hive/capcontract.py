"""G1 general capability contract: the one place that knows what a capability IS (interface, limits, evaluator, pins).

Contracts live in capabilities/<capability_id>/contract.json (schema: schemas/capability-contract-v1.json), are hand-reviewed and never
written by a proposer. Core modules (goal_runner, discovery, capability_registry, scripts/hive_admission.py) read them through this
module and carry no task knowledge. Admitted v1 statements are read through `normalize`, which synthesizes the same contract view
from the statement's own fields; the stored statement is never rewritten. Stdlib only; fails closed with Refused."""
from __future__ import annotations

import base64
import contextlib
import copy
import importlib.util
import json
import re
import sys
import tempfile
from pathlib import Path

from . import operator_runtime as O
from .bounded import run_bounded
from .operator_runtime import Refused, _sha

ROOT = O.ROOT
SCHEMA, V1, V2 = "hive-capability-contract-v1", "hive-capability-admission-v1", "hive-capability-admission-v2"
SCHEMA2, V3 = "hive-capability-contract-v2", "hive-capability-admission-v3"  # G2: derived environments, binary envelope; v1/v2 stay valid
SCHEMA_PATH, CAPS = ROOT / "schemas" / "capability-contract-v1.json", ROOT / "capabilities"
SCHEMA2_PATH = ROOT / "schemas" / "capability-contract-v2.json"
CRLF, LF = bytes([13, 10]), bytes([10])
VERIFY_TIMEOUT_S = 60
# bare module names the evaluator families share (the evaluator folders import each other by bare name)
_BARE = ("oracle", "gen_public", "gen_private", "harness", "evaluate", "baseline_script", "baseline")
_VERIFY = r"""
import importlib.util, json, sys
spec = importlib.util.spec_from_file_location("hive_c4_oracle", sys.argv[1]); o = importlib.util.module_from_spec(spec); spec.loader.exec_module(o)
job = json.load(open(sys.argv[2], encoding="utf-8"))
try:
    exp = getattr(o, sys.argv[3])(job["env"])
    res = {"verdict": "PASS" if exp == job["output"] else "FAIL", "expected_sha256": __import__("hashlib").sha256(exp.encode()).hexdigest()}
except Exception as e:
    res = {"verdict": "UNVERIFIABLE", "reason": type(e).__name__ + ": " + str(e)[:200]}
print(json.dumps(res))
"""


def canon(o): return json.dumps(o, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sha(contract): return _sha(canon(contract))


def lf_sha(rel): return _sha((ROOT / rel).read_bytes().replace(CRLF, LF))


# ---------------------------------------------------------------- validation (JSON-schema subset)
_TYPES = {"object": dict, "array": list, "string": str, "integer": int, "boolean": bool, "null": type(None)}


def _is(v, t):
    return isinstance(v, _TYPES[t]) and not (t == "integer" and isinstance(v, bool))


def _check(sc, v, at, out):
    if "const" in sc and (v != sc["const"] or type(v) is not type(sc["const"])):
        out.append(f"{at}: must be {sc['const']!r}")
        return
    if "enum" in sc and v not in sc["enum"]:
        out.append(f"{at}: not one of {sc['enum']}")
        return
    t = sc.get("type")
    if t is not None and not any(_is(v, x) for x in ([t] if isinstance(t, str) else t)):
        out.append(f"{at}: wrong type")
        return
    if isinstance(v, str):
        if len(v) < sc.get("minLength", 0) or ("pattern" in sc and not re.search(sc["pattern"], v)):
            out.append(f"{at}: bad string")
    elif isinstance(v, int) and not isinstance(v, bool):
        if not sc.get("minimum", v) <= v <= sc.get("maximum", v):
            out.append(f"{at}: out of range")
    elif isinstance(v, list):
        if not sc.get("minItems", 0) <= len(v) <= sc.get("maxItems", len(v)):
            out.append(f"{at}: bad length")
        for n, x in enumerate(v):
            if "items" in sc:
                _check(sc["items"], x, f"{at}[{n}]", out)
    elif isinstance(v, dict):
        props = sc.get("properties", {})
        out += [f"{at}.{k}: missing" for k in sc.get("required", []) if k not in v]
        if sc.get("additionalProperties") is False:
            out += [f"{at}.{k}: unknown field" for k in v if k not in props]
        for k, x in v.items():
            if k in props:
                _check(props[k], x, f"{at}.{k}", out)


_RESERVED = re.compile(r"^(report\.json|s\d+\..*)$", re.I)


def _rel(p):
    """A repo-relative path with no escape from the repo, or Refused."""
    q = Path(str(p).partition("#")[0])
    if q.anchor or q.is_absolute() or ".." in q.parts:
        raise Refused(f"contract path escapes the repo: {str(p)[:80]}")
    return q


def is_v2(c): return isinstance(c, dict) and c.get("schema") == SCHEMA2


def base_image(c):
    """The pinned base image a contract builds on: the environment itself (pinned) or the derived environment's base."""
    e = c["execution"]["environment_ref"]
    return e["base"] if e.get("kind") == "derived" else e


def _v2_rules(c):
    """Cross-field rules the schema subset cannot express."""
    i, e, p = c["inputs"], c["execution"]["environment_ref"], c["permissions"]
    if e["kind"] == "pinned" and ("image" not in e or "digest" not in e or "base" in e or "stage_policy" in e):
        raise Refused("contract invalid: a pinned environment needs image+digest only")
    if e["kind"] == "derived":
        if "base" not in e or "stage_policy" not in e or "image" in e or "digest" in e:
            raise Refused("contract invalid: a derived environment needs base+stage_policy only")
        if not (ROOT / _rel(e["stage_policy"])).is_file():
            raise Refused("contract stage_policy file is missing")
    if p["filesystem"] == "read-only-inputs" and i["envelope"] != "files-v2":
        raise Refused("contract invalid: read-only-inputs needs the files-v2 envelope (base64 files to write)")
    if p["imports"]["staged"] and e["kind"] != "derived":
        raise Refused("contract invalid: staged imports need a derived environment")
    if i["envelope"] == "files-v2":
        if i["format"] != "base64" or "limits" not in i or i["arity"][1] > i["limits"]["max_files"]:
            raise Refused("contract invalid: files-v2 needs format base64, limits, and arity within max_files")
    elif "limits" in i:
        raise Refused("contract invalid: limits only apply to files-v2")


def validate(c):
    """Fail closed before anything runs: schema, engine ceilings (the schema encodes them), pinned image, every referenced file."""
    from .adapters.isolation import PINNED_IMAGE
    out = []
    v2 = is_v2(c)
    _check(json.loads((SCHEMA2_PATH if v2 else SCHEMA_PATH).read_text(encoding="utf-8")), c, "contract", out)
    if out:
        raise Refused("contract invalid: " + "; ".join(out[:4]))
    if v2:
        _v2_rules(c)
    v, ex = c["verification"], c["execution"]
    an = c["outputs"]["artifact_name"]
    if an.strip(".") == "" or _RESERVED.match(an):  # names the goal runner itself writes into the same folder
        raise Refused(f"contract artifact_name is reserved: {an[:40]}")
    pins = v["evaluator"]["pin_files"]
    names = [Path(p).name for p in pins]
    if len(set(names)) != len(names):
        raise Refused("contract pin_files must have unique file names")
    need = [v["evaluator"]["path"], v["harness"], v["oracle"].partition("#")[0], v["gen_public"], v["gen_private"]]
    if any(p not in pins for p in need):
        raise Refused("contract pin_files must include the evaluator, harness, oracle and both generators")
    for p in pins + [v["baseline"], v["suite_ref"]]:
        if not (ROOT / _rel(p)).exists():
            raise Refused(f"contract file missing: {p}")
    ref = base_image(c)
    if (ref["image"], ref["digest"]) != (PINNED_IMAGE["reference"], PINNED_IMAGE["digest"]):
        raise Refused("contract environment is not the engine's pinned image")
    ref = ex["adapter_ref"]
    if ref is not None and (set(ref) != {"path", "sha256"} or lf_sha(_rel(ref["path"])) != ref["sha256"]):
        raise Refused("contract adapter does not match its sha256")
    return c


def load(path):
    try:
        c = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        raise Refused(f"contract unreadable: {type(e).__name__}") from None
    validate(c)
    if Path(path).parent.name != c["capability_id"]:
        raise Refused("contract folder name must equal capability_id")
    return c


def _scan():
    """({capability_id: contract}, {capability_id: reason}). One invalid or colliding contract disables only itself."""
    good, bad, names = {}, {}, {}
    for p in sorted(CAPS.glob("*/contract.json")):
        cid = p.parent.name
        try:
            c = load(p)
            an = c["outputs"]["artifact_name"].lower()
            if an in names:
                raise Refused(f"artifact_name collides with capability {names[an]}")
            names[an] = cid
            good[cid] = c
        except (Refused, KeyError, TypeError, ValueError) as e:
            bad[cid] = str(e)[:200]
    return good, bad


def contracts():
    """Every valid repo contract, sorted by capability_id. A broken one is left out (and refused by name in get), not fatal to the rest."""
    return list(_scan()[0].values())


def get(cap_id):
    good, bad = _scan()
    if cap_id in bad:
        raise Refused(f"capability contract {str(cap_id)[:40]!r} is invalid: {bad[cap_id]}")
    c = good.get(cap_id)
    if c is None:
        raise Refused(f"no capability contract for {str(cap_id)[:40]!r}")
    return c


def contracts_for_gap(sig):
    """EVERY contract whose interface matches a typed gap signature {in, arity, out}, in capability_id order (same-contract alternatives)."""
    return [c for c in contracts() if (sorted(c["inputs"]["types"]) == sig["ins"] if "ins" in sig else len(set(c["inputs"]["types"])) == 1 and sig["in"] in c["inputs"]["types"])
            and c["inputs"]["arity"][0] <= sig["arity"] <= c["inputs"]["arity"][1]
            and c["outputs"]["type"] == sig["out"]]


def contract_for_gap(sig):
    """The contract whose interface matches a typed gap signature {in, arity, out}, or None (the first of contracts_for_gap)."""
    return next(iter(contracts_for_gap(sig)), None)


def default():
    """The contract callers get when they name none: the one that accepts legacy (pre-contract) frozen protocols, else the first by id."""
    cs = contracts()
    return next((c for c in cs if c["compatibility"].get("legacy_frozen")), cs[0])


def pin(c):
    """Evaluator pin: sha over `name:sha\\n` of the LF-normalised pin_files, in contract order."""
    return _sha("".join(f"{Path(p).name}:{lf_sha(_rel(p))}\n" for p in c["verification"]["evaluator"]["pin_files"]))


def harness_sha(c): return lf_sha(_rel(c["verification"]["harness"]))


# A contract may declare verification.real_holdout: a sealed, owner-approved real-data set that a candidate must pass once before admission.
HOLDOUT_OPEN, HOLDOUT_RECEIPT = "real_holdout/open/", "real_holdout/receipt/"


def holdout_receipt_sha(r): return _sha(json.dumps({k: v for k, v in r.items() if k != "receipt_sha256"}, sort_keys=True, separators=(",", ":")))


def holdout_problem(store, c, cand):
    """Why the candidate may not be admitted for want of its real-holdout PASS receipt (None when the contract declares none, or the receipt is good)."""
    h = c["verification"].get("real_holdout")
    if not h:
        return None
    r = store.get(HOLDOUT_RECEIPT + c["capability_id"] + "/" + cand)
    if not r:
        return "the contract declares a real holdout and this candidate has no PASS receipt from it"
    if (r.get("receipt_sha256") != holdout_receipt_sha(r) or r.get("candidate_sha256") != cand or r.get("approval_sha256") != h["approval_sha256"]
            or r.get("verdict") != "PASS" or r.get("pass_count") != r.get("n") or not r.get("n")):
        return "the real-holdout receipt is not a PASS bound to this candidate and the contract's approval pin"
    return None


def text_ref(ref):
    """Text behind `file.md` or `file.json#dotted.path` (repo relative)."""
    f, _, key = ref.partition("#")
    raw = (ROOT / _rel(f)).read_text(encoding="utf-8").replace("\r\n", "\n")
    if not key:
        return raw
    v = json.loads(raw)
    for k in key.split("."):
        v = v[k]
    if not isinstance(v, str):
        raise Refused("contract text reference is not text")
    return v


def build_env(c, items):
    """The candidate's input env, by the contract's envelope. items: text (v1) or (name, bytes) pairs."""
    i = c["inputs"]
    if i["envelope"] == "files-v1":
        return {"files": [{"format": i["format"], "text": t if isinstance(t, str) else t[1].decode("utf-8")} for t in items]}
    if i["envelope"] != "files-v2":
        raise Refused("unsupported input envelope")
    L, files, seen, total = i["limits"], [], set(), 0
    if not i["arity"][0] <= len(items) <= min(i["arity"][1], L["max_files"]):
        raise Refused("input count outside the contract")
    for name, data in items:
        total += len(data)
        if not isinstance(data, bytes) or len(data) > L["max_file_bytes"] or total > L["max_total_bytes"] or name in seen:
            raise Refused("input over the contract's size limits, or a duplicate name")
        seen.add(name)
        files.append({"name": name, "format": "base64", "data": base64.b64encode(data).decode("ascii")})
    return {"files": files}


def envelope_text(c):
    i = c["inputs"]
    if i["envelope"] == "files-v2":
        ro = c["permissions"]["filesystem"] == "read-only-inputs"
        return ('env {"files":[{"name":NAME,"format":"base64","data":BASE64' + (',"path":PATH' if ro else "") + '},...]} (%d to %d files, any order; NAME = the file name, BASE64 = its bytes'
                % tuple(i["arity"]) + ("; PATH = the same bytes as a read-only file" if ro else "") + ")")
    return 'env {"files":[' + ",".join('{"format":"%s","text":INPUT_%d}' % (i["format"], n) for n in range(i["arity"][0])) + "]} (INPUT_n = input n, in order)"


def import_policy(c, packages=()):
    """Top-level module names a candidate may import under this contract: its stdlib list plus the staged packages (when `staged`)."""
    if not is_v2(c):
        return ["json"]
    p = c["permissions"]["imports"]
    std = set(sys.stdlib_module_names)
    return sorted(set(p["stdlib"]) | ({x for x in packages if x not in std and x.lower() not in {n.lower() for n in std}} if p["staged"] else set()))


def exec_args(c, env=None):
    """Extra run_isolated arguments for a v2 contract: its resource limits and, when derived, the staged image by ID. {} for v1."""
    if not is_v2(c):
        return {}
    r = c["execution"]["resources"]
    kw = {"limits": {"memory_mb": r["memory_mb"], "cpu_count": r["cpus"], "pids": r["pids"], "tmpfs_mb": r.get("tmpfs_mb", 16)}}
    if env:
        kw["image"] = {"id": env["id"]}
    if c["permissions"]["filesystem"] == "read-only-inputs":
        kw["inputs"] = "read-only"
    return kw


def ensure_image(env, images_dir):
    """Test seam and default: the admitted derived image present locally with exactly its recorded ID (docker load from the verified tar if not)."""
    from . import acq_stage
    pol = json.loads((ROOT / "configs" / "acquisition_policy.json").read_text(encoding="utf-8"))
    try:
        return acq_stage.Stager(pol).ensure(dict(env, tar_path=str(Path(images_dir) / env["tar_name"])))
    except acq_stage.StageRejected as e:
        raise Refused(f"staged image unavailable: {e}") from None


def verify_tar(env, images_dir):
    """Admission-time check, every time and whether or not the image is present: the saved tar hashes to the sha256 the statement will sign."""
    from . import acq_stage
    pol = json.loads((ROOT / "configs" / "acquisition_policy.json").read_text(encoding="utf-8"))
    try:
        acq_stage.Stager(pol).verify_tar(dict(env, tar_path=str(Path(images_dir) / env["tar_name"])))
    except acq_stage.StageRejected as e:
        raise Refused(f"staged image tar not verified: {e}") from None


ENV_KEYS = {"id", "base", "lock_sha256", "wheelhouse_manifest_sha256", "image_tar_sha256", "tar_name", "packages", "vendored_tree_sha256"}


def env_record(e):
    """The statement/frozen form of a Stager environment record: a store-relative tar name instead of a host path, nothing else extra."""
    return {"id": e["id"], "base": dict(e["base"]), "lock_sha256": e["lock_sha256"], "wheelhouse_manifest_sha256": e["wheelhouse_manifest_sha256"],
            "image_tar_sha256": e["image_tar_sha256"], "tar_name": Path(e["tar_path"]).name, "packages": list(e["packages"]),
            "vendored_tree_sha256": e["vendored_tree_sha256"]}


def images_dir(store_root):
    """Where admitted staged-image tars live inside a store."""
    return Path(store_root) / "acquisition" / "images"


def check_environment(env):
    """Shape and base of a statement's derived environment record (before the image itself is looked at)."""
    from .adapters.isolation import PINNED_IMAGE
    if not isinstance(env, dict) or set(env) != ENV_KEYS or not re.fullmatch(r"sha256:[0-9a-f]{64}", str(env["id"])):
        raise Refused("statement environment record is malformed")
    if not re.fullmatch(r"[A-Za-z0-9._-]{1,80}\.tar", str(env["tar_name"])) or not isinstance(env["packages"], list) \
            or not all(isinstance(x, str) and x.isidentifier() and x.lower() not in {n.lower() for n in sys.stdlib_module_names} for x in env["packages"]):
        raise Refused("statement environment record is malformed")
    b = env["base"] if isinstance(env["base"], dict) else {}
    if (b.get("reference"), b.get("digest")) != (PINNED_IMAGE["reference"], PINNED_IMAGE["digest"]):
        raise Refused("derived environment is not built on the engine's pinned image")


# ---------------------------------------------------------------- bare-name evaluator modules
def module_dirs(c):
    v = c["verification"]
    ps = [v["evaluator"]["path"], v["harness"], v["oracle"].partition("#")[0], v["gen_public"], v["gen_private"], v["baseline"]]
    return list(dict.fromkeys(str(ROOT / _rel(p).parent) for p in ps))


@contextlib.contextmanager
def scope(c=None):
    """Evaluator modules import each other by bare name (also at call time), and the evaluator families reuse those names: hide cached
    bare modules inside the scope and restore them after, so no family ever sees another's. In-process calls into evaluate() must run
    in this scope. Default contract = the first repo contract (callers that know their contract pass it)."""
    ds = module_dirs(c or default())
    names = set(_BARE) | {p.stem for d in ds for p in Path(d).glob("*.py")}
    saved, path = {n: sys.modules.pop(n) for n in names if n in sys.modules}, list(sys.path)
    sys.path[:0] = ds
    try:
        yield
    finally:
        sys.path[:] = path  # the evaluator modules also insert their own folder; drop that too
        for n in names:
            sys.modules.pop(n, None)
        sys.modules.update(saved)


def load_module(name, c=None, rel=None):
    """Load `name` (or the file `rel`) from the contract's evaluator folders under an isolated bare-name scope."""
    c = c or default()
    with scope(c):
        f = ROOT / _rel(rel) if rel else next((Path(d) / f"{name}.py" for d in module_dirs(c) if (Path(d) / f"{name}.py").is_file()), None)
        if f is None:
            raise Refused(f"evaluator module {name!r} not found")
        spec = importlib.util.spec_from_file_location("ev_" + name, f)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        return mod


# ---------------------------------------------------------------- statements (v1 + v2)
def normalize(st):
    """Contract view of an admitted statement, either schema. v2 embeds its contract; v1 is synthesized from its own fields over the
    repo contract of the same capability, which must agree on every path (the stored event is never rewritten)."""
    if st.get("schema") in (V2, V3):
        return st["contract"]
    if st.get("schema") != V1:
        raise Refused("unknown statement schema")
    c = copy.deepcopy(get(st["cap_id"]))
    v = c["verification"]
    if (st["harness"]["path"], st["verifier"]["path"] + "#expected", st["verifier"]["evaluator"]) != (v["harness"], v["oracle"], v["evaluator"]["path"]):
        raise Refused("legacy statement paths differ from the repo contract")
    c["inputs"].update(arity=st["arity"], types=[st["in_type"]])
    c["outputs"]["type"] = st["out_type"]
    c["execution"].update(timeout_seconds=st["limits"]["timeout_s"], max_output_bytes=st["limits"]["max_out"],
                          environment_ref={"image": st["env"]["image"], "digest": st["env"]["digest"]})
    return c


def recheck(st, images_dir=None):
    """Current-file checks on EVERY use: nothing in the statement is trusted without recomputing it from the files in the repo.
    v3 (derived environment) additionally needs images_dir (where the admitted image tars live) to prove the image is present."""
    from .adapters.isolation import PINNED_IMAGE
    if _sha(st["body"]) != st["impl_sha256"]:
        raise Refused("implementation body does not match its admitted sha256")
    c, v2, v3 = normalize(st), st["schema"] in (V2, V3), st["schema"] == V3
    if v2:
        if sha(c) != st["contract_sha256"] or c["capability_id"] != st["cap_id"]:
            raise Refused("contract differs from its admitted sha256")
        validate(c)
        if v3 != is_v2(c):
            raise Refused("statement and contract schema versions disagree")
    if harness_sha(c) != (st["harness_sha256"] if v2 else st["harness"]["sha256"]):
        raise Refused("evaluator harness differs from the admitted one")
    if pin(c) != (st["pin"] if v2 else st["verifier"]["pin"]):
        raise Refused("evaluator pin differs from the admitted one")
    e = base_image(c)
    if (e["image"], e["digest"]) != (PINNED_IMAGE["reference"], PINNED_IMAGE["digest"]):
        raise Refused("execution image differs from the admitted one")
    pk = ()
    if v3 and c["execution"]["environment_ref"]["kind"] == "derived":
        env = st.get("environment")
        check_environment(env)
        if images_dir is None:
            raise Refused("no image store given for a derived environment")
        if ensure_image(env, images_dir) != env["id"]:
            raise Refused("staged image ID differs from the admitted one")
        pk = env["packages"]
    elif v3 and "environment" in st:
        raise Refused("a pinned environment cannot carry a staged image record")
    h = load_module("harness", c, c["verification"]["harness"])
    bad = h.static_problems(st["body"], import_policy(c, pk)) if v3 else h.static_problems(st["body"])
    if bad:
        raise Refused("static check failed: " + ", ".join(bad))


def verify(c, env, output, timeout=VERIFY_TIMEOUT_S):
    """Independent output check: the contract's oracle in a separate `python -I` process (mirrors operator_runtime.independent_verify)."""
    oracle, _, fn = c["verification"]["oracle"].partition("#")
    ident = {"evaluator": oracle, "pin": pin(c), "process": "separate python -I"}
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
        job = Path(tmp) / "job.json"
        job.write_text(json.dumps({"env": env, "output": output}), encoding="utf-8")
        try:
            rc, out, _, timed_out = run_bounded([sys.executable, "-I", "-c", _VERIFY, str(ROOT / _rel(oracle)), str(job), fn], timeout=min(timeout, VERIFY_TIMEOUT_S), cwd=tmp)
        except OSError as e:
            return dict(ident, verdict="UNVERIFIABLE", reason=f"evaluator process did not complete: {type(e).__name__}")
    if timed_out:
        return dict(ident, verdict="UNVERIFIABLE", reason="evaluator process did not complete: timed out (process tree killed)")
    try:
        return dict(ident, **json.loads(out.strip().splitlines()[-1]))
    except (ValueError, IndexError):
        return dict(ident, verdict="UNVERIFIABLE", reason=f"evaluator process failed (exit {rc})")
