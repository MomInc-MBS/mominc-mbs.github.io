"""M2 research-subject client (protocol §4, §8, §12, §13): fixed-sampling OpenAI-compatible calls to the local model.
Stdlib only. Never edits a proposal; never executes model output. Stub mode (loopback, any port, no approval) is for testing only."""
from __future__ import annotations
import base64, copy, hashlib, http.client, json, os, re, subprocess, time, urllib.error, urllib.request
from pathlib import Path
from urllib.parse import urlparse
from . import m2_workflow as W
from .usage_ledger import HostedLedger, UsageLedger, UsageRecord

ROOT = W.ROOT


class CapReached(RuntimeError): """A §12 cap was reached: the run ends INCONCLUSIVE (§11)."""
class Invalidated(RuntimeError): """A §8 invalidation trigger (weights, model id, host)."""
class Refused(RuntimeError): """The §13 operator-approval gate refused the call."""
class BudgetRefused(CapReached): """The spend gate refused a call before any request: a priced policy's remaining budget cannot cover its worst-case cost."""
class DataRefused(Refused): """The hosted-backend data guard refused a prompt that carries (or may carry) real input data: nothing was sent."""
class PromptTooLarge(RuntimeError): """The base prompt with no history exceeds the byte cap: blocks the manifest freeze."""


DISPATCH_CFG = ROOT / "configs" / "model_dispatch.json"
LOOPBACK = ("127.0.0.1", "localhost", "::1")
PROMPT_TOKEN_MARGIN = 256  # same chat-template allowance as dispatch_gate

# -- hosted class (config entry "class": "hosted"): a priced, remote OpenAI-compatible endpoint. The allowlist lives in CODE, not in the config or the store:
# exactly these hosts, https only, each mapped to the ONE environment variable its key may come from. Tests patch these two names (and only tests).
HOSTED_HOSTS = {"integrate.api.nvidia.com": "NVIDIA_API_KEY"}
HOSTED_SCHEMES = ("https",)
HOSTED_MAX_BYTES = 1 << 20  # a hosted reply larger than this is refused unread
HOSTED_LIST_TIMEOUT_S = 30
REASONING_LINE = "Reasoning: low\n"  # the gpt-oss-specific first line of the discovery system prompt; a backend may swap it via config "system_prefix"
ENCODED_RUN = re.compile(r"[A-Za-z0-9+/=_-]{512,}")  # a long base64-like run in a hosted prompt is treated as an input payload
KEY_CHARS = re.compile(r"[A-Za-z0-9._~+/=-]{8,512}")


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k): return None  # a 3xx becomes an HTTPError: the key is never forwarded to another URL


_NO_REDIRECT = urllib.request.build_opener(_NoRedirect)


def hosted_endpoint_problem(endpoint):
    """Why `endpoint` is not an allowed hosted endpoint (None = allowed): allowlisted host exactly, https, no userinfo/query/fragment, path /v1."""
    u = urlparse(endpoint)
    try: u.port
    except ValueError: return "bad port"
    if u.scheme not in HOSTED_SCHEMES: return f"scheme {u.scheme!r} is not allowed (https only)"
    if u.hostname not in HOSTED_HOSTS: return f"host {u.hostname!r} is not an allowed hosted host"
    if u.username or u.password or u.query or u.fragment or u.params or u.path.rstrip("/") != "/v1": return "endpoint must be https://<host>/v1 with no userinfo, query or fragment"
    return None


def scrub(text, key):
    return text.replace(key, "[REDACTED]") if key and isinstance(text, str) else text


def data_problem(messages, blobs=()):
    """Why a prompt may not go to a hosted backend (None = clean): it carries a long encoded payload, or a probe of a registered real input blob.
    ponytail: probes are the head/middle/tail 24 chars (+ base64 head) of each blob >= 8 chars; a blob shorter than that, or paraphrased data, is not detectable here."""
    text = "\n".join(str(m.get("content", "")) for m in messages)
    if ENCODED_RUN.search(text): return "prompt carries a long encoded payload"
    for b in blobs or ():
        raw = bytes(b) if isinstance(b, (bytes, bytearray)) else str(b).encode("utf-8")
        s = raw.decode("utf-8", "replace").strip()
        if len(s) < 8: continue
        probes = {s} if len(s) < 24 else {s[:24], s[len(s) // 2 - 12:len(s) // 2 + 12], s[-24:]}
        probes.add(base64.b64encode(raw)[:48].decode("ascii"))
        if any(p and p in text for p in probes): return "prompt contains input file content"
    return None


def _dispatch_cfg(cfg=None):
    return cfg if isinstance(cfg, dict) else json.loads(Path(cfg or DISPATCH_CFG).read_text(encoding="utf-8-sig"))


def list_backends(cfg=None):
    """Ids of the qualified backends (configs/model_dispatch.json "backends"); the first is the default."""
    b = _dispatch_cfg(cfg)["backends"]
    return [b["default"]] + [e["id"] for e in b["list"] if e["id"] != b["default"]]


def request_extra(x):
    """Config-only extra request fields for a hosted backend. Allowlist: chat_template_kwargs.enable_thinking (bool), used to switch a
    reasoning model's hidden thinking off so the code fits max_tokens. Anything else is refused (no headers, no other body fields)."""
    if not (isinstance(x, dict) and set(x) == {"chat_template_kwargs"} and isinstance(x["chat_template_kwargs"], dict)
            and set(x["chat_template_kwargs"]) == {"enable_thinking"} and isinstance(x["chat_template_kwargs"]["enable_thinking"], bool)):
        raise Refused("request_extra: only {\"chat_template_kwargs\": {\"enable_thinking\": bool}} is allowed")
    return {"chat_template_kwargs": {"enable_thinking": x["chat_template_kwargs"]["enable_thinking"]}}


def apply_backend(pol, backend_id=None, cfg=None):
    """A copy of `pol` bound to one qualified backend (id, endpoint, weights file + sha256 pin, approval file), or `pol` itself when backend_id is None
    (the default backend is whatever the policy already names: gpt-oss). Entries inherit missing fields from pol["model"] when they are that same model.
    Caps, sampling and every approval check stay the policy's; only the single-model assumption is configurable. Raises Refused (unknown backend or
    incomplete pins) or Invalidated (non-loopback endpoint). The caller's `pol` is never mutated. CLI/demo entry point."""
    if backend_id is None: return pol
    entries = {e["id"]: e for e in _dispatch_cfg(cfg)["backends"]["list"]}
    if backend_id not in entries: raise Refused(f"backend {backend_id!r} is not a qualified backend ({sorted(entries)})")
    m = dict(pol["model"]) if pol["model"]["id"] == backend_id else {}
    m.update({k: v for k, v in entries[backend_id].items() if k not in ("approval_path", "approval_sha256", "class")})
    hosted = entries[backend_id].get("class") == "hosted"
    if hosted:  # no weights to hash: provider + host + exact model id are the pins (bound again in the approval)
        for k in ("file", "bytes", "sha256"): m.pop(k, None)
        m["hosted"] = True
        missing = [k for k in ("id", "provider", "endpoint", "context") if not m.get(k)]
    else:
        missing = [k for k in ("id", "file", "bytes", "sha256", "endpoint", "context") if not m.get(k)]
    if missing: raise Refused(f"backend {backend_id!r} is missing pins: {missing}")
    if hosted:
        bad = hosted_endpoint_problem(m["endpoint"])
        if bad: raise Invalidated(f"hosted backend endpoint refused: {bad}")
        if backend_id == _dispatch_cfg(cfg)["backends"]["default"]: raise Refused("a hosted backend cannot be the default backend")
        m["key_env"] = HOSTED_HOSTS[urlparse(m["endpoint"]).hostname]  # fixed by code: the config cannot point a host at a different secret
    elif urlparse(m["endpoint"]).hostname not in LOOPBACK: raise Invalidated(f"backend endpoint must be loopback, got {m['endpoint']}")
    p = copy.deepcopy(pol)
    p["model"] = m
    p["approval_path"] = entries[backend_id].get("approval_path") or pol["approval_path"]
    if backend_id != _dispatch_cfg(cfg)["backends"]["default"]:  # a non-default backend needs an ACTIVE approval whose file sha256 is bound here (L4)
        p["approval_sha256"], p["approval_must_be_active"] = entries[backend_id].get("approval_sha256"), True
    return p


def is_hosted(backend_id, cfg=None):
    """True when `backend_id` is a hosted (priced, remote) backend in the config; False for anything else, including an unreadable config."""
    try: return any(e["id"] == backend_id and e.get("class") == "hosted" for e in _dispatch_cfg(cfg)["backends"]["list"])
    except (OSError, ValueError, KeyError, TypeError): return False


def seed_for(campaign, effect, rnd, pol=None):
    pol = pol or W.load_policy()
    return pol["seed_base"] + 1000 * pol["seed_campaign"][campaign] + 100 * pol["seed_effect"][effect] + rnd


def smoke_seed(i, pol=None): return (pol or W.load_policy())["smoke_seed_base"] + i


def parse_reply(content):
    """§4 output contract: last `{` position whose raw_decode is a dict with keys exactly {"steps"} and steps a list of 1..3 strings. Else None."""
    if not isinstance(content, str): return None
    dec, found = json.JSONDecoder(), None
    for p, ch in enumerate(content):
        if ch != "{": continue
        try: obj, _ = dec.raw_decode(content, p)
        except ValueError: continue
        if isinstance(obj, dict) and set(obj) == {"steps"} and isinstance(obj["steps"], list) and 1 <= len(obj["steps"]) <= 3 and all(isinstance(s, str) for s in obj["steps"]):
            found = obj["steps"]
    return found


def weight_sha(path, chunk=1 << 24):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while b := f.read(chunk): h.update(b)
    return h.hexdigest()


def manifest_problems(pol=None, manifest_path=None):
    """Why the evaluation manifest is not frozen (empty = frozen): exists, parses, schema, and every pin it records equals the live value."""
    pol, path = pol or W.load_policy(), Path(manifest_path or W.MANIFEST_PATH)
    try: m = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e: return [f"manifest unreadable: {type(e).__name__}"]
    bad = []
    if m.get("schema") != pol["manifest_schema"]: bad.append("manifest schema")
    if (m.get("protocol") or {}).get("blob_sha256") != W.protocol_sha(): bad.append("manifest protocol blob sha")
    if (m.get("policy") or {}).get("blob_sha256") != W.policy_sha(): bad.append("manifest policy blob sha")
    if m.get("inventory") != W.inventory(): bad.append("manifest inventory pins")
    if m.get("prompts") != W.prompt_hashes(pol): bad.append("manifest prompt hashes")
    return bad


def _git_blob_sha(commit, path):
    out = subprocess.run(["git", "show", f"{commit}:{path}"], cwd=ROOT, capture_output=True, check=True).stdout
    return hashlib.sha256(out.replace(b"\r\n", b"\n")).hexdigest()


def approval_problems(path=None, pol=None, manifest_path=None):
    """§13: every reason the gate refuses (empty = approved)."""
    pol = pol or W.load_policy()
    path = Path(path) if path else ROOT / pol["approval_path"]
    try:
        raw = path.read_bytes()
        a = json.loads(raw.decode("utf-8"))
    except FileNotFoundError: return ["approval file missing"]
    except (OSError, ValueError) as e: return [f"approval file unreadable: {type(e).__name__}"]
    if not isinstance(a, dict): return ["approval file is not an object"]
    bad = []
    m = pol["model"]
    if "DRAFT" in path.name.upper() or str(a.get("status", "")).upper() == "DRAFT": bad.append("approval is a DRAFT")
    if "status" in a and a["status"] != "active": bad.append("status is not active")
    if pol.get("approval_must_be_active"):
        if a.get("status") != "active": bad.append("status must be 'active'")
        want = pol.get("approval_sha256")
        if not want: bad.append("approval sha256 not bound in the backend config")
        elif hashlib.sha256(raw).hexdigest() != want: bad.append("approval file sha256 differs from the bound sha256 (renamed or edited)")
    if a.get("schema") != pol["approval_schema"]: bad.append("schema")
    for k in ("approver", "approved_at", "statement"):
        if not (isinstance(a.get(k), str) and a[k].strip()): bad.append(f"{k} missing")
    live = W.protocol_sha()
    if a.get("protocol_blob_sha256") != live or live != pol["protocol_blob_sha256"]: bad.append("protocol_blob_sha256")
    if a.get("protocol_commit") != pol["protocol_commit"]: bad.append("protocol_commit")
    else:
        try:
            if _git_blob_sha(pol["protocol_commit"], pol["protocol_path"]) != live: bad.append("protocol blob at commit differs from the working file")
        except (OSError, subprocess.SubprocessError): bad.append("protocol commit not verifiable in git")
    if a.get("model_id") != m["id"]: bad.append("model_id")
    if m.get("hosted"):  # a hosted model has no weights: the approval says so, and binds provider + host + model id instead
        if a.get("model_file_sha256") is not None: bad.append("model_file_sha256 (a hosted model has no weights hash)")
        if a.get("hosted") is not True: bad.append("hosted")
        if a.get("provider") != m["provider"]: bad.append("provider")
        if a.get("host") != urlparse(m["endpoint"]).hostname: bad.append("host")
    elif a.get("model_file_sha256") != m["sha256"]: bad.append("model_file_sha256")
    if a.get("endpoint") != m["endpoint"]: bad.append("endpoint")
    if a.get("caps") != pol["approval_caps"]: bad.append("caps")
    bad += manifest_problems(pol, manifest_path)
    return bad


class Model:
    """One client per run. `stub=True`: loopback endpoint of any port, no approval, no weight check (records go only where `out` points)."""

    def __init__(self, out, stub=False, endpoint=None, pol=None, weights_path=None, approval_path=None, manifest_path=None, timeout=None,
                 backend=None, dispatch_cfg=None, pricing=None, budget_usd=None, ledger_path=None, private_blobs=None):
        self.pol, self.out, self.stub = apply_backend(pol or W.load_policy(), backend, dispatch_cfg), Path(out), stub
        if backend and approval_path is None: approval_path = ROOT / self.pol["approval_path"]  # a non-default backend carries its own approval file
        m = self.pol["model"]
        self.hosted, self.private_blobs = bool(m.get("hosted")), list(private_blobs or ())
        self.live = self.hosted and not stub  # a live hosted call carries the key; a loopback stub never sees it
        self.pricing = pricing if pricing is not None else _dispatch_cfg(dispatch_cfg).get("pricing", {})
        blk = _dispatch_cfg(dispatch_cfg).get("budget") or {}  # project-level spend budget: a cap against ONE ledger shared by every run
        self.budget_usd = budget_usd if budget_usd is not None else self.pol.get("budget_usd", blk.get("remaining_usd"))
        # a LIVE hosted call uses the ONE project ledger from configs (outside the store, under the user profile: "~" = %USERPROFILE%); local and stub runs keep their own under `out`
        lp = ledger_path or (ROOT / os.path.expandvars(os.path.expanduser(blk["ledger"])) if blk.get("ledger") and self.live else None)
        self.ledger_path = Path(lp) if lp else self.out / "usage-ledger.jsonl"
        self.run_id = f"m2-{int(time.time())}-{id(self) & 0xffff:x}"
        self.endpoint = (endpoint or m["endpoint"]).rstrip("/")
        self.timeout = timeout or self.pol["call_timeout_s"]
        self.weights_path = weights_path or (None if stub or self.hosted else m["file"])
        host = urlparse(self.endpoint)
        if stub:
            if host.hostname not in ("127.0.0.1", "localhost"): raise Invalidated(f"stub endpoint must be loopback, got {self.endpoint}")
        else:
            if self.endpoint != m["endpoint"]: raise Invalidated(f"call to a host other than {m['endpoint']}: {self.endpoint}")
            if self.hosted and (bad := hosted_endpoint_problem(self.endpoint)): raise Invalidated(f"hosted endpoint refused: {bad}")
            bad = approval_problems(approval_path, self.pol, manifest_path)
            if bad: raise Refused("operator approval gate refused: " + "; ".join(bad))
        self.out.mkdir(parents=True, exist_ok=True)

    # -- ledger --
    def _log(self, name, rec):
        rec = {"ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), **rec}
        with open(self.out / name, "a", encoding="utf-8", newline="\n") as f: f.write(json.dumps(rec, sort_keys=True) + "\n")

    def ledger(self):
        p = self.out / "model_calls.jsonl"
        return [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()] if p.exists() else []

    def totals(self):
        rows = self.ledger()
        return {"calls": len(rows), "tokens": sum(r.get("tokens", 0) for r in rows)}

    def check_weights(self, label):
        if not self.weights_path: return None
        sha, want = weight_sha(self.weights_path), self.pol["model"]["sha256"]
        self._log("weight_checks.jsonl", {"label": label, "sha256": sha, "expected": want, "ok": sha == want})
        if sha != want: raise Invalidated(f"weight sha mismatch at {label}")
        return sha

    def list_models(self):
        key = self._key()
        req = urllib.request.Request(self.endpoint + "/models", headers=self._headers(key), method="GET")
        ids = [d["id"] for d in json.loads(scrub(self._fetch(req, HOSTED_LIST_TIMEOUT_S if self.hosted else 30).decode("utf-8", "replace"), key))["data"]]
        self._log("model_list.jsonl", {"ids": ids})
        if self.pol["model"]["id"] not in ids: raise Invalidated(f"unexpected model ids {ids}")
        return ids

    # -- request --
    def body(self, messages, seed):
        s, m = self.pol["sampling"], self.pol["model"]
        if "system_prefix" in m:  # per-backend system line: the gpt-oss "Reasoning: low" line is swapped, the task text after it is untouched
            messages = [dict(x, content=(m["system_prefix"] + "\n" if m["system_prefix"] else "") + x["content"][len(REASONING_LINE):])
                        if x.get("role") == "system" and str(x.get("content", "")).startswith(REASONING_LINE) else x for x in messages]
        b = self._body(messages, seed, s)
        if self.hosted:
            for k in ("top_k", "repeat_penalty"): b.pop(k)  # not OpenAI-standard fields: a hosted API may reject them
            if m.get("request_extra") is not None: b.update(request_extra(m["request_extra"]))
        return b

    def _key(self):
        """The API key, read from the environment at call time (never stored); None unless this is a live hosted call."""
        if not self.live: return None
        k = os.environ.get(self.pol["model"]["key_env"], "").strip()
        if not KEY_CHARS.fullmatch(k): raise Refused(f"{self.pol['model']['key_env']} is not set in the environment (or is malformed): hosted backend refused")
        return k

    def _headers(self, key):
        return {"Content-Type": "application/json", **({"Authorization": "Bearer " + key} if key else {})}

    def _fetch(self, req, timeout):
        if not self.hosted:
            with urllib.request.urlopen(req, timeout=timeout) as r: return r.read()
        deadline = time.monotonic() + timeout  # total wall time for the whole request, not just per socket operation
        with _NO_REDIRECT.open(req, timeout=timeout) as r:  # no redirects followed; the body is bounded
            raw = b""
            while len(raw) <= HOSTED_MAX_BYTES:
                if time.monotonic() > deadline: raise TimeoutError(f"hosted call exceeded {timeout}s in total")
                chunk = r.read1(min(65536, HOSTED_MAX_BYTES + 1 - len(raw)))
                if not chunk: break
                raw += chunk
        if len(raw) > HOSTED_MAX_BYTES: raise ValueError(f"hosted response over {HOSTED_MAX_BYTES} bytes")
        return raw

    def _body(self, messages, seed, s):
        return {"model": self.pol["model"]["id"], "messages": messages, "temperature": s["temperature"], "top_p": s["top_p"], "top_k": s["top_k"],
                "max_tokens": s["max_tokens"], "stream": s["stream"], "n": s["n"], "repeat_penalty": s["repeat_penalty"],
                "frequency_penalty": s["frequency_penalty"], "presence_penalty": s["presence_penalty"], "seed": seed}

    # -- spend gate (reserve worst case before the request, reconcile after, record refusals) --
    def _price_table(self):
        mid = self.pol["model"]["id"]
        if mid in self.pricing: return self.pricing
        if self.stub and not self.hosted: return dict(self.pricing, **{mid: {"fresh_input": 0.0, "cached_read": 0.0, "cache_write": 0.0, "output": 0.0}})  # loopback stub: nothing to bill
        raise BudgetRefused(f"no price for model {mid!r}: billing data unavailable, refusing (fail closed)")

    def _refuse(self, kind, attempt, why):
        self._log("model_calls.jsonl", {"kind": kind, "attempt": attempt, "status": "budget_refused", "reason": why, "tokens": 0})
        raise BudgetRefused(why)

    def _reserve(self, raw, attempt, kind):
        """Atomically (ledger lock) check the remaining budget against the worst-case cost of this request and reserve it. Raises BudgetRefused BEFORE any HTTP request."""
        mid, task = self.pol["model"]["id"], f"{kind}#{attempt}"
        try:
            table = self._price_table()
            if self.budget_usd is None and any(float(v) > 0 for v in (table.get(mid) or {}).values()):
                raise BudgetRefused(f"priced backend {mid!r} has no spend budget configured (budget.remaining_usd): refusing (fail closed)")
            ledger = (HostedLedger if self.live else UsageLedger)(self.ledger_path, table)
            worst = ledger.cost_usd(UsageRecord(self.run_id, None, task, mid, len(raw) + PROMPT_TOKEN_MARGIN, 0, 0, self._max_tokens(), 0.0, False, "reservation_bound"))
        except (BudgetRefused, ValueError, TypeError, OSError) as e:
            self._refuse(kind, attempt, str(e))
        try:
            with ledger.locked():
                if self.live: ledger.check()  # missing, emptied, truncated, chain-broken or negative-cost hosted ledger: refused before any request
                t = ledger.totals()
                spent = t["usd_measured"] + t["usd_estimated"] + ledger.outstanding_reserved_usd()
                if self.budget_usd is not None and spent + worst > self.budget_usd + 1e-12:
                    why = f"budget refused: worst-case ${worst:.6f} + spent/reserved ${spent:.6f} exceeds ${self.budget_usd:.6f}"
                    ledger.record(UsageRecord(self.run_id, None, task, mid, 0, 0, 0, 0, 0.0, False, "refusal: " + why[:200]))
                    self._refuse(kind, attempt, why)
                return ledger, ledger.reserve(self.run_id, task, mid, worst)
        except (OSError, TimeoutError, ValueError, KeyError, TypeError, AttributeError) as e:  # ledger lock/IO unavailable, torn or malformed: never dispatch unaccounted
            self._refuse(kind, attempt, f"usage ledger unavailable: {type(e).__name__}: {e}")

    def _max_tokens(self):
        """The per-call output cap as a plain int in 1..context; anything else (negative, zero, float, bool, str, over the context) is refused."""
        mt, ctx = self.pol["sampling"]["max_tokens"], self.pol["model"].get("context")
        if type(mt) is not int or mt < 1 or (type(ctx) is int and mt > ctx): raise ValueError(f"max_tokens must be an integer from 1 to the context size, got {mt!r}")
        return mt

    def _settle(self, ledger, rid, kind, attempt, raw, usage, wall):
        """Reconcile one reservation with what the endpoint reported; with no usage (or a transport error) the worst case is charged, conservatively."""
        mid = self.pol["model"]["id"]
        try: fresh, cached, out = _usage_tokens(usage)
        except (TypeError, ValueError, KeyError): fresh = None
        ok = fresh is not None
        if not ok: fresh, cached, out = len(raw) + PROMPT_TOKEN_MARGIN, 0, self._max_tokens()  # no usable usage: the worst case, never zero
        ledger.record(UsageRecord(self.run_id, None, f"{kind}#{attempt}", mid, fresh, cached, 0, out, wall, ok, "endpoint_usage" if ok else "estimate"), reservation_id=rid)

    def _cap(self):
        t = self.totals()
        if t["calls"] >= self.pol["max_model_calls"]: raise CapReached(f"model call cap {self.pol['max_model_calls']} reached")
        if t["tokens"] >= self.pol["max_tokens_total"]: raise CapReached(f"token cap {self.pol['max_tokens_total']} reached")

    def call(self, kind, messages, seed, campaign=None, rnd=None):
        """One logical call (proposal or smoke): up to 1 + transport_retries identical-bytes attempts, each logged and counted.
        Returns {content, usage, status, attempts, seed}; status is ok or transport_failure (the proposal is then consumed)."""
        if self.hosted and (why := data_problem(messages, self.private_blobs)):  # real input data never leaves for a hosted backend: refused before the key or the ledger
            self._log("model_calls.jsonl", {"kind": kind, "status": "data_refused", "reason": why, "tokens": 0})
            raise DataRefused(f"hosted backend refused: {why}")
        key = self._key()  # read now, in this (trusted parent) process; never stored, logged or put in a body
        raw = json.dumps(self.body(messages, seed), sort_keys=True, ensure_ascii=True).encode("utf-8")
        for attempt in range(1, self.pol["transport_retries"] + 2):
            self._cap()
            ledger, rid = self._reserve(raw, attempt, kind)  # refuses (BudgetRefused) before any HTTP request
            t0, rec = time.time(), {"kind": kind, "campaign": campaign, "round": rnd, "attempt": attempt, "seed": seed, "model": self.pol["model"]["id"],
                                    "endpoint": self.endpoint, "request_sha256": hashlib.sha256(raw).hexdigest(), "request_bytes": len(raw), "request_body": raw.decode("utf-8")}
            try:
                req = urllib.request.Request(self.endpoint + "/chat/completions", data=raw, headers=self._headers(key), method="POST")
                resp = self._fetch(req, self.timeout)
                if key: resp = resp.replace(key.encode("utf-8"), b"[REDACTED]")  # a reply that echoes the key is scrubbed before anything is parsed or written
                data = json.loads(resp)
                content = data["choices"][0]["message"].get("content")
                usage = data.get("usage")
                usage = usage if isinstance(usage, dict) else {}  # a usage of the wrong shape is "no usage": charged at the worst case
                tokens = max(0, int(usage.get("prompt_tokens", 0)) + int(usage.get("completion_tokens", 0)))
                if not usage: tokens = len(raw) // 3 + self.pol["sampling"]["max_tokens"]  # conservative when usage is absent
                rec.update(status="ok", http_status=200, response_bytes=len(resp), response_sha256=hashlib.sha256(resp).hexdigest(), response_text=resp.decode("utf-8", "replace"),
                           usage=usage, tokens=tokens, response_model=data.get("model"), latency_s=round(time.time() - t0, 3))
                self._log("model_calls.jsonl", rec)
                self._settle(ledger, rid, kind, attempt, raw, usage, time.time() - t0)
                ok_ids = {self.pol["model"]["id"]} | set(self.pol["model"].get("reply_model_ids") or ()) if self.hosted else {self.pol["model"]["id"]}
                if data.get("model") not in ok_ids: raise Invalidated(f"unexpected model id in response: {data.get('model')!r}")  # hosted aliases: config-only list
                return {"content": content if isinstance(content, str) else "", "usage": usage, "status": "ok", "attempts": attempt, "seed": seed}
            except Invalidated: raise
            except KeyboardInterrupt:  # cancelled mid-request: charged the worst case like any unusable reply, recorded as "cancelled", never retried or sent elsewhere
                self._settle(ledger, rid, kind, attempt, raw, None, time.time() - t0)
                self._log("model_calls.jsonl", dict(rec, status="cancelled", tokens=0, latency_s=round(time.time() - t0, 3)))
                raise
            except (urllib.error.URLError, OSError, ValueError, KeyError, IndexError, TypeError, AttributeError, http.client.HTTPException) as e:  # odd reply shapes are a clean model error
                self._settle(ledger, rid, kind, attempt, raw, None, time.time() - t0)
                timed_out = isinstance(e, TimeoutError) or isinstance(getattr(e, "reason", None), TimeoutError)
                rec.update(status="timeout" if timed_out else "transport_error", error=scrub(f"{type(e).__name__}: {e}", key), http_status=getattr(e, "code", None), tokens=0, latency_s=round(time.time() - t0, 3))
                if self.hosted and isinstance(e, urllib.error.HTTPError):  # a short, scrubbed look at the provider's error text
                    try: rec["error_body"] = scrub(e.read(65536).decode("utf-8", "replace"), key)[:500]  # scrub the whole text BEFORE cutting: a key echoed at the cut must not leave a fragment
                    except Exception: pass
                self._log("model_calls.jsonl", rec)
        return {"content": "", "usage": {}, "status": "transport_failure", "attempts": attempt, "seed": seed}


def _usage_tokens(usage):
    """(fresh input, cached input, output) tokens from an OpenAI-style usage object; raises when it lacks the two counts or they are negative/non-integer."""
    if not isinstance(usage, dict): raise TypeError("no usage")
    p, o = usage["prompt_tokens"], usage["completion_tokens"]
    if isinstance(p, bool) or isinstance(o, bool) or int(p) < 0 or int(o) < 0: raise ValueError("bad usage")
    det = usage.get("prompt_tokens_details")
    c = det.get("cached_tokens") if isinstance(det, dict) else 0
    c = max(0, min(int(c or 0), int(p)))
    return int(p) - c, c, int(o)


def assemble(system, user_head, history_rows, contract, cap, log=None):
    """Build the (system, user) pair. user_head has <<HISTORY>> and <<CONTRACT>> slots; history_rows are already-rendered strings, oldest first.
    Drops the oldest rows one at a time until system+user <= cap UTF-8 bytes; each drop is passed to log. Raises PromptTooLarge if even zero rows is over."""
    rows = list(history_rows)
    while True:
        hist = "".join(rows) if rows else "(none)\n"
        user = user_head.replace("<<HISTORY>>", hist).replace("<<CONTRACT>>", contract)
        size = len((system + user).encode("utf-8"))
        if size <= cap: return system, user, size
        if not rows: raise PromptTooLarge(f"base prompt is {size} bytes, over {cap}")
        if log: log({"dropped_history_row": rows[0][:80], "size_before": size})
        rows.pop(0)
