"""Per-capability performance history (C2 minimal), persisted in the Store. Only numbers and enums go in and come out: ids are pattern-checked,
status / failure_class are closed enums, the rest are ints. No free text from an outcome can reach a prompt, a policy or the planner's ranking."""
from __future__ import annotations

import re
import statistics

from .operator_runtime import _now, _txn

KEY = "operator/caphist/"
KEEP = 200  # newest rows kept per capability
STATUS = ("OK", "FAILED", "REFUSED")
FAILURE = ("NONE", "EXECUTION", "TIMEOUT", "OUTPUT_REJECTED", "UNAVAILABLE", "INTEGRITY", "OTHER")
_ID = re.compile(r"[A-Za-z0-9._-]{1,128}")


def record(store, cap_id, version, goal_id, status, elapsed_ms, model_calls=0, failure_class="NONE"):
    """Append one executed-step row. Raises ValueError for anything that is not an id / enum / non-negative int."""
    if not (_ID.fullmatch(str(cap_id)) and _ID.fullmatch(str(goal_id)) and status in STATUS and failure_class in FAILURE):
        raise ValueError("cap_history: bad id or enum")
    nums = [int(version), int(elapsed_ms), int(model_calls)]
    if min(nums) < 0 or any(isinstance(x, bool) for x in (version, elapsed_ms, model_calls)):
        raise ValueError("cap_history: bad number")
    row = {"v": nums[0], "goal": goal_id, "status": status, "ms": nums[1], "model_calls": nums[2], "fail": failure_class, "at": _now()}
    with _txn(store):
        rows = store.get(KEY + cap_id, [])
        store.set(KEY + cap_id, (rows + [row])[-KEEP:])


def _num(x): return isinstance(x, int) and not isinstance(x, bool) and x >= 0


def _valid(r):
    """The same checks record() applies on write; a store-written row that fails them is ignored on read."""
    return (isinstance(r, dict) and _num(r.get("v")) and _num(r.get("ms")) and _num(r.get("model_calls")) and r.get("status") in STATUS
            and r.get("fail") in FAILURE and isinstance(r.get("goal"), str) and bool(_ID.fullmatch(r["goal"])))


def rows(store, cap_id, version=None):
    got = store.get(KEY + cap_id, [])
    return [r for r in (got if isinstance(got, list) else []) if _valid(r) and (version is None or r["v"] == version)]


def stats(store, cap_id, version=None):
    """{"n", "success_rate", "median_ms"} (None when nothing was recorded). Only executed rows count."""
    r = rows(store, cap_id, version)
    if not r:
        return {"n": 0, "success_rate": None, "median_ms": None}
    return {"n": len(r), "success_rate": sum(x["status"] == "OK" for x in r) / len(r), "median_ms": statistics.median(x["ms"] for x in r)}
