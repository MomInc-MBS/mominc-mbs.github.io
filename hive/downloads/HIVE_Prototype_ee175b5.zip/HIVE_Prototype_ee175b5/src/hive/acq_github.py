"""G2 search: GitHub repository search (REST, urllib, unauthenticated by default) and the tier order retained -> installed -> GitHub.

Trusted kernel. Network happens only through `transport(url, headers) -> (status, headers, body)`; the default uses urllib against
https://api.github.com and refuses redirects. A token from env HIVE_GITHUB_TOKEN is read per request, sent as a header only, and never
stored, logged, cached or put in an error message. Results are cache-keyed by query only. Stdlib only."""
from __future__ import annotations

import hashlib
import json
import os
import re
import time
import urllib.error
import urllib.request
from pathlib import Path

HOST = "https://api.github.com"
FULL_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9-]{0,38}/[A-Za-z0-9._-]{1,100}$")
QUERY = re.compile(r"^[A-Za-z0-9 _.-]{1,60}$")
TOKEN_ENV = "HIVE_GITHUB_TOKEN"


class NetworkUnavailable(RuntimeError):
    """Rate limit not clearing, bad status, oversized or malformed body: the run ends NETWORK_UNAVAILABLE (never silently empty).
    `status` and `detail` (GitHub's own short message, sanitised) are kept for the run manifest; never headers, never the token."""

    def __init__(self, msg, status=None, detail=None):
        super().__init__(msg)
        self.status, self.detail = status, detail


def why(status, body):
    """GitHub's JSON "message" for a non-200 reply: control characters stripped, token redacted, at most 200 characters."""
    try:
        m = json.loads(body.decode("utf-8")).get("message", "")
    except (ValueError, AttributeError, UnicodeDecodeError):
        m = ""
    m = re.sub(r"[\x00-\x1f\x7f]", " ", m if isinstance(m, str) else "")
    tok = os.environ.get(TOKEN_ENV)
    if tok:
        m = m.replace(tok, "***")
    m = re.sub(r"\b\d{1,3}(?:\.\d{1,3}){3}\b|\b(?:[0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}\b", "<ip>", m)  # rate-limit replies name the caller's IP
    return " ".join(m.split())[:200]


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        return None


def urllib_transport(url, headers, max_bytes=1 << 20, timeout=20):
    if not url.startswith(HOST + "/"):
        raise NetworkUnavailable("only api.github.com is allowed")
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.build_opener(_NoRedirect).open(req, timeout=timeout) as r:
            return r.status, dict(r.headers), r.read(max_bytes + 1)
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers or {}), e.read(max_bytes + 1)
    except (urllib.error.URLError, OSError) as e:
        raise NetworkUnavailable(f"request failed: {type(e).__name__}") from None


def valid_query(q):
    return isinstance(q, str) and QUERY.match(q) is not None


def queries_for(keywords, extra=()):
    """Deterministic queries from the contract's keywords (`a|b|c` or a list) plus validated extras (e.g. model suggestions)."""
    words = keywords.split("|") if isinstance(keywords, str) else list(keywords)
    out = []
    for q in [w.strip() for w in words] + list(extra):
        if valid_query(q) and q not in out:
            out.append(q)
    return out


def _repo(item):
    """Narrow a search item to the fields we use; None when it is not a usable repo."""
    if not isinstance(item, dict):
        return None
    name = item.get("full_name")
    if not isinstance(name, str) or not FULL_NAME.match(name):
        return None
    lic = (item.get("license") or {}).get("spdx_id") if isinstance(item.get("license"), dict) else None
    return {"full_name": name, "url": f"https://github.com/{name}", "description": str(item.get("description") or "")[:300],
            "license_spdx": lic if isinstance(lic, str) and lic != "NOASSERTION" else None, "stars": int(item.get("stargazers_count") or 0),
            "pushed_at": str(item.get("pushed_at") or ""), "size_kb": int(item.get("size") or 0), "archived": bool(item.get("archived")),
            "language": str(item.get("language") or ""), "open_issues": int(item.get("open_issues_count") or 0), "fork": bool(item.get("fork")),
            "topics": [t[:50] for t in (item.get("topics") if isinstance(item.get("topics"), list) else []) if isinstance(t, str)][:20]}


def clone_url(repo):
    """The ONLY URL a clone may use: https://github.com/<owner>/<repo> derived from the validated full_name. A stored URL that disagrees (other host,
    local path, other repo, http) is refused, so the deny/allow check on the name is a check on what is actually fetched."""
    name = repo.get("full_name") if isinstance(repo, dict) else None
    if not isinstance(name, str) or not FULL_NAME.match(name):
        raise ValueError("SOURCE_NOT_ALLOWED: invalid owner/repo name")
    url = f"https://github.com/{name}"
    if repo.get("url") not in (url, url + ".git"):
        raise ValueError("SOURCE_NOT_ALLOWED: the stored clone URL does not match owner/repo on github.com")
    return url


def source_refusal(full_name, policy, host="github.com"):
    """None when `owner/repo` on `host` may be acquired, else a short stable reason. policy["sources"] = {hosts, allow, deny}: the host must be listed
    (default github.com only); a non-empty allow list admits only matching entries; deny always wins. Entries are `owner/repo` or `owner/*`, case-insensitive.
    An empty allow list means any owner (the licence gate still applies)."""
    s = policy.get("sources") or {}
    hosts = [h.lower() for h in s.get("hosts", ["github.com"])]
    name = str(full_name).lower()
    hit = lambda entries: any(name == e.lower() or (e.endswith("/*") and name.startswith(e.lower()[:-1])) for e in entries)
    if host.lower() not in hosts:
        return f"SOURCE_NOT_ALLOWED: host {host}"
    if hit(s.get("deny", [])):
        return f"SOURCE_NOT_ALLOWED: {full_name} is on the deny list"
    if s.get("allow") and not hit(s["allow"]):
        return f"SOURCE_NOT_ALLOWED: {full_name} is not on the allow list"
    return None


class GitHubSearch:
    def __init__(self, cache_dir, policy, transport=None, sleep=time.sleep, now=time.time):
        self.dir, self.lim, self.policy, self.refused = Path(cache_dir), policy["limits"], policy, []
        self.dir.mkdir(parents=True, exist_ok=True)
        self.transport, self.sleep, self.now = transport or urllib_transport, sleep, now
        self.requests = 0

    def _get(self, url):
        for attempt in range(self.lim["max_retries"] + 1):
            if self.requests >= self.lim["max_requests"]:
                raise NetworkUnavailable("request budget exhausted")
            headers = {"Accept": "application/vnd.github+json", "User-Agent": "hive-acquire"}
            tok = os.environ.get(TOKEN_ENV)
            if tok:
                headers["Authorization"] = "Bearer " + tok
            self.requests += 1
            status, h, body = self.transport(url, headers)
            if len(body) > self.lim["max_response_bytes"]:
                raise NetworkUnavailable("response too large")
            if status == 200:
                try:
                    return json.loads(body.decode("utf-8"))
                except ValueError:
                    raise NetworkUnavailable("malformed JSON") from None
            detail = why(status, body)
            if status in (403, 429) and attempt < self.lim["max_retries"]:
                h = {k.lower(): v for k, v in h.items()}
                wait = float(h["retry-after"]) if h.get("retry-after", "").isdigit() else (
                    max(0.0, float(h["x-ratelimit-reset"]) - self.now()) if h.get("x-ratelimit-reset", "").isdigit() else 2.0 ** (attempt + 1) * 5)
                if wait > self.lim["max_wait_s"]:
                    raise NetworkUnavailable(f"rate limited for {int(wait)}s (GitHub status {status}: {detail})", status, detail)
                self.sleep(wait)
                continue
            raise NetworkUnavailable(f"GitHub status {status}" + (f": {detail}" if detail else ""), status, detail)
        raise NetworkUnavailable("rate limited")

    def search(self, query, per_page=10):
        """Repositories for one validated query, cached by query for cache_ttl_s, minus sources the policy refuses (applied after the cache, so a
        policy change takes effect at once; refusals are listed in `self.refused`). Returns [repo dict]."""
        repos = self._search(query, per_page)
        ok = [r for r in repos if not source_refusal(r["full_name"], self.policy, "github.com")]
        self.refused += [{"repo": r["full_name"], "reason": source_refusal(r["full_name"], self.policy)} for r in repos if r not in ok]
        return ok

    def _search(self, query, per_page):
        if not valid_query(query):
            raise ValueError("invalid search query")
        key = self.dir / (hashlib.sha256(query.encode("utf-8")).hexdigest() + ".json")
        try:
            c = json.loads(key.read_text(encoding="utf-8"))
            if self.now() - c["at"] < self.lim["cache_ttl_s"] and c["query"] == query:
                return c["repos"]
        except (OSError, ValueError, KeyError, TypeError):
            pass
        q = urllib.request.quote(f"{query} language:Python", safe="")
        data = self._get(f"{HOST}/search/repositories?q={q}&per_page={int(per_page)}")
        items = data.get("items") if isinstance(data, dict) else None
        if not isinstance(items, list):
            raise NetworkUnavailable("unexpected response shape")
        repos = [r for r in map(_repo, items[:per_page]) if r]
        key.write_text(json.dumps({"query": query, "at": self.now(), "repos": repos}, sort_keys=True), encoding="utf-8", newline="\n")
        return repos


def _tokens(text):
    return [t for t in re.findall(r"[a-z0-9]+", str(text).lower()) if len(t) >= 3]


def _matches(term, toks):
    return any(t == term or (len(t) >= 4 and (t.startswith(term) or term.startswith(t))) for t in toks)


SIZE_WEIGHT = 0.8  # relevance units lost per doubling of the repo size in MB (log2(1 + MB)): a 25 MB repo sits about 4 units below a sub-MB one


def size_penalty(size_kb):
    import math
    return SIZE_WEIGHT * math.log2(1 + max(int(size_kb), 0) / 1024)


def rank_hits(repos, terms, max_kb, licenses=None):
    """Order search hits for inspection (the scarce resource) and skip the ones not worth a clone. Returns (ranked, skipped): ranked =
    [(repo, breakdown)] best first, skipped = [(repo, reason, breakdown)]. Score = relevance - size penalty, where relevance = 2 x distinct
    queries that returned the repo + the rank-weighted best position per query + 0.5 x the contract/spec/type terms its description, topics
    and name share, and the penalty grows with log2 of the size in MB; ties go to the more recent push, then stars, then the name. Skipped
    before any clone: archived repos, forks, repos over the clone cap, and (when `licenses` is given) hits whose search-metadata licence is
    missing or not on the allowlist (the card's own licence check stays the authority for the rest)."""
    ranked, skipped, terms = [], [], list(dict.fromkeys(t.lower() for t in terms))
    for r in repos:
        hits = r.get("hits") or [{"q": q, "pos": 0} for q in r.get("queries", [])]
        best = {}
        for h in hits:
            best[h["q"]] = min(best.get(h["q"], 10**6), int(h["pos"]))
        toks = _tokens(" ".join([r.get("description", ""), " ".join(r.get("topics", [])), r["full_name"].split("/")[-1].replace("-", " ").replace("_", " ")]))
        found = [t for t in terms if _matches(t, toks)]
        bd = {"queries": sorted(best), "n_queries": len(best), "best_pos": dict(sorted(best.items())), "pos_score": round(sum(1 / (1 + p) for p in best.values()), 4),
              "overlap": len(found), "overlap_terms": found[:20], "size_kb": r.get("size_kb", 0), "pushed_at": r.get("pushed_at", ""), "stars": r.get("stars", 0),
              "license_spdx": r.get("license_spdx")}
        bd["relevance"] = round(2 * bd["n_queries"] + bd["pos_score"] + 0.5 * bd["overlap"], 4)
        bd["size_penalty"] = round(size_penalty(bd["size_kb"]), 4)
        bd["score"] = round(bd["relevance"] - bd["size_penalty"], 4)
        lic = r.get("license_spdx")
        why = ("ARCHIVED" if r.get("archived") else "FORK" if r.get("fork") else
               f"REPO_TOO_LARGE: {r.get('size_kb')} KB reported by GitHub (limit {max_kb})" if r.get("size_kb", 0) > max_kb else
               f"SKIPPED_LICENSE_METADATA: search metadata says {lic or 'no licence'}" if licenses is not None and (not lic or lic == "NOASSERTION" or lic not in licenses) else None)
        (skipped.append((r, why, bd)) if why else ranked.append((r, bd)))
    pushed = lambda bd: int("".join(c for c in bd["pushed_at"] if c.isdigit())[:14] or 0)
    ranked.sort(key=lambda t: (-t[1]["score"], -pushed(t[1]), -t[1]["stars"], t[0]["full_name"]))
    for n, (_, bd) in enumerate(ranked):
        bd["rank"] = n
    return ranked, skipped


def search_tiers(retained, installed, github, require_new_external=False):
    """Tier order retained -> installed -> GitHub. Each argument yields candidates (lists or zero-arg callables; `github` is lazy and is
    only called when nothing earlier is selectable, or when require_new_external). Every tier is recorded, even empty. With
    require_new_external the first two tiers are recorded but never selectable. Returns {"tiers":[{tier,found,selectable}],"selectable":[...]}."""
    tiers, sel = [], []
    for name, src in (("retained", retained), ("installed", installed), ("github", github)):
        if name == "github" and sel and not require_new_external:
            tiers.append({"tier": name, "found": [], "selectable": False, "skipped": "earlier tier selectable"})
            continue
        found = list(src() if callable(src) else src or [])
        ok = name == "github" or not require_new_external
        tiers.append({"tier": name, "found": found, "selectable": ok})
        if ok:
            sel += [dict(f, tier=name) for f in found]
    return {"tiers": tiers, "selectable": sel}
