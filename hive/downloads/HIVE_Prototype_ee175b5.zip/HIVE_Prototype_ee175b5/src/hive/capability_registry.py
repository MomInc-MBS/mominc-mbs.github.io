"""C4 generalized capability registry: signed admissions of discovered capabilities, beside the M2 chains.

Chain `operator/capreg/<cap_id>` = append-only hash-linked events (same pattern as operator_runtime._event). Admit / revoke /
rollback events carry an OpenSSH signature that only the admission authority (scripts/hive_admission.py, private key outside
the repo and store) can make. This module only VERIFIES (public key in configs/admission_signers); it never signs and nothing a
model or the runtime writer produces can pass verify. Every use re-verifies the whole chain and the current statement."""
from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
import uuid
from pathlib import Path

from . import capcontract as CC
from . import operator_runtime as O
from .capcontract import canon
from .operator_runtime import Refused, _now, _sha, _txn

CHAIN = "operator/capreg/"
SCHEMA, EVENT_SCHEMA = CC.V2, "hive-capability-event-v1"  # SCHEMA = what new admissions write; v1 statements are still read
PRINCIPAL = NAMESPACE = "hive-admission"
SIGNERS = O.ROOT / "configs" / "admission_signers"
SIGNED = ("admit", "revoke", "rollback")


class Unavailable(Refused):
    """No eligible version (nothing admitted, all revoked, or no earlier version to roll back to)."""


def keygen(): return shutil.which("ssh-keygen") or ""


def authority_info():
    ssh = shutil.which("ssh")
    try:
        ver = subprocess.run([ssh, "-V"], capture_output=True, text=True, timeout=10).stderr.strip() if ssh else "unknown"
    except OSError:
        ver = "unknown"
    return {"ssh_keygen": keygen(), "version": ver}


def _run(args, data=None):
    return subprocess.run([keygen()] + args, input=data, capture_output=True, timeout=30)


def sign(data: bytes, key) -> str:
    """Authority side only (called from scripts/hive_admission.py)."""
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as t:
        f = Path(t) / "m"
        f.write_bytes(data)
        p = _run(["-Y", "sign", "-q", "-f", str(key), "-n", NAMESPACE, str(f)])
        if p.returncode or not (Path(t) / "m.sig").exists():
            raise Refused("signing failed: " + p.stderr.decode(errors="replace")[:200])
        return (Path(t) / "m.sig").read_bytes().decode().replace("\r\n", "\n")


def verify_sig(data: bytes, sig: str) -> bool:
    if not keygen() or not isinstance(sig, str) or not Path(SIGNERS).is_file():
        return False
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as t:
        s = Path(t) / "m.sig"
        s.write_bytes(sig.encode())
        p = _run(["-Y", "verify", "-f", str(SIGNERS), "-I", PRINCIPAL, "-n", NAMESPACE, "-s", str(s)], data)
    return p.returncode == 0


# ---------------------------------------------------------------- revocation list (outside the store)
def revocations_path():
    """Owner-written, beside the signers (configs/capability_revocations.json): the store chain alone cannot un-revoke."""
    return Path(SIGNERS).parent / "capability_revocations.json"


def revocations():
    """Entries of configs/capability_revocations.json (missing file = none). A malformed entry or unknown scope fails closed: Refused."""
    p = revocations_path()
    if not p.is_file():
        return []
    try:
        ents = json.loads(p.read_text(encoding="utf-8"))["revoked"]
        if not isinstance(ents, list) or not all(isinstance(e, dict) and isinstance(e.get("cap_id"), str) and isinstance(e.get("version"), int) for e in ents):
            raise ValueError("shape")
        for e in ents:  # no scope = legacy = global; anything but store/global is unknown
            if "scope" in e and e["scope"] not in ("store", "global"):
                raise ValueError("scope")
            if e.get("scope") == "store" and not isinstance(e.get("store_uuid"), str):
                raise ValueError("store_uuid")
    except (OSError, ValueError, KeyError, TypeError):
        raise Refused("configs/capability_revocations.json is unreadable or malformed") from None
    return ents


STORE_UUID_KEY = "operator/store_uuid"


def store_uuid(store):
    """Stable identity of this store, kept in its sqlite kv: made once, then only read (moves and copies keep it)."""
    store.db.execute("INSERT OR IGNORE INTO kv(key, value) VALUES (?, ?)", (STORE_UUID_KEY, json.dumps(uuid.uuid4().hex)))
    return json.loads(store.db.execute("SELECT value FROM kv WHERE key = ?", (STORE_UUID_KEY,)).fetchone()["value"])


def revoked_impls(cap_id=None, store=None):
    """Revoked bodies, per capability: revoking one capability's body never revokes another capability that happens to share it.
    Global/legacy bodies always; store-scoped bodies only for `store` (none when store is None)."""
    uid = store_uuid(store) if store is not None else None
    return {e["impl_sha256"] for e in revocations() if e.get("impl_sha256") and cap_id in (None, e["cap_id"])
            and (e.get("scope", "global") == "global" or e["store_uuid"] == uid)}


def record_revocation(cap_id, version, impl_sha256, statement_sha, reason, *, scope="global", store_uuid=None):
    """Authority side only (scripts/hive_admission.py, next to the signed revoke). Append-only: older entries are never dropped or rewritten;
    an identical (scope, store_uuid, cap_id, version, statement_sha) entry is not added twice."""
    if scope not in ("store", "global") or (scope == "store" and not store_uuid):
        raise Refused("revocation scope must be global, or store with a store_uuid")
    store_uuid = store_uuid if scope == "store" else None
    ents = revocations()
    key = (scope, store_uuid, cap_id, version, statement_sha)
    if any((e.get("scope", "global"), e.get("store_uuid"), e["cap_id"], e["version"], e.get("statement_sha")) == key for e in ents):
        return
    ents.append({"scope": scope, "store_uuid": store_uuid, "cap_id": cap_id, "version": version, "impl_sha256": impl_sha256, "statement_sha": statement_sha,
                 "reason": reason[:300], "at": _now()})
    revocations_path().parent.mkdir(parents=True, exist_ok=True)
    revocations_path().write_bytes((json.dumps({"revoked": ents}, indent=1, sort_keys=True) + "\n").encode())


# ---------------------------------------------------------------- chain
def cap_ids(store):
    return sorted(r["key"][len(CHAIN):] for r in store.db.execute("SELECT key FROM kv WHERE key LIKE ?", (CHAIN + "%",)).fetchall())


def head(store, cap_id): return store.get(CHAIN + cap_id)


def history(store, cap_id):
    """Events oldest first, each artifact re-hashed on read; a missing or altered artifact raises Refused (chain broken)."""
    out, ref = [], head(store, cap_id)
    try:
        while ref:
            ev = store.read_artifact(ref)
            out.append(dict(ev, ref=ref))
            ref = ev["prev"]
    except (OSError, ValueError, KeyError) as e:
        raise Refused(f"capability chain broken: {type(e).__name__}") from None
    return out[::-1]


def append(store, cap_id, typ, *, statement=None, between=None, **extra):
    """One transaction: statement artifact (admit) + event. A crash or exception before the event leaves the head unchanged."""
    with _txn(store):
        ex = dict(extra)
        if statement is not None:
            ex["statement_ref"] = store.put_artifact(statement)
        if between:
            between()  # failure-injection seam for the interrupted-promotion test; no-op in production
        ref = store.put_artifact({"kind": "capability_registry_event", "cap_id": cap_id, "type": typ, "at": _now(), "prev": head(store, cap_id), **ex})
        store.set(CHAIN + cap_id, ref)
    return ref


def signed_payload(typ, cap_id, prev, **fields):
    """What the authority signs for revoke / rollback (admit signs its statement). Bound to the chain position via prev."""
    return {"schema": EVENT_SCHEMA, "type": typ, "cap_id": cap_id, "prev": prev, "at": _now(), **fields}


def versions(store, cap_id):
    """Raw (UNVERIFIED) admitted version numbers; the authority uses it to number the next version."""
    out = {}
    for e in history(store, cap_id):
        if e["type"] == "admit":
            try:
                st = store.read_artifact(e["statement_ref"])
                out[st["version"]] = e.get("statement_sha")
            except (OSError, ValueError, KeyError):
                pass
    return out


def _state(store, cap_id):
    """Verify every signed event, then fold: (admitted {v: (statement, event)}, revoked set, current version or None)."""
    adm, revoked, cur = {}, set(), None
    for n, e in enumerate(history(store, cap_id)):
        t = e["type"]
        if t == "rejected":
            continue  # unsigned by design; never eligible
        if t not in SIGNED:
            raise Refused(f"event {n}: unknown type {str(t)[:20]!r}")
        if t == "admit":
            try:
                st = store.read_artifact(e["statement_ref"])
            except (OSError, ValueError, KeyError):
                raise Refused(f"event {n}: statement artifact missing or altered") from None
            if not verify_sig(canon(st), e.get("signature")) or e.get("statement_sha") != _sha(canon(st)):
                raise Refused(f"event {n}: admission signature does not verify (unauthorized or altered)")
            if st.get("schema") not in (CC.V1, CC.V2, CC.V3) or st.get("cap_id") != cap_id or not isinstance(st.get("version"), int):
                raise Refused(f"event {n}: malformed statement")
            adm[st["version"]], cur = (st, e), st["version"]
        else:
            sp = e.get("signed")
            if not isinstance(sp, dict) or not verify_sig(canon(sp), e.get("signature")) or sp.get("type") != t or sp.get("cap_id") != cap_id \
                    or sp.get("prev") != e.get("prev"):
                raise Refused(f"event {n}: {t} signature does not verify (unauthorized or altered)")
            if t == "revoke":
                revoked.add(sp["version"])
                cur = None if cur == sp["version"] else cur
            else:
                if sp["to_version"] not in adm or sp["to_version"] in revoked:
                    raise Refused(f"event {n}: rollback target is not an admitted, unrevoked version")
                cur = sp["to_version"]
    bad, uid = revoked_impls(cap_id, store), store_uuid(store)  # owner-written list: a listed version or body is revoked whatever the chain head says
    for e in revocations():
        if e["cap_id"] != cap_id:
            continue
        if e.get("scope", "global") == "global":
            revoked.add(e["version"])
        else:  # store scope: this store's uuid + version, or the exact admission statement (a copied lineage cannot resurrect it)
            revoked |= {v for v, (_st, ev) in adm.items() if (e["store_uuid"] == uid and v == e["version"]) or (e.get("statement_sha") and ev.get("statement_sha") == e["statement_sha"])}
            if e["store_uuid"] == uid:
                revoked.add(e["version"])
    revoked |= {v for v, (st, _e) in adm.items() if st.get("impl_sha256") in bad}
    if cur in revoked:
        cur = None
    return adm, revoked, cur


def resolve_discovered(store, cap_id):
    """The verified current statement (+ event ref) or Refused / Unavailable. Never returns anything unverified."""
    if head(store, cap_id) is None:
        raise Unavailable(f"{cap_id}: nothing admitted")
    adm, revoked, cur = _state(store, cap_id)
    if cur is None:
        raise Unavailable(f"{cap_id}: no eligible version (all admitted versions revoked)")
    st, e = adm[cur]
    try:
        CC.recheck(st, CC.images_dir(store.root))
    except KeyError as k:
        raise Refused(f"statement field missing: {k}") from None
    return {"cap_id": cap_id, "version": cur, "statement": st, "statement_sha": e["statement_sha"], "event_ref": e["ref"]}


def rollback_target(store, cap_id):
    """Previous admitted, unrevoked version below the current one (or the newest unrevoked one when nothing is current); else Unavailable."""
    adm, revoked, cur = _state(store, cap_id)
    ok = [v for v in adm if v not in revoked and (cur is None or v < cur)]
    if not ok:
        raise Unavailable(f"{cap_id}: no earlier admitted, unrevoked version to roll back to (only: {sorted(set(adm) - revoked)})")
    return cur, max(ok)


def eligible_discovered(store):
    """({cap_id: type row}, [{op, reason}]) for the planner. Types come only from the verified statement."""
    ok, ex = {}, []
    for cid in cap_ids(store):
        try:
            r = resolve_discovered(store, cid)
        except Unavailable as e:
            ex.append({"op": cid, "reason": str(e)})
            continue
        except Refused as e:
            ex.append({"op": cid, "reason": "refused: " + str(e)[:200]})
            continue
        st = r["statement"]
        c = CC.normalize(st)
        ok[cid] = {"kind": "discovered", "in": c["inputs"]["types"][0], "out": c["outputs"]["type"], "arity": c["inputs"]["arity"], "verifier": c["verification"]["oracle"].partition("#")[0],
                   "version": r["version"], "statement_sha": r["statement_sha"], "genome": r["statement_sha"], "ordered": True,  # discovered n-ary capabilities come from an ordered gap
                   "cost": c["execution"]["timeout_seconds"] * c["execution"]["resources"]["cpus"] if "resources" in c["execution"] else c["execution"]["timeout_seconds"],
                   "timeout_s": c["execution"]["timeout_seconds"], "types": list(c["inputs"]["types"]), "pass_ratio": _pass_ratio(st)}
        if len(set(c["inputs"]["types"])) > 1:  # typed slots: one input per listed type, matched by type (the DAG planner's join)
            ok[cid]["ins"] = list(c["inputs"]["types"])
    return ok, ex


def _pass_ratio(st):
    """Hidden-suite pass ratio from the admission receipt recorded in the signed statement (0.0 when absent)."""
    e = st.get("evaluation") or {}
    n = e.get("n")
    return e.get("pass_count", 0) / n if isinstance(n, int) and n > 0 and isinstance(e.get("pass_count"), int) else 0.0


def _provenance(st):
    """(repo, revision, tree sha256) a statement records, each None when absent."""
    a = st.get("acquisition") or st.get("provenance") or {}
    return (a.get("repo"), a.get("revision"), (st.get("environment") or {}).get("vendored_tree_sha256"))


def find_duplicate(store, *, contract_sha256=None, provenance=None):
    """T04. An ELIGIBLE (verified, unrevoked) admitted capability with the identical contract sha256, or identical provenance
    ({repo, revision, tree_sha256}, all three given and equal). Returns {cap_id, version, statement_sha, match} or None. A separate call on purpose:
    admission never calls it, so an explicit 'improve' request can bypass it by not calling it."""
    want = (provenance.get("repo"), provenance.get("revision"), provenance.get("tree_sha256")) if provenance else None
    if want is not None and None in want:
        want = None
    for cid in cap_ids(store):
        try:
            r = resolve_discovered(store, cid)
        except Refused:
            continue
        st = r["statement"]
        hit = "contract_sha256" if contract_sha256 and CC.sha(CC.normalize(st)) == contract_sha256 else "provenance" if want and _provenance(st) == want else None
        if hit:
            return {"cap_id": cid, "version": r["version"], "statement_sha": r["statement_sha"], "match": hit}
    return None
