"""Goal -> validated task contract -> typed plan from registered capabilities -> step-by-step execution through run_task.

Deterministic only (parser deterministic-v1): zero model calls. Instructions are read from the goal text alone, never from
input file contents. The explicit-operation interface in operator_runtime is unchanged and is what every registry step uses."""
from __future__ import annotations

import copy, itertools, json, os, re, subprocess, time
from collections import deque
from datetime import datetime, timedelta, timezone
from pathlib import Path

from . import cap_history as H
from . import capcontract as CC
from . import operator_runtime as O
from .operator_runtime import Refused, _json, _now, _sha, _txn
from .storage import Store

TYPES_PATH = O.ROOT / "configs" / "capability_types.json"
CONTRACT_SCHEMA, PLAN_SCHEMA = "hive-task-contract-v1", "hive-typed-plan-v1"
PARSER = "deterministic-v1"
NAME = re.compile(r"[A-Za-z0-9._ -]{1,128}")
STEP_OK = "VERIFIED"
STEP_ID = re.compile(r"s\d{1,2}")
GOAL_ID = re.compile(r"g-[0-9a-f]{20}")


def _goal_dir(store_root, gid):
    """output/goal/<goal_id>: the only folder a goal writes to; the id must be a plain contract id and the folder must resolve under output/goal."""
    base = Path(store_root) / "output" / "goal"
    if not isinstance(gid, str) or not GOAL_ID.fullmatch(gid) or (base / gid).resolve().parent != base.resolve():
        raise Refused("goal output folder is not contained")
    return base / gid


def types(): return json.loads(TYPES_PATH.read_text(encoding="utf-8"))


def _sub(T, t, want):
    while t:
        if t == want:
            return True
        t = T["types"][t]["subtype_of"]
    return False


# ---------------------------------------------------------------- C1 contract
def load_inputs(allowed_root, sources, listed=None):
    """Relative paths under the allowed root -> [(name, 'file'|'folder', bytes|path)]. Raises ValueError/Refused."""
    from .console import _bounded_read, _under
    root = Path(allowed_root).resolve(strict=True)
    if not isinstance(sources, list) or not 1 <= len(sources) <= 20 or len(set(map(str, sources))) != len(sources):
        raise Refused("select 1 to 20 distinct permitted files or folders")
    out = []
    for raw in sources:
        try:
            p = _under(root, raw, file=False)
        except OSError:
            raise Refused("source not found under the permitted folder") from None
        rel = p.relative_to(root)
        if any(part.startswith(".") for part in rel.parts):
            raise Refused("hidden paths are not permitted")
        if p.is_dir():
            out.append((p.name, "folder", p))
        else:
            if listed is not None and rel.as_posix() not in listed:
                raise Refused("select a listed permitted CSV/JSON file")
            out.append((p.name, "file", _bounded_read(p)))
    return out


def _schema_tag(data):
    """The top-level "schema" string of a small JSON object, else None."""
    try:
        v = json.loads(data.decode("utf-8")) if len(data) <= O.MAX_FILE else None
    except ValueError:
        return None
    return v.get("schema") if isinstance(v, dict) and isinstance(v.get("schema"), str) else None


def make_contract(goal_text, inputs, *, deliverable=None, budget=None, allow_discovery=False, allow_acquisition=False):
    """Normalise a goal into a versioned contract, or a NEEDS_CLARIFICATION dict. Raises Refused for malformed input."""
    T = types()
    if not isinstance(goal_text, str) or not goal_text.strip() or len(goal_text) > 2000:
        raise Refused("a goal of 1 to 2000 characters is required")
    if deliverable is not None and deliverable not in T["deliverables"]:
        raise Refused(f"unsupported deliverable {str(deliverable)[:40]!r}; supported: {', '.join(T['deliverables'])}")
    if deliverable is None:
        spans = {}  # deliverable -> matched keyword spans; a match inside another deliverable's longer match does not count
        for d in T["deliverables"]:
            m = [x.span() for x in re.finditer(T["types"][d].get("keywords") or "(?!)", goal_text.lower())]
            if m:
                spans[d] = m
        inside = lambda s, d: any(o != d and a <= s[0] and s[1] <= b and b - a > s[1] - s[0] for o in spans for a, b in spans[o])
        hits = [d for d in spans if not all(inside(s, d) for s in spans[d])]
        if len(hits) != 1:
            return {"state": "NEEDS_CLARIFICATION", "reason": "goal matched " + (", ".join(hits) if hits else "no deliverable"),
                    "supported_deliverables": {d: T["types"][d]["description"] for d in T["deliverables"]}}
        deliverable = hits[0]
    if not isinstance(inputs, (list, tuple)) or not 1 <= len(inputs) <= 20:
        raise Refused("1 to 20 inputs are required")
    pol, total, ins = O.load_policy(), 0, []
    for name, kind, data in inputs:
        if not isinstance(name, str) or not NAME.fullmatch(name):
            raise Refused(f"bad input name {str(name)[:40]!r}")
        ftype = T["file_input_type"]
        if kind == "folder":
            data = O.snapshot_dir(data, limit=SITE_MAX_FILES)  # may raise Refused (empty/too large); hash of the snapshot taken at intake
        elif kind == "file":
            if not isinstance(data, bytes):
                raise Refused(f"{name}: file content required")
            ext = Path(name).suffix.lower()[1:]  # the deliverable's type row may name the input types it accepts (`from`) by file format
            ftype = next((x for x in T["types"][deliverable].get("from", []) if ext in T["types"][x].get("accepts_formats", ())), None)
            if ftype is None and ext == "json":  # a type row may name the "schema" tag of a JSON file it types (only that one field is read)
                tag = _schema_tag(data)
                ftype = next((x for x in T["types"][deliverable].get("from", []) if tag and T["types"][x].get("schema_tag") == tag), None)
            if ftype is None:
                O._fmt(name)
                ftype = T["file_input_type"]
            if len(data) > O.MAX_FILE:
                raise Refused(f"{name}: exceeds the 2 MiB limit")
        else:
            raise Refused(f"bad input kind {str(kind)[:20]!r}")
        total += len(data)
        ins.append({"name": name, "type": "folder" if kind == "folder" else ftype, "sha256": _sha(data), "bytes": len(data)})
    if total > pol["max_total_bytes"]:
        raise Refused("inputs exceed 2 MiB in total")
    dflt, b = T["default_budget"], dict(T["default_budget"])
    for k, v in (budget or {}).items():
        if k not in dflt or not isinstance(v, int) or isinstance(v, bool) or not 0 <= v <= dflt[k]:
            raise Refused(f"budget {k!r} may only be lowered (0..{dflt.get(k)})")
        b[k] = v
    core = {"schema": CONTRACT_SCHEMA, "goal_text": goal_text, "goal_sha256": _sha(goal_text), "deliverable": deliverable,
            "output_schema": {"type": deliverable, "description": T["types"][deliverable]["description"]}, "inputs": ins,
            "success_criteria": ["every registry step independently verified PASS by its pinned oracle", "deliverable type matches",
                                 "no model calls"],
            "allowed_operations": sorted(T["capabilities"]),
            "permissions": dict({"network": False, "model_calls": 0, "discovery": bool(allow_discovery), "side_effects": "write verified outputs under store output/ only"},
                                **({"acquisition": True} if allow_acquisition else {})),
            "budget": b, "parser": PARSER}
    now = datetime.now(timezone.utc)
    return dict(core, contract_id="g-" + _sha(_json(core))[:20], created_at=now.isoformat(timespec="seconds"),
                deadline=(now + timedelta(seconds=b["wall_s"])).isoformat(timespec="seconds"))


def prepare(store_root, allowed_root, goal, sources, deliverable=None, budget=None, listed=None, allow_discovery=False):
    """load_inputs + make_contract; a malformed submission is counted as a refusal before anything runs."""
    try:
        inputs = load_inputs(allowed_root, sources, listed)
        return make_contract(goal, inputs, deliverable=deliverable, budget=budget, allow_discovery=allow_discovery), inputs
    except ValueError as e:
        O.note_refusal(store_root, "goal", e)
        raise


# ---------------------------------------------------------------- C2 planner
def eligible_caps(store):
    """(eligible {op: type row + genome}, excluded [{op, reason}]). Registry ops must resolve() OK right now."""
    ok, ex = {}, []
    for op, c in types()["capabilities"].items():
        if c["kind"] == "registry":
            try:
                ok[op] = dict(c, genome=O.resolve(store, op)["genome"])
            except Refused as e:
                ex.append({"op": op, "reason": str(e)})
        else:
            ok[op] = dict(c)
    from . import capability_registry as CR  # C4: admitted discovered capabilities, types from the verified signed statement
    dok, dex = CR.eligible_discovered(store)
    ok.update(dok)
    return ok, ex + dex


MAX_BRANCHES = 8  # input choices explored per op per state
MAX_EXPANSIONS = 300  # states expanded per plan call; past it the planner stops with a stated limit (never a hang)


def _takes(match, lo, hi):
    """Input choices for one op, the old pick first: arity-1 ops one branch per matching item (item order); n-ary ops the
    combinations of size hi down to lo (match[:hi] first). At most MAX_BRANCHES."""
    if hi == 1:
        return [[x] for x in match[:MAX_BRANCHES]]
    out = []
    for n in range(min(hi, len(match)), lo - 1, -1):
        for combo in itertools.combinations(match, n):
            if len(out) == MAX_BRANCHES:
                return out
            out.append(list(combo))
    return out


RANK_BY = "hidden-suite pass ratio desc, observed success rate desc, observed median latency asc, estimated cost asc, version desc, capability_id"
RANK_FIELDS = ("pass_ratio", "success_rate", "median_ms", "cost", "version")


def _collapse(store, ok):
    """T03. Discovered capabilities with the same interface (input types, arity, output type) are alternatives for one step. Returns {op: [the ranked
    alternatives of op's group, best first]} for every op in a group of two or more (a group of one has no entry, so old plans are exact)."""
    groups = {}
    for op, c in ok.items():
        if c["kind"] == "discovered":
            groups.setdefault((tuple(c["types"]), tuple(c["arity"]), c["out"]), []).append(op)
    alts = {}
    for ops in (g for g in groups.values() if len(g) > 1):
        hist = {op: H.stats(store, op, ok[op]["version"]) for op in ops}
        known = [h for h in hist.values() if h["n"]]
        neutral_ms = sum(h["median_ms"] for h in known) / len(known) if known else 0  # unknown = the group's own average, so history neither rewards nor punishes it
        row = lambda op: {"pass_ratio": ok[op]["pass_ratio"], "success_rate": hist[op]["success_rate"] if hist[op]["n"] else 0.5,
                          "median_ms": hist[op]["median_ms"] if hist[op]["n"] else neutral_ms, "cost": ok[op]["cost"], "version": ok[op]["version"]}
        key = lambda op: (-row(op)["pass_ratio"], -row(op)["success_rate"], row(op)["median_ms"], row(op)["cost"], -row(op)["version"], op)
        ranked = sorted(ops, key=key)
        best = row(ranked[0])
        entries = []
        for n, op in enumerate(ranked):
            r = row(op)
            why = "best by the rank key" if not n else next((f"{f} {r[f]} vs {best[f]}" for f in RANK_FIELDS if r[f] != best[f]), "capability_id order")
            entries.append({"op": op, "version": ok[op]["version"], "statement_sha": ok[op]["statement_sha"], "rank": r, "reason": why})
        alts.update({op: entries for op in ops})
    return alts


def plan_goal(store, contract):
    """Search over the eligible capabilities, then each step that has same-interface alternatives is given the best-ranked one; the ranked list is kept in
    step['ranking']['alternatives'] (the first is the one chosen, the rest are the bounded runtime fallbacks)."""
    ok, ex = eligible_caps(store)
    alts = _collapse(store, ok)
    plan = _plan_goal(store, contract, ok, ex)
    for st in plan["steps"]:
        if st["op"] in alts:
            best = alts[st["op"]][0]
            if best["op"] != st["op"]:
                st.update(_alt_step(st, best))
                st["allowance"] = dict(st["allowance"], timeout_s=ok[best["op"]].get("timeout_s", st["allowance"]["timeout_s"]))
            st["ranking"] = {"by": RANK_BY, "chosen": 0, "alternatives": alts[st["op"]]}
    if plan.get("estimate"):
        plan["estimate"]["worst_wall_s"] = sum(x["allowance"]["timeout_s"] for x in plan["steps"] if x["allowance"]["container_runs"])
    return plan


def _plan_goal(store, contract, ok, ex):
    """Fewest-steps search (op-name tie-break) from the input types to a single item of the deliverable type that consumes every
    input. First the first-match search (each op takes the first matching item(s)): its plan is the one every earlier release
    produced, so it wins whenever it exists. Only when it finds none does the bounded enumeration (other input choices) run.
    Ordered (discovered) capabilities get their inputs in the user's order. steps == [] means no plan."""
    T = types()
    goal, maxs = contract["deliverable"], contract["budget"]["max_steps"]
    start = tuple((i["type"], f"input:{n}", n) for n, i in enumerate(contract["inputs"]))  # (type, ref, the user's input position)
    budget_s = O.load_policy()["container_timeout_s"]  # policy read once per plan call

    def child(items, path, op, take):
        c = ok[op]
        if c.get("ordered"):
            take = sorted(take, key=lambda x: x[2])
        sid = f"s{len(path) + 1}"
        step = {"step_id": sid, "op": op, "kind": c["kind"], "capability": op, "inputs": [x[1] for x in take],
                "expected_output": c["out"], "verifier": c["verifier"],
                "allowance": {"container_runs": 1 if c["kind"] in ("registry", "discovered") else 0, "timeout_s": budget_s},
                "after": [x[1][5:] for x in take if x[1].startswith("step:")]}
        step.update({"adapter": c["adapter"]} if c["kind"] == "builtin_adapter" else {"genome": c["genome"]})
        if c["kind"] == "discovered":
            step.update(version=c["version"], statement_sha=c["statement_sha"])
        return tuple(x for x in items if x not in take) + ((c["out"], "step:" + sid, min(x[2] for x in take)),), path + (step,)

    def search(choices, seen=None):
        queue, n = deque([(start, ())]), 0
        while queue:
            items, path = queue.popleft()
            if path and len(items) == 1 and items[0][0] == goal:
                return list(path), None
            if len(path) >= maxs:
                continue
            if seen is not None:
                n += 1
                if n > MAX_EXPANSIONS:
                    return [], f"planner expansion limit ({MAX_EXPANSIONS}) reached without a plan"
            for op in sorted(ok):
                if "ins" in ok[op]:  # typed-slot capabilities belong to the DAG planner
                    continue
                lo, hi = ok[op]["arity"]
                match = [x for x in items if _sub(T, x[0], ok[op]["in"])]
                for take in choices(match, lo, hi):
                    nxt, npath = child(items, path, op, take)
                    if seen is None:
                        queue.append((nxt, npath))
                        continue
                    k = (tuple(sorted(x[1] for x in nxt if x[1].startswith("input:"))), tuple(sorted(x[0] for x in nxt if x[1].startswith("step:"))))
                    if k not in seen:  # the same (remaining inputs, produced types) is never explored twice
                        seen.add(k)
                        queue.append((nxt, npath))
        return [], None

    first = lambda match, lo, hi: [match[:1] if hi == 1 else match[:hi]] if len(match[:1] if hi == 1 else match[:hi]) >= lo else []
    steps, limit = search(first)
    if not steps:
        dag, dlimit = plan_dag(T, ok, contract, budget_s)  # fan-out / typed-slot plans (the bounded partition search below cannot express them)
        if dag:
            return {"schema": PLAN_SCHEMA, "steps": dag["steps"], "excluded": ex, "dag": True, "estimate": dag["estimate"], "ranking": dag["ranking"]}
        steps, limit = search(_takes, {(tuple(x[1] for x in start), ())})
        limit = limit or dlimit
    return {"schema": PLAN_SCHEMA, "steps": steps, "excluded": ex, **({"limit": limit} if limit and not steps else {})}


# ---------------------------------------------------------------- G3 typed DAG planner
MAX_DAG_STEPS = 8  # plan size cap
MAX_DAG_EXPANSIONS = 600  # states expanded per DAG search
MAX_DAG_PLANS = 64  # complete plans collected per search


def _dag_takes(T, c, items):
    """Input choices for one op over the available items (inputs stay available after use; produced outputs are used once). A typed-slot op takes one
    item per slot (by type, any order of arrival); an arity-1 op one branch per matching item; an n-ary op every matching item. At most MAX_BRANCHES."""
    if "ins" in c:
        pools = [[x for x in items if _sub(T, x[0], t)] for t in c["ins"]]
        out = []
        for combo in itertools.product(*pools):
            if len({x[1] for x in combo}) == len(combo):
                out.append(list(combo))
                if len(out) == MAX_BRANCHES:
                    break
        return out
    lo, hi = c["arity"]
    match = [x for x in items if _sub(T, x[0], c["in"])]
    if hi == 1:
        return [[x] for x in match[:MAX_BRANCHES]]
    return [match[:hi]] if len(match[:hi]) >= lo else []  # an n-ary op takes every matching item (a fan-out consumer never sees a subset)


def _dag_step(c, op, sid, refs, budget_s, final):
    step = {"step_id": sid, "op": op, "kind": c["kind"], "capability": op, "inputs": refs, "expected_output": c["out"], "verifier": c["verifier"],
            "allowance": {"container_runs": 1 if c["kind"] in ("registry", "discovered") else 0, "timeout_s": c.get("timeout_s", budget_s)},
            "after": [r[5:] for r in refs if r.startswith("step:")], "report_name": "report.json" if final else sid + ".report.json"}
    step.update({"adapter": c["adapter"]} if c["kind"] == "builtin_adapter" else {"genome": c["genome"]})
    if c["kind"] == "discovered":
        step.update(version=c["version"], statement_sha=c["statement_sha"])
    return step


def plan_dag(T, ok, contract, budget_s):
    """Typed DAG search. Inputs are immutable and may feed several steps (fan-out); a step whose inputs are produced types joins them (fan-in, by type);
    a produced output is consumed once. A plan is complete when every input is used, exactly one output is left and it is the deliverable. Every complete plan
    is ranked (fewest steps, then estimated cost from the contracts' timeout x cpus, then op names) instead of taking the first. Only plans that need the
    DAG (some input feeds two steps, or a typed-slot op is used) are returned. Bounded by MAX_DAG_STEPS / MAX_DAG_EXPANSIONS / MAX_DAG_PLANS.
    Returns ({steps, estimate, ranking} | None, limit message | None)."""
    goal, cap = contract["deliverable"], min(contract["budget"]["max_steps"], MAX_DAG_STEPS)
    ins = [(i["type"], f"input:{n}") for n, i in enumerate(contract["inputs"])]
    ops, queue, seen, found, n, limit = sorted(ok), deque([()]), set(), [], 0, None
    while queue and len(found) < MAX_DAG_PLANS:
        path = queue.popleft()  # path = tuple of nodes (op, refs, out type, expression)
        if len(path) >= cap:
            continue
        n += 1
        if n > MAX_DAG_EXPANSIONS:
            limit = f"DAG planner expansion limit ({MAX_DAG_EXPANSIONS}) reached"
            break
        used = {r for node in path for r in node[1]}
        expr = {r: r for _, r in ins} | {f"step:s{i + 1}": node[3] for i, node in enumerate(path)}
        items = ins + [(node[2], f"step:s{i + 1}") for i, node in enumerate(path) if f"step:s{i + 1}" not in used]
        anc = {r: set() for _, r in ins}  # what each item is derived from (transitively)
        for i, node in enumerate(path):
            anc[f"step:s{i + 1}"] = set(node[1]).union(*(anc[r] for r in node[1]))
        for op in ops:
            for take in _dag_takes(T, ok[op], items):
                refs = [x[1] for x in take]
                if any(a in anc[b] for a in refs for b in refs):  # never an item together with something derived from it (that would count it twice)
                    continue
                if "ins" in ok[op] and any(r in n[1] for n in path if n[0] == op for r in refs if r.startswith("input:")):  # a typed-slot op never re-binds an input it already took (each release gets its own scope)
                    continue
                node = (op, refs, ok[op]["out"], f"{op}({','.join(expr[r] for r in refs)})")
                child = path + (node,)
                key = frozenset(x[3] for x in child)
                if key in seen:
                    continue
                seen.add(key)
                used2 = used | set(refs)
                outs = [x for x in items if x[1].startswith("step:") and x[1] not in refs] + [(node[2], f"step:s{len(child)}")]
                if len(outs) == 1 and outs[0][0] == goal and all(r in used2 for _, r in ins):
                    uses = [r for x in child for r in x[1] if r.startswith("input:")]
                    if len(set(uses)) < len(uses) or any("ins" in ok[x[0]] for x in child):
                        found.append(child)
                        cap = min(cap, len(child))  # fewest steps first: nothing deeper than the first complete depth is searched
                elif len(child) < cap:
                    queue.append(child)
    if not found:
        return None, limit
    cost = lambda c: _cost(ok[c[0]], budget_s)
    ranked = sorted((p for p in found if len(p) == cap), key=lambda p: (len(p), sum(map(cost, p)), tuple(x[0] for x in p), tuple(x[3] for x in p)))
    best = ranked[0]
    steps = [_dag_step(ok[x[0]], x[0], f"s{i + 1}", x[1], budget_s, i == len(best) - 1) for i, x in enumerate(best)]
    est = {"steps": len(steps), "container_runs": sum(x["allowance"]["container_runs"] for x in steps),
           "worst_wall_s": sum(x["allowance"]["timeout_s"] for x in steps if x["allowance"]["container_runs"]), "worst_cpu_s": sum(map(cost, best))}
    rank = {"considered": len(ranked), "expansions": n, "chosen": 0, "by": "steps, estimated cost, op names",
            "alternatives": [{"ops": [x[0] for x in p], "cost": sum(map(cost, p)), "expression": p[-1][3]} for p in ranked[:5]]}
    return {"steps": steps, "estimate": est, "ranking": rank}, None


def _cost(c, budget_s):
    """Estimated cost of one step: timeout x cpus for a retained capability, the container budget for a registry op, nothing for an engineering adapter."""
    return c.get("cost", budget_s if c["kind"] in ("registry", "discovered") else 0)


def validate_plan(store, contract, plan):
    """Independent re-check of a plan (not of the search). Returns a list of problems; empty means valid."""
    T, (ok, _) = types(), eligible_caps(store)
    steps = plan.get("steps") or []
    if not steps:
        return ["empty plan"]
    if not all(isinstance(s, dict) and isinstance(s.get("step_id"), str) and STEP_ID.fullmatch(s["step_id"]) and isinstance(s.get("inputs"), list)
               and all(isinstance(r, str) for r in s["inputs"]) for s in steps):
        return ["malformed step (step ids must look like s1, inputs must be a list of references)"]
    by = {s["step_id"]: s for s in steps}
    order = {s["step_id"]: n for n, s in enumerate(steps)}
    if len(by) != len(steps) or len(order) != len(steps):
        return ["duplicate or missing step ids"]
    if len(steps) > contract["budget"]["max_steps"]:
        return [f"{len(steps)} steps exceeds the budget of {contract['budget']['max_steps']}"]
    dag = bool(plan.get("dag"))  # a DAG plan: inputs may feed several steps; typed-slot capabilities; size cap
    if dag and len(steps) > MAX_DAG_STEPS:
        return [f"{len(steps)} steps exceeds the DAG plan cap of {MAX_DAG_STEPS}"]
    done, consumed = {}, []

    def ref_type(ref, path):
        kind, _, k = str(ref).partition(":")
        if kind == "input" and k.isdigit() and int(k) < len(contract["inputs"]):
            return contract["inputs"][int(k)]["type"]
        if kind == "step" and k in by:
            return check(k, path)
        raise ValueError(f"unknown reference {ref!r}")

    def check(sid, path=()):
        if sid in path:
            raise ValueError(f"cycle through {sid}")
        if sid in done:
            return done[sid]
        s, c = by[sid], T["capabilities"].get(by[sid].get("op")) or ok.get(by[sid].get("op"))
        if c is None:
            raise ValueError(f"{sid}: unknown capability {s.get('op')!r}")
        if s["op"] not in ok:
            raise ValueError(f"{sid}: capability {s['op']} is not eligible (revoked, damaged or unpinned)")
        if c["kind"] in ("registry", "discovered") and s.get("genome") != ok[s["op"]]["genome"]:
            raise ValueError(f"{sid}: plan genome is not the currently eligible one")
        if c["kind"] == "discovered" and s.get("statement_sha") != ok[s["op"]]["statement_sha"]:
            raise ValueError(f"{sid}: plan statement pin is not the currently admitted one")
        lo, hi = c["arity"]
        if not lo <= len(s["inputs"]) <= hi or ("ins" in c and len(s["inputs"]) != len(c["ins"])):
            raise ValueError(f"{sid}: {s['op']} takes {lo} to {hi} inputs, got {len(s['inputs'])}")
        if len(set(map(str, s["inputs"]))) != len(s["inputs"]):
            raise ValueError(f"{sid}: the same item is given twice")
        for dep in s.get("after", []):
            if dep not in by:
                raise ValueError(f"{sid}: unknown dependency {dep!r}")
            check(dep, path + (sid,))
        for k, ref in enumerate(s["inputs"]):
            t = ref_type(ref, path + (sid,))
            want = c["ins"][k] if "ins" in c else c["in"]  # a typed-slot capability: input k must fit slot k
            if not _sub(T, t, want):
                raise ValueError(f"{sid}: {t} is not accepted as {want}")
            if str(ref).startswith("step:") and order[ref[5:]] >= order[sid]:
                raise ValueError(f"{sid}: depends on a later step")
            consumed.append(ref)
        done[sid] = c["out"]
        if s.get("expected_output") != c["out"]:
            raise ValueError(f"{sid}: expected_output does not match the type table")
        return c["out"]

    try:
        for sid in by:
            check(sid)
        once = [r for r in consumed if r.startswith("step:")] if dag else consumed  # DAG: inputs are immutable and may feed several steps
        if len(set(once)) != len(once):
            raise ValueError("an input or step output is used twice")
        left = [("input:%d" % n) for n in range(len(contract["inputs"]))] + ["step:" + s for s in by]
        left = [r for r in left if r not in consumed]
        if len(left) != 1:
            raise ValueError(f"plan leaves {len(left)} unconsumed items; exactly one deliverable is required")
        if (done[left[0][5:]] if left[0].startswith("step:") else contract["inputs"][int(left[0][6:])]["type"]) != contract["deliverable"]:
            raise ValueError("final output type does not match the deliverable")
    except (ValueError, KeyError, TypeError) as e:
        return [str(e)]
    return []


def missing_step(store, contract):
    """C3: the smallest typed step that is missing, or None. Only when no eligible capability produces the deliverable at all.
    Each input is normalised as far as eligible single-input capabilities go (greedy, op-name order, no type revisited); if every
    input ends at the same type T the gap is (T, arity=#inputs, ordered, out=deliverable) and the normalising steps are the partial plan."""
    T, (ok, _) = types(), eligible_caps(store)
    if any(c["out"] == contract["deliverable"] for c in ok.values()):
        return None
    ends, partial = [], []
    for n, i in enumerate(contract["inputs"]):
        t, ref, seen = i["type"], f"input:{n}", {i["type"]}
        while True:
            op = next((o for o in sorted(ok) if ok[o]["arity"] == [1, 1] and _sub(T, t, ok[o]["in"]) and ok[o]["out"] not in seen), None)
            if op is None:
                break
            partial.append({"step_id": f"s{len(partial) + 1}", "op": op, "inputs": [ref], "expected_output": ok[op]["out"]})
            t, ref = ok[op]["out"], "step:" + partial[-1]["step_id"]
            seen.add(t)
        ends.append(t)
    if len(set(ends)) != 1:  # inputs of different types: a typed-slot gap, only when a repo contract declares exactly those slots
        sig = {"in": min(ends), "ins": sorted(ends), "arity": len(ends), "out": contract["deliverable"]}
        return (sig, partial) if CC.contract_for_gap(sig) else None
    return {"in": ends[0], "arity": len(ends), "ordered": True, "out": contract["deliverable"]}, partial


def record_gap(store, contract, plan, missing=None):
    """Open (or re-hit) the typed gap for C3. Discovery is NOT started here. `missing` = missing_step() result or None."""
    ins = sorted(i["type"] for i in contract["inputs"])
    key = "operator/gap/" + _sha(_json([contract["deliverable"], ins] + ([missing[0]] if missing else [])))[:16]
    ok, _ = eligible_caps(store)
    with _txn(store):
        g = store.get(key) or {"unmet_type": contract["deliverable"], "desired_behavior": contract["output_schema"]["description"],
                               "input_types": ins, "goal_ids": [], "count": 0, "allowed_tools": ["registry capabilities", "builtin adapters"],
                               "success_criteria": contract["success_criteria"], "status": "OPEN", "discovery": "not started (C3)"}
        if missing:
            g["missing_step"], g["partial_plan"] = missing
        g["capability_inventory"] = {"eligible": {op: {"in": c["in"], "out": c["out"], "arity": c["arity"], "kind": c["kind"]} for op, c in ok.items()},
                                     "excluded": plan.get("excluded", [])}
        g["count"] += 1
        if contract["contract_id"] not in g["goal_ids"]:
            g["goal_ids"].append(contract["contract_id"])
        store.set(key, g)
    return key


# ---------------------------------------------------------------- execution
def _step_snapshot(store_root, contract, inputs, step, rec):
    n = int(step["inputs"][0][6:])
    try:
        outdir = _goal_dir(store_root, contract["contract_id"])
        name = step["step_id"] + ".csv"
        target = O.contained(outdir, name)
        data = O.snapshot_dir(inputs[n][2])
        if _sha(data) != contract["inputs"][n]["sha256"]:
            raise Refused("folder content changed since the contract was made")
        O.intake_check("convert", [(step["step_id"] + ".csv", data)])
        bad = O.explain_rejection(step["step_id"] + ".csv", data)
        if bad:
            raise Refused(bad)
    except (Refused, OSError) as e:
        rec.update(state="REFUSED", reason=str(e)[:300], verdict="FAIL")
        return None
    O._write(target, data)
    rec.update(state=STEP_OK, verdict="PASS", mode="builtin_adapter", artifacts=[{"name": name, "ref": f"output/goal/{contract['contract_id']}/{name}", "sha256": _sha(data)}])
    return name, data


SITE_ADAPTER, SITE_MAX_FILES = "site-pack-v1", 2000


def _step_site_pack(store_root, contract, inputs, step, rec):
    """Packing only (no extraction, resolution or classification): folder + site scope -> site_pages / site_manifest, by the same code as
    scripts/export_site_inputs.py. The scope file (schema site-scope-v1) carries commit, excluded_top_level, excluded_files_over_5MB and committed_at;
    a packed output that would hold a null (no committed_at) refuses the step."""
    n, k = int(step["inputs"][0][6:]), int(step["inputs"][1][6:])
    try:
        # ponytail: intake hashes path+size of every file, not content; same-size edits between intake and run are not detected
        if _sha(O.snapshot_dir(inputs[n][2], limit=SITE_MAX_FILES)) != contract["inputs"][n]["sha256"] or _sha(inputs[k][2]) != contract["inputs"][k]["sha256"]:
            raise Refused("input changed since the contract was made")
        sc = json.loads(inputs[k][2].decode("utf-8"))
        if not isinstance(sc, dict) or sc.get("schema") != "site-scope-v1" or not isinstance(sc.get("commit"), str):
            raise Refused("the scope input must be a site-scope-v1 object with a commit")
        import importlib.util
        spec = importlib.util.spec_from_file_location("export_site_inputs", O.ROOT / "scripts" / "export_site_inputs.py")
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        try:
            docs = m.export(str(inputs[n][2]), sc, sc.get("committed_at"))
        except (ValueError, TypeError) as e:
            raise Refused(f"cannot pack: {e}") from None
        doc = next(d for d in docs if d["schema"] == types()["types"][step["expected_output"]]["schema_tag"])
        gone = [k for k, v in doc.items() if v is None]
        if gone:  # ponytail: a value the scope input does not carry (committed_at) is never invented
            raise Refused(f"the scope input has no {', '.join(gone)}; take it from git log of the site repo")
        data = m.dump(doc).encode("ascii")
        if len(data) > O.MAX_FILE:
            raise Refused("packed output exceeds the 2 MiB limit")
        name = step["step_id"] + ".json"
        target = O.contained(_goal_dir(store_root, contract["contract_id"]), name)
    except (Refused, OSError) as e:
        rec.update(state="REFUSED", reason=str(e)[:300], verdict="FAIL")
        return None
    O._write(target, data)
    rec.update(state=STEP_OK, verdict="PASS", mode="builtin_adapter", artifacts=[{"name": name, "ref": f"output/goal/{contract['contract_id']}/{name}", "sha256": _sha(data)}])
    return name, data


def _run_discovered(s, store_root, contract, step, files, sr, stop_path, left=None):
    """C4: run an admitted discovered capability on the step's inputs. resolve_discovered re-verifies signature, chain, body hash, harness,
    pin and image on EVERY use. Same capability statement + same inputs -> saved-result replay; otherwise one container run, then the
    independent oracle in its own process. Only PASS is exported (the contract's artifact + report.json under output/goal/<goal_id>/)."""
    from . import capability_registry as CR, experiment_compare as EC
    store_root = Path(store_root)
    r = CR.resolve_discovered(s, step["op"])  # Refused -> step REFUSED, nothing executed
    st = r["statement"]
    if r["statement_sha"] != step.get("statement_sha"):
        raise Refused("the admitted version changed since the plan was made")
    c = CC.normalize(st)
    env = CC.build_env(c, files)
    tid = "u-" + _sha(_json({"cap": r["statement_sha"], "pin": CC.pin(c), "inputs": [_sha(d) for _, d in files]}))[:20]
    sr.update(capability={"cap_id": step["op"], "version": r["version"], "statement_sha": r["statement_sha"]}, task_id=tid)
    outdir, ukey = _goal_dir(store_root, contract["contract_id"]), "operator/capuse/" + tid
    rn = step.get("report_name", "report.json")  # a plan with several retained steps keeps one report per step (only the last is report.json)
    an = c["outputs"]["artifact_name"]
    O.contained(outdir, an), O.contained(outdir, rn)  # both names are plain file names inside the goal folder, or the step is refused

    def export(out, ver):
        report = {"goal_id": contract["contract_id"], "step": step["step_id"], "capability": sr["capability"], "inputs": [{"name": n, "sha256": _sha(d)} for n, d in files],
                  "output_sha256": _sha(out), "verification": {k: ver.get(k) for k in ("verdict", "evaluator", "pin", "expected_sha256")}}
        arts = []
        for name, data in ((an, out.encode("utf-8")), (rn, json.dumps(report, sort_keys=True, indent=1).encode("utf-8"))):
            O._write(O.contained(outdir, name), data)
            arts.append({"name": name, "ref": (outdir / name).relative_to(store_root).as_posix(), "sha256": _sha(data)})
        return arts

    cached = _cached_output(s, store_root, s.get(ukey), r, an, c["execution"]["max_output_bytes"])
    if cached is not None:  # replay = the saved bytes re-checked by the SAME independent oracle as a fresh run; no container, no model
        ver = CC.verify(c, env, cached, timeout=max(1, min(CC.VERIFY_TIMEOUT_S, left() if left else CC.VERIFY_TIMEOUT_S)))
        if ver["verdict"] == "PASS":
            arts = export(cached, ver)
            sr.update(mode="saved_result_replay", state=STEP_OK, verdict="PASS", reason=None, verification=ver, artifacts=arts)
            O._bump(s, replays=1)
            return step["step_id"] + Path(arts[0]["name"]).suffix, cached.encode("utf-8")
    if stop_path.exists():
        sr.update(state="STOPPED", reason="STOP is set")
        return None
    O._bump(s, container_runs=1)  # counted at start: an interrupted run is still a run
    left = left or (lambda: float("inf"))  # seconds to the goal's absolute deadline: the step never outlives the goal's wall budget
    try:
        res = json.loads(EC.run_isolated(CC.load_module("harness", c, c["verification"]["harness"]).wrap(st["body"]), json.dumps([env]), {},
                                         timeout=max(1, int(min(c["execution"]["timeout_seconds"], left()))), max_out=c["execution"]["max_output_bytes"],
                                         backend="container", operator_class="generated", **CC.exec_args(c, st.get("environment"))))
        out = res[0] if isinstance(res, list) and len(res) == 1 else None
    except Refused:  # load_module / exec_args refused the pinned harness or environment: integrity, never recoverable
        raise
    except Exception as e:
        O._bump(s, executions=1)
        sr.update(state="EXECUTION_FAILED", reason=f"{type(e).__name__}: {str(e)[:300]}", failure_class=_failure_class(e))
        return None
    O._bump(s, executions=1)
    if not isinstance(out, str):
        sr.update(state="EXECUTION_FAILED", reason="the capability produced no output for these inputs", failure_class="EXECUTION")
        return None
    ver = CC.verify(c, env, out, timeout=max(1, min(CC.VERIFY_TIMEOUT_S, left())))
    sr.update(mode="retained_capability_execution", verdict=ver["verdict"], verification=ver)
    if ver["verdict"] != "PASS":
        sr.update(state="VERIFICATION_FAILED" if ver["verdict"] == "FAIL" else "REVIEW_PENDING", reason="Independent check " + ver["verdict"] + "; output withheld",
                  failure_class="OUTPUT_REJECTED" if ver["verdict"] == "FAIL" else "OTHER")
        return None
    arts = export(out, ver)
    s.set(ukey, {"artifacts": arts, "verification": sr["verification"], "statement_sha": r["statement_sha"], "at": _now()})
    sr.update(state=STEP_OK, reason=None, artifacts=arts)
    return step["step_id"] + Path(arts[0]["name"]).suffix, out.encode("utf-8")


def _cached_output(s, store_root, saved, r, an, max_bytes):
    """The saved output text of an earlier verified use of this exact statement + inputs, or None. The record is store-written and untrusted: the file must
    sit under output/, hash as recorded, be the contract's artifact, and fit the output limit. The caller still runs the independent oracle on it."""
    try:
        if not isinstance(saved, dict) or saved.get("statement_sha") != r["statement_sha"]:
            return None
        a = next(x for x in saved["artifacts"] if x["name"] == an)
        base = (Path(store_root) / "output").resolve()
        p = (Path(store_root) / a["ref"]).resolve()
        if not p.is_relative_to(base) or not p.is_file() or p.stat().st_size > max_bytes:
            return None
        data = p.read_bytes()
        return data.decode("utf-8") if _sha(data) == a["sha256"] else None
    except (StopIteration, KeyError, TypeError, AttributeError, OSError, ValueError):
        return None


def _failure_class(e):
    """Recoverable failure classes only, by allowlist: the candidate's own timeout, non-zero exit / bad output (plain RuntimeError / ValueError from the
    runner). Anything else (sandbox / image / daemon verification, unknown exception types) is INTEGRITY and fails the goal closed."""
    if isinstance(e, (subprocess.TimeoutExpired, TimeoutError)) or (type(e) is RuntimeError and "timed out" in str(e)):
        return "TIMEOUT"
    return "EXECUTION" if type(e) in (RuntimeError, ValueError, json.JSONDecodeError) else "INTEGRITY"


MAX_FALLBACKS = 2  # per goal, each one counted against the goal's container budget
RECOVERABLE = frozenset({"EXECUTION", "TIMEOUT", "OUTPUT_REJECTED", "UNAVAILABLE"})  # UNAVAILABLE = a signed revoke only  # INTEGRITY (signature / pin / hash / tamper) is never recoverable


def _alt_step(step, alt):
    """The same step run by the next-ranked alternative: same inputs, report name and allowance; pinned to the alternative's own statement."""
    st = {k: v for k, v in step.items() if k != "ranking"}
    return dict(st, op=alt["op"], capability=alt["op"], genome=alt["statement_sha"], version=alt["version"], statement_sha=alt["statement_sha"])


def _attempt(s, store_root, contract, step, files, sr, stop_path, left):
    """One run of one capability. Returns (out, failure_class); history is appended for every real execution (never for a saved-result replay)."""
    from .capability_registry import Unavailable
    t0, m0 = time.monotonic(), O._counters(s)["model_calls"]
    sr.pop("failure_class", None)
    try:
        out = _run_discovered(s, store_root, contract, step, files, sr, stop_path, left)
    except Unavailable as e:  # every version revoked by a signed event: another capability may still do the step. A pinned step whose chain is gone is integrity.
        from .capability_registry import head
        sr.update(state="REFUSED", reason=str(e)[:300], failure_class="UNAVAILABLE" if head(s, step["op"]) is not None else "INTEGRITY")
        out = None
    except Refused as e:  # signature, chain, pin, hash, image or pinned-version recheck failed: fail closed
        sr.update(state="REFUSED", reason=str(e)[:300], failure_class="INTEGRITY")
        out = None
    fc = "NONE" if out else sr.get("failure_class") or "OTHER"
    if sr.get("mode") != "saved_result_replay" and sr["state"] != "STOPPED":
        v = (sr.get("capability") or {}).get("version") or step.get("version") or 0
        try:
            H.record(s, step["op"], v, contract["contract_id"], "OK" if out else "REFUSED" if sr["state"] == "REFUSED" else "FAILED",
                     int((time.monotonic() - t0) * 1000), O._counters(s)["model_calls"] - m0, fc)
        except ValueError:
            pass
    return out, fc


def _discovered(s, store_root, contract, step, files, sr, stop_path, left, rec, c0):
    """Run a discovered step; on a recoverable failure run it with the next-ranked alternative (bounded: MAX_FALLBACKS per goal, each inside the container
    budget, never after an integrity failure). Every attempt is kept in sr['attempts'] and every fallback in rec['fallbacks']."""
    tries, n = [step], 0
    while n < len(tries):
        st = tries[n]
        if n:
            if len(rec["fallbacks"]) >= MAX_FALLBACKS or left() <= 0 or O._counters(s)["container_runs"] - c0["container_runs"] >= contract["budget"]["container_runs"]:
                sr["reason"] = (sr.get("reason") or "") + "; fallback budget exhausted"
                return None
            sr.setdefault("attempts", []).append({k: sr.get(k) for k in ("op", "state", "reason", "failure_class", "capability")})
            rec["fallbacks"].append({"step_id": step["step_id"], "from": tries[n - 1]["op"], "to": st["op"], "reason": fc})
            sr.update(op=st["op"], state=None, verdict=None, reason=None, artifacts=[], mode=None, genome=st.get("genome"))
        out, fc = _attempt(s, store_root, contract, st, files, sr, stop_path, left)
        if out is not None:
            return out
        if fc == "INTEGRITY":
            rec["integrity_failure"] = {"step_id": step["step_id"], "op": st["op"], "reason": (sr.get("reason") or "")[:200]}
        if fc not in RECOVERABLE:
            return None
        if n == 0:  # alternatives are recomputed now from the admitted contracts (same inputs / arity / output type), never read from the stored ranking
            ok, _ = eligible_caps(s)
            tries += [_alt_step(step, a) for a in _collapse(s, ok).get(step["op"], []) if a["op"] != step["op"]]
        n += 1
    return None


def goal_artifact(store_root, ref):
    """Allowlisted lookup for output/goal/<goal_id>/<name> (a verified discovered-capability result of that goal)."""
    parts = ref.split("/") if isinstance(ref, str) else []
    if len(parts) != 4 or parts[:2] != ["output", "goal"]:
        return None
    s = Store(store_root)
    try:
        rec = s.get("operator/goal/" + parts[2]) or {}
    finally:
        s.close()
    return next((a for a in rec.get("deliverable") or [] if a.get("ref") == ref), None)


def _duplicate(s, ms):
    """T04: an admitted capability that already has the identical contract of the gap's minimal missing step, so acquiring another is pointless.
    run_goal only; an explicit 'improve' request skips this by not calling it (capability_registry.find_duplicate is its own call)."""
    from . import capability_registry as CR
    for c in CC.contracts_for_gap(ms[0]):
        d = CR.find_duplicate(s, contract_sha256=CC.sha(c))
        if d:
            return d
    return None


def _iface(c):
    return tuple(c["types"]), tuple(c["arity"]), c["out"]


def _revoked_iface(store, op):
    """Interface (types, arity, output type) of a discovered capability whose EVERY admitted version was revoked by a signed event; None for anything else
    (chain gone, signature / chain failure, still eligible): those are integrity problems, not a reason to substitute."""
    from . import capability_registry as CR
    if CR.head(store, op) is None:
        return None
    try:
        adm, _, cur = CR._state(store, op)
        if cur is not None or not adm:
            return None
        c = CC.normalize(adm[max(adm)][0])
        return tuple(c["inputs"]["types"]), tuple(c["inputs"]["arity"]), c["outputs"]["type"]
    except (Refused, KeyError, TypeError, ValueError):
        return None


def _step_from(ok, budget_s, raw, op, sid, inputs, dag, last, pin=None):
    """One plan step rebuilt from the admitted registry: only the identifiers (step id, op, input references and the version pins) come from the stored
    plan; kind, adapter, expected output, verifier, allowance, dependencies and report name are derived here. A stored timeout may only be lower."""
    c = ok[op]
    default = c.get("timeout_s", budget_s)
    t_s = raw.get("allowance", {}).get("timeout_s") if isinstance(raw.get("allowance"), dict) else None
    step = {"step_id": sid, "op": op, "kind": c["kind"], "capability": op, "inputs": list(inputs), "expected_output": c["out"], "verifier": c["verifier"],
            "allowance": {"container_runs": 1 if c["kind"] in ("registry", "discovered") else 0,
                          "timeout_s": t_s if isinstance(t_s, int) and not isinstance(t_s, bool) and 0 < t_s < default else default},
            "after": [r[5:] for r in inputs if r.startswith("step:")]}
    if dag:
        step["report_name"] = "report.json" if last else sid + ".report.json"
    if c["kind"] == "builtin_adapter":
        step["adapter"] = c["adapter"]
    elif c["kind"] == "discovered" and pin:
        step.update(genome=pin["statement_sha"], version=pin["version"], statement_sha=pin["statement_sha"])
    else:
        step.update(genome=raw.get("genome"))
        if c["kind"] == "discovered":
            step.update(version=raw.get("version"), statement_sha=raw.get("statement_sha"))
    return step


def _refresh_stored(store, contract, plan):
    """T11: a persisted plan, re-derived and re-checked now. Everything the run uses comes from the admitted contracts and the type table; the stored plan
    only names step ids, ops, input references and version pins, each checked here or by validate_plan. A step whose pinned capability had EVERY version
    revoked by a signed event takes the best-ranked eligible capability with exactly the same input types, arity and output type (at most MAX_FALLBACKS
    per goal); a tampered, damaged or missing chain is an integrity failure, never a substitution. Returns (plan, substitutions, integrity failures);
    raises Refused for a malformed plan."""
    ok, ex = eligible_caps(store)
    raw = plan.get("steps") if isinstance(plan, dict) else None
    if not isinstance(raw, list) or not raw or len(raw) > contract["budget"]["max_steps"] or not all(
            isinstance(x, dict) and isinstance(x.get("op"), str) and isinstance(x.get("step_id"), str) and STEP_ID.fullmatch(x["step_id"]) and isinstance(x.get("inputs"), list)
            and all(isinstance(r, str) for r in x["inputs"]) for x in raw):
        raise Refused("stored plan is malformed")
    budget_s, subs, bad, steps = O.load_policy()["container_timeout_s"], [], [], []
    uses = [r for x in raw for r in x["inputs"] if r.startswith("input:")]
    dag = len(set(uses)) < len(uses) or any("ins" in ok[x["op"]] for x in raw if x["op"] in ok)  # a fan-out / typed-slot plan, derived from the steps themselves
    for n, x in enumerate(raw):
        op, pin, last = x["op"], None, n == len(raw) - 1
        if op not in ok and op not in types()["capabilities"]:
            iface = _revoked_iface(store, op)
            if iface is None:
                bad.append({"step_id": x["step_id"], "op": op[:100], "reason": "pinned capability is missing, damaged or failed verification"})
            else:
                cands = [o for o, c in ok.items() if c["kind"] == "discovered" and o != op and _iface(c) == iface]
                if cands and len(subs) < MAX_FALLBACKS:
                    best = _collapse(store, {o: ok[o] for o in cands}).get(cands[0], [{"op": cands[0]}])[0]["op"]
                    subs.append({"step_id": x["step_id"], "from": op, "to": best, "reason": "UNAVAILABLE", "phase": "run-plan"})
                    op, pin = best, {"version": ok[best]["version"], "statement_sha": ok[best]["statement_sha"]}
        if op in ok:
            steps.append(_step_from(ok, budget_s, x, op, x["step_id"], x["inputs"], dag, last, pin))
        else:  # not eligible: validate_plan refuses the plan
            steps.append({"step_id": x["step_id"], "op": op, "inputs": list(x["inputs"])})
    out = {"schema": PLAN_SCHEMA, "steps": steps, "excluded": ex}
    if dag:
        runs = sum(x["allowance"]["container_runs"] for x in steps if "allowance" in x)
        out.update(dag=True, estimate={"steps": len(steps), "container_runs": runs, "worst_cpu_s": sum(_cost(ok[x["op"]], budget_s) for x in steps if x["op"] in ok),
                                       "worst_wall_s": sum(x["allowance"]["timeout_s"] for x in steps if "allowance" in x and x["allowance"]["container_runs"])})
    return out, subs, bad


def _check_stored_contract(contract, goal_id):
    """run-plan reads the contract from the store: re-apply the make_contract rules (the budget may only be lowered, the id is the hash of the content)."""
    T = types()
    core = {k: v for k, v in contract.items() if k not in ("contract_id", "created_at", "deadline")} if isinstance(contract, dict) else {}
    b, dflt = core.get("budget"), T["default_budget"]
    if (not core or contract.get("contract_id") != goal_id or not GOAL_ID.fullmatch(str(goal_id)) or goal_id != "g-" + _sha(_json(core))[:20]
            or core.get("schema") != CONTRACT_SCHEMA or core.get("deliverable") not in T["types"] or not isinstance(b, dict) or set(b) != set(dflt)
            or any(not isinstance(v, int) or isinstance(v, bool) or not 0 <= v <= dflt[k] for k, v in b.items())
            or not isinstance(core.get("inputs"), list) or not isinstance(core.get("permissions"), dict)):
        raise Refused("stored contract failed its re-check (id, budget or fields do not match)")


def plan_only(store_root, contract, sources):
    """T11: compute and persist a validated plan for a goal WITHOUT running it. run_plan(goal_id) runs it later. Nothing is acquired or queued."""
    s = Store(store_root)
    try:
        gid, key = contract["contract_id"], "operator/goal/" + contract["contract_id"]
        ref = s.put_artifact(contract)
        rec = {"goal_id": gid, "contract_ref": ref, "state": "PLANNING", "plan": None, "steps": [], "reason": None, "stages": [], "submitted_at": _now(),
               "pid": os.getpid(), "prior_attempts": [], "gap_ref": None, "replayed_steps": 0, "sources": list(sources), "fallbacks": []}
        plan = plan_goal(s, contract)
        problems = validate_plan(s, contract, plan) if plan["steps"] else [plan.get("limit") or "no typed plan from the eligible capabilities"]
        rec.update(plan=plan, state="UNRESOLVED" if problems else "PLANNED", reason="; ".join(problems)[:400] or None)
        O._stage(s, key, rec, "planned_only", steps=[x["op"] for x in plan["steps"]])
        return rec
    finally:
        s.close()


def run_plan(store_root, goal_id, allowed_root, *, stop_path=None):
    """T11: reload the persisted plan of a PLANNED goal and run it WITHOUT replanning (plan_goal is never called): every pinned version is re-checked,
    a revoked one takes its next-ranked alternative or the plan is refused, and the run must count 0 model calls."""
    s = Store(store_root)
    try:
        rec = s.get("operator/goal/" + str(goal_id))
        if not rec or not rec.get("plan") or rec.get("state") != "PLANNED":
            raise Refused(f"goal {str(goal_id)[:40]!r} has no stored plan waiting to run (state {rec and rec.get('state')})")
        contract, sources = s.read_artifact(rec["contract_ref"]), rec["sources"]
        _check_stored_contract(contract, str(goal_id))
    finally:
        s.close()
    inputs = load_inputs(allowed_root, sources)
    out = run_goal(store_root, contract, inputs, stop_path=stop_path, stored_plan=rec["plan"], sources=sources)
    out["stored_plan"] = dict(out.get("stored_plan") or {}, replanned=False, model_calls=(out.get("usage") or {}).get("model_calls", 0))
    return out


def run_goal(store_root, contract, inputs, *, stop_path=None, stored_plan=None, sources=None):
    """Persist contract, plan, execute. inputs = the same [(name, kind, bytes|path)] the contract was made from.
    stored_plan (run_plan only) = a persisted plan to re-validate and run instead of planning."""
    store_root = Path(store_root)
    stop_path = Path(stop_path or store_root / "STOP")
    gid, key = contract["contract_id"], "operator/goal/" + contract["contract_id"]
    for (name, kind, data), want in zip(inputs, contract["inputs"]):  # file bytes must be the ones the contract hashed
        if kind == "file" and _sha(data) != want["sha256"]:
            raise Refused(f"{name}: content differs from the contract")
    s = Store(store_root)
    try:
        saved = s.get(key)
        prior = [{k: saved.get(k) for k in ("state", "submitted_at", "reason")}] + saved.get("prior_attempts", [])[:9] if saved else []
        ref = s.put_artifact(contract)
        rec = {"goal_id": gid, "contract_ref": ref, "state": "PLANNING", "plan": None, "steps": [], "reason": None, "stages": [],
               "submitted_at": _now(), "pid": os.getpid(), "prior_attempts": prior, "gap_ref": None, "replayed_steps": 0, "fallbacks": []}
        if sources is not None:
            rec["sources"] = list(sources)
        O._stage(s, key, rec, "contract_persisted", contract_ref=ref)
        c0, t0 = O._counters(s), time.monotonic()
        deadline = t0 + contract["budget"]["wall_s"]  # one absolute deadline per goal; every phase is clamped to it
        left = lambda: deadline - time.monotonic()
        if stored_plan is not None:
            try:
                plan, subs, bad = _refresh_stored(s, contract, stored_plan)
                problems = (["integrity: " + bad[0]["reason"]] if bad else validate_plan(s, contract, plan))
            except Refused as e:
                plan, subs, bad, problems = {"schema": PLAN_SCHEMA, "steps": [], "excluded": []}, [], [], [str(e)]
            if bad:
                rec["integrity_failure"] = bad[0]
            rec["fallbacks"] += subs
            rec["stored_plan"] = {"replanned": False, "substitutions": len(subs)}
        else:
            plan = plan_goal(s, contract)
            problems = validate_plan(s, contract, plan) if plan["steps"] else [plan.get("limit") or "no typed plan from the eligible capabilities"]
        rec["plan"] = plan
        if problems and stored_plan is not None:  # a stored plan that no longer validates is refused, never replanned and never acquired for
            rec.update(state="PLAN_INVALID", reason="stored plan refused: " + "; ".join(problems)[:360], usage={"container_runs": 0, "model_calls": 0, "proposal_calls": 0},
                       completed_at=_now())
            O._stage(s, key, rec, "done", state=rec["state"])
            return rec
        if problems:
            ms = missing_step(s, contract)
            rec.update(state="UNRESOLVED", reason="; ".join(problems)[:400], gap_ref=record_gap(s, contract, plan, ms))
            if ms:
                rec["missing_step"], rec["partial_plan"] = ms
            dup = _duplicate(s, ms) if ms and (contract["permissions"].get("acquisition") or contract["permissions"].get("discovery")) else None
            if dup:  # T04: the identical contract is already admitted; reuse it, acquire nothing
                rec.update(state="DUPLICATE", duplicate=dup, reason=f"{dup['cap_id']} v{dup['version']} is already admitted with the identical contract; reused, nothing acquired")
            elif ms and contract["permissions"].get("acquisition"):  # G2: queue (never run inline) a bounded acquisition for a gap a contract declares
                from . import acquire as A
                try:
                    if left() <= 0:
                        raise Refused("no goal wall budget left")
                    rec.update(state="ACQUISITION_QUEUED", acquisition_run=A.open_run(s, rec["gap_ref"])["run_id"])
                except Refused as e:
                    rec["reason"] += f"; acquisition not opened: {str(e)[:120]}"
            elif ms and contract["permissions"].get("discovery"):
                from . import discovery as D
                try:
                    rec.update(state="DISCOVERY_QUEUED", experiment_id=D.open_experiment(s, rec["gap_ref"])["exp_id"])
                except Refused as e:
                    rec["reason"] += f"; discovery not opened: {str(e)[:120]}"
            O._stage(s, key, rec, "unresolved", reason=rec["reason"], gap=rec["gap_ref"])
            return rec
        b, est = contract["budget"], plan.get("estimate")
        if est and (est["container_runs"] > b["container_runs"] or est["worst_wall_s"] > b["wall_s"]):  # a DAG plan is costed before anything starts
            rec.update(state="BUDGET_EXHAUSTED", reason=f"estimated {est['container_runs']} container runs / {est['worst_wall_s']} s worst case exceeds the budget; nothing ran",
                       usage={"container_runs": 0, "model_calls": 0, "proposal_calls": 0}, completed_at=_now())
            O._stage(s, key, rec, "done", state=rec["state"])
            return rec
        rec["state"] = "RUNNING"
        O._stage(s, key, rec, "planned", steps=[x["op"] for x in plan["steps"]])
        vals = {}
        for i, step in enumerate(plan["steps"]):
            c = O._counters(s)
            if stop_path.exists():
                rec.update(state="STOPPED", reason="STOP is set; nothing further ran")
                break
            remaining = left()
            if i >= b["max_steps"] or remaining <= 0 or (step["kind"] in ("registry", "discovered") and c["container_runs"] - c0["container_runs"] >= b["container_runs"]):
                # ponytail: the container budget is checked before the step, so a would-be replay is also held back
                rec.update(state="BUDGET_EXHAUSTED", reason=f"budget exhausted before step {step['step_id']}")
                break
            sr = {"step_id": step["step_id"], "op": step["op"], "kind": step["kind"], "task_id": None, "mode": None,
                  "genome": step.get("genome"), "adapter": step.get("adapter"), "state": None, "verdict": None, "reason": None, "artifacts": []}
            rec["steps"].append(sr)
            O._stage(s, key, rec, "step_start", step=step["step_id"])
            out = None
            try:
                if step["kind"] == "builtin_adapter":
                    out = (_step_site_pack if step.get("adapter") == SITE_ADAPTER else _step_snapshot)(store_root, contract, inputs, step, sr)
                elif step["kind"] == "discovered":
                    files = [vals[r] if r.startswith("step:") else (inputs[int(r[6:])][0], inputs[int(r[6:])][2]) for r in step["inputs"]]
                    out = _discovered(s, store_root, contract, step, files, sr, stop_path, left, rec, c0)
                    rec["replayed_steps"] += sr["mode"] == "saved_result_replay"
                else:
                    files = []
                    for r in step["inputs"]:
                        files.append(vals[r] if r.startswith("step:") else (inputs[int(r[6:])][0], inputs[int(r[6:])][2]))
                    t = O.run_task(store_root, step["op"], files, stop_path=stop_path, timeout_cap=remaining, left=left)
                    sr.update(task_id=t["task_id"], mode=t["mode"], state=t["state"], verdict=(t.get("verification") or {}).get("verdict"),
                              reason=t.get("reason") or (t.get("summary") or {}).get("verdict"), artifacts=t.get("artifacts", []))
                    a = next((x for x in sr["artifacts"] if x["name"] != "report.json"), None)
                    if sr["state"] == STEP_OK and a:
                        data = O.contained(store_root / "output" / "operator" / t["task_id"], a["name"]).read_bytes()
                        if O._sha(data) != a["sha256"]:
                            raise Refused("registry artifact does not match its recorded hash")
                        out = (step["step_id"] + Path(a["name"]).suffix, data)
                    if t["mode"] == "saved_result_replay":
                        rec["replayed_steps"] += 1
            except (Refused, OSError, ValueError) as e:
                sr.update(state="REFUSED", reason=str(e)[:300])
            except Exception as e:  # never leave a RUNNING goal behind
                sr.update(state="ERROR", reason=f"{type(e).__name__}: {str(e)[:200]}")
            O._stage(s, key, rec, "step_done", step=step["step_id"], state=sr["state"])
            if sr["state"] != STEP_OK or out is None:
                last = i == len(plan["steps"]) - 1
                rec.update(state="STOPPED" if sr["state"] == "STOPPED" else "REJECTED" if sr["state"] == "REJECTED" and last else "STEP_FAILED",
                           reason=f"step {step['step_id']} ({sr['op']}): {sr['state']}" + (f" - {sr['reason']}" if sr["reason"] else ""))
                break
            vals["step:" + step["step_id"]] = out
        else:
            regs = [x for x in rec["steps"] if x["kind"] in ("registry", "discovered")]
            rec.update(state="VERIFIED", deliverable=rec["steps"][-1]["artifacts"],
                       mode="saved_result_replay" if regs and rec["replayed_steps"] == len(regs) else "executed")
        c1 = O._counters(s)
        rec["usage"] = {"container_runs": c1["container_runs"] - c0["container_runs"], "model_calls": c1["model_calls"] - c0["model_calls"],
                        "proposal_calls": c1["proposal_calls"] - c0["proposal_calls"]}
        if rec["usage"]["model_calls"] or rec["usage"]["proposal_calls"]:  # contract permits 0; never report success past it
            rec.update(state="POLICY_VIOLATION", reason="a model/proposal call was counted during a zero-model goal", deliverable=[])
        rec["completed_at"] = _now()
        O._stage(s, key, rec, "done", state=rec["state"])
        O._log(s, {"task_id": gid, "op": "goal", "mode": rec.get("mode") or "goal", "state": rec["state"], "reason": rec["reason"]})
        return rec
    finally:
        s.close()


def goals(store):
    """Latest 50 goal summaries for the console."""
    rows = [store.get(r["key"]) for r in store.db.execute("SELECT key FROM kv WHERE key LIKE 'operator/goal/%'").fetchall()]
    rows.sort(key=lambda g: g.get("submitted_at", ""), reverse=True)
    out = []
    for g in rows[:50]:
        exp = store.get("operator/discovery/" + g["experiment_id"]) if g.get("experiment_id") else None
        try:
            c = store.read_artifact(g["contract_ref"])
        except (OSError, ValueError, KeyError):
            c = {}
        out.append({"goal_id": g["goal_id"], "state": g["state"], "goal_text": c.get("goal_text"), "deliverable": c.get("deliverable"),
                    "inputs": [i["name"] for i in c.get("inputs", [])], "plan": [x["op"] + "(" + ",".join(x["inputs"]) + ")" for x in (g.get("plan") or {}).get("steps", [])],
                    "excluded": (g.get("plan") or {}).get("excluded", []), "steps": g.get("steps", []), "reason": g.get("reason"),
                    "gap_ref": g.get("gap_ref"), "missing_step": g.get("missing_step"), "partial_plan": g.get("partial_plan"),
                    "experiment_id": g.get("experiment_id"), "experiment_state": exp and exp["state"], "mode": g.get("mode"), "replayed_steps": g.get("replayed_steps"),
                    "deliverable_artifacts": g.get("deliverable", []), "usage": g.get("usage"), "contract_ref": g["contract_ref"]})
    return out
