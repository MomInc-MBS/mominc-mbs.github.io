"""Operator views and lifecycle commands for capabilities: list, history, acquisition status, goal receipt, revoke/rollback (signed), improve, overview.

Every function reads (or, for revoke/rollback/improve, asks the signed admission authority); none of them signs, edits a chain, or reaches a model
except `improve`. The CLI prints `render(...)` unless --json. Generic: no task or capability identifiers."""
from __future__ import annotations

import importlib
import sys
from datetime import datetime

from . import acquire as A
from . import capability_registry as CR
from . import discovery as D
from . import operator_runtime as O
from .operator_runtime import Refused
from .storage import Store


def _admission():
    """scripts/hive_admission.py: the only signer. Loaded by path so the CLI never carries a second signing code path."""
    sp = str(O.ROOT / "scripts")
    if not (O.ROOT / "scripts" / "hive_admission.py").is_file():
        raise Refused("scripts/hive_admission.py (the admission authority) is not available in this install")
    if sp not in sys.path:
        sys.path.append(sp)
    return importlib.import_module("hive_admission")


def _open(root, fn):
    s = Store(root)
    try:
        return fn(s)
    finally:
        s.close()


def _admit_events(s):
    """{exp_id: 'admitted'|'rejected'} from every capability chain (the chain, not the experiment record, says what happened to a candidate)."""
    out = {}
    for cid in CR.cap_ids(s):
        try:
            for e in CR.history(s, cid):
                if e["type"] in ("admit", "rejected") and e.get("exp_id"):
                    out[e["exp_id"]] = "admitted" if e["type"] == "admit" else out.get(e["exp_id"], "rejected")
        except Refused:
            continue
    return out


# ---------------------------------------------------------------- list / history
def _provenance(st):
    bits = [f"operator-authored by {st.get('author')}" if st.get("route") == "operator-authored" else f"model {(st.get('lineage') or {}).get('proposer_model')}"]
    acq = st.get("acquisition") or {}
    if isinstance(acq, dict) and acq.get("repo"):
        bits.append(f"repo {acq['repo']}@{str(acq.get('revision') or '')[:10]}")
    if st.get("improvement"):
        bits.append(f"improves v{st['improvement']['base_version']}")
    return "; ".join(bits)


def capabilities(store_root):
    def go(s):
        rows = []
        try:
            m2 = O.status(store_root)["capabilities"]
        except (Refused, OSError, KeyError):
            m2 = {}
        for op, c in sorted(m2.items()):
            imp = next((e for e in c.get("history", []) if e.get("type") == "import"), {})
            acc = c.get("accepted") if isinstance(c.get("accepted"), dict) else {}
            rows.append({"id": op, "kind": "m2", "version": (c.get("genome") or "")[:12] or None, "lifecycle": "active" if c.get("eligible") else "inactive",
                         "provenance": f"retained workflow, selected by {c.get('selected_by')}" if c.get("eligible") else str(c.get("reason"))[:120],
                         "receipt": (acc.get("receipt_sha") or "")[:12] or None, "admitted_at": imp.get("at")})
        for cid in CR.cap_ids(s):
            try:
                adm, revoked, cur = CR._state(s, cid)
            except Refused as e:
                rows.append({"id": cid, "kind": "discovered", "version": None, "lifecycle": "invalid", "route": None, "provenance": str(e)[:160], "receipt": None, "admitted_at": None})
                continue
            for v, (st, _) in sorted(adm.items()):
                rows.append({"id": cid, "kind": "discovered", "version": v, "lifecycle": "revoked" if v in revoked else "active" if v == cur else "superseded",
                             "route": st.get("route", "learned"), "provenance": _provenance(st), "receipt": st["evaluation"]["receipt_sha256"][:12], "admitted_at": st.get("admitted_at")})
        seen = _admit_events(s)
        for e in D.experiments(s):
            if e["state"] == "CANDIDATE_PASSED" and e["exp_id"] not in seen:
                try:
                    cid = D.contract_of(e)["capability_id"]
                except Refused:
                    continue
                rows.append({"id": cid, "kind": "discovered", "version": None, "lifecycle": "candidate", "route": "operator-authored" if e["frozen"].get("authored") else "learned", "provenance": f"experiment {e['exp_id']}, awaiting signed admission",
                             "receipt": ((e.get("receipt") or {}).get("receipt_sha256") or "")[:12] or None, "admitted_at": None})
        return rows
    return _open(store_root, go)


def history(store_root, cap_id):
    def go(s):
        if CR.head(s, cap_id) is None:
            raise Refused(f"{cap_id}: no chain")
        try:
            CR._state(s, cap_id)  # verifies every signature and the hash links
            ok, why = True, None
        except Refused as e:
            ok, why = False, str(e)
        ev = []
        for n, e in enumerate(CR.history(s, cap_id)):
            sp = e.get("signed") or {}
            row = {"n": n, "type": e["type"], "at": e.get("at"), "exp_id": e.get("exp_id"), "reason": e.get("reason") or sp.get("reason"), "ref": e["ref"][:16]}
            if e["type"] == "admit":
                st = s.read_artifact(e["statement_ref"])
                row.update(version=st["version"], statement_sha=e["statement_sha"][:16], impl_sha256=st["impl_sha256"][:16], signed=True)
            elif e["type"] in ("revoke", "rollback"):
                row.update(version=sp.get("version"), from_version=sp.get("from_version"), to_version=sp.get("to_version"), signed=True)
            else:
                row["signed"] = False
            ev.append(row)
        return {"cap_id": cap_id, "chain_ok": ok, "chain_problem": why, "events": ev}
    return _open(store_root, go)


# ---------------------------------------------------------------- acquisition
_RUN_PHASE = {"SEARCH": "discovered", "INSPECT": "inspected", "SELECT": "inspected", "STAGE": "acquired", "ADAPT": "acquired", "VERIFY": "acquired",
              "ADMIT": "acquired", "AWAITING_ADMISSION": "acquired", "EXECUTE": "admitted", "RECORD_OUTCOME": "admitted", "DONE": "admitted"}


def acquisitions(store_root):
    def go(s):
        seen = _admit_events(s)
        runs = []
        for r in A.runs(s):
            phase = _RUN_PHASE.get(r["state"], "rejected" if r["state"] in A.TERMINAL else "discovered")
            runs.append({"run_id": r["run_id"], "gap": r["gap_key"][-16:], "state": r["state"], "phase": phase, "attempts": len(r["attempts"]), "reason": r.get("reason"),
                         "ledger": {k: r["ledger"].get(k) for k in ("attempts", "model_calls", "container_runs", "wall_s")}})
        exps = []
        for e in D.experiments(s):
            ph = seen.get(e["exp_id"]) or ("acquired" if e["state"] == "CANDIDATE_PASSED" else
                                           "rejected" if e["state"] in ("NO_QUALIFYING_CANDIDATE", "BUDGET_EXHAUSTED", "MODEL_UNAVAILABLE", "STOPPED") else "discovered")
            exps.append({"exp_id": e["exp_id"], "gap": e["gap_key"][-16:], "state": e["state"], "phase": ph, "kind": "improve" if e["frozen"].get("improve") else "authored" if e["frozen"].get("authored") else "discovery",
                         "route": "operator-authored" if e["frozen"].get("authored") else "learned",
                         "reason": e.get("reason"), "calls": e["ledger"]["calls"], "container_runs": e["ledger"]["container_runs"]})
        return {"runs": runs, "experiments": exps}
    return _open(store_root, go)


# ---------------------------------------------------------------- goal receipt
def _secs(a, b):
    try:
        return round((datetime.fromisoformat(b) - datetime.fromisoformat(a)).total_seconds(), 1)
    except (TypeError, ValueError):
        return None


def _route(s, cap_id, version):
    try:
        return CR._state(s, cap_id)[0][version][0].get("route", "learned")
    except (Refused, KeyError, TypeError):
        return None


def goal_receipt(store_root, goal_id):
    def go(s):
        keys = [r["key"] for r in s.db.execute("SELECT key FROM kv WHERE key LIKE ?", ("operator/goal/" + goal_id + "%",)).fetchall()]
        if len(keys) != 1:
            raise Refused(f"goal {goal_id!r}: " + ("no match" if not keys else "ambiguous prefix"))
        g = s.get(keys[0])
        try:
            c = s.read_artifact(g["contract_ref"])
        except (OSError, ValueError, KeyError):
            c = {}
        steps = [{"step_id": x["step_id"], "op": x["op"], "kind": x["kind"], "state": x["state"], "verdict": x.get("verdict"), "mode": x.get("mode"),
                  "version": (x.get("capability") or {}).get("version"), "artifacts": [a.get("name") for a in x.get("artifacts", [])]} for x in g.get("steps", [])]
        u = g.get("usage") or {}
        return {"goal_id": g["goal_id"], "goal_text": c.get("goal_text"), "state": g["state"], "reason": g.get("reason"), "plan": [x["op"] + "(" + ",".join(x["inputs"]) + ")" for x in (g.get("plan") or {}).get("steps", [])],
                "versions_used": {x["op"]: x["version"] for x in steps if x["version"] is not None}, "operator_authored": sorted({x["op"] for x in steps if _route(s, x["op"], x["version"]) == "operator-authored"}), "steps": steps, "verdict": g["state"],
                "model_calls": u.get("model_calls"), "proposal_calls": u.get("proposal_calls"), "container_runs": u.get("container_runs"),
                "elapsed_s": _secs(g.get("submitted_at"), g.get("completed_at")), "artifacts": [a.get("name") for a in g.get("deliverable", []) or []]}
    return _open(store_root, go)


# ---------------------------------------------------------------- signed lifecycle (the authority does the signing)
def revoke(store_root, cap_id, reason, version=None, key=None, *, global_scope=False):
    H = _admission()
    if version is None:
        version = _open(store_root, lambda s: CR.resolve_discovered(s, cap_id)["version"])
    return H.revoke(store_root, cap_id, version, reason, key, global_scope=global_scope)


def rollback(store_root, cap_id, key=None):
    return _admission().rollback(store_root, cap_id, key)


def improve(store_root, cap_id, objective, key=None, **kw):
    H = _admission()
    return A.improve(store_root, cap_id, objective, admit=lambda root, exp: H.admit(root, exp, key), **kw)


def author(store_root, cap_id, body_file, author, key=None):
    """Operator-authored route: the human-written body goes through the same experiment/evaluator/receipt gates as a proposed one (0 model calls), then
    the existing signed admission. Refused with the gate's reason (evidence kept on the experiment) when any gate fails."""
    H = _admission()
    body = D._read_lf(body_file)
    s = Store(store_root)
    try:
        exp = D.open_authored(s, cap_id, author, body)["exp_id"]
    finally:
        s.close()
    rec = D.run_experiment(store_root, exp)
    if rec["state"] != "CANDIDATE_PASSED":
        raise Refused(f"authored body refused ({rec['state']}): {rec.get('reason')}; experiment {exp}")
    return H.admit(store_root, exp, key)


def parse_objective(text):
    """'failure_class:wrong_output' -> the objective dict (validated again by the improve path; there is no latency objective)."""
    kind, _, val = str(text).partition(":")
    return {"kind": kind, "value": val}


# ---------------------------------------------------------------- overview
def overview(store_root):
    def go(s):
        rows = [r for r in capabilities(store_root) if r["kind"] == "discovered" or r["lifecycle"] == "active"]
        counts, authored = {}, {}  # operator-authored versions are counted apart: never as learned
        for r in rows:
            d = authored if r.get("route") == "operator-authored" else counts
            d[r["lifecycle"]] = d.get(r["lifecycle"], 0) + 1
        goals = [s.get(r["key"]) for r in s.db.execute("SELECT key FROM kv WHERE key LIKE 'operator/goal/%'").fetchall()]
        goals.sort(key=lambda g: g.get("submitted_at", ""), reverse=True)
        return {"store": str(store_root), "capabilities": counts, "operator_authored": authored, "goals": len(goals),
                "last_goals": [{"goal_id": g["goal_id"], "state": g["state"], "at": g.get("submitted_at")} for g in goals[:3]],
                "last_acquisitions": [{"run_id": r["run_id"], "state": r["state"]} for r in A.runs(s)[-3:]],
                "last_experiments": [{"exp_id": e["exp_id"], "state": e["state"]} for e in D.experiments(s)[-3:]],
                "ledger": {"counters": O._counters(s), "discovery": s.get(D.LEDGER)}}
    return _open(store_root, go)


# ---------------------------------------------------------------- human views
def _table(rows, cols):
    if not rows:
        return "(none)"
    w = [max(len(c), *(len(str(r.get(c) if r.get(c) is not None else "-")) for r in rows)) for c in cols]
    line = lambda v: "  ".join(str(x).ljust(n) for x, n in zip(v, w)).rstrip()
    return "\n".join([line(cols)] + [line([r.get(c) if r.get(c) is not None else "-" for c in cols]) for r in rows])


def render(kind, d):
    if kind == "list":
        return _table(d, ["id", "kind", "route", "version", "lifecycle", "receipt", "admitted_at", "provenance"])
    if kind == "show":
        head = f"{d['cap_id']}: chain {'OK' if d['chain_ok'] else 'BROKEN - ' + str(d['chain_problem'])}"
        return head + "\n" + _table(d["events"], ["n", "type", "version", "from_version", "to_version", "signed", "at", "exp_id", "reason"])
    if kind == "acquisitions":
        return "runs\n" + _table(d["runs"], ["run_id", "state", "phase", "attempts", "gap"]) + "\nexperiments\n" + _table(d["experiments"], ["exp_id", "kind", "route", "state", "phase", "calls", "gap"])
    if kind == "receipt":
        return (f"goal {d['goal_id']}  {d['state']}  {d['elapsed_s']}s  model_calls={d['model_calls']} proposal_calls={d['proposal_calls']} container_runs={d['container_runs']}\n"
                f"text: {d['goal_text']}\noperator-authored steps: {', '.join(d['operator_authored']) or '-'}\nplan: {' -> '.join(d['plan']) or '-'}\nversions used: {d['versions_used'] or '-'}\nreason: {d['reason'] or '-'}\n"
                + _table(d["steps"], ["step_id", "op", "kind", "state", "verdict", "mode", "version"]) + f"\nartifacts: {', '.join(d['artifacts']) or '-'}")
    if kind == "overview":
        c = ", ".join(f"{k}={v}" for k, v in sorted(d["capabilities"].items())) or "none"
        ct, dl = d["ledger"]["counters"], d["ledger"]["discovery"] or {}
        au = ", ".join(f"{k}={v}" for k, v in sorted(d.get("operator_authored", {}).items())) or "none"
        return (f"store {d['store']}\ncapabilities: {c} (learned/other)\noperator-authored: {au}\ngoals: {d['goals']}  last: " + (", ".join(f"{g['goal_id'][:12]}:{g['state']}" for g in d["last_goals"]) or "-")
                + f"\nacquisition runs: " + (", ".join(f"{r['run_id'][:10]}:{r['state']}" for r in d["last_acquisitions"]) or "-")
                + f"\nexperiments: " + (", ".join(f"{e['exp_id'][:10]}:{e['state']}" for e in d["last_experiments"]) or "-")
                + f"\nledger: executions={ct.get('executions')} container_runs={ct.get('container_runs')} model_calls={ct.get('model_calls')} proposal_calls={ct.get('proposal_calls')}"
                + f" | discovery calls={dl.get('calls', 0)} proposals={dl.get('proposals', 0)} container_runs={dl.get('container_runs', 0)}")
    if kind == "event":
        return " ".join(f"{k}={v}" for k, v in d.items() if k != "event_ref") + (f"\nevent {str(d.get('event_ref'))[:16]}" if d.get("event_ref") else "")
    return str(d)
