"""Opt-in proposer model choice from measured outcomes (docs/GAP_MODEL_CHOICE.md). Pure over (config, evidence); never changes a default route,
approval, cap or the spend gate. Evidence = build/coop/model_choice_evidence_v1.json (scripts/model_evidence.py): numbers and enums only."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

from . import m2_model as M
from . import model_dispatch as MD

EVIDENCE = Path(__file__).resolve().parents[2] / "build" / "coop" / "model_choice_evidence_v1.json"
USD_BASIS = ("local_zero", "probe_per_call_estimate", "unknown")
_ID = re.compile(r"^[A-Za-z0-9._/-]{1,100}$")
_NUM = ("campaigns", "sealed_pass", "calls", "wall_s", "out_tokens")
_NAMES = ("pass_rate", "calls_per_pass", "wall_per_pass", "usd_per_pass", "tie_local_first")


def _num(x): return isinstance(x, (int, float)) and not isinstance(x, bool) and x >= 0


def check_evidence(ev):
    """Raises ValueError unless every row is ids + non-negative numbers + a usd number-or-null + a basis enum (no free text rides along)."""
    if not (isinstance(ev, dict) and ev.get("schema") == "hive-model-choice-evidence-v1" and isinstance(ev.get("rows"), list)):
        raise ValueError("evidence: bad schema")
    for r in ev["rows"]:
        if not (isinstance(r, dict) and set(r) == {"capability", "backend", "usd", "usd_basis", *_NUM}):
            raise ValueError("evidence: row fields")
        if not (_ID.match(str(r["capability"])) and _ID.match(str(r["backend"])) and all(_num(r[k]) for k in _NUM)
                and (r["usd"] is None or _num(r["usd"])) and r["usd_basis"] in USD_BASIS and r["sealed_pass"] <= r["campaigns"]):
            raise ValueError("evidence: row values")
    return ev


def load_evidence(path=None):
    """(evidence, sha256 of the file); (empty evidence, None) when the file is absent. A present but malformed file raises."""
    p = Path(path or EVIDENCE)
    if not p.is_file(): return {"schema": "hive-model-choice-evidence-v1", "rows": []}, None
    raw = p.read_bytes()
    return check_evidence(json.loads(raw.decode("utf-8"))), hashlib.sha256(raw).hexdigest()


def eligible(cfg=None, rejected=None):
    """[{"id", "hosted"}] in ladder order (default first): MD-qualified (measured + evidence) AND the backend's approval passes M.approval_problems.
    `rejected` (a list, optional) receives [{"backend", "reason"}] for each filtered-out backend: not_qualified | approval_refused | unknown_pins."""
    from . import discovery as D  # late: discovery imports this package's m2_model/model_dispatch at load
    cfg = MD.load(cfg)
    ok = {m for m, e in cfg["qualified"].items() if isinstance(e, dict) and e.get("measured") is True and e.get("evidence")}
    out = []
    for b in M.list_backends(cfg):
        if b not in ok:
            if rejected is not None: rejected.append({"backend": b, "reason": "not_qualified"})
            continue
        try:
            if not M.approval_problems(None, M.apply_backend(D.pol(), b, cfg)): out.append({"id": b, "hosted": M.is_hosted(b, cfg)})
            elif rejected is not None: rejected.append({"backend": b, "reason": "approval_refused"})
        except Exception:  # unknown/incomplete pins or a refused endpoint: not eligible
            if rejected is not None: rejected.append({"backend": b, "reason": "unknown_pins"})
    return out


def _key(r, hosted):
    inf, p = float("inf"), r["sealed_pass"]
    usd = r["usd"] / p if p and r["usd"] is not None else None
    return (-p / r["campaigns"] if r["campaigns"] else 0, r["calls"] / p if p else inf, r["wall_s"] / p if p else inf, (usd is None, usd or 0.0), hosted)


def rank(evidence, cap, elig):
    """Ordered [{"backend", "reason"}] for `cap` over `elig` ([{"id","hosted"}]). Reason enum = the criterion that placed it above the next entry
    (last: "last_ranked"; sole: "only_eligible"; no evidence at all: "no_evidence_default_ladder"; a backend with no row among evidenced ones: "no_evidence_for_backend")."""
    rows = {r["backend"]: r for r in check_evidence(evidence)["rows"] if r["capability"] == cap}
    ladder = sorted(elig, key=lambda e: e["hosted"])  # stable: local before hosted, config order inside each
    if not any(e["id"] in rows for e in elig):
        return [{"backend": e["id"], "reason": "no_evidence_default_ladder"} for e in ladder]
    seen = sorted((e for e in elig if e["id"] in rows), key=lambda e: _key(rows[e["id"]], e["hosted"]))
    keys = [_key(rows[e["id"]], e["hosted"]) for e in seen]
    out = [{"backend": e["id"], "reason": "only_eligible" if len(elig) == 1 else "last_ranked" if i == len(seen) - 1 else
            _NAMES[next(j for j in range(5) if keys[i][j] != keys[i + 1][j])]} for i, e in enumerate(seen)]
    rest = [e for e in ladder if e["id"] not in rows]
    if rest: out[-1]["reason"] = "evidence_beats_none"
    return out + [{"backend": e["id"], "reason": "no_evidence_for_backend"} for e in rest]


POLICY_VERSION = "model-route-v1"


def choose(cap, evidence=None, cfg=None, elig=None, store_id=None):
    """{"policy_version", "backend", "reason", "rank", "rejected", "evidence_sha256", "store_id"}; backend None when nothing is eligible (the caller ends MODEL_UNAVAILABLE).
    `rejected` = backends eligible() filtered out, with reason codes (only known when eligibility is computed here, else [])."""
    ev, h = (evidence, None) if evidence is not None else load_evidence()
    rej = []
    rk = rank(ev, cap, eligible(cfg, rej) if elig is None else elig)
    return {"policy_version": POLICY_VERSION, "backend": rk[0]["backend"] if rk else None, "reason": rk[0]["reason"] if rk else "no_eligible_backend", "rank": rk,
            "rejected": rej, "evidence_sha256": h, "store_id": store_id}


# --- bounded fallback: classify how a proposer experiment ended (strings produced by discovery.run_experiment's _End) --------------------------------
_RETRY_EXC = ("ConnectionError", "ConnectionRefusedError", "ConnectionResetError", "URLError", "TimeoutError", "OSError", "timeout", "RemoteDisconnected")
_STOP_TEXT = ("weight", "sha", "integrity", "loopback", "endpoint refused", "unexpected model id in response")


def classify(state, reason):
    """(class, code): class is "retryable" | "stop". Retryable only for MODEL_UNAVAILABLE caused by transport / endpoint unreachable / model not loaded or not listed /
    context does not fit. Everything else, anything unknown, and every refusal (approval, data policy, budget) or identity/integrity failure is "stop" (fail closed)."""
    r = str(reason or "")
    if state != "MODEL_UNAVAILABLE": return "stop", str(state or "unknown").lower()
    if "reply verification failed" in r: return "stop", "reply_verification_failed"
    if "transport_failure" in r: return "retryable", "transport_failure"
    if "CONTEXT_DOES_NOT_FIT" in r: return "retryable", "context_does_not_fit"
    if r.endswith("NO_EXECUTABLE_MODEL"): return "retryable", "no_executable_model"
    m = re.search(r"MODEL_NOT_LOADED: (\w+): ?(.*)", r)
    if not m: return "stop", "unknown"
    exc, msg = m.groups()
    if "Refused" in exc or "Refused" in msg or any(x in msg.lower() for x in _STOP_TEXT): return "stop", "refused_or_integrity"
    if exc in _RETRY_EXC or "not loaded" in msg or "unexpected model ids" in msg: return "retryable", "model_not_loaded"
    return "stop", "unknown"


def classify_failure(state, reason): return classify(state, reason)[0]


def frozen_route(store_root, exp_id):
    """The backend frozen in that experiment's `model_choice` (auto-routed), else None = today's incumbent (legacy experiments are unchanged)."""
    from . import discovery as D
    from .storage import Store
    s = Store(store_root)
    try:
        rec = s.get(D.KEY + exp_id) or {}
    finally:
        s.close()
    return ((rec.get("frozen") or {}).get("model_choice") or {}).get("backend")
