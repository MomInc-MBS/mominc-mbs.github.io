"""G2 proposer side: everything the model may see, and the only thing it may hand back. No kernel authority lives here.

The model receives a contract-derived behaviour spec, public dev cases and a bounded, fenced excerpt of the selected repository card
(untrusted data). It returns text; `adapter_bytes` turns that into candidate source bytes or nothing. It never sees hidden fixtures, keys,
permissions, admission policy or evaluator paths, and nothing it returns selects any kernel input. Stdlib only."""
from __future__ import annotations

import re

from . import acq_card as AC
from . import acq_github as AG

MAX_PROMPT_TOKENS = 8000
MAX_EXCERPT_TOKENS = 750  # ~3,000 characters of repository data
_FENCE = re.compile(r"```(?:python|py)?[ \t]*\n(.*?)```", re.S)


def tokens(text):
    return len(text) // 4 + 1


def card_excerpt(card, max_tokens=MAX_EXCERPT_TOKENS):
    """The fenced untrusted excerpt, hard-capped (the card's own excerpt is already control-stripped and fence-neutralised)."""
    return AC.excerpt(card, max_chars=max_tokens * 4)


def staged_text(card, env, stdlib):
    """What is installed for this attempt, from the lock (distribution==version, import names, the vendored tool modules) plus the fenced card
    excerpt with the tool's public signatures. States that nothing else can be imported."""
    from . import acq_card as _AC
    dists = ", ".join(f"{_AC.clean(w.get('name'), 60)}=={_AC.clean(w.get('version'), 30)}" for w in env.get("wheelhouse", []) if isinstance(w, dict)) or "none besides the tool"
    names = ", ".join(_AC.clean(n, 60) for n in env.get("packages", []))
    tool = ", ".join(_AC.clean(n, 60) for n in env.get("tool_modules", []))
    head = (f"AVAILABLE IN THE RUN (nothing else can be imported or used): standard-library modules: {', '.join(stdlib)}. Installed distributions (exact versions): {dists}. "
            f"Importable top-level names: {names}. Vendored tool module(s) your adapter MUST import and call: {tool or 'none'}. "
            "Only use APIs that exist in these exact versions; do not reimplement the tool.")
    return head + "\n" + card_excerpt(card)


def prompt_problems(messages, limit=MAX_PROMPT_TOKENS):
    """Why a prompt may not be sent (empty = ok): estimated input tokens over the limit."""
    n = sum(tokens(m["content"]) for m in messages)
    return [f"prompt is about {n} input tokens (limit {limit})"] if n > limit else []


def adapter_bytes(content):
    """Candidate source from a model reply as UTF-8 bytes, or None. The last fenced block that defines run wins; a bare reply is accepted only
    when it has no fences at all. Nothing here executes or imports anything."""
    text = content or ""
    blocks = _FENCE.findall(text)
    body = next((b for b in reversed(blocks) if "def run" in b), None)
    if body is None and "```" not in text and "def run" in text:
        body = text
    return (body.strip("\n") + "\n").encode("utf-8") if body else None


def query_messages(view):
    """Ask the model for up to 3 short search queries. It sees only the contract purpose, behaviour spec and input/output types (view =
    {purpose, behaviour_spec, inputs, output, media_type}); never fixtures, keys, permissions, policy or any card. Read only via parse_queries."""
    user = (f"Purpose: {view['purpose'][:600]}\nInput types: {', '.join(view['inputs'])[:200]}\nOutput type: {view['output'][:100]} ({view['media_type'][:60]})\n"
            f"Behaviour:\n{view['behaviour_spec'][:6000]}")
    return [{"role": "system", "content": "Reply with at most 3 lines, each a GitHub repository search query of 2 to 6 plain words for an existing open-source "
                                          "Python library that could do this. No other text."},
            {"role": "user", "content": user}]


def parse_queries(content):
    """Validated queries (the same rule as acq_github.valid_query) from a model reply; anything else is dropped."""
    out = []
    for line in (content or "").splitlines()[:10]:
        q = re.sub(r"^[\s\-*0-9.)]+", "", line).strip().strip('"`')
        if AG.valid_query(q) and q not in out:
            out.append(q)
    return out[:3]
