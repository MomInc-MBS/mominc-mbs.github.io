"""G2 staging runner (trusted kernel): turns one admissible repository card into a pinned, derived Docker image.

1 vendor   copy the importable package from the pinned revision (text only, size-capped, never built: no setup.py/backend runs)
2 download wheels-only dependency closure in a throwaway container (the ONLY step with network; no secrets, one writable mount)
3 scan     every wheel: no .pth, no traversal, licence from its METADATA in the allowlist, size caps; hash -> trusted lock
4 build    runner-generated Dockerfile, `docker build --network=none`, `pip install --no-index --no-deps --require-hashes`
5 record   image ID, `docker save` tar + sha256 (`ensure` reloads the exact ID from the tar, never rebuilds), offline non-root smoke
Every container and image the runner creates is named with this Stager's unique prefix, so cleanup and leak checks can be exact.
Nothing here names a task. Stdlib only; docker and pip are only ever run through argv lists."""
from __future__ import annotations

import hashlib
import io
import json
import os
import re
import secrets
import shutil
import sys
import tempfile
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

from .bounded import run_bounded
from .repo_intel import ContentCache, RepoIntelError, RepoTreeIndex, SelectiveFetcher

NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
SPEC = re.compile(r"^[<>=!~][A-Za-z0-9.*,<>=!~+]{0,40}$")
SITE = "/usr/local/lib/python3.11/site-packages"
LIC_MAP = {"mit license": "MIT", "mit": "MIT", "apache software license": "Apache-2.0", "apache-2.0": "Apache-2.0", "apache 2.0": "Apache-2.0",
           "isc license (iscl)": "ISC", "isc": "ISC", "bsd license": "BSD-3-Clause", "bsd-3-clause": "BSD-3-Clause", "bsd-2-clause": "BSD-2-Clause",
           "python software foundation license": "PSF-2.0", "psf-2.0": "PSF-2.0", "historical permission notice and disclaimer (hpnd)": "HPND",
           "hpnd": "HPND", "mit-cmu": "MIT-CMU"}
NO_BINARY = ("no matching distribution", "could not find a version", "no binary", "only-binary")


STARTUP_MODULES = ("sitecustomize", "usercustomize")
SCRIPT_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
SCRATCH = ".hive-tmp"  # pip's temp/home inside the download mount (the 64 MB tmpfs is too small for big wheels); counted by the cap, removed after
_LIC_TOKEN = re.compile(r"\s+(?:AND|OR)\s+|[()]", re.I)


def license_of(h):
    """Comma-joined SPDX ids of a wheel's declared licence, or None when it cannot be mapped. License-Expression alone decides when present
    (every operand must map; WITH exceptions do not); otherwise EVERY License:: classifier must map, and a licence field that maps or names
    a copyleft/proprietary licence must agree."""
    ex = (h.get("license-expression") or [""])[0].strip()
    if ex:
        toks = [t.strip() for t in _LIC_TOKEN.split(ex) if t.strip()]
        ids = [LIC_MAP.get(t.lower()) for t in toks]
        return ",".join(sorted(set(ids))) if toks and all(ids) else None
    cl = [c.split("::")[-1].strip() for c in h.get("classifier", []) if c.startswith("License ::")]
    ids = [LIC_MAP.get(c.lower()) for c in cl]
    field = (h.get("license") or [""])[0].strip()
    if field and re.search(r"gpl|proprietary|commercial|copyleft", field, re.I):
        return None
    if field and field.lower() in LIC_MAP:
        ids.append(LIC_MAP[field.lower()])
    elif not cl:
        return None
    return ",".join(sorted(set(ids))) if ids and all(ids) else None


class StageRejected(RuntimeError):
    """A candidate that cannot be staged: `code` is the stable rejection reason recorded against the attempt."""

    def __init__(self, code, detail=""):
        super().__init__(f"{code}: {detail}"[:300])
        self.code = code


def tree_size(path):
    """Total bytes under a directory, ignoring anything that vanishes while we walk (pip creates and deletes temp files constantly)."""
    total, stack = 0, [str(path)]
    while stack:
        try:
            with os.scandir(stack.pop()) as it:
                for e in it:
                    try:
                        if e.is_dir(follow_symlinks=False):
                            stack.append(e.path)
                        elif e.is_file(follow_symlinks=False):
                            total += e.stat(follow_symlinks=False).st_size
                    except OSError:
                        continue
        except OSError:
            continue
    return total


def safe_packages(names):
    """Top-level import names a candidate may be given: identifiers only, never a standard-library name (or one differing only by case),
    never a start-up hook. Repo/wheel content therefore cannot widen the import list to ctypes, importlib, builtins, shutil, ..."""
    std = {n.lower() for n in sys.stdlib_module_names}
    return sorted(m for m in names if m.isidentifier() and m.lower() not in std and m.lower() not in STARTUP_MODULES)


def _sha(b): return hashlib.sha256(b if isinstance(b, bytes) else b.encode("utf-8")).hexdigest()


def _w(path, data):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_bytes(data)


# ---------------------------------------------------------------- 1 vendor
def vendor_tree(repo_path, sha, package_dir, policy, cache_dir):
    """{relative path: bytes} of the package directory at the pinned revision plus the tree sha256 (over `path\\0sha256\\n` lines)."""
    L, pkg = policy["limits"], package_dir.strip("/")
    entries = [e for e in RepoTreeIndex(repo_path, sha).list(pkg + "/") if e.path.endswith(".py") or e.path.endswith((".txt", ".json", ".md", ".cfg"))]
    if not entries or sum(max(e.size, 0) for e in entries) > L["max_tree_bytes"]:
        raise StageRejected("VENDOR_TREE_SIZE", f"{len(entries)} files or over {L['max_tree_bytes']} bytes")
    f = SelectiveFetcher(repo_path, ContentCache(Path(cache_dir) / "blobs"), max_bytes=L["max_file_bytes"])
    name, files = pkg.split("/")[-1], {}
    if name.lower() in STARTUP_MODULES or name in sys.stdlib_module_names:
        raise StageRejected("VENDOR_NAME_REFUSED", f"{name[:30]} would shadow or hook the interpreter")
    for e in sorted(entries, key=lambda x: x.path):
        try:
            files[name + e.path[len(pkg):]] = f.fetch(sha, e.path)
        except RepoIntelError as ex:
            raise StageRejected("VENDOR_FILE_REFUSED", f"{e.path}: {ex}") from None
    return files, _sha("".join(f"{p}\0{_sha(b)}\n" for p, b in sorted(files.items())))


def vendor_module(repo_path, sha, path, policy, cache_dir):
    """A single-file tool: {name.py: bytes} and its tree sha256, under the same size / text / shadowing rules as a package."""
    L, name = policy["limits"], path.rsplit("/", 1)[-1][:-3]
    if name.lower() in STARTUP_MODULES or name in sys.stdlib_module_names:
        raise StageRejected("VENDOR_NAME_REFUSED", f"{name[:30]} would shadow or hook the interpreter")
    f = SelectiveFetcher(repo_path, ContentCache(Path(cache_dir) / "blobs"), max_bytes=min(L["max_file_bytes"], L["max_tree_bytes"]))
    try:
        data = f.fetch(sha, path)
    except RepoIntelError as ex:
        raise StageRejected("VENDOR_FILE_REFUSED", f"{path}: {ex}") from None
    files = {name + ".py": data}
    return files, _sha(f"{name}.py\0{_sha(data)}\n")


def vendor(repo_path, card, policy, cache_dir):
    """Dispatch: the first package directory, else the first single-file module of the card."""
    if card["packages"]:
        return vendor_tree(repo_path, card["revision"], card["packages"][0], policy, cache_dir)
    if card.get("modules"):
        return vendor_module(repo_path, card["revision"], card["modules"][0], policy, cache_dir)
    raise StageRejected("NO_IMPORTABLE_PACKAGE", "the card names neither a package nor a module")


def prestage(repo_path, card, policy, cache_dir):
    """The cheap, local checks that need no network and no Docker (vendorable within limits, safe names, valid dependency list). A candidate
    failing them is rejected at inspection and never uses one of the attempts."""
    vendor(repo_path, card, policy, cache_dir)
    requirements(card["deps"], policy)


# ---------------------------------------------------------------- 2 requirements, download
def requirements(deps, policy):
    out = []
    if len(deps) > policy["limits"]["max_deps"]:
        raise StageRejected("TOO_MANY_DEPS", str(len(deps)))
    for d in deps:
        n, s = d.get("name"), (d.get("spec") or "").replace(" ", "")
        if not isinstance(n, str) or not NAME.match(n) or (s and not SPEC.match(s)):
            raise StageRejected("BAD_DEPENDENCY", str(n)[:40])
        out.append(n + s)
    return out


class Stager:
    def __init__(self, policy, run=None, prefix=None, cache_dir=None):
        self.pol, self.S = policy, policy["stage"]
        self.prefix = prefix or "hive-stage-" + secrets.token_hex(4)
        self._run = run or (lambda argv, timeout: run_bounded(argv, timeout=timeout, max_out=1 << 22)[:3])
        self.images, self.n, self.cache_dir, self._bins = [], 0, cache_dir, {}

    def docker(self, *args, timeout=60):
        rc, out, err = self._run(["docker", *args], timeout)
        return rc, (out.decode("utf-8", "replace") if isinstance(out, bytes) else out), (err.decode("utf-8", "replace") if isinstance(err, bytes) else err)

    def _name(self, what):
        self.n += 1
        return f"{self.prefix}-{what}{self.n}"

    def download_argv(self, reqs, out_dir, name):
        from .adapters.isolation import PINNED_IMAGE
        L = self.S["download_limits"]
        img = PINNED_IMAGE["reference"].split("@", 1)[0] + "@" + PINNED_IMAGE["digest"]
        return ["docker", "run", "--pull=never", "--rm", "--name", name, "--read-only", "--cap-drop=ALL", "--security-opt=no-new-privileges",
                "--user=1000:1000", f"--memory={L['memory_mb']}m", f"--pids-limit={L['pids']}", "--tmpfs=/tmp:rw,noexec,nosuid,size=64m", "-e", f"HOME=/out/{SCRATCH}", "-e", f"TMPDIR=/out/{SCRATCH}",
                "--mount", f"type=bind,src={Path(out_dir).resolve()},dst=/out", img,
                "python", "-m", "pip", "download", "--disable-pip-version-check", "--no-cache-dir", "--only-binary=:all:",
                "--index-url", "https://pypi.org/simple/", "-d", "/out", *reqs]

    def precheck(self, reqs, fetch=None):
        """Before any download: each direct requirement's smallest wheel for its newest release must fit the per-wheel cap, from the PyPI
        JSON metadata. Skipped (not failed) when the metadata is unavailable: the download watchdog and the scan are the hard caps."""
        fetch = fetch or self._pypi_fetch
        for r in reqs:
            name = re.split(r"[<>=!~]", r)[0]
            try:
                meta = json.loads(fetch(f"https://pypi.org/pypi/{name}/json"))
                wheels = [u["size"] for u in meta.get("urls", []) if u.get("packagetype") == "bdist_wheel" and isinstance(u.get("size"), int)]
            except Exception:
                continue
            if wheels and min(wheels) > self.S["max_wheel_bytes"]:
                raise StageRejected("WHEEL_TOO_LARGE", f"{name[:40]}: smallest wheel {min(wheels)} bytes (limit {self.S['max_wheel_bytes']})")

    def _pypi_fetch(self, url):
        if not url.startswith("https://pypi.org/pypi/"):
            raise ValueError("only pypi.org")
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "hive-acquire"}), timeout=self.S["pypi_timeout_s"]) as r:
            data = r.read(self.S["pypi_json_max_bytes"] + 1)
        if len(data) > self.S["pypi_json_max_bytes"]:
            raise ValueError("too large")
        return data

    poll_s = 1.0

    def download(self, reqs, out_dir):
        """Default downloader: network only inside this throwaway container. A watchdog removes the container the moment the output
        directory passes the wheelhouse cap, so pip cannot fill the host disk. Test seam: stage(..., downloader=fn(reqs, out_dir))."""
        if not reqs:
            return
        name, over, done = self._name("dl"), [], threading.Event()
        cap = self.S["max_wheelhouse_bytes"]
        (Path(out_dir) / SCRATCH).mkdir(parents=True, exist_ok=True)

        def watch():
            while not done.wait(self.poll_s):
                try:
                    if tree_size(out_dir) > cap:
                        over.append(1)
                        self._run(["docker", "rm", "--force", name], 30)
                        return
                except Exception:  # the watchdog never dies on a transient error; the next poll tries again
                    continue
        t = threading.Thread(target=watch, daemon=True)
        t.start()
        try:
            rc, _, err = self._run(self.download_argv(reqs, out_dir, name), self.S["download_timeout_s"])
        finally:
            done.set()
            t.join(5)
            self._run(["docker", "rm", "--force", name], 30)
            shutil.rmtree(Path(out_dir) / SCRATCH, ignore_errors=True)  # never part of the scan, lock or any hash
        err = err.decode("utf-8", "replace") if isinstance(err, bytes) else err
        if over:
            raise StageRejected("WHEELHOUSE_TOO_LARGE", f"download directory passed {cap} bytes; the container was removed")
        if rc:
            low = err.lower()
            raise StageRejected("COMPILED_OR_SDIST_ONLY" if any(k in low for k in NO_BINARY) else "DOWNLOAD_FAILED", err[-160:])

    # ------------------------------------------------------------ 3 scan + lock
    def scan_wheel(self, path):
        """Facts about one wheel, or StageRejected. Pure local inspection: nothing is imported or executed."""
        p = Path(path)
        if p.suffix != ".whl":
            raise StageRejected("WHEEL_REFUSED", f"not a wheel: {p.name[:60]}")
        try:
            z = zipfile.ZipFile(p)
        except (zipfile.BadZipFile, OSError):
            raise StageRejected("WHEEL_REFUSED", f"unreadable: {p.name[:60]}") from None
        with z:
            names = z.namelist()
            for n in names:
                parts = n.split("/")
                if n.startswith("/") or "\\" in n or ".." in parts or ":" in parts[0]:
                    raise StageRejected("WHEEL_REFUSED", f"unsafe path in {p.name[:60]}")
                if n.endswith(".pth"):
                    raise StageRejected("WHEEL_REFUSED", f".pth startup file in {p.name[:60]}")
                if parts[0].endswith(".data") and (len(parts) < 2 or parts[1] not in ("purelib", "platlib")):
                    raise StageRejected("WHEEL_REFUSED", f"{parts[0][:40]} entry outside purelib/platlib (would install outside site-packages)")
                top = parts[2:] if parts[0].endswith(".data") else parts
                if top and top[0].lower().removesuffix(".py") in STARTUP_MODULES:
                    raise StageRejected("WHEEL_REFUSED", f"{top[0][:30]} runs at interpreter start-up")
            if sum(i.file_size for i in z.infolist()) > self.S["max_unpacked_bytes"] or any(i.file_size > self.S["max_wheel_bytes"] for i in z.infolist()):
                raise StageRejected("WHEEL_REFUSED", f"expands too large: {p.name[:60]}")
            meta = next((n for n in names if n.endswith(".dist-info/METADATA") and n.count("/") == 1), None)
            if meta is None:
                raise StageRejected("WHEEL_REFUSED", f"no METADATA in {p.name[:60]}")
            ep = next((n for n in names if n.endswith(".dist-info/entry_points.txt") and n.count("/") == 1), None)
            if ep:
                bad = self.script_problem(z.read(ep).decode("utf-8", "replace"))
                if bad:
                    raise StageRejected("WHEEL_REFUSED", f"script entry point {bad} in {p.name[:60]}")
            text = z.read(meta).decode("utf-8", "replace")
            roots = set()
            for n in names:
                parts = n.split("/")
                if parts[0].endswith(".dist-info"):
                    continue
                if parts[0].endswith(".data"):
                    parts = parts[2:]
                if len(parts) > 1:
                    roots.add(parts[0])
                elif parts and parts[0].endswith(".py"):
                    roots.add(parts[0][:-3])
            tops = sorted(roots)
        h = {}
        for line in text.split("\n\n", 1)[0].splitlines():
            k, _, v = line.partition(":")
            h.setdefault(k.strip().lower(), []).append(v.strip())
        name = h.get("name", ["?"])[0][:40]
        lic = license_of(h)
        if lic is None or any(t not in self.pol["licenses"] for t in lic.split(",")):
            raise StageRejected("LICENSE_NOT_ALLOWED", f"{name}: {(lic or 'unknown or unmapped')[:60]}")
        if not h.get("name") or not h.get("version"):
            raise StageRejected("WHEEL_REFUSED", "METADATA lacks name/version")
        return {"name": h["name"][0].lower().replace("_", "-"), "version": h["version"][0], "license": lic, "file": p.name,
                "sha256": _sha(p.read_bytes()), "bytes": p.stat().st_size, "top_level": tops}

    def script_names(self, text):
        """Names declared under [console_scripts] / [gui_scripts] of an entry_points.txt."""
        names, cur = [], None
        for line in text.splitlines():
            t = line.strip()
            if t.startswith("[") and t.endswith("]"):
                cur = t[1:-1].strip()
            elif cur in ("console_scripts", "gui_scripts") and t and not t.startswith(("#", ";")) and "=" in t:
                names.append(t.split("=", 1)[0].strip())
        return names

    def script_problem(self, text):
        """None, or the first script name that may not be installed: bad pattern, python*/pip*, or an executable the base image already has."""
        names = self.script_names(text)
        if not names:
            return None
        have = None
        for n in names:
            if not SCRIPT_NAME.match(n) or n.lower().startswith(("python", "pip")):
                return repr(n[:40])
            if have is None:
                have = self.base_executables()
            if n in have or n.lower() in have:
                return f"{n[:40]!r} (already in the base image)"
        return None

    def base_executables(self, base=None):
        """Executable names in the pinned base image (/usr/local/bin, /usr/bin, /bin), listed once per base digest and cached on disk by digest."""
        from .adapters.isolation import PINNED_IMAGE
        base = base or PINNED_IMAGE
        key = base["digest"].split(":")[-1][:16]
        if key in self._bins:
            return self._bins[key]
        cf = Path(self.cache_dir) / f"base-bins-{key}.json" if self.cache_dir else None
        if cf and cf.is_file():
            try:
                names = json.loads(cf.read_text(encoding="utf-8"))
                if isinstance(names, list) and names:
                    self._bins[key] = set(names)
                    return self._bins[key]
            except (OSError, ValueError):
                pass
        name = self._name("ls")
        ref = base["reference"].split("@", 1)[0] + "@" + base["digest"]
        try:
            rc, out, err = self.docker("run", "--pull=never", "--rm", "--name", name, "--network=none", "--read-only", "--cap-drop=ALL", "--user=1000:1000",
                                       "--memory=128m", "--pids-limit=32", ref, "ls", "-1", "/usr/local/bin", "/usr/bin", "/bin", timeout=60)
        finally:
            self.docker("rm", "--force", name, timeout=30)
        names = sorted({ln.strip() for ln in out.splitlines() if ln.strip() and not ln.strip().endswith(":") and "/" not in ln})
        if rc or not names:
            raise StageRejected("WHEEL_REFUSED", "the base image's executables could not be listed")
        self._bins[key] = set(names)
        if cf:
            cf.parent.mkdir(parents=True, exist_ok=True)
            cf.write_text(json.dumps(names), encoding="utf-8", newline="\n")
        return self._bins[key]

    def scan_all(self, wheel_dir):
        ws = sorted(w for w in Path(wheel_dir).glob("*") if w.name != SCRATCH)
        if len(ws) > self.S["max_wheels"]:
            raise StageRejected("TOO_MANY_WHEELS", str(len(ws)))
        if sum(w.stat().st_size for w in ws) > self.S["max_wheelhouse_bytes"]:
            raise StageRejected("WHEELHOUSE_TOO_LARGE", "")
        return [self.scan_wheel(w) for w in ws]

    @staticmethod
    def lock_text(wheels):
        return "".join((f"# optional (imported by the tool inside try/except ImportError)\n" if w.get("optional") else "")
                       + f"{w['name']}=={w['version']} --hash=sha256:{w['sha256']}\n" for w in sorted(wheels, key=lambda w: w["name"]))

    def stage_optional(self, card, wheels, wheel_dir, tmp, downloader=None):
        """Stage at most policy max_optional of the tool's optional imports (mapped to distributions through the policy table) that pass every
        wheel gate (precheck, download, licence, scripts, sizes, total cap, no version clash). A failing one is skipped, never fatal.
        Returns (extra wheels marked optional, [{import, dist, reason}])."""
        table, extra, skipped = self.pol.get("optional_dists", {}), [], []
        have = {n.lower() for w in wheels for n in w["top_level"]} | {w["name"] for w in wheels}
        todo = [i for i in card.get("optional_imports", []) if i.lower() not in have]
        for k, imp in enumerate(todo):
            dist = table.get(imp, imp)
            if len({w["optional_for"] for w in extra}) >= self.S.get("max_optional", 2):
                skipped.append({"import": imp, "dist": dist, "reason": "MAX_OPTIONAL: limit reached"})
                continue
            if not NAME.match(dist):
                skipped.append({"import": imp, "dist": dist, "reason": "BAD_DEPENDENCY"})
                continue
            d = Path(tmp) / f"optional-{k}"
            d.mkdir()
            try:
                if downloader is None:
                    self.precheck([dist])
                (downloader or self.download)([dist], d)
                got = self.scan_all(d)
                if not any(w["name"] == dist.lower().replace("_", "-") for w in got):
                    raise StageRejected("COMPILED_OR_SDIST_ONLY", "no wheel for the optional distribution")
                allw = wheels + extra
                names = {w["name"]: w["version"] for w in allw}
                new = [w for w in got if (w["name"], w["version"]) not in {(x["name"], x["version"]) for x in allw}]
                if any(w["name"] in names and names[w["name"]] != w["version"] for w in new):
                    raise StageRejected("VERSION_CLASH", "an optional wheel conflicts with a pinned one")
                if sum(w["bytes"] for w in allw + new) > self.S["max_wheelhouse_bytes"]:
                    raise StageRejected("WHEELHOUSE_TOO_LARGE", "with the optional wheels")
            except StageRejected as e:
                skipped.append({"import": imp, "dist": dist, "reason": e.code})
                continue
            for w in new:
                shutil.copy2(d / w["file"], Path(wheel_dir) / w["file"])
                extra.append(dict(w, optional=True, optional_for=imp))
        return extra, skipped

    # ------------------------------------------------------------ 4 build
    @staticmethod
    def dockerfile(base, has_wheels):
        ref = base["reference"].split("@", 1)[0] + "@" + base["digest"]
        lines = [f"FROM {ref}"]
        if has_wheels:
            lines += ["COPY wheelhouse/ /wheelhouse/", "COPY lock.txt /lock.txt",
                      "RUN python -m pip install --no-index --no-deps --require-hashes --disable-pip-version-check --no-cache-dir "
                      "--find-links /wheelhouse -r /lock.txt && rm -rf /wheelhouse /lock.txt"]
        lines.append(f"COPY vendor/ {SITE}/")
        return "\n".join(lines) + "\n"

    def build(self, ctx, base, has_wheels):
        tag = f"{self.prefix}:{self._name('img').rsplit('-', 1)[-1]}"
        (Path(ctx) / "Dockerfile").write_bytes(self.dockerfile(base, has_wheels).encode("utf-8"))
        rc, _, err = self.docker("build", "--network=none", "--pull=false", "-q", "-t", tag, str(ctx), timeout=self.S["build_timeout_s"])
        if rc:
            raise StageRejected("BUILD_FAILED", err[-200:])
        self.images.append(tag)
        rc, out, _ = self.docker("image", "inspect", "--format", "{{.Id}}", tag)
        iid = out.strip()
        if rc or not re.fullmatch(r"sha256:[0-9a-f]{64}", iid):
            raise StageRejected("BUILD_FAILED", "image ID not readable")
        return tag, iid

    # ------------------------------------------------------------ 5 smoke, save, load
    def smoke(self, image_id, packages):
        """Import every staged top-level name offline, non-root, read-only: proves the image works before any model touches it."""
        name = self._name("smoke")
        mods = [m for m in packages if NAME.match(m)]
        try:
            rc, _, err = self.docker("run", "--pull=never", "--rm", "--name", name, "--network=none", "--read-only", "--cap-drop=ALL",
                                     "--security-opt=no-new-privileges", "--user=1000:1000", "--memory=256m", "--pids-limit=32", image_id,
                                     "python", "-I", "-c", "import " + ",".join(mods or ["sys"]), timeout=self.S["smoke_timeout_s"])
        finally:
            self.docker("rm", "--force", name, timeout=30)
        if rc:
            raise StageRejected("SMOKE_FAILED", err[-200:])

    def save(self, tag, tar_path):
        rc, _, err = self.docker("save", "-o", str(tar_path), tag, timeout=self.S["save_timeout_s"])
        if rc:
            raise StageRejected("SAVE_FAILED", err[-200:])
        h = hashlib.sha256()
        with open(tar_path, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        return h.hexdigest()

    def image_id(self, ref):
        rc, out, _ = self.docker("image", "inspect", "--format", "{{.Id}}", ref)
        return out.strip() if rc == 0 else None

    def tar_sha256(self, tar):
        h = hashlib.sha256()
        with open(tar, "rb") as f:
            for chunk in iter(lambda: f.read(1 << 20), b""):
                h.update(chunk)
        return h.hexdigest()

    def verify_tar(self, env):
        """The saved image tar hashes to its recorded sha256 (checked even when the image is already present)."""
        try:
            got = self.tar_sha256(env["tar_path"])
        except OSError:
            raise StageRejected("IMAGE_MISSING", "the image tar is unreadable") from None
        if got != env["image_tar_sha256"]:
            raise StageRejected("IMAGE_TAR_MISMATCH", "tar differs from its recorded sha256")

    def ensure(self, env):
        """The admitted image, present locally with exactly its recorded ID: inspect, else verify the tar hash and `docker load` it.
        Never rebuilds (a rebuild changes the ID). Raises StageRejected otherwise."""
        want = env["id"]
        if self.image_id(want) == want:
            return want
        tar = Path(env["tar_path"])
        h = hashlib.sha256()
        try:
            with open(tar, "rb") as f:
                for chunk in iter(lambda: f.read(1 << 20), b""):
                    h.update(chunk)
        except OSError:
            raise StageRejected("IMAGE_MISSING", "image absent and its tar is unreadable") from None
        if h.hexdigest() != env["image_tar_sha256"]:
            raise StageRejected("IMAGE_TAR_MISMATCH", "tar differs from its recorded sha256")
        rc, _, err = self.docker("load", "-i", str(tar), timeout=self.S["save_timeout_s"])
        if rc or self.image_id(want) != want:
            raise StageRejected("IMAGE_ID_MISMATCH", err[-120:] if rc else "loaded image has a different ID")
        return want

    def cleanup(self, keep_ids=()):
        """Remove only images this Stager built (by tag, so a shared layer set is left to Docker's own refcount)."""
        for t in self.images:
            self.docker("rmi", "--force", t, timeout=60)
        self.images = []

    # ------------------------------------------------------------ orchestrator
    def stage(self, repo_path, card, store_dir, cache_dir, downloader=None):
        """Card (already admissible) -> environment record for the frozen run and the v3 statement. Raises StageRejected."""
        from .adapters.isolation import PINNED_IMAGE
        store_dir = Path(store_dir)
        store_dir.mkdir(parents=True, exist_ok=True)
        self.cache_dir = self.cache_dir or cache_dir
        files, tree_sha = vendor(repo_path, card, self.pol, cache_dir)
        reqs = requirements(card["deps"], self.pol)
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as t:
            ctx = Path(t)
            (ctx / "wheelhouse").mkdir()
            if downloader is None:
                self.precheck(reqs)
            (downloader or self.download)(reqs, ctx / "wheelhouse")
            wheels = self.scan_all(ctx / "wheelhouse")
            have = {w["name"] for w in wheels}
            if any(re.split(r"[<>=!~]", r)[0].lower().replace("_", "-") not in have for r in reqs):
                raise StageRejected("COMPILED_OR_SDIST_ONLY", "a declared dependency has no wheel")
            opt, opt_skipped = self.stage_optional(card, wheels, ctx / "wheelhouse", ctx, downloader)
            wheels = wheels + opt
            lock = self.lock_text(wheels)
            (ctx / "lock.txt").write_bytes(lock.encode("utf-8"))
            for p, b in files.items():
                _w(ctx / "vendor" / p, b)
            tag, iid = self.build(ctx, PINNED_IMAGE, bool(wheels))
        packages = safe_packages({(f[:-3] if "/" not in f and f.endswith(".py") else f.split("/")[0]) for f in files} | {m for w in wheels for m in w["top_level"]})
        self.smoke(iid, packages)
        tar = store_dir / (iid.split(":")[1][:16] + ".tar")
        tar_sha = self.save(tag, tar)
        wh = [dict({k: w[k] for k in ("name", "version", "license", "sha256", "bytes")}, **({"optional": True} if w.get("optional") else {})) for w in wheels]
        return {"id": iid, "tag": tag, "base": dict(PINNED_IMAGE), "lock_sha256": _sha(lock), "wheelhouse_manifest_sha256": _sha(json.dumps(wh, sort_keys=True)),
                "wheelhouse": wh, "image_tar_sha256": tar_sha, "tar_path": str(tar), "packages": packages, "vendored_tree_sha256": tree_sha,
                "optional_skipped": opt_skipped, "vendored_files": len(files), "tool_modules": safe_packages({(f[:-3] if "/" not in f and f.endswith(".py") else f.split("/")[0]) for f in files})}
