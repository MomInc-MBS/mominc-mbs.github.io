"""C3 capability-gap discovery: one frozen, bounded experiment per gap, judged by an independent evaluator process.

Proposer side only. This module never reads the private acceptance cases or their answers (it passes a directory NAME to
the contract's private-case generator and evaluator, which run as separate `python -I` processes) and never produces a verdict:
it launches the evaluator and re-checks the hashes of the receipt it wrote. A passing candidate is NOT registered or executed
in goals here; admission is the next gate (C4)."""
from __future__ import annotations

import base64
import json
import os
import re
import sqlite3
import subprocess
import sys
import time
from pathlib import Path
from types import SimpleNamespace

from . import capability_registry as CR
from . import capcontract as CC
from . import coop as CP
from .bounded import run_bounded
from . import experiment_compare as EC
from . import m2_model as M
from . import model_dispatch as MD
from . import m2_workflow as W
from . import operator_runtime as O
from .operator_runtime import Refused, _json, _now, _sha, _txn
from .storage import Store, _alive

ROOT = O.ROOT
APPROVAL = "build/c-series/c3_inference_approval.json"
PRIVATE = ROOT / ".hive" / "c3-private"  # only ever handed to the evaluator-side scripts as an argument
KEY, LEDGER = "operator/discovery/", "operator/discovery_ledger"
SCHEMA, RECEIPT_SCHEMA = "hive-c3-frozen-v2", "hive-c3-evaluation-receipt-v1"
TERMINAL = {"CANDIDATE_PASSED", "NO_QUALIFYING_CANDIDATE", "BUDGET_EXHAUSTED", "STOPPED", "MODEL_UNAVAILABLE", "PUBLIC_CANDIDATE_FROZEN"}
# Opt-in evaluation policy: the runtime never touches the hidden set. A dev-perfect candidate ends the experiment as a public final candidate; scoring is the evaluator's, after freeze.
SEALED = "public_feedback_sealed_final_v1"
SEALED_POLICY = {"id": SEALED, "hidden_gate": False, "feedback": "public dev only", "carry_best": "public dev pass", "check": "public dev cases + static check",
                 "selector": "best public dev pass, then earliest experiment, then sha", "final_state": "PUBLIC_CANDIDATE_FROZEN", "max_experiments": 3,
                 "prompt_view": "decoded-public-v1"}
DECODED_CAP = 400  # sealed-policy view: chars shown per public file when the files together exceed DECODED_FULL
DECODED_FULL = 8000  # ponytail: one total threshold (extract fits whole, resolve is cut); a per-cap token budget if more caps use the view
BUDGET = {"calls": 6, "proposals": 3, "container_runs": 12, "in_tokens": 36000, "out_tokens": 6000, "wall_s": 900, "max_tokens_per_call": 4096}
IMPROVE_CAP_MULT = 2  # improvement spend per capability: at most this many discovery budgets in total (2 experiments per base version)
APPROVAL_CAPS = {"model_calls": 6, "proposals": 3, "container_runs": 12, "input_tokens": 36000, "output_tokens": 6000, "wall_minutes": 15}
SYSTEM = ("Reasoning: low\nYou write one pure Python 3 function. Reply with exactly one ```python code block that defines "
          "`def run(env: dict) -> str` and nothing after it. Use only the json module (`import json`); no file, network, os or sys access.")


# The bare-name evaluator import shim lives in capcontract (generic over whatever folder a contract names); defaults = first contract.
eval_scope, _load = CC.scope, CC.load_module
c3_scope = eval_scope  # name kept for the existing tests


def contract_of(rec):
    """The repo contract an experiment was frozen against (v1 records predate the contract field: found by gap signature)."""
    fz = rec["frozen"]
    if fz.get("schema") == SCHEMA and not isinstance(fz.get("contract"), dict):
        raise Refused("frozen protocol has no capability contract")
    c = CC.get(fz["contract"]["capability_id"]) if fz.get("contract") else CC.contract_for_gap(fz["gap"]["signature"])
    if c is None:
        raise Refused("no capability contract matches this experiment")
    return c


def check_frozen(rec, c):
    """What runs on the host comes from the repo contract, never from the store: the frozen contract sha, evaluator path and suite must
    all agree with it (a store writer can recompute frozen_sha, so agreement with the trusted contract is the only check that holds)."""
    fz, V = rec["frozen"], c["verification"]
    if fz.get("schema") == SCHEMA:
        if not isinstance(fz.get("contract"), dict) or fz["contract"].get("sha256") != CC.sha(c):
            raise Refused("the capability contract no longer matches the frozen protocol")
    elif not c["compatibility"].get("legacy_frozen"):  # a relabelled record must not skip the contract check
        raise Refused("this capability's contract does not accept legacy frozen protocols")
    derived = CC.is_v2(c) and c["execution"]["environment_ref"]["kind"] == "derived"
    if derived != isinstance(fz.get("environment"), dict):
        raise Refused("frozen environment does not match the contract's environment kind")
    if derived:
        CC.check_environment(fz["environment"])
    ev, want = fz.get("evaluator") or {}, {"path": V["evaluator"]["path"], **({"suite": V["suite_ref"]} if V["evaluator"].get("suite_arg") else {})}
    if {k: ev.get(k) for k in ("path", "suite")} != {"path": want["path"], "suite": want.get("suite")}:
        raise Refused("frozen evaluator path or suite differs from the contract")


def _read_lf(path):
    return Path(path).read_bytes().decode("utf-8").replace("\r\n", "\n")


def _write_lf(path, text):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_bytes(text.encode("utf-8"))


def pol():
    """The M2 client policy, narrowed to the C3 budget; the M2 policy file itself is untouched."""
    p = W.load_policy()
    p.update(max_model_calls=BUDGET["calls"], max_tokens_total=BUDGET["in_tokens"] + BUDGET["out_tokens"], transport_retries=0, call_timeout_s=240,
             approval_path=APPROVAL, approval_caps=APPROVAL_CAPS)
    p["sampling"] = dict(p["sampling"], temperature=0.2, max_tokens=BUDGET["max_tokens_per_call"])
    return p


def _keys(store):
    return [r["key"] for r in store.db.execute("SELECT key FROM kv WHERE key LIKE ?", (KEY + "%",)).fetchall()]


def experiments(store, gap_key=None):
    rows = [store.get(k) for k in _keys(store)]
    return sorted((r for r in rows if gap_key in (None, r["gap_key"])), key=lambda r: r["opened_at"])


def discoveries(store):
    return [{"exp_id": e["exp_id"], "gap_key": e["gap_key"], "state": e["state"], "reason": e.get("reason"), "ledger": e["ledger"],
             "route": "operator-authored" if e["frozen"].get("authored") else "learned", "candidate_sha256": e.get("candidate_sha256"), "report": e.get("report"), "baselines": e["baselines"]} for e in experiments(store)[-20:]]


def _zero(): return {"calls": 0, "proposals": 0, "container_runs": 0, "in_tokens": 0, "out_tokens": 0, "wall_s": 0.0, "estimated_tokens": False}


# ---------------------------------------------------------------- frozen protocol
def open_experiment(store, gap_key, *, private_dir=None, seed=None, budget=None, environment=None, card_excerpt=None, acq_run=None, tool_modules=None, seed_best=None, improve=None, capability_id=None, proposer_model=None, authored=None, authored_body=None, coop=None, seed_base=None, policy=None, sealed_final=None, model_choice=None):
    """Freeze the protocol, make the acceptance set (hash only comes back) and persist the experiment BEFORE any generation.
    Refuses when the gap has an open or passed experiment, has had 2 already, or is not a gap with a missing step. Never opens gaps.
    `improve` (set only by open_improvement) is the ONE explicit-request bypass of "one finished run per gap": see check().
    `capability_id` names which of several contracts sharing the gap's interface to acquire (same-interface alternatives, T03); the "open or passed
    experiment" and retry-depth checks then count only that capability's experiments. Default None: the first contract, as before.
    `coop` (a coop.RECIPES id) freezes a cooperative round: 3 independent candidates, one hidden-gate run. `seed_base` shifts the proposer seeds (a repeat of the
    same protocol). Both default None: frozen dict, exp_id and behaviour are then exactly as before.
    `model_choice` (opt-in auto mode, model_choice.choose) is recorded in the frozen protocol; None = frozen dict and exp_id as before.
    `policy` = SEALED freezes the public-feedback / sealed-final protocol: no hidden set is generated or gated by the runtime (frozen gets "eval_policy"); at most 3 experiments per campaign."""
    if policy is not None:
        if policy != SEALED or coop is not None or improve or authored:
            raise Refused(f"policy must be {SEALED!r}, alone (no coop, improve or authored)")
    if coop is not None and coop not in CP.RECIPES:
        raise Refused(f"unknown coop recipe {coop!r} (known: {sorted(CP.RECIPES)})")
    if seed_best is not None:
        sb = seed_best
        if not (isinstance(sb, dict) and isinstance(sb.get("body"), str) and len(sb["body"]) <= 20000 and isinstance(sb.get("dev_pass"), int)
                and not isinstance(sb["dev_pass"], bool) and sb["dev_pass"] >= 0 and isinstance(sb.get("feedback", ""), str)):
            raise Refused("seed_best must be {body: str <= 20000 chars, dev_pass: int >= 0, feedback: str}")
    gap = store.get(gap_key)
    if not gap or not gap.get("missing_step"):
        raise Refused("not a gap with a minimal missing step")

    def check():
        prior = experiments(store, gap_key)
        if capability_id:
            prior = [e for e in prior if (e["frozen"].get("contract") or {}).get("capability_id") == capability_id]
        if authored or sealed_final:  # operator-authored / sealed-final acceptance route: its own gap per capability; one open at a time, at most 12 tries (a passed-but-unadmitted one does not block)
            if any(e["state"] not in TERMINAL for e in prior) or len(prior) >= 12:
                raise Refused("this capability has an open authored experiment, or 12 already")
            return len(prior) + 1
        if improve:  # explicit authorised improvement of an admitted capability: a passed prior run is expected; an open one is not
            mine = [e for e in prior if (e["frozen"].get("improve") or {}).get("base_version") == improve["base_version"]]
            if any(e["state"] not in TERMINAL for e in prior):
                raise Refused("this gap already has an open experiment")
            if len(mine) >= 2:
                raise Refused("retry depth reached: at most 2 improvement experiments per base version")
            return len(prior) + 1
        if any(e["state"] not in TERMINAL or e["state"] in ("CANDIDATE_PASSED", "PUBLIC_CANDIDATE_FROZEN") for e in prior):
            raise Refused("this gap already has an open or passed experiment")
        if policy and sum(1 for e in prior if e["frozen"].get("acq_run") == acq_run and e["frozen"].get("eval_policy")) >= SEALED_POLICY["max_experiments"]:
            raise Refused("campaign boundary: at most 3 experiments per sealed-final campaign")
        if acq_run:  # an acquisition run owns up to 3 candidate attempts; a gap takes at most 2 runs
            if sum(1 for e in prior if e["frozen"].get("acq_run") == acq_run) >= 12 or len(prior) >= 24:
                raise Refused("retry depth reached: at most 12 experiments (candidates plus retries) per acquisition run and 24 per gap")
        elif len(prior) >= 2:
            raise Refused("retry depth reached: at most 2 experiments per gap")
        return len(prior) + 1
    check()
    ms = gap["missing_step"]
    c = next((x for x in CC.contracts_for_gap(ms) if capability_id in (None, x["capability_id"])), None)
    if c is None:
        raise Refused("no capability contract declares this gap")
    cpf = None
    if coop:
        try:
            cpf = CP.frozen(coop, cap=c["capability_id"], spec=CC.text_ref(c["proposer"]["behaviour_spec_ref"]))
        except ValueError as e:
            raise Refused(str(e)) from None
    V = c["verification"]
    derived = CC.is_v2(c) and c["execution"]["environment_ref"]["kind"] == "derived"
    if derived != (environment is not None):
        raise Refused("a derived-environment capability needs a staged environment record, and no other kind may have one")
    if derived:  # the record that goes into the frozen protocol and, later, the admission statement (never a host path)
        CC.check_environment(environment)
    dev = _load("gen_public", c).cases()
    try:
        if policy:  # sealed final: no hidden set exists for the runtime; the evaluator builds the block's fixtures separately (evaluator/coop/sealed_final.py)
            acc = {"set_sha256": None, "n": None}
        else:
            rc, out, _, timed_out = run_bounded([sys.executable, "-I", str(CC.ROOT / V["gen_private"]), "--out", str(private_dir or PRIVATE)] + (["--seed", str(seed)] if seed is not None else []),
                                                timeout=120)
            if rc or timed_out:
                raise ValueError("generator failed")
            acc = json.loads(out.strip().splitlines()[-1])
    except (OSError, ValueError, IndexError):
        raise Refused("the acceptance set could not be generated") from None
    if improve and acc["set_sha256"] in {e["frozen"]["acceptance"]["set_sha256"] for e in experiments(store, gap_key)}:
        raise Refused("the hidden holdout is not fresh: an earlier experiment already used this set")
    base = _read_lf(CC.ROOT / V["baseline"])
    frozen = {"schema": SCHEMA, "gap": {"key": gap_key, "signature": ms, "partial_plan": gap.get("partial_plan")},
              "contract": {"capability_id": c["capability_id"], "sha256": CC.sha(c)},
              "behaviour_spec": CC.text_ref(c["proposer"]["behaviour_spec_ref"]),
              "io_envelope": {"input": CC.envelope_text(c), "candidate": "def run(env: dict) -> str"},
              "output_canonical_form": c["outputs"]["canonical_form"],
              "dev_set_sha256": _sha(_json(dev)), "acceptance": {"set_sha256": acc["set_sha256"], "n": acc["n"], "note": "hash only; cases and answers stay in .hive/c3-private"} if not policy else {"note": "sealed final: no hidden set at run time"},
              "evaluator": {"path": V["evaluator"]["path"], "pin": CC.pin(c), **({"suite": V["suite_ref"]} if V["evaluator"].get("suite_arg") else {})},
              "baselines": {"unchanged_hive": "no capability for the gap: expected 0/n (measured by the planner refusing)",
                            "scripted": {"path": V["baseline"], "sha256": _sha(base), "label": "hand-written, evaluated like a candidate"},
                            **V["baseline_notes"]},
              **({"environment": environment, "card_excerpt": str(card_excerpt or "")[:5000], "tool_modules": sorted(tool_modules or [])} if derived else {}),
              **({"acq_run": acq_run} if acq_run else {}), **({"improve": improve} if improve else {}), **({"authored": authored} if authored else {}), **({"sealed_final": sealed_final} if sealed_final else {}),
              **({"coop": cpf} if coop else {}), **({"seed_base": int(seed_base)} if seed_base else {}), **({"model_choice": model_choice} if model_choice else {}), **({"eval_policy": SEALED_POLICY} if policy else {}),
              "budget": dict(BUDGET, **(budget or {})), "proposer": {"model": "operator-authored" if authored else sealed_final["proposer_model"] if sealed_final else proposer_model if proposer_model and M.is_hosted(proposer_model) else "openai/gpt-oss-20b", "task_class": c["proposer"]["task_class"], "approval": APPROVAL, "sampling": "temperature 0.2, max_tokens 4096, Reasoning: low"},
              "admission_criteria": ["static check clean", f"perfect on the {len(dev)} public dev cases", "independent evaluator PASS on every acceptance case (pass_count == n)",
                                     "receipt hashes re-checked against this frozen protocol", "within budget", "registration/execution is NOT part of C3 (admission gate C4)"] if not policy else
                                    ["static check clean", f"perfect on the {len(dev)} public dev cases ends the experiment as a public final candidate", "within budget",
                                     "scored once, by the evaluator, after the campaign's final receipt exists; no admission"],
              "attempt": None}
    with _txn(store):
        frozen["attempt"] = check()
        sha = _sha(_json(frozen))
        rec = {"exp_id": "d-" + sha[:20], "frozen_sha": sha, "frozen": frozen, "gap_key": gap_key, "state": "OPEN", "opened_at": _now(), "pid": None,
               "ledger": _zero(), "proposals": [], "calls": [], "baselines": {}, "feedback": "", "stages": [{"stage": "frozen", "at": _now()}]}
        if authored or sealed_final:
            rec["authored_body"] = authored_body
        if seed_best is not None:
            rec["best"] = {"sha256": _sha(seed_best["body"]), "dev_pass": seed_best["dev_pass"], "body": seed_best["body"]}
            rec["feedback"] = str(seed_best.get("feedback") or "")[:2000]
        store.set(KEY + rec["exp_id"], rec)
        if not store.get(LEDGER):
            store.set(LEDGER, _zero())
    return rec


# ---------------------------------------------------------------- budget
def _save(store, rec): store.set(KEY + rec["exp_id"], rec)


def _spend(store, rec, **kw):
    """Add to the experiment ledger and the global ledger together (one transaction), and persist."""
    with _txn(store):
        g = store.get(LEDGER) or _zero()
        for k, v in kw.items():
            g[k] = g.get(k, 0) + v
            rec["ledger"][k] = rec["ledger"].get(k, 0) + v
        store.set(LEDGER, g)
        _save(store, rec)


def _left(store, rec, k):
    imp = rec["frozen"].get("improve")
    if imp:  # an improvement has no run ledger (its spend still lands in the global discovery ledger via _spend): its own frozen budget AND a per-capability
        # improvement total (IMPROVE_CAP_MULT x the discovery budget, summed over every improvement experiment of that capability) cap it
        used = sum(e["ledger"].get(k, 0) for e in experiments(store) if (e["frozen"].get("improve") or {}).get("cap_id") == imp["cap_id"])  # includes this one
        return min(rec["frozen"]["budget"][k] - rec["ledger"][k], IMPROVE_CAP_MULT * BUDGET[k] - used)
    if rec["frozen"].get("acq_run") or rec["frozen"].get("authored") or rec["frozen"].get("sealed_final"):  # an acquisition attempt is bounded by its frozen budget; the run's own ledger caps the sum
        return rec["frozen"]["budget"][k] - rec["ledger"][k]
    g = store.get(LEDGER) or _zero()
    return min(rec["frozen"]["budget"][k] - rec["ledger"][k], BUDGET[k] - g[k])


class _End(Exception):
    def __init__(self, state, reason):
        super().__init__(reason)
        self.state, self.reason = state, reason


def _gate(store, rec, clock, stop_path, **need):
    """Checked BEFORE every call/run: STOP, wall, then every needed allowance. Raises _End; never lets a limit be crossed."""
    now = time.monotonic()
    _spend(store, rec, wall_s=now - clock[0])
    clock[0] = now
    if Path(stop_path).exists():
        raise _End("STOPPED", "STOP is set; nothing further ran")
    if _left(store, rec, "wall_s") <= 0:
        raise _End("BUDGET_EXHAUSTED", "wall_s exhausted")
    for k, n in need.items():
        if _left(store, rec, k) < n:
            raise _End("BUDGET_EXHAUSTED", f"{k} exhausted (need {n}, {_left(store, rec, k)} left)")


# ---------------------------------------------------------------- proposals
def _show(env, cap=None):
    """An env for the prompt: long base64 payloads are shown as their length, never inlined (the proposer needs the shape, not the pixels).
    cap (sealed policy prompt view "decoded-public-v1"): each file's public UTF-8 text instead, cut at `cap` chars."""
    def one(f):
        if "data" not in f:
            return f
        if cap is None:
            return dict(f, data=f"<base64 {len(f['data'])} chars>")
        t = base64.b64decode(f["data"]).decode("utf-8", "replace")
        return {k: v for k, v in f.items() if k != "data"} | {"text": t[:cap] + (f"...(truncated, {len(t)} chars)" if len(t) > cap else "")}
    return {"files": [one(f) for f in env["files"]]}


def system_for(c, rec):
    if not CC.is_v2(c):
        return SYSTEM
    mods = CC.import_policy(c, ((rec["frozen"].get("environment") or {}).get("packages") or ()))
    return ("Reasoning: low\nYou write one pure Python 3 function. Reply with exactly one ```python code block that defines "
            "`def run(env: dict) -> str` and nothing after it. You may import only these modules: " + ", ".join(mods) + "; no file, network, os or sys access. "
            "Names like compile, eval, exec, getattr, type, vars are refused even as attributes, so no re.compile: pass pattern strings straight to re.finditer/re.sub/re.findall.")


def prompt(rec, dev):
    """Frozen behaviour spec + public dev cases + the previous candidate's dev failures (+ the bounded tool excerpt for a staged environment)."""
    c = contract_of(rec)
    dec = None
    if rec["frozen"].get("eval_policy") and CC.is_v2(c):  # whole files when all public text fits DECODED_FULL, else DECODED_CAP per file
        tot = sum(len(base64.b64decode(f["data"])) for k in dev for f in k["env"]["files"] if "data" in f)
        dec = DECODED_FULL if tot <= DECODED_FULL else DECODED_CAP
    ex = "\n".join(f"- {k['name']}\n  input: {json.dumps(_show(k['env'], dec) if CC.is_v2(c) else k['env'], separators=(',', ':'), ensure_ascii=dec is None)}\n  expected: {k['expected']}" for k in dev)
    user = f"{CC.text_ref(c['proposer']['behaviour_spec_ref'])}\n\nWorked cases (input env -> expected return value):\n{ex}\n"
    if CC.is_v2(c) and c["permissions"]["filesystem"] == "read-only-inputs":
        user += ("\nInput files are available BOTH as base64 `data` and as a read-only file at the entry's `path` (same bytes). Use `path` with libraries that "
                 "take file paths: pass the `path` strings straight to the tool. Do NOT import os, tempfile or similar and do not call open(): such code is refused "
                 "before it runs. Nothing else on the filesystem is readable or writable except a small non-executable /tmp.\n")
    if rec["frozen"].get("card_excerpt"):
        user += f"\n{rec['frozen']['card_excerpt']}\n"
    imp = rec["frozen"].get("improve")
    if imp:  # spec + current admitted code + the declared objective (enum or number only); never the hidden holdout
        user += (f"\nThis is an IMPROVEMENT of an already-admitted implementation. Keep it correct on every case above.\n"
                 f"Current admitted code:\n```python\n{imp['base_body'][:6000]}\n```\nObjective: {objective_text(imp['objective'])}\n")
    system = system_for(c, rec)
    if rec["feedback"]:
        fb = f"\nYour previous candidate failed on the cases above (truncated):\n{rec['feedback']}\n"
        best = rec.get("best")
        if best:
            lim = rec["frozen"]["budget"].get("max_prompt_tokens")
            carry = (f"\nYour best previous candidate (dev {best['dev_pass']} of {len(dev)} passed) was:\n```python\n{best['body'][:6000]}\n```\n"
                     "Fix it; keep what works.\n")
            if not lim or (len(system) + len(user) + len(carry) + len(fb)) // 4 + 1 <= lim:  # over the prompt limit: drop the body, never overflow
                user += carry
        user += fb
    return [{"role": "system", "content": system}, {"role": "user", "content": user}]


def extract_code(content):
    blocks = re.findall(r"```(?:python|py)?[ \t]*\n(.*?)```", content or "", re.S)
    body = next((b for b in reversed(blocks) if "def run" in b), None)
    if body is None and "```" not in (content or "") and "def run" in (content or ""):
        body = content
    return body.strip("\n") + "\n" if body else None


def _imports(body):
    import ast
    names = set()
    try:
        for n in ast.walk(ast.parse(body)):
            if isinstance(n, ast.Import):
                names |= {a.name.split(".")[0] for a in n.names}
            elif isinstance(n, ast.ImportFrom) and not n.level:
                names.add((n.module or "").split(".")[0])
    except (SyntaxError, ValueError, RecursionError, MemoryError):
        pass
    return names


def _static(harness, c, rec, body):
    """The harness static check under the contract's import policy (v1: json only, the harness's own default). For an acquisition attempt the
    adapter must also import at least one of the vendored tool's modules: reimplementing the tool is refused, with the reason as feedback."""
    if not CC.is_v2(c):
        return harness.static_problems(body)
    bad = harness.static_problems(body, CC.import_policy(c, (rec["frozen"].get("environment") or {}).get("packages", ())))
    tool = rec["frozen"].get("tool_modules") or []
    if tool and not bad and not (_imports(body) & set(tool)):
        bad = [f"does not use the vendored tool: it imports none of ({', '.join(tool)}); use the tool's functions, do not reimplement them"]
    return bad


def _outputs(body, envs, harness, timeout=60, **kw):
    """One container run of a candidate over extra input envs (the coop differential inputs): the raw run_isolated JSON. No expected values are involved."""
    return json.loads(EC.run_isolated((getattr(harness, "wrap_dev", None) or harness.wrap)(body), json.dumps(envs), {}, timeout=timeout,
                                      backend="container", operator_class="generated", **kw))


def _dev_run(body, dev, harness, timeout=60, **kw):
    ok, fails = _dev_ok(body, dev, harness, timeout, **kw)
    return {"n": len(dev), "pass_count": sum(ok)}, "\n".join(fails[:4 if fails and fails[0].startswith("your function returned the same") else 3])[:1500]


def _cap(v):
    return json.dumps(v, ensure_ascii=False)[:300]


def _jdiff(a, b, path):
    """First difference between two parsed JSON values as 'at <path> expected X got Y', or None."""
    if isinstance(a, dict) and isinstance(b, dict):
        if set(a) != set(b):
            return f"at {path or '$'} missing keys {sorted(set(a) - set(b))[:5]} extra keys {sorted(set(b) - set(a))[:5]}"
        for k in a:
            d = _jdiff(a[k], b[k], f"{path}.{k}" if path else k)
            if d:
                return d
        return None
    if isinstance(a, list) and isinstance(b, list):
        for i, (x, y) in enumerate(zip(a, b)):  # a wrong row is shown whole (kind, page, raw ...), so the proposer can find its pattern
            d = _jdiff(x, y, f"{path}[{i}]") if isinstance(x, list) else (None if x == y and type(x) is type(y) else f"at {path}[{i}] expected {_cap(x)} got {_cap(y)}")
            if d:
                return d
        if len(a) != len(b):
            return f"at {path or '$'} expected length {len(a)} got length {len(b)}, first differing index {min(len(a), len(b))}"
        return None
    return None if a == b and type(a) is type(b) else f"at {path or '$'} expected {_cap(a)} got {_cap(b)}"


def _first_diff(exp, got):
    got = str(got)
    try:
        d = _jdiff(json.loads(exp), json.loads(got), "")
        if d:
            return d
    except (ValueError, TypeError):
        pass
    i = next((i for i, (x, y) in enumerate(zip(exp, got)) if x != y), min(len(exp), len(got)))
    lo = max(0, i - 40)
    return f"first difference at char {i}: expected ...{exp[lo:i + 40]!r} got ...{got[lo:i + 40]!r}"


def _dev_ok(body, dev, harness, timeout=60, **kw):
    """One container run over the PUBLIC dev cases -> ([case passed], [failure lines]). A harness with wrap_dev reports, per failing case, the exception
    type, message and the last traceback line inside the adapter; nothing here ever touches the hidden acceptance cases."""
    raw = json.loads(EC.run_isolated((getattr(harness, "wrap_dev", None) or harness.wrap)(body), json.dumps([c["env"] for c in dev]), {}, timeout=timeout,
                                     backend="container", operator_class="generated", **kw))
    out, errs = (raw["out"], raw["err"]) if isinstance(raw, dict) else (raw, [None] * len(dev))
    fails = [f"case {c['name']}: raised {e}" if e else f"case {c['name']}: {_first_diff(c['expected'], o)}"
             for c, o, e in zip(dev, out, errs) if o != c["expected"]]
    if fails and len(set(map(str, out))) == 1 and len({c["expected"] for c in dev}) > 1 and not any(errs):  # a constant answer to differing cases
        fails.insert(0, f"your function returned the same value {str(out[0])[:60]!r} for every case: it is a stub. Write the full implementation of the spec; "
                        "a partial implementation that passes some cases is better than a stub.")
    return [o == c["expected"] for c, o in zip(dev, out)], fails


# ---------------------------------------------------------------- evaluator
def _launch(args, evaluator):
    """The evaluator as its own tree-killed process; the host deadline is the evaluator's own --timeout plus grace (default 400 s)."""
    t = int(args[args.index("--timeout") + 1]) + 30 if "--timeout" in args else 400
    rc, out, err, timed_out = run_bounded([sys.executable, "-I", str(CC.ROOT / evaluator)] + args, timeout=t)
    return SimpleNamespace(returncode=rc, stdout=out, stderr=err, timed_out=timed_out)


def receipt_problems(rec, r, cand_sha, label):
    """Re-check a receipt the evaluator wrote. Discovery cannot make or change a verdict; it only refuses receipts that do not match."""
    fz, bad = rec["frozen"], []
    want = {"schema": RECEIPT_SCHEMA, "label": label, "exp_id": rec["exp_id"], "frozen_sha": rec["frozen_sha"], "candidate_sha256": cand_sha,
            "acceptance_set_sha256": fz["acceptance"]["set_sha256"], "n": fz["acceptance"]["n"]}
    bad += [k for k, v in want.items() if r.get(k) != v]
    if (r.get("evaluator") or {}).get("pin") != fz["evaluator"]["pin"]:
        bad.append("evaluator pin")
    if "environment" in fz and r.get("environment_id") != fz["environment"]["id"]:
        bad.append("environment id")
    if r.get("verdict") != ("PASS" if r.get("pass_count") == r.get("n") else "FAIL"):
        bad.append("verdict")
    if r.get("receipt_sha256") != _sha(json.dumps({k: v for k, v in r.items() if k != "receipt_sha256"}, sort_keys=True, separators=(",", ":"))):
        bad.append("receipt_sha256")
    return bad


def _evaluate(rec, outdir, body_path, label, private_dir, baseline_receipt=None, timeout=None):
    c = contract_of(rec)
    check_frozen(rec, c)
    V = c["verification"]
    body = _read_lf(body_path)
    cand = _sha(body)
    out = Path(outdir) / f"receipt-{label}-{cand[:12]}.json"
    out.unlink(missing_ok=True)
    args = ["--exp", rec["exp_id"], "--frozen-sha", rec["frozen_sha"], "--candidate-file", str(body_path), "--candidate-sha", cand, "--private", str(private_dir or PRIVATE),
            "--set", rec["frozen"]["acceptance"]["set_sha256"], "--out", str(out), "--label", label] + (["--baseline-receipt", str(baseline_receipt)] if baseline_receipt else []) + (["--timeout", str(timeout)] if timeout else [])
    if CC.is_v2(c):  # trusted caller passes the import policy, resource limits and staged image; the proposer chooses none of them
        env, R = rec["frozen"].get("environment"), c["execution"]["resources"]
        args += ["--imports", ",".join(CC.import_policy(c, (env or {}).get("packages", ()))), "--memory-mb", str(R["memory_mb"]), "--cpus", str(R["cpus"]),
                 "--pids", str(R["pids"]), "--tmpfs-mb", str(R.get("tmpfs_mb", 16))] + (["--image-id", env["id"]] if env else [])
        if c["permissions"]["filesystem"] == "read-only-inputs":
            args += ["--inputs", "read-only"]
    if V["evaluator"].get("suite_arg"):  # evaluators that take their task from a suite folder
        args += ["--suite", str(CC.ROOT / CC._rel(V["suite_ref"]))]
    ev = V["evaluator"]["path"]
    CC._rel(ev)  # rooted / parent paths are Refused
    if not (CC.ROOT / ev).resolve().is_relative_to(CC.ROOT.resolve()):  # a link inside the repo must not lead out of it
        raise Refused("evaluator path resolves outside the repo")
    p = _launch(args, ev)
    if not out.exists():
        raise RuntimeError(f"evaluator produced no receipt (exit {p.returncode}): {(p.stderr or p.stdout)[-200:]}")
    r = json.loads(out.read_text(encoding="utf-8"))
    bad = receipt_problems(rec, r, cand, label)
    if bad:
        raise RuntimeError("receipt rejected: " + ", ".join(bad))
    return r, out


def _wall(store, rec, cap):
    """A step timeout clamped to what is left of the experiment wall budget (>= 1 s; _gate already refused when none is left)."""
    return max(1, min(cap, int(_left(store, rec, "wall_s"))))


def _summ(r): return {k: r[k] for k in ("pass_count", "n", "verdict", "receipt_sha256", "candidate_sha256")}


# ---------------------------------------------------------------- improve (T14): an explicit new version of an admitted capability
FAILURE_CLASSES = {"wrong_output": "the current version returns a wrong answer on some inputs: fix those without breaking the cases above",
                   "run_error": "the current version crashes or times out on some inputs: make it robust on all of them"}


def check_objective(o):
    """The declared objective is an enum value, never free outcome text: {"kind":"failure_class","value":<enum>}. A latency objective is not
    supported: it cannot be re-measured honestly at admission (REVIEW_P1 L3/M3)."""
    if not isinstance(o, dict) or set(o) != {"kind", "value"}:
        raise Refused("objective must be {kind, value}")
    k, v = o["kind"], o["value"]
    if k == "failure_class" and isinstance(v, str) and v in FAILURE_CLASSES:
        return {"kind": k, "value": v}
    raise Refused(f"objective must be failure_class in {sorted(FAILURE_CLASSES)}")


def objective_text(o):
    return FAILURE_CLASSES[o["value"]]


def objective_result(o, old, new):
    """Did the declared objective improve? old = the previous-version receipt on the fresh holdout, new = the candidate's receipt (a PASS). Pure function of the two
    evaluator receipts: the authority recomputes it at admission. The text never carries holdout counts (they would leak to the proposer)."""
    bad = (old["run_error"] is not None) if o["value"] == "run_error" else (old["run_error"] is None and old["pass_count"] < old["n"])
    met = bad and not new["run_error"]
    return {"met": bool(met), "why": f"previous version had {'a' if bad else 'no'} {o['value']} failure on the fresh holdout",
            "old": {"pass_count": old["pass_count"], "n": old["n"], "run_error": old["run_error"]}, "new": {"pass_count": new["pass_count"], "n": new["n"]}}


def open_improvement(store, cap_id, objective, *, private_dir=None, seed=None, budget=None, proposer_model=None):
    """Open ONE bounded experiment to improve the CURRENT verified version of cap_id. Same contract, evaluator, pin and caps as acquisition; the hidden
    holdout is a fresh generator set (new seed unless a test passes one) that no proposer sees. Refuses if the capability is not admitted and active,
    if the repo contract is not the admitted one, or if the objective is not an enum/number. Records the bypass of 'one finished run per gap'."""
    obj = check_objective(objective)
    cur = CR.resolve_discovered(store, cap_id)  # verifies the whole signed chain and the current statement
    st = cur["statement"]
    c = CC.get(cap_id)
    if c is None or st.get("contract_sha256") != CC.sha(c):
        raise Refused("the repo contract is not the admitted one")
    exp_id = store.read_artifact(cur["event_ref"]).get("exp_id")
    orig = next((e for e in experiments(store) if e["exp_id"] == exp_id), None)
    if orig is None:
        raise Refused("the experiment that admitted the current version is missing")
    b = {k: min(v, BUDGET[k]) for k, v in (budget or {}).items() if k in BUDGET}  # callers may lower a cap, never raise it
    fz = orig["frozen"]
    imp = {"cap_id": cap_id, "base_version": cur["version"], "base_statement_sha": cur["statement_sha"], "base_impl_sha256": st["impl_sha256"], "base_body": st["body"],
           "objective": obj, "explicit_request": True, "bypass": "one finished run per gap (this explicit improvement request only)"}
    return open_experiment(store, st["lineage"]["gap_key"], private_dir=private_dir, seed=seed, budget=b, environment=fz.get("environment"), card_excerpt=fz.get("card_excerpt"),
                           tool_modules=fz.get("tool_modules"), improve=imp, proposer_model=proposer_model)


def comparison(store, rec, *, admitted=None, reason=None):
    """The old-vs-new receipt for an improvement experiment (ADMITTED with the new version, or REJECTED with the evidence). Saved as a store artifact and
    at operator/improve/<exp_id>; the per-proposal evidence stays on the experiment record."""
    imp, base = rec["frozen"]["improve"], rec["baselines"].get("previous") or {}
    ev = rec.get("improve_eval") or {}
    best = next((p for p in reversed(rec["proposals"]) if p.get("acceptance")), None)
    r = {"schema": "hive-improve-comparison-v1", "cap_id": imp["cap_id"], "exp_id": rec["exp_id"], "verdict": "ADMITTED" if admitted else "REJECTED",
         "reason": reason or rec.get("reason"), "objective": imp["objective"], "bypass": imp["bypass"], "explicit_request": imp["explicit_request"],
         "holdout_set_sha256": rec["frozen"]["acceptance"]["set_sha256"], "evaluator_pin": rec["frozen"]["evaluator"]["pin"],
         "old": {"version": imp["base_version"], "impl_sha256": imp["base_impl_sha256"], "statement_sha": imp["base_statement_sha"],
                 "holdout": {k: base.get(k) for k in ("pass_count", "n", "run_error", "receipt_sha256")}, "dev_ms": base.get("dev_ms")},
         "new": {"version": (admitted or {}).get("version"), "statement_sha": (admitted or {}).get("statement_sha"),
                 "impl_sha256": rec.get("candidate_sha256") or (best or {}).get("sha256"),
                 "holdout": (best or {}).get("acceptance"), "dev_ms": (best or {}).get("dev_ms")},
         "objective_result": ev.get("objective") or (best or {}).get("objective"), "regression": ev.get("regression") or (best or {}).get("regression"),
         "proposals": [{k: p.get(k) for k in ("n", "sha256", "static", "dev", "acceptance", "objective")} for p in rec["proposals"]],
         "ledger": rec["ledger"], "state": rec["state"], "at": _now()}
    r["receipt_sha256"] = _sha(json.dumps({k: v for k, v in r.items() if k != "receipt_sha256"}, sort_keys=True, separators=(",", ":")))
    ref = store.put_artifact(r)
    store.set("operator/improve/" + rec["exp_id"], {"ref": ref, "verdict": r["verdict"], "receipt_sha256": r["receipt_sha256"]})
    return r, ref


# ---------------------------------------------------------------- run
def run_experiment(store_root, exp_id, *, stop_path=None, stub_endpoint=None, private_dir=None, requested_model=None, dispatch_cfg=None, private_blobs=None):
    """Run or resume one experiment to a terminal state. Budget is the frozen one, minus whatever the ledgers already show spent."""
    store_root = Path(store_root)
    stop_path = Path(stop_path or store_root / "STOP")
    s = Store(store_root)
    try:
        rec = s.get(KEY + exp_id)
        if not rec:
            raise Refused("unknown experiment")
        if rec["state"] in TERMINAL:
            return rec
        if rec["state"] == "RUNNING" and isinstance(rec.get("pid"), int) and rec["pid"] != os.getpid() and _alive(rec["pid"]):
            raise Refused("experiment is running in another process")
        rec.update(state="RUNNING", pid=os.getpid(), reason=None)
        rec["stages"].append({"stage": "resume" if rec["ledger"]["calls"] or rec["baselines"] else "start", "at": _now()})
        _save(s, rec)
        clock, outdir = [time.monotonic()], store_root / "discovery" / exp_id
        try:
            _loop(s, rec, outdir, clock, stop_path, stub_endpoint, private_dir, requested_model, dispatch_cfg, private_blobs)
        except _End as e:
            rec.update(state=e.state, reason=e.reason)
        except M.CapReached as e:
            rec.update(state="BUDGET_EXHAUSTED", reason=f"model client cap: {e}")
        except (M.Refused, M.Invalidated, RuntimeError, OSError, ValueError, subprocess.SubprocessError) as e:
            rec.update(state="INTERRUPTED", reason=f"{type(e).__name__}: {str(e)[:300]} (resumable; the ledger is kept)")
        rec["stages"].append({"stage": rec["state"].lower(), "at": _now()})
        _spend(s, rec, wall_s=time.monotonic() - clock[0])
        if rec["state"] in TERMINAL:
            rec["completed_at"] = _now()
            _save(s, rec)
            with _txn(s):  # the gap stays OPEN; no candidate is promoted
                g = s.get(rec["gap_key"])
                g["discovery"] = {"experiment": exp_id, "state": rec["state"], "reason": rec.get("reason"), "ledger": rec["ledger"], "at": _now()}
                s.set(rec["gap_key"], g)
        _save(s, rec)
        return rec
    finally:
        s.close()


def proposer_seed(frozen, n):
    """Sampling seed of call n. Attempt 1 keeps the historical 2026300000+n; each later experiment on the gap gets fresh seeds, so retries explore instead of replaying the same sample."""
    return 2026300000 + int(frozen.get("seed_base") or 0) + 100 * (int(frozen.get("attempt") or 1) - 1) + n


def _loop(s, rec, outdir, clock, stop_path, stub_endpoint, private_dir, requested_model=None, dispatch_cfg=None, private_blobs=None):
    c = contract_of(rec)
    harness, gen_public = _load("harness", c), _load("gen_public", c)
    dev, B, fz = gen_public.cases(), rec["frozen"]["budget"], rec["frozen"]
    try:
        check_frozen(rec, c)
    except Refused as e:
        raise _End("INTERRUPTED", str(e))
    if _sha(_json(dev)) != fz["dev_set_sha256"] or CC.pin(c) != fz["evaluator"]["pin"]:
        raise _End("INTERRUPTED", "dev set or evaluator no longer matches the frozen protocol")
    imp0 = fz.get("improve")
    if imp0:  # a stored improvement is re-validated on every resume: enum objective, body = the admitted one, base still the active version
        try:
            if check_objective(imp0["objective"]) != imp0["objective"] or _sha(imp0["base_body"]) != imp0["base_impl_sha256"]:
                raise Refused("stored improvement body or objective is not valid")
            cur = CR.resolve_discovered(s, imp0["cap_id"])
            if (cur["version"], cur["statement_sha"], cur["statement"]["impl_sha256"], cur["statement"]["body"]) != (
                    imp0["base_version"], imp0["base_statement_sha"], imp0["base_impl_sha256"], imp0["base_body"]):
                raise Refused("the base version is no longer the active admitted one")
        except (Refused, KeyError, TypeError) as e:
            raise _End("INTERRUPTED", f"improvement re-validation failed: {str(e)[:200]}")
    outdir.mkdir(parents=True, exist_ok=True)
    # -- baselines, measured up front (the unchanged-HIVE one is the planner refusing)
    if "unchanged_hive" not in rec["baselines"]:
        from . import goal_runner as G
        sig = fz["gap"]["signature"]
        steps = G.plan_goal(s, {"deliverable": sig["out"], "budget": {"max_steps": 6}, "inputs": [{"type": t} for t in sig.get("ins") or [c["inputs"]["types"][0]] * sig["arity"]]})["steps"]
        rec["baselines"]["unchanged_hive"] = {"pass_count": 0 if not steps else None, "n": fz["acceptance"].get("n"), "basis": f"planner returned {len(steps)} steps for the gap"}
        _save(s, rec)
    if "scripted" not in rec["baselines"] and not fz.get("eval_policy"):  # the scripted baseline is a hidden-set run: not under the sealed policy
        _gate(s, rec, clock, stop_path, container_runs=1)
        _spend(s, rec, container_runs=1)
        bp = outdir / "baseline.py"
        _write_lf(bp, _read_lf(CC.ROOT / c["verification"]["baseline"]))
        r, path = _evaluate(rec, outdir, bp, "scripted_baseline", private_dir, timeout=_wall(s, rec, 120))
        rec["baselines"]["scripted"] = dict(_summ(r), receipt_path=path.name, label="hand-written")
        _save(s, rec)
    imp = fz.get("improve")
    if imp and "previous" not in rec["baselines"]:  # the admitted version on the fresh holdout and the public dev cases (its regression fixtures)
        _gate(s, rec, clock, stop_path, container_runs=2)
        _spend(s, rec, container_runs=2)
        op = outdir / "previous.py"
        _write_lf(op, imp["base_body"])
        r, path = _evaluate(rec, outdir, op, "previous_version", private_dir, timeout=_wall(s, rec, 120))
        t0 = time.perf_counter()
        ok, _ = _dev_ok(imp["base_body"], dev, harness, _wall(s, rec, 60), **CC.exec_args(c, fz.get("environment")))
        rec["baselines"]["previous"] = dict(_summ(r), receipt_path=path.name, run_error=r["run_error"], dev_ms=round((time.perf_counter() - t0) * 1000, 1),
                                            regression=[k["name"] for k, g in zip(dev, ok) if g])
        _save(s, rec)
    if fz.get("authored") or fz.get("sealed_final"):
        return _authored(s, rec, outdir, clock, stop_path, private_dir, c, harness, dev)
    requested, weights_ok = requested_model or "openai/gpt-oss-20b", False  # the backend comes ONLY from the explicit request (never from a record field)
    if requested != fz["proposer"]["model"] and (M.is_hosted(requested, dispatch_cfg) or M.is_hosted(fz["proposer"]["model"], dispatch_cfg)):
        raise M.Refused(f"a hosted backend needs the request ({requested!r}) to equal the frozen protocol's backend ({fz['proposer']['model']!r})")
    sealed = fz.get("eval_policy")
    if sealed is not None:  # the policy, its selector and its check are code constants: a stored record cannot swap them, nor the backend
        if sealed != SEALED_POLICY:
            raise _End("INTERRUPTED", "eval_policy no longer matches the frozen protocol")
        if requested != fz["proposer"]["model"]:
            raise M.Refused(f"a sealed-final experiment is bound to its frozen backend {fz['proposer']['model']!r}, not {requested!r}")
    seen = {p["sha256"] for p in rec["proposals"]} | ({_sha(imp["base_body"])} if imp else set())

    def ask(msgs, temperature=None, **extra):
        """One model call: gate -> plan and validate the backend -> charge -> call -> record. -> (n, extracted code or None, result, latency_s).
        Every call is gated and charged (calls=1) BEFORE it is dispatched; `temperature` overrides this call's own copy of the sampling only."""
        nonlocal weights_ok
        size = sum(len(m["content"]) for m in msgs) // 4 + 1
        if B.get("max_prompt_tokens") and size > B["max_prompt_tokens"]:
            raise _End("BUDGET_EXHAUSTED", f"prompt exceeds {B['max_prompt_tokens']} input tokens")
        _gate(s, rec, clock, stop_path, calls=1, proposals=1, in_tokens=size, out_tokens=256)
        n = rec["ledger"]["calls"] + 1
        d = dict(MD.plan(outdir.parents[1], c["proposer"]["task_class"], requested, dispatch_cfg), call_id=f"{rec['exp_id']}:{n}")
        p, ex = pol(), d["executed_model"]
        p["sampling"]["max_tokens"] = min(B["max_tokens_per_call"], _left(s, rec, "out_tokens"))
        if temperature is not None:
            p["sampling"] = dict(p["sampling"], temperature=temperature)  # this call's own copy; pol() is fresh per call and nothing else sees it
        model, why = None, "NO_EXECUTABLE_MODEL"
        if ex:  # validate identity and readiness BEFORE any call: qualified, context fits, endpoint lists it loaded
            need = size + p["sampling"]["max_tokens"]
            try:
                if need > (d["context"].get(ex) or 0):
                    why = "CONTEXT_DOES_NOT_FIT"
                else:
                    why = "MODEL_NOT_LOADED"
                    if ex != p["model"]["id"]: p = M.apply_backend(p, ex, dispatch_cfg)  # a non-default backend brings its own pins, endpoint and approval (T18)
                    model = M.Model(outdir / "model", stub=bool(stub_endpoint), endpoint=stub_endpoint, pol=p, approval_path=ROOT / p["approval_path"], dispatch_cfg=dispatch_cfg,
                                private_blobs=private_blobs)  # real goal inputs, if the caller has them: a hosted backend refuses any prompt that contains them
                    if not stub_endpoint and not weights_ok:
                        model.check_weights("c3-run")
                        weights_ok = True
                    model.list_models()
                    if not model.hosted and MD.loaded(model.endpoint, ex) is False:
                        raise M.Invalidated(f"{ex} is listed but not loaded")
            except (M.Refused, M.Invalidated, OSError, ValueError, KeyError) as e:
                model, why = None, f"{why}: {type(e).__name__}: {str(e)[:200]}"
        if model is None:  # fallback P0: no model, no call, ledger untouched
            _dispatched(s, rec, outdir, d, error=why, **extra)
            raise _End("MODEL_UNAVAILABLE", f"fallback P0: {why}")
        _spend(s, rec, calls=1)  # counted at the start: an interrupted call is still a call
        try:
            res = model.call(c["proposer"]["task_class"].replace("-", "_"), msgs, proposer_seed(fz, n))
        except M.Invalidated as e:  # the endpoint reported a different model id: refused, recorded, not used
            _dispatched(s, rec, outdir, d, model, error=f"reply verification failed: {str(e)[:200]}", **extra)
            raise _End("MODEL_UNAVAILABLE", f"fallback P0: reply verification failed: {str(e)[:200]}") from None
        _dispatched(s, rec, outdir, d, model, error=None if res["status"] == "ok" else "transport_failure", **extra)
        if res["status"] != "ok":
            raise _End("MODEL_UNAVAILABLE", "fallback P0: transport_failure (no retry beyond transport_retries)")
        content, u = res["content"], res["usage"]
        est = not (u.get("prompt_tokens") is not None and u.get("completion_tokens") is not None)
        tin, tout = (sum(len(m["content"]) for m in msgs) // 4, len(content) // 4) if est else (int(u["prompt_tokens"]), int(u["completion_tokens"]))
        _spend(s, rec, in_tokens=tin, out_tokens=tout)
        rec["ledger"]["estimated_tokens"] = rec["ledger"]["estimated_tokens"] or est
        (outdir / f"reply-{n}.txt").write_text(content, encoding="utf-8", newline="\n")
        body = extract_code(content) if res["status"] == "ok" else None
        rec["calls"].append({"n": n, "status": res["status"], "in_tokens": tin, "out_tokens": tout, "estimated": est, "has_code": bool(body)})
        _save(s, rec)
        return n, body, res, (model.ledger() or [{}])[-1].get("latency_s")

    def dev_check(prop, body):
        """The public dev run of one candidate (container, gated and charged first); feeds the carry-best feedback."""
        _gate(s, rec, clock, stop_path, container_runs=1)
        _spend(s, rec, container_runs=1)
        t0 = time.perf_counter()
        try:
            prop["dev"], text = _dev_run(body, dev, harness, _wall(s, rec, 60), **CC.exec_args(c, fz.get("environment")))
            prop["dev_ms"] = round((time.perf_counter() - t0) * 1000, 1)
        except Exception as e:  # crash/timeout/bad output: nothing passed
            prop["dev"], text = {"n": len(dev), "pass_count": 0, "error": f"{type(e).__name__}: {str(e)[:200]}"}, f"it crashed or timed out: {type(e).__name__}: {str(e)[:200]}"
        prop["feedback"] = text[:400]
        _note_feedback(rec, prop["n"], prop["dev"]["pass_count"], prop["dev"]["n"], text, body)
        _save(s, rec)

    def hidden(prop, h, body):
        """The independent hidden gate for ONE dev-perfect candidate: raises _End("CANDIDATE_PASSED") on PASS, else records the withheld-details feedback."""
        _gate(s, rec, clock, stop_path, container_runs=1)
        _spend(s, rec, container_runs=1)
        r, path = _evaluate(rec, outdir, outdir / f"cand-{h}.py", "candidate", private_dir, outdir / rec["baselines"]["scripted"]["receipt_path"], _wall(s, rec, 120))
        prop["acceptance"] = _summ(r)
        text = f"it passed all dev cases but failed {r['n'] - r['pass_count']} of {r['n']} hidden acceptance cases (details withheld)"
        prop["feedback"] = text
        _note_feedback(rec, prop["n"], prop["dev"]["n"] + 1, prop["dev"]["n"], text, body)  # clearing every dev case outranks any dev failure
        if r["verdict"] == "PASS" and imp:
            prop["objective"] = objective_result(imp["objective"], rec["baselines"]["previous"], r)
            prop["regression"] = {"fixtures": rec["baselines"]["previous"]["regression"], "new_passes_all": prop["dev"]["pass_count"] == prop["dev"]["n"]}
            if not prop["objective"]["met"]:  # valid but not better: not admitted; the evidence stays on the proposal
                prop["feedback"] = f"it is correct but did not improve the objective ({prop['objective']['why']})"
                _note_feedback(rec, prop["n"], prop["dev"]["n"] + 1, prop["dev"]["n"], prop["feedback"], body)
                _save(s, rec)
                return
        if r["verdict"] == "PASS":
            ties = r["pass_count"] == rec["baselines"]["scripted"]["pass_count"]
            rec.update(candidate_sha256=h, receipt=dict(_summ(r), path=path.name), report={
                "candidate_sha256": h, "evaluator_receipt_sha256": r["receipt_sha256"], "pass_count": r["pass_count"], "n": r["n"], "baselines": rec["baselines"],
                "note": ("The candidate only ties the hand-written scripted baseline: mechanism evidence, NOT a learning advantage." if ties else "Differs from the scripted baseline.")
                        + " Awaiting admission (C4); not registered, not executed in goals."})
            if imp:
                rec["improve_eval"] = {"objective": prop["objective"], "regression": prop["regression"],
                                       "new": {"candidate_sha256": h, "dev_ms": prop["dev_ms"], "receipt_sha256": r["receipt_sha256"]}}
            raise _End("CANDIDATE_PASSED", "independent evaluator PASS; awaiting admission")
        _save(s, rec)

    def static_feedback(prop):
        why = "Your latest proposal was refused by the static check before it ran: " + "; ".join(prop["static"])
        prop["feedback"] = why[:400]
        best = rec.get("best_feedback")
        rec["feedback"] = (f"{best['text']}\n{why}" if best else "static check refused it: " + "; ".join(prop["static"]))[:2200]  # appended, never replacing
        _save(s, rec)

    def coop_round():
        """One cooperative round: N independent samples of the SAME messages (no branch sees another's reply, code or verdict), a dev run of each distinct
        one, differential agreement on public generator inputs, a pure selection, then the hidden gate for the selected candidate only. Always raises."""
        cp = fz["coop"]
        msgs = prompt(rec, dev)  # built once, before any candidate of the round is recorded
        mask = spec = None
        if cp["recipe"] in CP.MASKED:  # the masked views are checked against the live spec and the frozen mask hash BEFORE any model call
            spec = CC.text_ref(c["proposer"]["behaviour_spec_ref"])
            try:
                mask, msha = CP.load_mask(c["capability_id"], spec)
                if msha != cp["masks_sha256"]:
                    raise ValueError("mask file changed since the experiment was frozen (masks_sha256 mismatch)")
                for b in range(cp["branches"]):
                    CP.render_user(mask, cp["recipe"], b, spec, msgs[1]["content"])
            except ValueError as e:
                raise _End("INTERRUPTED", f"coop mask refused: {str(e)[:200]}")
        best = rec.get("best")
        parent = best["sha256"] if best and "Your best previous candidate" in msgs[1]["content"] else None
        live, bodies, stop = [], {}, None
        for b in range(cp["branches"]):
            line = CP.instruction(cp, b)
            m = [dict(x) for x in msgs] + ([{"role": "user", "content": line}] if line else [])
            vi = {}
            if mask:
                m[1]["content"] = CP.render_user(mask, cp["recipe"], b, spec, m[1]["content"])
                vi = CP.view_info(mask, cp["recipe"], b)
            try:
                n, body, res, lat = ask(m, cp["temperature"], recipe_id=cp["recipe"], branch=b)
            except _End as e:  # a cap/STOP/unavailable model ends the round cleanly: keep what exists, judge it, then end with this reason
                stop = e
                break
            row = rec["calls"][-1]
            row.update(recipe_id=cp["recipe"], branch=b, seed=res["seed"], temperature=cp["temperature"], parent_sha=parent, latency_s=lat, **vi)
            if not body:
                row["failure_category"] = "no_code"
                _save(s, rec)
                continue
            h = _sha(body)
            if h in seen:  # not an independent candidate: no proposal charged, no agreement vote
                row.update(duplicate_of=h, failure_category="duplicate")
                _save(s, rec)
                continue
            seen.add(h)
            _spend(s, rec, proposals=1)
            prop = {"n": n, "sha256": h, "static": _static(harness, c, rec, body), "dev": None, "acceptance": None, "recipe_id": cp["recipe"], "branch": b, "seed": res["seed"],
                    "temperature": cp["temperature"], "parent_sha": parent, "latency_s": lat, "out_tokens": row["out_tokens"], "failure_category": None, "agreement": None, "selected": False, **vi}
            rec["proposals"].append(prop)
            _write_lf(outdir / f"cand-{h}.py", body)
            if prop["static"]:
                prop["failure_category"] = "static_fail"
                static_feedback(prop)
                continue
            live.append(prop)
            bodies[h] = body
        for prop in live:
            dev_check(prop, bodies[prop["sha256"]])
            prop["failure_category"] = "dev_pass" if prop["dev"]["pass_count"] == prop["dev"]["n"] else "dev_fail"
        perfect = [p for p in live if p["failure_category"] == "dev_pass"]
        info = {"recipe": cp["recipe"], "candidates": [p["sha256"] for p in live], "selected": None, "selection_key": None, "diff_inputs_sha": None}
        if len(perfect) >= 2:
            envs = CP.diff_envs(gen_public, cp["diff_seed"], cp["diff_inputs"])
            if envs is None:
                note = "skipped-nogen"
            elif _left(s, rec, "container_runs") < len(perfect) + 1:  # one run per candidate, and the hidden gate still needs its own
                note = "skipped-cap"
            else:
                outs = {}
                for prop in perfect:
                    _gate(s, rec, clock, stop_path, container_runs=1)
                    _spend(s, rec, container_runs=1)
                    try:
                        outs[prop["sha256"]] = CP.canon(_outputs(bodies[prop["sha256"]], envs, harness, _wall(s, rec, 60), **CC.exec_args(c, fz.get("environment"))), len(envs))
                    except Exception:  # a crash or timeout on these inputs: no output, no vote
                        outs[prop["sha256"]] = None
                note = CP.agreement(outs)
                info["diff_inputs_sha"] = CP.digest(envs)
            for prop in perfect:
                prop["agreement"] = note if isinstance(note, str) else note[prop["sha256"]]
        win = CP.select([{"sha": p["sha256"], "dev_pass": p["dev"]["pass_count"], "agreement": p["agreement"], "dev_ms": p.get("dev_ms")} for p in live])
        chosen = None
        if win:
            chosen = next(p for p in live if p["sha256"] == win["sha"])
            chosen["selected"] = True
            info.update(selected=win["sha"], selection_key=CP.key(win))
        rec["coop"] = info
        _save(s, rec)
        if chosen and chosen["failure_category"] == "dev_pass":
            hidden(chosen, win["sha"], bodies[win["sha"]])
        if stop:
            raise stop
        raise _End("NO_QUALIFYING_CANDIDATE", f"coop round: {len(live)} distinct candidates, none passed")

    while True:
        if rec["ledger"]["proposals"] >= B["proposals"]:
            raise _End("NO_QUALIFYING_CANDIDATE", f"{B['proposals']} distinct proposals evaluated, none passed")
        if fz.get("coop"):
            coop_round()
        msgs = prompt(rec, dev)
        n, body, res, _ = ask(msgs)
        if not body:
            continue
        h = _sha(body)
        if h in seen:
            rec["calls"][-1]["duplicate_of"] = h
            best = rec.get("best_feedback")  # a repeat must not leave the prompt unchanged: say so, keep the best dev failures
            rec["feedback"] = ("your reply repeated an earlier proposal exactly; write different code that fixes the failures listed" + ("\n" + best["text"] if best else ""))[:2200]
            _save(s, rec)
            continue
        seen.add(h)
        _spend(s, rec, proposals=1)
        prop = {"n": n, "sha256": h, "static": _static(harness, c, rec, body), "dev": None, "acceptance": None}
        rec["proposals"].append(prop)
        _write_lf(outdir / f"cand-{h}.py", body)
        if prop["static"]:
            static_feedback(prop)
            continue
        dev_check(prop, body)
        if prop["dev"]["pass_count"] != prop["dev"]["n"]:
            continue
        if sealed:  # public final: dev-perfect ends the experiment; no hidden gate, no acceptance field, nothing hidden-derived anywhere
            rec.update(candidate_sha256=h, final={"sha256": h, "dev_pass": prop["dev"]["pass_count"], "n": prop["dev"]["n"]})
            raise _End("PUBLIC_CANDIDATE_FROZEN", "dev-perfect: frozen as the public final candidate; hidden scoring is the evaluator's, after freeze")
        hidden(prop, h, body)


def _authored_gap(store, cap_id):
    """The capability's own authored-route gap (shared by the authored and sealed-final acceptance routes). Returns the gap key."""
    c = CC.get(cap_id)
    if CC.is_v2(c) and c["execution"]["environment_ref"]["kind"] == "derived":
        raise Refused("operator-authored bodies do not support derived-environment capabilities")
    ts, ar = c["inputs"]["types"], c["inputs"]["arity"]
    sig = {"in": min(ts), "ins": sorted(ts), "arity": len(ts), "out": c["outputs"]["type"]} if len(set(ts)) > 1 else \
        {"in": ts[0], "arity": ar[0], "ordered": True, "out": c["outputs"]["type"]}
    gap_key = "operator/gap/authored-" + _sha(cap_id)[:16]
    with _txn(store):
        g = store.get(gap_key) or {"unmet_type": sig["out"], "input_types": sorted(ts), "goal_ids": [], "count": 0, "status": "OPEN", "discovery": "operator-authored route"}
        g["missing_step"] = sig
        store.set(gap_key, g)
    return gap_key


def open_authored(store, cap_id, author, body):
    """Operator-authored route: freeze an experiment for an existing contract whose body the operator wrote. No proposer, no model call (budget calls 0).
    The same gates then run in run_experiment -> _authored. Only pinned-environment contracts (a derived one needs a staged tool environment)."""
    author = str(author or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9 ._@-]{1,64}", author):
        raise Refused("author label must be 1-64 chars of letters, digits, space . _ @ -")
    if not isinstance(body, str) or not body.strip() or len(body) > 200000:
        raise Refused("body must be non-empty Python text (<= 200000 chars)")
    gap_key = _authored_gap(store, cap_id)
    return open_experiment(store, gap_key, capability_id=cap_id, authored={"route": "operator-authored", "author": author, "body_sha256": _sha(body)}, authored_body=body,
                           budget={"calls": 0, "proposals": 1, "in_tokens": 0, "out_tokens": 0})


def _ro_get(db_path, key):
    """One kv value from a store this process must not modify (sqlite read-only + immutable: no WAL/shm file is created)."""
    con = sqlite3.connect("file:" + Path(db_path).resolve().as_posix() + "?mode=ro&immutable=1", uri=True)
    try:
        row = con.execute("SELECT value FROM kv WHERE key=?", (key,)).fetchone()
    finally:
        con.close()
    return json.loads(row[0]) if row else None


def open_sealed_acceptance(store, campaign_store, receipt_path):
    """Sealed-final acceptance route: a final candidate a sealed campaign froze (receipt + body, read-only) is opened as a STANDARD experiment in `store`
    (fresh private hidden set, scripted baseline, static + dev + separate-process hidden gate) and run through _authored: no proposer, no model call (budget calls 0).
    The campaign's model is recorded in frozen["proposer"]["model"] and frozen["sealed_final"]; the signed statement keeps route "learned"."""
    campaign_store = Path(campaign_store)
    try:
        r = json.loads(Path(receipt_path).read_text(encoding="utf-8"))
        if r.get("schema") != "hive-sealed-final-receipt-v1" or r.get("policy") != SEALED:
            raise Refused("not a sealed-final receipt")
        if _sha(json.dumps({k: v for k, v in r.items() if k != "receipt_sha256"}, sort_keys=True, separators=(",", ":"))) != r.get("receipt_sha256"):
            raise Refused("sealed-final receipt does not recompute its sha")
        bp = (campaign_store / str(r.get("body_path"))).resolve()
        if campaign_store.resolve() not in bp.parents:
            raise Refused("receipt body path leaves the campaign store")
        body = _read_lf(bp)
        if not r.get("final_sha256") or _sha(body) != r["final_sha256"]:
            raise Refused("campaign body does not hash to the receipt's final_sha256")
        e = _ro_get(campaign_store / "hive.sqlite3", KEY + str(r.get("exp_id")))
    except Refused:
        raise
    except (OSError, ValueError, KeyError, sqlite3.Error) as ex:
        raise Refused(f"sealed-final receipt or campaign store unreadable: {type(ex).__name__}") from None
    fz = (e or {}).get("frozen") or {}
    if e is None or fz.get("eval_policy") != SEALED_POLICY or e.get("frozen_sha") != r.get("frozen_sha") or e.get("exp_id") != r["exp_id"]:
        raise Refused("campaign experiment is missing, not sealed-policy, or does not match the receipt's frozen_sha")
    cap = r.get("capability")
    if (fz.get("contract") or {}).get("capability_id") != cap:
        raise Refused("receipt capability does not match the campaign experiment")
    gap_key = _authored_gap(store, cap)
    sf = {"receipt_sha256": r["receipt_sha256"], "campaign_exp_id": e["exp_id"], "campaign_frozen_sha": e["frozen_sha"], "body_sha256": r["final_sha256"],
          "proposer_model": fz["proposer"]["model"], "screen": "backend_screen_v1"}
    return open_experiment(store, gap_key, capability_id=cap, sealed_final=sf, authored_body=body, budget={"calls": 0, "proposals": 1, "in_tokens": 0, "out_tokens": 0})


def _authored(s, rec, outdir, clock, stop_path, private_dir, c, harness, dev):
    """The authored body through the SAME gates as a proposed candidate (static check, public dev cases, separate-process evaluator + receipt re-check).
    Spends container runs only: never a model call or a proposal."""
    fz, body = rec["frozen"], rec.get("authored_body") or ""
    a = fz.get("authored") or fz["sealed_final"]
    h = _sha(body)
    if h != a["body_sha256"]:
        raise _End("INTERRUPTED", "authored body does not match the frozen protocol")
    prop = {"n": 1, "sha256": h, "static": _static(harness, c, rec, body), "dev": None, "acceptance": None}
    rec["proposals"] = [prop]
    _write_lf(outdir / f"cand-{h}.py", body)
    if prop["static"]:
        raise _End("NO_QUALIFYING_CANDIDATE", "static check refused the authored body: " + "; ".join(prop["static"]))
    _gate(s, rec, clock, stop_path, container_runs=1)
    _spend(s, rec, container_runs=1)
    try:
        prop["dev"], text = _dev_run(body, dev, harness, _wall(s, rec, 60), **CC.exec_args(c, fz.get("environment")))
    except Exception as e:
        prop["dev"], text = {"n": len(dev), "pass_count": 0}, f"crashed or timed out: {type(e).__name__}: {str(e)[:200]}"
    _save(s, rec)
    if prop["dev"]["pass_count"] != prop["dev"]["n"]:
        raise _End("NO_QUALIFYING_CANDIDATE", f"public dev cases {prop['dev']['pass_count']}/{prop['dev']['n']}: {text[:300]}")
    _gate(s, rec, clock, stop_path, container_runs=1)
    _spend(s, rec, container_runs=1)
    r, path = _evaluate(rec, outdir, outdir / f"cand-{h}.py", "candidate", private_dir, outdir / rec["baselines"]["scripted"]["receipt_path"], _wall(s, rec, 120))
    prop["acceptance"] = _summ(r)
    _save(s, rec)
    if r["verdict"] != "PASS":
        raise _End("NO_QUALIFYING_CANDIDATE", f"hidden acceptance {r['pass_count']}/{r['n']} (details withheld)")
    rec.update(candidate_sha256=h, receipt=dict(_summ(r), path=path.name), report={
        "candidate_sha256": h, "evaluator_receipt_sha256": r["receipt_sha256"], "pass_count": r["pass_count"], "n": r["n"], "baselines": rec["baselines"],
        "note": f"Operator-authored by {a['author']}: NOT autonomous discovery. Awaiting admission." if "author" in a else
        f"Sealed-final body from campaign experiment {a['campaign_exp_id']} (model {a['proposer_model']}), re-gated on a fresh hidden set. Awaiting admission."})
    raise _End("CANDIDATE_PASSED", "independent evaluator PASS; awaiting admission")


def _note_feedback(rec, n, passes, total, text, body=None):
    """Keep the dev feedback of the BEST proposal so far (most dev passes, the latest on a tie) as the feedback the next prompt shows."""
    best = rec.get("best_feedback")
    if body is not None and (rec.get("best") is None or passes >= rec["best"]["dev_pass"]):
        rec["best"] = {"sha256": _sha(body), "dev_pass": min(passes, total), "body": body}
    if best is None or passes >= best["passes"]:
        best = rec["best_feedback"] = {"n": n, "passes": passes, "text": f"(proposal {n}, {min(passes, total)} of {total} dev cases passed) {text}"[:2000]}
    rec["feedback"] = best["text"]


def _dispatched(s, rec, outdir, d, model=None, error=None, **extra):
    """One append-only dispatch record (JSONL beside the model log) plus a copy on the experiment record."""
    row = (model.ledger() or [{}])[-1] if model else {}
    u = row.get("usage") or {}
    r = MD.record(outdir / "model", {k: v for k, v in d.items() if k != "context"}, reported_model=row.get("response_model"), latency_s=row.get("latency_s"),
                  tokens_in=u.get("prompt_tokens"), tokens_out=u.get("completion_tokens"), error=error, called=bool(row),
                  **({"cost_usd": None, "cost_source": "usage ledger (hosted, priced)"} if model and model.hosted else {}), **extra)
    rec.setdefault("dispatches", []).append(r)
    _save(s, rec)


def recover(store_root):
    """After a crash: RUNNING experiments (not owned by another live process) become INTERRUPTED. Resume keeps the same ledger."""
    s, n = Store(store_root), 0
    try:
        for e in experiments(s):
            pid = e.get("pid")
            if e["state"] == "RUNNING" and not (isinstance(pid, int) and pid != os.getpid() and _alive(pid)):
                e["state"] = "INTERRUPTED"
                e["stages"].append({"stage": "interrupted", "at": _now()})
                _save(s, e)
                n += 1
        return n
    finally:
        s.close()
