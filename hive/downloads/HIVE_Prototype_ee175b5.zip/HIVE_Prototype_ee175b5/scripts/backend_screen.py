"""Backend screen: local gpt-oss vs hosted nemotron on the public_feedback_sealed_final_v1 policy, through scripts/g3_qualify.acquire_gap (the production campaign driver).

  python scripts/backend_screen.py --out DIR --private-root DIR [--inputs DIR] [--dry-run | --live]

Frozen manifest (screen-manifest.json): 2 caps (site.ref-extract, site.ref-resolve) x 2 backends (local openai/gpt-oss-20b, hosted nemotron via M.apply_backend and its approval)
x 2 repeats = 4 paired blocks = 8 campaigns, <= 72 calls (<= 3 experiments x <= 3 calls per campaign), temperature 0.2 on both, order alternating local-first / hosted-first by block.
Each block has ONE hidden manifest (evaluator/coop/sealed_final.py prepare, run as its own process BEFORE any generation); both backends of a block share its hash, a seed_base and
the same frozen start state, each in a fresh isolated store (no cross-backend carry-best). Before each block the WHOLE block is reserved in <out>/screen-ledger.json (campaigns,
experiments, calls, out tokens, container runs, hosted worst-case USD checked against the hosted ledger); if it does not fit the screen stops cleanly. A restart never resets the
ledger and never dispatches a started campaign again: it stays recorded as an incomplete pair (no replacement reruns). <out>/batch.json (campaign, store, final receipt sha) is what
`python -I evaluator/coop/sealed_final.py score` takes, after every final receipt exists. Default is --dry-run on the stub server (canned replies, no model, no network); --live is explicit."""
from __future__ import annotations

import argparse
import json
import os
import sys
import threading
import time
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))
import coop_pilot as P  # noqa: E402
import g3_qualify as Q  # noqa: E402
from hive import capcontract as CC, discovery as D, m2_model as M, operator_runtime as O  # noqa: E402
from hive.bounded import run_bounded  # noqa: E402
from hive.storage import Store  # noqa: E402
from hive.usage_ledger import HostedLedger  # noqa: E402

SCREEN = "backend_screen_v1"
CAPS = ("site.ref-extract", "site.ref-resolve")
BACKENDS = {"local": "openai/gpt-oss-20b", "hosted": "nvidia/nemotron-3.5-super-vl-120b-a12b"}
REPEATS, TEMPERATURE = 2, 0.2
PER_BLOCK = {"campaigns": 2, "experiments": 6, "calls": 18, "out_tokens": 36000, "container_runs": 6 * Q.EXP_BUDGET["container_runs"]}  # container runs: the frozen caps, not the (lower) expected use
LIMITS = {k: v * REPEATS * len(CAPS) for k, v in PER_BLOCK.items()}  # 8 campaigns, 24 experiments, 72 calls, 144000 out tokens
HOSTED_CALL_TOKENS_IN = Q.EXP_BUDGET["max_prompt_tokens"] * 4 + 1024 + 256  # the client prices a prompt's bytes as tokens (worst case), plus its margin


def sha(x):
    return Q.sha(x if isinstance(x, str) else json.dumps(x, sort_keys=True, separators=(",", ":")))


def _write(path, obj):
    tmp = Path(str(path) + ".tmp")
    tmp.write_text(json.dumps(obj, sort_keys=True, indent=1), encoding="utf-8", newline="\n")
    os.replace(tmp, path)


class Locked:
    """ponytail: one lock file for the screen state; a crashed holder needs the file deleted by hand. Fine for one operator on one machine."""

    def __init__(self, path): self.path = Path(str(path) + ".lock")

    def __enter__(self):
        for _ in range(200):
            try:
                self.fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                return self
            except FileExistsError:
                time.sleep(0.05)
        raise SystemExit(f"screen ledger is locked: {self.path}")

    def __exit__(self, *e):
        os.close(self.fd)
        os.unlink(self.path)


# ---------------------------------------------------------------- manifest freeze
def worst_case_usd(cfg):
    """Hosted worst case of ONE block: its 9 hosted calls, each reserving a full prompt (bytes as tokens) and the 4096-token output cap, at the config's price."""
    price = cfg["pricing"][BACKENDS["hosted"]]
    per = (HOSTED_CALL_TOKENS_IN * price["fresh_input"] + Q.EXP_BUDGET["max_tokens_per_call"] * price["output"]) / 1e6
    return round(per * PER_BLOCK["calls"] / 2, 6)


def freeze(a, cfg):
    """Check every backend can honour the frozen temperature and (live) is approved, prepare the four hidden manifests, and write/verify the frozen manifest."""
    out = Path(a.out)
    base, blocks, backends = D.pol(), [], {}
    for name, mid in BACKENDS.items():
        p = M.apply_backend(base, None if mid == base["model"]["id"] else mid, cfg)
        m = M.Model(out / "freeze-check" / name, stub=True, endpoint="http://127.0.0.1:1/v1", pol=p, dispatch_cfg=cfg)  # request body only: nothing is sent
        got = m.body([{"role": "user", "content": "x"}], 1).get("temperature")
        if got != TEMPERATURE:
            raise SystemExit(f"backend {name} ({mid}) cannot honour temperature {TEMPERATURE}: its request carries {got!r}")
        ap = ROOT / p["approval_path"]
        if a.live and (bad := M.approval_problems(ap, p)):
            raise SystemExit(f"backend {name} approval refused: {'; '.join(bad)}")
        backends[name] = {"model": mid, "approval_path": p["approval_path"], "approval_file_sha256": sha(ap.read_bytes().decode("utf-8", "replace")) if ap.is_file() else None,
                          "hosted": bool(p["model"].get("hosted")), "temperature": got}
    for i, (cap, rep) in enumerate((c, r) for c in CAPS for r in range(1, REPEATS + 1)):
        block = f"{cap}.r{rep}"
        rc, o, e, t = run_bounded([sys.executable, "-I", str(ROOT / "evaluator" / "coop" / "sealed_final.py"), "prepare", "--block", block, "--cap", cap, "--private", str(a.private_root)], timeout=180)
        if rc or t:
            raise SystemExit(f"hidden manifest for {block} could not be prepared: {(e or o)[-200:]}")
        pub = json.loads(o.strip().splitlines()[-1])
        blocks.append({"block_id": block, "cap": cap, "repeat": rep, "order": ["local", "hosted"] if i % 2 == 0 else ["hosted", "local"], "seed_base": 500000 * (i + 1),
                       "manifest": {"id": pub["manifest_id"], "sha256": pub["manifest_sha256"]}})
    specs = "".join(CC.text_ref(CC.get(c)["proposer"]["behaviour_spec_ref"]) for c in CAPS)
    m = {"schema": SCREEN, "policy": D.SEALED, "caps": list(CAPS), "backends": backends, "repeats": REPEATS, "temperature": TEMPERATURE, "exp_budget": Q.EXP_BUDGET,
         "limits": LIMITS, "per_block": PER_BLOCK, "hosted_worst_case_usd_per_block": worst_case_usd(cfg), "prompt_version": sha(D.SYSTEM + specs), "blocks": blocks}
    m["manifest_sha256"] = sha(m)
    mp = out / "screen-manifest.json"
    if mp.is_file():  # a restart: the frozen manifest must be exactly what was frozen (the hidden ids come back identical)
        if json.loads(mp.read_text(encoding="utf-8"))["manifest_sha256"] != m["manifest_sha256"]:
            raise SystemExit("the frozen screen manifest changed since the first start: use a fresh --out")
    else:
        _write(mp, m)
    return m


# ---------------------------------------------------------------- ledger: reserve a whole block, never reset
def hosted_ledger_path(cfg):
    return ROOT / os.path.expandvars(os.path.expanduser(cfg["budget"]["ledger"]))


def load_state(out, m):
    p = Path(out) / "screen-ledger.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.is_file() else {"schema": SCREEN, "manifest_sha256": m["manifest_sha256"], "blocks": {}, "campaigns": {}}


def reserve_block(a, m, cfg, ledger, block):
    """Atomically reserve the WHOLE block or refuse (a reason string). Reserved amounts stay counted whatever the block then uses."""
    with Locked(Path(a.out) / "screen-ledger.json"):
        st = load_state(a.out, m)
        if block["block_id"] in st["blocks"]:
            return st, None
        used = {k: sum(b["reserved"][k] for b in st["blocks"].values()) for k in PER_BLOCK}
        over = [k for k in PER_BLOCK if used[k] + PER_BLOCK[k] > LIMITS[k]]
        if over:
            return st, f"screen limit would be crossed: {over}"
        usd = m["hosted_worst_case_usd_per_block"]
        with ledger.locked():
            if a.live:
                ledger.check()
            t = ledger.totals()
            spent = t["usd_measured"] + t["usd_estimated"] + ledger.outstanding_reserved_usd()
        if spent + usd > cfg["budget"]["remaining_usd"] + 1e-12:
            return st, f"hosted budget: ${spent:.4f} spent/reserved + ${usd:.4f} worst case exceeds ${cfg['budget']['remaining_usd']:.2f}"
        st["blocks"][block["block_id"]] = {"status": "reserved", "reserved": dict(PER_BLOCK, usd=usd), "reserved_at": D._now()}
        st["campaigns"].update({f"{block['block_id']}.{b}": {"block_id": block["block_id"], "backend": b, "status": "pending"} for b in block["order"]})
        _write(Path(a.out) / "screen-ledger.json", st)
        return st, None


def save(a, m, fn):
    with Locked(Path(a.out) / "screen-ledger.json"):
        st = load_state(a.out, m)
        fn(st)
        _write(Path(a.out) / "screen-ledger.json", st)
        return st


def write_batch(a, st):
    rows = [{"campaign_id": cid, "block_id": c["block_id"], "cap": c["cap"], "backend": c["backend"], "store": c["store"], "receipt_sha256": c.get("receipt_sha256"),
             "status": "incomplete" if c["status"] == "incomplete" else "done"} for cid, c in sorted(st["campaigns"].items()) if c["status"] in ("final", "incomplete") and c.get("store")]
    _write(Path(a.out) / "batch.json", {"schema": SCREEN, "batch_id": sha(st["manifest_sha256"])[:16], "campaigns": rows})


# ---------------------------------------------------------------- run
def run_campaign(a, m, block, backend, cap):
    cid = f"{block['block_id']}.{backend}"
    store = Path(a.out) / "stores" / cid
    save(a, m, lambda st: st["campaigns"][cid].update(status="started", store=str(store), cap=cap, started_at=D._now()))  # recorded BEFORE any dispatch: a restart can never re-dispatch it
    store.mkdir(parents=True)
    s = Store(store)
    try:
        O.import_bundle(s)
    finally:
        s.close()
    goal, files = P.CAPS[cap]
    ins = [(f, "file", (Path(a.inputs) / P.OLD / f).read_bytes()) for f in files]
    srv = url = None
    if not a.live:  # dry run: this campaign's own stub (the cap's oracle as a candidate), serving the backend's model id
        import m2_stub_server as STUB
        srv = STUB.make_server({"R": P.stub_replies(cap)}, 0, str(Path(a.out) / f"stub-requests-{cid}.jsonl"), model_id=BACKENDS[backend])
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        url = f"http://127.0.0.1:{srv.server_port}/v1"
    ns = SimpleNamespace(private=None, model=BACKENDS[backend], stub_endpoint=url, admit_key=None, manifest=block["manifest"])
    try:
        r = Q.acquire_gap(ns, str(store), cid, cap, goal, ins, seed_base=block["seed_base"], policy=D.SEALED)
    except KeyboardInterrupt:
        save(a, m, lambda st: st["campaigns"][cid].update(status="incomplete", reason="interrupted"))
        raise
    finally:
        if srv:
            srv.shutdown()
    fr, cost = r.get("final_receipt"), r.get("cost") or {}
    save(a, m, lambda st: st["campaigns"][cid].update(status="final" if fr else "incomplete", state=r["state"], receipt_sha256=fr and fr["sha256"], receipt=fr and fr["path"],
                                                       ledger=cost, finished_at=D._now()))
    return r


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--out", required=True)
    ap.add_argument("--private-root", required=True)
    ap.add_argument("--inputs", default="D:/HIVE-operator-inputs/mom-site/exports")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--dry-run", action="store_true", help="the default: stub server, canned replies, no model, no network")
    g.add_argument("--live", action="store_true", help="real local model and hosted NIM (needs the active approvals, NVIDIA_API_KEY and the hosted ledger)")
    ap.add_argument("--admission", help="opt-in: a frozen resource profile JSON; the screen stops cleanly (no reservation, no calls) when the PC is over it")
    a = ap.parse_args(argv)
    out, priv = Path(a.out).resolve(), Path(a.private_root).resolve()
    if priv == out or out in priv.parents or priv in out.parents:
        raise SystemExit("--private-root must be outside --out (and so outside every store)")
    a.out, a.private_root = str(out), str(priv)
    out.mkdir(parents=True, exist_ok=True)
    cfg = M._dispatch_cfg()
    m = freeze(a, cfg)
    if a.live:
        ledger = HostedLedger(hosted_ledger_path(cfg), cfg["pricing"])
    else:  # dry run: the same ledger code path on a scratch ledger, never the project one
        ledger = HostedLedger(out / "dry-hosted-ledger.jsonl", cfg["pricing"])
        if not ledger.path.exists():
            ledger.init()
    stopped = None
    # restart: a campaign that was started and has no final receipt is an incomplete pair, never rerun
    def mark(st):
        for c in st["campaigns"].values():
            if c["status"] == "started":
                c.update(status="incomplete", reason="interrupted before its final receipt (not rerun)")
    save(a, m, mark)
    prof, last = (json.loads(Path(a.admission).read_text(encoding="utf-8")) if a.admission else None), None
    prof = prof and prof.get("admission", prof)  # a frozen hive-admission-profile-v1 document carries its thresholds under "admission"
    for block in m["blocks"]:
        adm = None
        if prof and block["block_id"] not in load_state(a.out, m)["blocks"]:
            import resource_profile as RP
            s0 = last
            if s0 is None:
                s0 = RP.sample()
                time.sleep(10)
            s1 = RP.sample()
            ok, reasons = RP.admission(prof, s0, s1)
            adm = {"s0": s0, "s1": s1, "ok": ok, "reasons": reasons}
            if not ok:
                stopped = f"{block['block_id']}: admission: {reasons}"
                save(a, m, lambda s, b=block["block_id"]: s.setdefault("admission_stops", {}).update({b: adm}))
                break
        st, why = reserve_block(a, m, cfg, ledger, block)
        if why:
            stopped = f"{block['block_id']}: {why}"
            break
        if st["blocks"][block["block_id"]]["status"] != "reserved":
            continue
        for backend in block["order"]:
            st = load_state(a.out, m)
            if st["campaigns"][f"{block['block_id']}.{backend}"]["status"] != "pending":
                continue
            if any(c["status"] == "incomplete" for k, c in st["campaigns"].items() if c["block_id"] == block["block_id"]):  # the pair is already broken: the partner is not run
                save(a, m, lambda s, k=f"{block['block_id']}.{backend}": s["campaigns"][k].update(status="not_run", reason="its pair is incomplete"))
                continue
            run_campaign(a, m, block, backend, block["cap"])
            st = load_state(a.out, m)
            write_batch(a, st)
        if prof:
            import resource_profile as RP
            last = RP.sample()
            adm = dict(adm or {}, after=last)
            save(a, m, lambda s, b=block["block_id"]: s["blocks"][b].update(admission=adm))
        save(a, m, lambda s, b=block["block_id"]: s["blocks"][b].update(status="incomplete" if any(c["status"] != "final" for c in s["campaigns"].values() if c["block_id"] == b) else "done"))
    st = load_state(a.out, m)
    write_batch(a, st)
    calls = sum((c.get("ledger") or {}).get("calls", 0) for c in st["campaigns"].values())
    summary = {"mode": "live" if a.live else "dry-run", "manifest_sha256": m["manifest_sha256"], "campaigns": len(st["campaigns"]), "calls": calls, "max_calls": LIMITS["calls"], "stopped": stopped,
               "rows": {cid: {k: c.get(k) for k in ("status", "state", "receipt_sha256", "block_id", "backend")} for cid, c in sorted(st["campaigns"].items())},
               "score": f"python -I evaluator/coop/sealed_final.py score --batch {out / 'batch.json'} --private {priv} --public-out <file outside both>"}
    _write(out / "screen-summary.json", summary)
    print(json.dumps({k: summary[k] for k in ("mode", "campaigns", "calls", "max_calls", "stopped")} | {"summary": str(out / "screen-summary.json")}, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
