"""G3 qualification: capability composition. The store already holds an admitted picture-matching capability (a copy of the G2 gate store).

  python scripts/g3_qualify.py --phase acquire   --store S --out DIR [--admit-key PATH] [--model ID] [--private DIR] [--seed N]
  python scripts/g3_qualify.py --phase composite --store S --out DIR --unseen-seed N        (the held-out composite goal, retained capabilities only)
  python scripts/g3_qualify.py --phase repeat    --store S --out DIR --unseen-seed M        (run again in a NEW process with another unseen seed)
  python scripts/g3_qualify.py --phase baseline  --store B --out DIR --unseen-seed N [--acquire-manifest DIR/manifest.json]
                                                    (B = a store copy WITHOUT the retained capabilities; same goal, records what happens)

acquire    two typed gaps (a property table of picture files; a report from one manifest and one property table) go through the normal path: goal with
           discovery -> typed gap -> experiment (contract found by the gap signature) -> local model with repair/carry-best (a second experiment is seeded
           with the best candidate of the first) -> independent evaluator -> admission (only with --admit-key; otherwise the admit command is printed).
composite  ONE goal whose deliverable no capability produces by itself and for which no route exists in any code: the planner composes the retained
           capabilities (fan-out over the pictures, join by type) and run_goal executes it with per-step independent verification. Zero model calls.
           Recorded: plan and ranking, estimated cost, per-step receipts (cached replay vs fresh execution), model calls, wall time, and a final check by the
           suites' own oracles applied to the oracle outputs of the upstream steps.
repeat     same as composite in a fresh process on another unseen seed (a seed already used in this run's manifest is refused).
baseline   the same goal where nothing is retained: what the planner says, whether acquisition is possible, what it would cost (from the acquire manifest).
Writes <out>/manifest.json (cumulative over phases). The fixture author is a conductor-side agent, not Ian. Seeds are recorded only as hashes."""
from __future__ import annotations

import argparse
import base64
import copy
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))
import g2_qualify as Q  # noqa: E402
from hive import capability_registry as CR, capcontract as CC, discovery as D, goal_runner as G, model_choice as MC, operator_runtime as O  # noqa: E402
from hive.storage import Store  # noqa: E402

MATCH, PROPS, RECON = "image.asset-match", "asset.properties", "report.reconcile"
GOALS = {"properties": "Write the image properties table for these pictures", "reconcile": "Write a reconciliation report using these two files",
         "composite": "Write a reconciliation report: which of these pictures are copies, and how much space can I reclaim?"}
SCHEMA = "hive-g3-run-v1"
sha, DISCLOSURE = Q.sha, Q.DISCLOSURE


def oracle(cap):
    return CC.load_module("oracle", CC.get(cap)).expected


def _file(name, text):
    return {"name": name, "format": "base64", "data": base64.b64encode(text.encode("utf-8")).decode("ascii")}


def picture_env(seed):
    return CC.load_module("gen_private", CC.get(MATCH)).generate(seed, 1)[0]["env"]


def pictures(seed):
    return [(f["name"], "file", base64.b64decode(f["data"])) for f in picture_env(seed)["files"]]


def upstream_outputs(seed):
    """What each upstream capability's own oracle says for this picture set, and the final report the reconcile oracle derives from them."""
    env = picture_env(seed)
    manifest, table = oracle(MATCH)(env), oracle(PROPS)(env)
    return manifest, table, oracle(RECON)({"files": [_file("manifest.json", manifest), _file("properties.json", table)]})


def snapshot(store):
    s = Store(store)
    try:
        return {"counters": O._counters(s), "experiments": len(D.experiments(s))}
    finally:
        s.close()


def retained(store, cap):
    s = Store(store)
    try:
        r = CR.resolve_discovered(s, cap)
        return {"cap_id": cap, "version": r["version"], "statement_sha": r["statement_sha"]}
    except O.Refused:
        return None
    finally:
        s.close()


# ---------------------------------------------------------------- acquire
CAMPAIGN = "g3-composition-campaign"
EXP_BUDGET = {"calls": 3, "proposals": 3, "container_runs": 10, "in_tokens": 24000, "out_tokens": 6000, "wall_s": 900, "max_tokens_per_call": 4096,
              "max_prompt_tokens": 8000}


def acquire_gap(a, store, label, cap, goal, ins, coop=None, seed_base=None, policy=None):
    """coop: a discovery coop recipe id (cooperative round per experiment); seed_base: shifts every proposer seed (a distinct repeat). Both None = as before.
    policy: D.SEALED = public-feedback / sealed-final campaign (see _sealed_campaign): no hidden gate, no admission, one frozen final receipt."""
    out = {"label": label, "capability": cap, "goal": goal}
    have = retained(store, cap)
    if have:
        return dict(out, state="ALREADY_RETAINED", retained=have)
    mc = None
    if a.model == "auto":  # opt-in: HIVE ranks the eligible backends from measured outcomes and records the choice in each frozen protocol; a failed campaign only HINTS the next one
        mc = MC.choose(cap, store_id=_store_id(store))
        if mc["backend"] is None:
            return dict(out, state="MODEL_UNAVAILABLE", model_choice=mc)
        a = copy.copy(a)
        a.model = mc["backend"]
        out["model_choice"] = mc
    # The goal records the typed gap without auto-opening discovery: the store-wide ad-hoc discovery allowance (discovery.BUDGET via the
    # global ledger) belongs to operator one-offs. G3 acquisitions run as a declared campaign (acq_run = CAMPAIGN) with the same frozen
    # per-experiment budget an acquisition attempt gets (within discovery.APPROVAL_CAPS), recorded in the manifest.
    r = G.run_goal(store, G.make_contract(goal, ins, allow_discovery=False), ins)
    out.update(goal_id=r["goal_id"], goal_state=r["state"], reason=r["reason"], gap_ref=r.get("gap_ref"), missing_step=r.get("missing_step"),
               campaign=CAMPAIGN, experiment_budget=EXP_BUDGET)
    if not r.get("gap_ref"):
        return dict(out, state="GOAL_NOT_QUEUED")
    if policy:
        return _escalate(_sealed_campaign(a, store, out, r["gap_ref"], seed_base, mc), mc)
    s = Store(store)
    try:
        exp = D.open_experiment(s, r["gap_ref"], private_dir=a.private, budget=dict(EXP_BUDGET), acq_run=CAMPAIGN, proposer_model=a.model, coop=coop, seed_base=seed_base, model_choice=mc)["exp_id"]
    finally:
        s.close()
    attempts, kw, fb = [], dict({"requested_model": a.model} if a.model else {}, **({"stub_endpoint": a.stub_endpoint} if a.stub_endpoint else {})), None
    for n in range(3):  # at most three experiments per gap; each later one is seeded with the best candidate so far (repair / carry-best)
        t0 = time.monotonic()
        d = D.run_experiment(store, exp, private_dir=a.private, **kw)
        attempts.append({"exp_id": exp, "state": d["state"], "reason": d.get("reason"), "ledger": d["ledger"], "wall_s": round(time.monotonic() - t0, 1),
                         "receipt": d.get("receipt") and {k: d["receipt"].get(k) for k in ("pass_count", "n", "verdict", "receipt_sha256")},
                         "best_dev_pass": (d.get("best") or {}).get("dev_pass"), "seeded_with_best": n > 0, **({"fallback": fb[1]} if fb and n == fb[2] else {})})
        alt = None if fb or n == 2 else _fallback(mc, d)
        if d["state"] == "CANDIDATE_PASSED" or n == 2 or (d["state"] not in ("NO_QUALIFYING_CANDIDATE", "BUDGET_EXHAUSTED") and not alt):
            break
        nxt, bud = (alt[0], dict(EXP_BUDGET, calls=1, proposals=1)) if alt else (mc, dict(EXP_BUDGET))
        if alt:  # ONE alternate experiment (calls=1, proposals=1) inside the existing slot count, frozen to the alternate backend
            fb, a, kw, mc = (alt[0], alt[1], n + 1), _with_model(a, alt[0]["backend"]), dict(kw, requested_model=alt[0]["backend"]), alt[0]
        s = Store(store)
        try:
            best = d.get("best")
            exp = D.open_experiment(s, r["gap_ref"], private_dir=a.private, budget=bud, acq_run=CAMPAIGN, proposer_model=a.model, coop=coop, seed_base=seed_base, model_choice=nxt,
                                    seed_best={"body": best["body"], "dev_pass": best["dev_pass"], "feedback": d.get("feedback") or ""} if best else None)["exp_id"]
        finally:
            s.close()
    out.update(attempts=attempts, cost=tally_attempts(attempts), state=attempts[-1]["state"])
    if attempts[-1]["state"] == "CANDIDATE_PASSED":
        exp_id = attempts[-1]["exp_id"]
        if a.admit_key:
            import hive_admission as H
            out["admission"] = H.admit(store, exp_id, a.admit_key)
            out["state"] = "ADMITTED"
        else:
            out["next"] = f"python scripts/hive_admission.py admit --store {store} --exp {exp_id} --key <external key>   (then repeat this phase: already-retained gaps are skipped)"
    return _escalate(out, mc)


def _store_id(store):
    try:
        s = Store(store)
        try:
            return CR.store_uuid(s)
        finally:
            s.close()
    except Exception:  # identity is a receipt nicety, never a reason to fail routing
        return None


def _with_model(a, model):
    a = copy.copy(a)
    a.model = model
    return a


def _fallback(mc, d):
    """Auto-routed goals only (mc is None when the model was pinned): after a RETRYABLE end, ONE alternate = the next ranked backend after the current one.
    -> (model_choice copy frozen to the alternate, {"from", "to", "reason_code"}) or None. Callers allow it once per goal."""
    if not mc or d["state"] != "MODEL_UNAVAILABLE":
        return None
    cls, code = MC.classify(d["state"], d.get("reason"))
    names = [r["backend"] for r in mc["rank"]]
    if cls != "retryable" or mc["backend"] not in names or mc["backend"] == names[-1]:
        return None
    alt = names[names.index(mc["backend"]) + 1]
    return (dict(mc, backend=alt, fallback_of={"backend": mc["backend"], "class": cls, "reason_code": code}),
            {"from": mc["backend"], "to": alt, "reason_code": code})


def _escalate(out, mc):
    """Auto mode only: a campaign without a dev-perfect public final (or MODEL_UNAVAILABLE) names the next ranked backend as "escalate_to". It starts nothing:
    another campaign is a separate, owner-gated call (caps and spend gates are unchanged)."""
    if mc and out["state"] not in ("PUBLIC_CANDIDATE_FROZEN", "CANDIDATE_PASSED", "ADMITTED"):
        names = [r["backend"] for r in mc["rank"]]  # never name a backend this campaign already used (original or fallback)
        used = {mc["backend"], (mc.get("fallback_of") or {}).get("backend")} | {x["fallback"]["to"] for x in out.get("attempts", []) if x.get("fallback")}
        out["escalate_to"] = next((x for x in names[names.index(mc["backend"]) + 1:] if x not in used), None)
    return out


SEALED_SCHEMA = "hive-sealed-final-receipt-v1"


def receipt_path(store, cap):
    return Path(store) / "campaign" / cap / "final-receipt.json"


def _sealed_campaign(a, store, out, gap_ref, seed_base, mc=None):
    """<= 3 experiments (carry-best by PUBLIC dev pass), stop at the first dev-perfect candidate, then ONE frozen final (best public dev pass; tie: earliest experiment,
    then sha) and its receipt + sha, written before anything is scored. No hidden gate, no hidden data, no admission. Nothing usable -> UNRESOLVED (the receipt says so).
    Restart: a finished campaign returns its receipt without a call; an unfinished one resumes its experiments (the ledgers are kept, nothing is dispatched twice)."""
    cap, rp, t0 = out["capability"], receipt_path(store, out["capability"]), D._now()
    if rp.exists():
        r = json.loads(rp.read_text(encoding="utf-8"))
        return dict(out, state=r["state"], attempts=[], final_receipt={"path": str(rp), "sha256": r["receipt_sha256"]}, resumed=True)
    kw = dict({"requested_model": a.model} if a.model else {}, **({"stub_endpoint": a.stub_endpoint} if a.stub_endpoint else {}))
    s = Store(store)
    try:
        prior = [e["exp_id"] for e in D.experiments(s, gap_ref) if e["frozen"].get("eval_policy") and e["frozen"].get("acq_run") == CAMPAIGN]
    finally:
        s.close()
    attempts, recs, fb, alt = [], [], None, None
    for n in range(3):
        if n < len(prior):
            exp = prior[n]
        else:
            best = recs[-1].get("best") if recs else None
            bud = dict(EXP_BUDGET)
            if alt:  # ONE alternate experiment (calls=1, proposals=1) in this slot, frozen to the next ranked backend
                fb, mc, bud, a, kw = (alt[1], n), alt[0], dict(EXP_BUDGET, calls=1, proposals=1), _with_model(a, alt[0]["backend"]), dict(kw, requested_model=alt[0]["backend"])
            s = Store(store)
            try:
                exp = D.open_experiment(s, gap_ref, budget=bud, acq_run=CAMPAIGN, proposer_model=a.model, seed_base=seed_base, policy=D.SEALED, model_choice=mc,
                                        seed_best={"body": best["body"], "dev_pass": best["dev_pass"], "feedback": recs[-1].get("feedback") or ""} if best else None)["exp_id"]
            finally:
                s.close()
        t1 = time.monotonic()
        d = D.run_experiment(store, exp, **kw)
        recs.append(d)
        attempts.append({"exp_id": exp, "state": d["state"], "reason": d.get("reason"), "ledger": d["ledger"], "wall_s": round(time.monotonic() - t1, 1),
                         "best_dev_pass": (d.get("best") or {}).get("dev_pass"), "seeded_with_best": n > 0, **({"fallback": fb[0]} if fb and n == fb[1] else {})})
        # an unavailable model (one charged timeout, no retry) ends that experiment only; the campaign goes on to its next experiment.
        # Auto mode: a retryable outage moves the NEXT slot to the next ranked backend once; any other outage ends the campaign (no more dispatching).
        alt = None if fb else _fallback(mc, d)
        if d["state"] == "PUBLIC_CANDIDATE_FROZEN" or d["state"] not in ("NO_QUALIFYING_CANDIDATE", "BUDGET_EXHAUSTED", "MODEL_UNAVAILABLE"):
            break
        if mc and d["state"] == "MODEL_UNAVAILABLE" and not alt:
            break
    out.update(attempts=attempts, cost=tally_attempts(attempts))
    if recs[-1]["state"] not in D.TERMINAL:  # interrupted: resumable, no final yet (and so nothing may be scored)
        return dict(out, state="INCOMPLETE")
    cands = sorted((-p["dev"]["pass_count"], i, p["sha256"], rec["exp_id"], p["dev"]["n"]) for i, rec in enumerate(recs) for p in rec["proposals"]
                   if not p.get("static") and (p.get("dev") or {}).get("pass_count", 0) > 0)
    fin = None
    if cands:
        neg, i, h, exp, dn = cands[0]
        bp = Path(store) / "discovery" / exp / f"cand-{h}.py"
        if D._sha(D._read_lf(bp)) == h:
            fin = (h, -neg, dn, exp, bp, recs[i])
    calls, models = [], set()
    for rec in recs:
        mc = Path(store) / "discovery" / rec["exp_id"] / "model" / "model_calls.jsonl"
        calls += [{k: r.get(k) for k in ("seed", "request_sha256", "response_model", "status", "ts")} for r in map(json.loads, mc.read_text(encoding="utf-8").splitlines())] if mc.exists() else []
        models |= {d.get("reported_model") for d in rec.get("dispatches", []) if d.get("reported_model")}
    state = "UNRESOLVED" if fin is None else "PUBLIC_CANDIDATE_FROZEN" if fin[1] == fin[2] else "FINAL_FROZEN"
    if recs[-1]["state"] == "STOPPED":  # operator STOP: the best-so-far is kept but labelled, so the pair is reported as interrupted, never rerun
        state = "INTERRUPTED_" + state
    rcpt = {"schema": SEALED_SCHEMA, "policy": D.SEALED, "label": out["label"], "capability": cap, "state": state, "campaign": CAMPAIGN,
            "final_sha256": fin and fin[0], "final_dev_pass": fin and fin[1], "dev_n": fin and fin[2], "exp_id": fin and fin[3], "frozen_sha": fin and fin[5]["frozen_sha"],
            "body_path": fin and str(fin[4].relative_to(store)).replace("\\", "/"), "experiments": [x["exp_id"] for x in attempts], "ledger": out["cost"],
            "backend": {"requested": a.model or "openai/gpt-oss-20b", "frozen": recs[0]["frozen"]["proposer"]["model"], "returned_models": sorted(models)},
            "calls": calls, "seed_base": seed_base, "manifest": getattr(a, "manifest", None), "started_at": t0, "finalized_at": D._now()}
    rcpt["receipt_sha256"] = sha(json.dumps(rcpt, sort_keys=True, separators=(",", ":")))
    rp.parent.mkdir(parents=True, exist_ok=True)
    tmp = rp.with_suffix(".tmp")
    tmp.write_bytes(json.dumps(rcpt, sort_keys=True, indent=1).encode("utf-8"))
    tmp.replace(rp)  # the receipt is whole or absent; its sha is also returned, so the caller can record it before any scoring
    rp.with_suffix(".sha256").write_text(rcpt["receipt_sha256"], encoding="utf-8")
    return dict(out, state=state, final_receipt={"path": str(rp), "sha256": rcpt["receipt_sha256"]})


def tally_attempts(attempts):
    return {k: round(sum(x["ledger"][k] for x in attempts), 1) for k in ("calls", "proposals", "container_runs", "in_tokens", "out_tokens", "wall_s")}


def phase_acquire(a, m):
    seed = a.seed
    env = picture_env(seed)
    manifest, table, _ = upstream_outputs(seed)
    pair = [("manifest.json", "file", manifest.encode("utf-8")), ("properties.json", "file", table.encode("utf-8"))]
    gaps = [acquire_gap(a, a.store, "properties", PROPS, GOALS["properties"], pictures(seed)),
            acquire_gap(a, a.store, "reconcile", RECON, GOALS["reconcile"], pair)]
    return {"gaps": gaps, "seed_sha256": sha(seed), "pictures": len(env["files"]), "retained_after": {c: retained(a.store, c) for c in (MATCH, PROPS, RECON)},
            "ok": all(g["state"] in ("ADMITTED", "ALREADY_RETAINED") for g in gaps)}


# ---------------------------------------------------------------- composite / repeat / baseline
def run_composite(a, seed, **kw):
    ins = pictures(seed)
    contract = G.make_contract(GOALS["composite"], ins, **kw)
    before, t0 = snapshot(a.store), time.monotonic()
    res = G.run_goal(a.store, contract, ins)
    wall = round(time.monotonic() - t0, 2)
    return contract, res, before, snapshot(a.store), wall


def phase_composite(a, m):
    seed = a.unseen_seed
    contract, res, before, after, wall = run_composite(a, seed)
    manifest, table, report = upstream_outputs(seed)
    want = {MATCH: manifest, PROPS: table}
    steps = []
    for sr in res.get("steps", []):
        art = next((x for x in sr["artifacts"] if x["name"] != "report.json" and not x["name"].endswith(".report.json")), None)
        text = (Path(a.store) / art["ref"]).read_text(encoding="utf-8") if art else None
        steps.append({"step": sr["step_id"], "op": sr["op"], "kind": sr["kind"], "mode": sr["mode"], "state": sr["state"], "verdict": sr["verdict"],
                      "capability": sr.get("capability"), "task_id": sr.get("task_id"), "fresh_execution": sr["mode"] == "retained_capability_execution",
                      "cached_replay": sr["mode"] == "saved_result_replay", "matches_oracle_output": None if sr["op"] not in want else text == want[sr["op"]],
                      "artifacts": sr["artifacts"], "verification": {k: (sr.get("verification") or {}).get(k) for k in ("verdict", "evaluator", "pin", "expected_sha256")}})
    final = next((x for x in res.get("deliverable") or [] if not x["name"].endswith("report.json")), None)
    final_text = (Path(a.store) / final["ref"]).read_text(encoding="utf-8") if final else None
    delta = {k: after["counters"][k] - before["counters"][k] for k in ("model_calls", "proposal_calls", "container_runs", "executions", "replays")}
    plan = res.get("plan") or {}
    ok = (res["state"] == "VERIFIED" and final_text == report and delta["model_calls"] == 0 and delta["proposal_calls"] == 0
          and after["experiments"] == before["experiments"] and all(x["verdict"] == "PASS" for x in steps if x["kind"] == "discovered")
          and all(x["matches_oracle_output"] in (None, True) for x in steps))
    return {"ok": ok, "goal_id": contract["contract_id"], "goal": contract["goal_text"], "state": res["state"], "reason": res["reason"], "seed_sha256": sha(seed),
            "pictures": len(contract["inputs"]), "plan": {"dag": plan.get("dag"), "steps": [{"id": x["step_id"], "op": x["op"], "inputs": x["inputs"]} for x in plan.get("steps", [])],
                                                          "estimate": plan.get("estimate"), "ranking": plan.get("ranking"), "excluded": plan.get("excluded")},
            "steps": steps, "final_artifact": final, "final_verified_by_independent_oracles": final_text == report if final_text is not None else False,
            "model_calls": delta["model_calls"], "proposal_calls": delta["proposal_calls"], "new_experiments": after["experiments"] - before["experiments"],
            "counter_delta": delta, "usage": res.get("usage"), "mode": res.get("mode"), "wall_s": wall,
            "cached_steps": sum(x["cached_replay"] for x in steps), "fresh_steps": sum(x["fresh_execution"] for x in steps), "fresh_process": True}


def phase_baseline(a, m):
    seed = a.unseen_seed
    held = [c for c in (MATCH, PROPS, RECON) if retained(a.store, c)]
    contract, res, before, after, wall = run_composite(a, seed, allow_discovery=True)
    cost = None
    if a.acquire_manifest:
        gaps = json.loads(Path(a.acquire_manifest).read_text(encoding="utf-8")).get("phases", {}).get("acquire", {}).get("gaps", [])
        cost = {"to_acquire_the_missing_capabilities": {k: round(sum((g.get("cost") or {}).get(k, 0) for g in gaps), 1) for k in ("calls", "proposals", "container_runs", "in_tokens", "out_tokens", "wall_s")},
                "source": "acquire phase of the retained run"}
    return {"ok": res["state"] != "VERIFIED" and not held, "retained_in_this_store": held, "state": res["state"], "reason": res["reason"], "missing_step": res.get("missing_step"),
            "gap_ref": res.get("gap_ref"), "experiment_opened": res.get("experiment_id"), "plan_steps": len((res.get("plan") or {}).get("steps", [])), "wall_s": wall,
            "model_calls": after["counters"]["model_calls"] - before["counters"]["model_calls"], "seed_sha256": sha(seed),
            "what_it_means": "no capability produces the deliverable: the goal is UNRESOLVED and needs acquisition before it can run" if res["state"] == "UNRESOLVED" else None,
            "acquisition_cost": cost}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--phase", choices=("acquire", "composite", "repeat", "baseline"), required=True)
    ap.add_argument("--store", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--seed", type=int, default=404, help="acquire: picture set the two acquisition goals are made from")
    ap.add_argument("--unseen-seed", type=int, default=505)
    ap.add_argument("--model", default="auto", help="a backend id (authoritative; protocols unchanged), or 'auto' (default) = HIVE chooses from measured outcomes (model_choice)")
    ap.add_argument("--private")
    ap.add_argument("--admit-key")
    ap.add_argument("--acquire-manifest")
    ap.add_argument("--stub-endpoint", help="test seam: a stub model endpoint instead of LM Studio")
    a = ap.parse_args(argv)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    mf = out / "manifest.json"
    m = json.loads(mf.read_text(encoding="utf-8")) if mf.is_file() else {"schema": SCHEMA, "phases": {}, "fixture_author": DISCLOSURE, "commands": []}
    fresh = not (Path(a.store) / "hive.sqlite3").exists()
    s = Store(a.store)
    try:
        if fresh:
            O.import_bundle(s)  # a brand-new store gets the registry's built-in operations, once
    finally:
        s.close()
    if a.phase in ("composite", "repeat"):
        used = [p.get("seed_sha256") for k, p in m["phases"].items() if k in ("composite", "repeat", "baseline")]
        if sha(a.unseen_seed) in used:
            print(json.dumps({"ok": False, "reason": "this seed was already used in this run: the inputs must be unseen"}))
            return 4
    t0 = time.monotonic()
    rec = {"acquire": phase_acquire, "composite": phase_composite, "repeat": phase_composite, "baseline": phase_baseline}[a.phase](a, m)
    rec.update(phase=a.phase, wall_s_this_invocation=round(time.monotonic() - t0, 1), command=" ".join([sys.executable, *sys.argv]), environment=Q.env_info(),
               at=time.strftime("%Y-%m-%dT%H:%M:%S%z"))
    m["phases"][a.phase] = rec
    m["commands"].append(rec["command"])
    mf.write_text(json.dumps(m, sort_keys=True, indent=1), encoding="utf-8", newline="\n")
    print(json.dumps({k: rec.get(k) for k in ("phase", "ok", "state", "reason", "model_calls", "wall_s", "cached_steps", "fresh_steps")} | {"manifest": str(mf)}, indent=1))
    return 0 if rec.get("ok") else 3


if __name__ == "__main__":
    sys.exit(main())
