"""Conductor-run, owner-authorised: activate a backend approval DRAFT (L4). Copies <name>.approval.DRAFT.json to <name>.approval.json with status "active"
and the owner's own words, then prints the sha256 to bind as approval_sha256 in configs/model_dispatch.json (backends.list[<id>]).
Usage: python scripts/activate_backend_approval.py build/prototype/approvals/qwen3.8-27b.approval.DRAFT.json --approver "..." --statement "..." [--approved-at ISO]
Nothing is activated until the owner authorises this run; the approval stays refused while the sha is unbound or the file changes by one byte."""
import argparse, hashlib, json, sys, time
from pathlib import Path


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("draft"); ap.add_argument("--approver", required=True); ap.add_argument("--statement", required=True)
    ap.add_argument("--approved-at", default=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    a = ap.parse_args(argv)
    src = Path(a.draft)
    if ".DRAFT." not in src.name: sys.exit("refused: not a .DRAFT. approval file")
    d = json.loads(src.read_text(encoding="utf-8"))
    if d.get("status") != "DRAFT": sys.exit("refused: source status is not DRAFT")
    d.update(status="active", approver=a.approver, approved_at=a.approved_at, statement=a.statement)
    if "DRAFT" in json.dumps(d).upper(): sys.exit("refused: DRAFT text remains in the approval body (edit the --approver/--statement/context)")
    dst = src.with_name(src.name.replace(".DRAFT", ""))
    data = (json.dumps(d, indent=2) + "\n").encode("utf-8")
    dst.write_bytes(data)
    print(f"wrote {dst}\napproval_sha256 = {hashlib.sha256(data).hexdigest()}\nBind it: configs/model_dispatch.json backends.list[<id>].approval_sha256")


if __name__ == "__main__":
    main()
