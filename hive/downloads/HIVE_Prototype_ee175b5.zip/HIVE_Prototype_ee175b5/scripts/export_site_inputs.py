"""Deterministic export of a real website snapshot into the two typed JSON inputs the site capabilities read. No synthesis: every value is read from disk.

  python scripts/export_site_inputs.py <snapshot_dir> <scope_json> <out_dir> [--committed-at ISO8601] [--derive]

Writes into <out_dir>:
  site-manifest-<commit>.json  {schema site-manifest-v1, commit, committed_at, excluded_prefixes, files:[{path,bytes,sha256}]}  (every file on disk, sorted by path)
  site-pages-<commit>.json     {schema site-pages-v1, commit, subset, pages:[{path,text}]}  (.html/.htm/.css files, sorted by path)
  with --derive also raw-reference-table-<commit>.json (the site.ref-extract oracle over the pages, the direct input of the site.ref-resolve goal) and
  reference-table-<commit>.json (the site.ref-resolve oracle over that raw table, the direct input of the reference check goal). Evaluator-side derivation only.
<commit> and the excluded prefixes come from the scope file ("commit", "excluded_top_level", "excluded_files_over_5MB"). The subset rule keeps every
page unless the serialised file would exceed LIMIT bytes; then whole top-level sections are dropped, largest page bytes first, until it fits, and the
dropped sections are recorded in "subset". Undecodable files (not UTF-8) are listed in "subset.undecodable" and left out.
"""
import argparse
import hashlib
import json
import os
from datetime import datetime, timezone

LIMIT = 1_900_000  # bytes of one export file; the engine's per-file input limit is 2 MiB
PAGE_EXT = (".html", ".htm", ".css")


def dump(o):
    return json.dumps(o, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def walk(root):
    out, base = [], os.path.realpath(root)
    inside = lambda p: os.path.realpath(p).startswith(base + os.sep)  # no symlink or junction leads out of the snapshot
    for d, ds, fs in os.walk(root):
        ds[:] = [x for x in ds if not os.path.islink(os.path.join(d, x)) and inside(os.path.join(d, x))]
        for f in fs:
            p = os.path.join(d, f)
            if not os.path.islink(p) and inside(p):
                out.append(os.path.relpath(p, root).replace(os.sep, "/"))
    return sorted(out)


def section(path):
    return path.split("/", 1)[0] if "/" in path else "(root)"


def utc(ts):
    t = datetime.fromisoformat(ts.replace("Z", "+00:00"))
    return t.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def export(snap, scope, committed_at=None):
    sc = scope if isinstance(scope, dict) else json.load(open(scope, encoding="utf-8"))
    commit = sc["commit"]
    excl = sorted([t + "/" for t in sc.get("excluded_top_level", [])] + [x["path"] for x in sc.get("excluded_files_over_5MB", [])])
    paths = walk(snap)
    files, pages, undecodable = [], [], []
    for p in paths:
        b = open(os.path.join(snap, p), "rb").read()
        files.append({"path": p, "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()})
        if p.lower().endswith(PAGE_EXT):
            try:
                pages.append({"path": p, "text": b.decode("utf-8")})
            except UnicodeDecodeError:
                undecodable.append(p)
    manifest = {"schema": "site-manifest-v1", "commit": commit, "committed_at": utc(committed_at) if committed_at else None, "excluded_prefixes": excl, "files": files}
    dropped = []
    while True:
        subset = {"rule": "all .html/.htm/.css files; if over the size limit, whole top-level sections are dropped largest first", "limit_bytes": LIMIT,
                  "dropped_sections": sorted(dropped), "undecodable": undecodable}
        doc = {"schema": "site-pages-v1", "commit": commit, "subset": subset, "pages": pages}
        if len(dump(doc)) <= LIMIT or not pages:
            break
        size = {}
        for q in pages:
            size[section(q["path"])] = size.get(section(q["path"]), 0) + len(q["text"])
        big = sorted(size, key=lambda s: (-size[s], s))[0]
        dropped.append(big)
        pages = [q for q in pages if section(q["path"]) != big]
    return manifest, doc


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("snapshot_dir")
    ap.add_argument("scope_json")
    ap.add_argument("out_dir")
    ap.add_argument("--committed-at")
    ap.add_argument("--derive", action="store_true")
    a = ap.parse_args(argv)
    manifest, pages = export(a.snapshot_dir, a.scope_json, a.committed_at)
    os.makedirs(a.out_dir, exist_ok=True)
    out = {"site-manifest": manifest, "site-pages": pages}
    if a.derive:
        import base64
        import importlib.util
        root = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "capabilities")

        def run_oracle(cap, doc):
            spec = importlib.util.spec_from_file_location("oracle_" + cap.replace(".", "_"), os.path.join(root, cap, "suite", "oracle.py"))
            m = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(m)
            r = m.expected({"files": [{"name": "p.json", "format": "base64", "data": base64.b64encode(dump(doc).encode()).decode()}]})
            if r == "ERROR":
                raise SystemExit(cap + " oracle returned ERROR")
            return json.loads(r)

        out["raw-reference-table"] = run_oracle("site.ref-extract", pages)
        out["reference-table"] = run_oracle("site.ref-resolve", out["raw-reference-table"])
    for k, doc in out.items():
        path = os.path.join(a.out_dir, f"{k}-{doc['commit']}.json")
        with open(path, "w", encoding="utf-8", newline="\n") as f:
            f.write(dump(doc))
        print(json.dumps({"file": path, "bytes": os.path.getsize(path)}))


if __name__ == "__main__":
    main()
