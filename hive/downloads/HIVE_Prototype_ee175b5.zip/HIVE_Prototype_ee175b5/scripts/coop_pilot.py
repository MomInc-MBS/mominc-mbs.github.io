"""Cooperative-round pilot: caps x recipes x repeats, one fresh store per run, through scripts/g3_qualify.acquire_gap (the production campaign driver).

  python scripts/coop_pilot.py --out DIR --private-root DIR [--caps a,b] [--recipes incumbent,sample3,diverse3] [--repeats 3] [--first-repeat 1] [--order grouped|interleaved] [--inputs DIR]
                               [--model ID] [--max-wall-s 21600] [--stub]

Fixed order (cap, recipe, repeat), no retries; a run that exhausts its budget is recorded as it is. Writes <out>/rows.jsonl (one JSON row per run, appended as each run ends),
stores under <out>/stores/<run>, hidden sets under <private-root>/<run> (outside every store). Repeat r uses seed_base = 10000*r, so repeats really sample differently
(proposer seeds do not depend on the campaign id). The hidden pass count is read only for the candidate the round SELECTED (the incumbent's only gated candidate);
judging every candidate is evaluator/coop/coverage.py, run afterwards. --stub serves canned replies from the stub server (dry test, no model)."""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))
import g3_qualify as Q  # noqa: E402
from hive import capcontract as CC, discovery as D, operator_runtime as O  # noqa: E402
from hive.storage import Store  # noqa: E402

OLD = "2633d9b"  # the release the demo learns from (read-only exports)
CAPS = {  # cap -> (goal text, input files under <inputs>/<OLD>/), as scripts/prototype_demo.py L1, L1b, L2
    "site.ref-extract": ("Scan the pages of this site for every raw reference.", [f"site-pages-{OLD}.json"]),
    "site.ref-resolve": ("Resolve these scanned page references into a reference table.", [f"raw-reference-table-{OLD}.json"]),
    "site.ref-check": ("Check these references against the site manifest and list the broken links.", [f"reference-table-{OLD}.json", f"site-manifest-{OLD}.json"]),
}
RECIPES = ("incumbent", "sample3", "diverse3", "maskpos3", "maskrand3")


def stub_replies(cap):
    """Canned replies for --stub: one wrong, the capability's own oracle wrapped as a candidate, and a same-behaviour variant (so a round has two dev-perfect candidates).
    The oracle only passes the static check for some caps (e.g. site.ref-check); others end as dev_fail/static_fail rows, which is still a valid dry run."""
    c = CC.get(cap)
    oracle = D._read_lf(CC.ROOT / c["verification"]["oracle"].partition("#")[0]) + "\n\ndef run(env):\n    return expected(env)\n"
    fence = lambda b: "```python\n" + b + "\n```"  # noqa: E731
    return [fence("import json\ndef run(env):\n    return json.dumps({\"v\": 0})"), fence(oracle), fence("# variant\n" + oracle)]


def judge(store, exp_id, recipe):
    """Per-candidate rows of one experiment. Hidden counts only for the selected candidate (the incumbent has just the one it gated)."""
    s = Store(store)
    try:
        rec = s.get(D.KEY + exp_id)
    finally:
        s.close()
    rows = []
    for p in rec["proposals"]:
        dev = p.get("dev") or {}
        cat = p.get("failure_category") or ("static_fail" if p.get("static") else "dev_pass" if dev and dev.get("pass_count") == dev.get("n") else "dev_fail")
        gated = p.get("selected") or (recipe == "incumbent" and p.get("acceptance"))
        rows.append({"exp_id": exp_id, "sha256": p["sha256"], "recipe_id": p.get("recipe_id") or "incumbent", "branch": p.get("branch"), "dev_pass": dev.get("pass_count"), "dev_n": dev.get("n"),
                     "agreement": p.get("agreement"), "selected": bool(p.get("selected")), "failure_category": cat,
                     "hidden_pass": (p["acceptance"] or {}).get("pass_count") if gated and p.get("acceptance") else None})
    rows += [{"exp_id": exp_id, "n": c["n"], "recipe_id": c.get("recipe_id") or "incumbent", "branch": c.get("branch"), "failure_category": c["failure_category"]}
             for c in rec["calls"] if c.get("failure_category") in ("no_code", "duplicate")]
    return rows


def one_run(a, cap, recipe, rep, srv_mod):
    run = f"{cap}.{recipe}.r{rep}"
    store, priv = Path(a.out) / "stores" / run, Path(a.private_root) / run
    store.mkdir(parents=True)
    priv.mkdir(parents=True, exist_ok=True)
    s = Store(store)
    try:
        O.import_bundle(s)
    finally:
        s.close()
    srv = None
    if a.stub:
        srv, url = srv_mod.serve_thread({"R": stub_replies(cap)})
    ns = SimpleNamespace(private=str(priv), model=a.model, stub_endpoint=url if srv else None, admit_key=None)
    goal, files = CAPS[cap]
    ins = [(f, "file", (Path(a.inputs) / OLD / f).read_bytes()) for f in files]
    t0 = time.monotonic()
    try:
        out = Q.acquire_gap(ns, str(store), run, cap, goal, ins, coop=None if recipe == "incumbent" else recipe, seed_base=10000 * rep)
    finally:
        if srv:
            srv.shutdown()
    att = out.get("attempts", [])
    cost = out.get("cost") or {}
    row = {"run": run, "cap": cap, "recipe": recipe, "repeat": rep, "state": out["state"], "reason": (att[-1].get("reason") if att else out.get("reason")),
           "experiments": len(att), "calls": cost.get("calls"), "proposals": cost.get("proposals"), "in_tokens": cost.get("in_tokens"), "out_tokens": cost.get("out_tokens"),
           "container_runs": cost.get("container_runs"), "wall_s": round(time.monotonic() - t0, 1), "store": str(store), "private": str(priv), "inputs_root": str(a.inputs),
           "exp_ids": [x["exp_id"] for x in att], "selected_hidden": [x.get("receipt") for x in att],
           "candidates": [c for x in att for c in judge(store, x["exp_id"], recipe)]}
    return row


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--caps", default=",".join(CAPS))
    ap.add_argument("--recipes", default=",".join(RECIPES))
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--out", required=True)
    ap.add_argument("--private-root", required=True)
    ap.add_argument("--inputs", default="D:/HIVE-operator-inputs/mom-site/exports")
    ap.add_argument("--model", default="openai/gpt-oss-20b")
    ap.add_argument("--max-wall-s", type=float, default=21600)
    ap.add_argument("--order", choices=("grouped", "interleaved"), default="grouped")
    ap.add_argument("--first-repeat", type=int, default=1, help="repeat r uses seed_base 10000*r; start higher for fresh seeds")
    ap.add_argument("--stub", action="store_true", help="dry test: canned replies from scripts/m2_stub_server.py, no model")
    a = ap.parse_args(argv)
    caps, recipes = a.caps.split(","), a.recipes.split(",")
    bad = [x for x in caps if x not in CAPS] + [x for x in recipes if x not in RECIPES]
    if bad:
        raise SystemExit(f"unknown: {bad}")
    out, priv = Path(a.out).resolve(), Path(a.private_root).resolve()
    if priv == out or out in priv.parents or priv in out.parents:
        raise SystemExit("--private-root must be outside --out (and so outside every store)")
    out.mkdir(parents=True, exist_ok=True)
    rows = out / "rows.jsonl"
    if rows.exists() and rows.stat().st_size:
        raise SystemExit(f"{rows} already has rows: use a fresh --out (no retries, no resume)")
    srv_mod = __import__("m2_stub_server") if a.stub else None
    t0 = time.monotonic()
    grid = [(c, r, k) for c in caps for r in recipes for k in range(a.first_repeat, a.first_repeat + a.repeats)]
    if a.order == "interleaved":  # repeat-major, recipe innermost: server drift over time spreads evenly across recipes
        grid = [(c, r, k) for k in range(a.first_repeat, a.first_repeat + a.repeats) for c in caps for r in recipes]
    for cap, recipe, rep in grid:
        if time.monotonic() - t0 > a.max_wall_s:
            row = {"run": f"{cap}.{recipe}.r{rep}", "cap": cap, "recipe": recipe, "repeat": rep, "state": "not-run", "reason": f"--max-wall-s {a.max_wall_s} reached"}
        else:
            row = one_run(a, cap, recipe, rep, srv_mod)
        with open(rows, "a", encoding="utf-8", newline="\n") as f:
            f.write(json.dumps(row, sort_keys=True) + "\n")
        print(row["run"], row["state"], flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
