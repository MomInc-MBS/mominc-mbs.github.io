"""P2: consolidate one prototype store, 0 model calls. Copies demo store s8 (learned site.ref-check, site.release-diff, image.asset-match v1),
admits the hosted sealed-final site.ref-extract / site.ref-resolve through the standard acceptance route (fresh hidden gate + signed admission),
and store-locally revokes image.asset-match v1 (contract 1.0.0, fails the real-image contract). Never resurrects test-store admissions.

  HIVE_REAL_DOCKER=1 python scripts/p2_registry.py --store C:/hive-work/demo/proto1 --out build/prototype-final/p2
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "scripts")]
from hive import capability_registry as CR  # noqa: E402
from hive.storage import Store  # noqa: E402
import c5_lifecycle as C5  # noqa: E402
import hive_admission as H  # noqa: E402

SOURCE = Path("C:/hive-work/demo/s8")


def caps(store):
    s = Store(store)
    try:
        out = {}
        for cap in CR.cap_ids(s):
            adm, revoked, cur = CR._state(s, cap)
            out[cap] = {"admitted": sorted(adm), "revoked": sorted(revoked), "current": cur}
        return {"store_uuid": CR.store_uuid(s), "caps": out}
    finally:
        s.close()


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--store", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    store, out = Path(a.store), Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    rep = {"source": str(SOURCE)}
    if not store.exists():
        shutil.copytree(SOURCE, store)
        rep["copied"] = True
    rep["before"] = caps(store)
    rep["sealed"] = {}
    for cap in ("site.ref-extract", "site.ref-resolve"):
        if rep["before"]["caps"].get(cap, {}).get("current"):
            rep["sealed"][cap] = {"state": "ALREADY_ADMITTED"}
            continue
        tries = [C5.v2_try(store, cap, "r1")]
        if tries[-1]["state"] == "NO_QUALIFYING_CANDIDATE":  # only a failed fresh hidden gate moves on to the other campaign
            tries.append(C5.v2_try(store, cap, "r2"))
        rep["sealed"][cap] = tries
    img = rep["before"]["caps"].get("image.asset-match", {})
    if img.get("current") == 1:
        rep["image_v1_revoke"] = C5.attempt(lambda: H.revoke(store, "image.asset-match", 1,
                                            "contract 1.0.0 superseded by 2.0.0 (transparency counts); v1 failed the independent real-image check"))
    rep["after"] = caps(store)
    (out / "P2_REGISTRY.json").write_text(json.dumps(rep, indent=1, sort_keys=True, default=str) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({k: rep[k] for k in ("after",)}, default=str))


if __name__ == "__main__":
    main()
