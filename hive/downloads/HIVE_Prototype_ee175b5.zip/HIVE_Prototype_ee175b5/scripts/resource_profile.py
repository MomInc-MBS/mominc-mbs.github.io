"""Resource sampling + admission for the live backend screen (stdlib only; OBS WebSocket v5 over a raw socket).

  python scripts/resource_profile.py sample --seconds 60 --interval 2 --out s.jsonl
  python scripts/resource_profile.py summarize s.jsonl
  python scripts/resource_profile.py record-start | record-stop     (the caller sets OBS's folder; streaming is refused)
"""
import argparse
import base64
import ctypes
import hashlib
import json
import os
import socket
import struct
import subprocess
import sys
import time
import uuid

REFUSED = {"StartStream", "ToggleStream"}
CONFIG = "%APPDATA%/obs-studio/plugin_config/obs-websocket/config.json"


# ---- RFC 6455 -------------------------------------------------------------------------------------------------------
def ws_encode(data, opcode=1, key=None):
    """One masked client frame (FIN set)."""
    key = os.urandom(4) if key is None else key
    n = len(data)
    h = bytes([0x80 | opcode]) + (bytes([0x80 | n]) if n < 126 else b"\xfe" + struct.pack(">H", n) if n < 65536 else b"\xff" + struct.pack(">Q", n))
    return h + key + bytes(b ^ key[i % 4] for i, b in enumerate(data))


def ws_read(recv):
    """recv(n) -> exactly n bytes. Returns (opcode, payload) of one whole message (continuations joined)."""
    out, op0 = b"", None
    while True:
        b0, b1 = recv(2)
        n = b1 & 0x7F
        n = struct.unpack(">H", recv(2))[0] if n == 126 else struct.unpack(">Q", recv(8))[0] if n == 127 else n
        key = recv(4) if b1 & 0x80 else None
        d = recv(n)
        if key:
            d = bytes(b ^ key[i % 4] for i, b in enumerate(d))
        op = b0 & 0x0F
        if op >= 8:  # control frame: hand straight back
            return op, d
        op0 = op if op else op0
        out += d
        if b0 & 0x80:
            return op0, out


def auth_string(password, salt, challenge):
    s = base64.b64encode(hashlib.sha256((password + salt).encode()).digest())
    return base64.b64encode(hashlib.sha256(s + challenge.encode()).digest()).decode()


def read_config():
    """-> (port, password). The password never leaves the caller's local variable."""
    c = json.load(open(os.path.expandvars(CONFIG), encoding="utf-8"))
    return int(c["server_port"]), c.get("server_password", "")


class Obs:
    def __init__(self, sock):
        self.sock = sock  # holds no password: connect() uses it once and drops it

    def __repr__(self):
        return "Obs(<socket>)"

    __str__ = __repr__

    def _recv(self, n):
        b = b""
        while len(b) < n:
            c = self.sock.recv(n - len(b))
            if not c:
                raise ConnectionError("closed")
            b += c
        return b

    def _msg(self):
        while True:
            op, d = ws_read(self._recv)
            if op == 9:
                self.sock.sendall(ws_encode(d, 10))
            elif op == 8:
                raise ConnectionError("closed by OBS")
            elif op == 1:
                return json.loads(d)

    def _send(self, o):
        self.sock.sendall(ws_encode(json.dumps(o).encode()))

    def identify(self, password):
        hello = self._msg()["d"]
        ident = {"rpcVersion": 1, "eventSubscriptions": 0}
        if hello.get("authentication"):
            a = hello["authentication"]
            ident["authentication"] = auth_string(password or "", a["salt"], a["challenge"])
        self._send({"op": 1, "d": ident})
        while self._msg()["op"] != 2:
            pass

    @classmethod
    def connect(cls, host="127.0.0.1", port=None, password=None, timeout=3):
        if port is None:
            port, password = read_config()
        s = socket.create_connection((host, port), timeout=timeout)
        k = base64.b64encode(os.urandom(16)).decode()
        s.sendall((f"GET / HTTP/1.1\r\nHost: {host}:{port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: {k}\r\n"
                   "Sec-WebSocket-Version: 13\r\nSec-WebSocket-Protocol: obswebsocket.json\r\n\r\n").encode())
        buf = b""
        while b"\r\n\r\n" not in buf:
            c = s.recv(1)
            if not c:
                raise ConnectionError("no handshake")
            buf += c
        if b" 101 " not in buf.split(b"\r\n")[0]:
            raise ConnectionError("websocket upgrade refused")
        o = cls(s)
        o.identify(password)
        return o

    def request(self, rtype, data=None):
        if rtype in REFUSED:
            raise PermissionError(f"{rtype} is refused: this tool never streams")
        rid = uuid.uuid4().hex
        self._send({"op": 6, "d": {"requestType": rtype, "requestId": rid, "requestData": data or {}}})
        while True:
            m = self._msg()
            if m["op"] == 7 and m["d"]["requestId"] == rid:
                if not m["d"]["requestStatus"]["result"]:
                    raise RuntimeError(f"{rtype}: {m['d']['requestStatus'].get('comment')}")
                return m["d"].get("responseData") or {}

    def close(self):
        try:
            self.sock.sendall(ws_encode(b"", 8))
        finally:
            self.sock.close()


# ---- sampling -------------------------------------------------------------------------------------------------------
class _MS(ctypes.Structure):
    _fields_ = [("l", ctypes.c_ulong), ("load", ctypes.c_ulong)] + [(n, ctypes.c_ulonglong) for n in ("tp", "ap", "tpf", "apf", "tv", "av", "x")]  # MEMORYSTATUSEX: 7 ULONGLONGs, else dwLength is wrong and the call fails


def _ram():
    m = _MS()
    m.l = ctypes.sizeof(m)
    ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
    return m.tp // 2**20, m.ap // 2**20


def _times():
    t = [ctypes.c_ulonglong() for _ in range(3)]
    ctypes.windll.kernel32.GetSystemTimes(*map(ctypes.byref, t))
    return [x.value for x in t]  # idle, kernel (includes idle), user


def _cpu(gap=0.2):
    a = _times()
    time.sleep(gap)
    b = _times()
    tot = (b[1] - a[1]) + (b[2] - a[2])
    return round(100 * (1 - (b[0] - a[0]) / tot), 1) if tot else None


def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _gpu():
    try:
        r = subprocess.run(["nvidia-smi", "--query-gpu=memory.used,memory.total,utilization.gpu,encoder.stats.sessionCount,encoder.stats.averageFps,encoder.stats.averageLatency",
                            "--format=csv,noheader,nounits"], capture_output=True, text=True, timeout=10).stdout.splitlines()[0]
        v = [_num(x.strip()) for x in r.split(",")]
        return dict(zip(("gpu_mem_used_mib", "gpu_mem_total_mib", "gpu_util_pct", "enc_sessions", "enc_fps", "enc_latency_us"), v))
    except Exception:
        return {}


OBS_KEYS = ("cpuUsage", "memoryUsage", "activeFps", "averageFrameRenderTime", "renderSkippedFrames", "renderTotalFrames", "outputSkippedFrames", "outputTotalFrames")


def sample(obs="auto"):
    """obs: an Obs, None (skip OBS) or 'auto' (connect, close after)."""
    s = {"ts": time.time(), "obs": "unavailable"}
    s.update({k: None for k in OBS_KEYS + ("record_active", "record_duration_ms", "record_bytes", "stream_active")})
    own = obs == "auto"
    try:
        if own:
            obs = Obs.connect()
        if obs:
            st = obs.request("GetStats")
            s.update({k: st.get(k) for k in OBS_KEYS})
            r = obs.request("GetRecordStatus")
            s.update(record_active=r.get("outputActive"), record_duration_ms=r.get("outputDuration"), record_bytes=r.get("outputBytes"))
            s["stream_active"] = obs.request("GetStreamStatus").get("outputActive")
            s["obs"] = "ok"
    except Exception:
        s["obs"] = "unavailable"
    finally:
        if own and obs:
            try:
                obs.close()
            except Exception:
                pass
    s.update(_gpu())
    try:
        s["ram_total_mib"], s["ram_avail_mib"] = _ram()
        s["sys_cpu_pct"] = _cpu()
    except Exception:
        pass
    return s


# ---- summary / admission --------------------------------------------------------------------------------------------
def _pct(a, b):
    return round(100 * a / b, 3) if b else None


def _isnum(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def summarize(rows):
    out = {"samples": len(rows), "fields": {}}
    for k in sorted({k for r in rows for k, v in r.items() if _isnum(v)} - {"ts"}):
        v = [r[k] for r in rows if _isnum(r.get(k))]
        out["fields"][k] = {"min": min(v), "max": max(v), "mean": round(sum(v) / len(v), 3)}
    if len(rows) > 1:
        a, b = rows[0], rows[-1]
        d = lambda k: None if a.get(k) is None or b.get(k) is None else b[k] - a[k]
        out["render_frames"], out["render_skipped"] = d("renderTotalFrames"), d("renderSkippedFrames")
        out["render_skip_pct"] = None if out["render_frames"] is None else _pct(out["render_skipped"], out["render_frames"])
        out["output_frames"], out["output_skipped"] = d("outputTotalFrames"), d("outputSkippedFrames")
        out["output_skip_pct"] = None if out["output_frames"] is None else _pct(out["output_skipped"], out["output_frames"])
    f = out["fields"]
    out["peak_vram_used_mib"] = f.get("gpu_mem_used_mib", {}).get("max")
    out["min_free_vram_mib"] = min((r["gpu_mem_total_mib"] - r["gpu_mem_used_mib"] for r in rows if _isnum(r.get("gpu_mem_total_mib")) and _isnum(r.get("gpu_mem_used_mib"))), default=None)
    out["peak_gpu_util_pct"] = f.get("gpu_util_pct", {}).get("max")
    out["max_encoder_latency_us"] = f.get("enc_latency_us", {}).get("max")
    return out


def admission(profile, s0, s1):
    """-> (ok, reasons). A field that cannot be measured is a stop ('unknown:<field>'), never a pass."""
    why = []
    one = lambda k: [x[k] for x in (s0, s1) if x.get(k) is not None]
    for f, lim in profile.items():
        if f == "min_free_vram_mib":
            v = [x["gpu_mem_total_mib"] - x["gpu_mem_used_mib"] for x in (s0, s1) if x.get("gpu_mem_total_mib") is not None and x.get("gpu_mem_used_mib") is not None]
            val, bad = (min(v) if v else None), lambda x: x < lim
        elif f == "max_vram_used_mib":
            v = one("gpu_mem_used_mib")
            val, bad = (max(v) if v else None), lambda x: x > lim
        elif f in ("max_render_skip_pct", "max_output_skip_pct"):
            p = "render" if "render" in f else "output"
            try:
                val = _pct(s1[p + "SkippedFrames"] - s0[p + "SkippedFrames"], s1[p + "TotalFrames"] - s0[p + "TotalFrames"])
            except (TypeError, KeyError):
                val = None
            bad = lambda x: x > lim
        elif f == "max_obs_cpu_pct":
            v = one("cpuUsage")
            val, bad = (max(v) if v else None), lambda x: x > lim
        elif f == "min_ram_available_mib":
            v = one("ram_avail_mib")
            val, bad = (min(v) if v else None), lambda x: x < lim
        elif f == "max_encoder_latency_us":
            v = one("enc_latency_us")
            val, bad = (max(v) if v else None), lambda x: x > lim
        else:
            why.append(f"unknown:{f}")
            continue
        if val is None:
            why.append(f"unknown:{f}")
        elif bad(val):
            why.append(f"{f}: {val} vs {lim}")
    return not why, why


# ---- CLI ------------------------------------------------------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sp = ap.add_subparsers(dest="cmd", required=True)
    p = sp.add_parser("sample")
    p.add_argument("--seconds", type=float, default=10)
    p.add_argument("--interval", type=float, default=2)
    p.add_argument("--out", required=True)
    sp.add_parser("summarize").add_argument("file")
    sp.add_parser("record-start").add_argument("--dir", help="informational only: set the recording folder in OBS yourself")
    sp.add_parser("record-stop")
    a = ap.parse_args(argv)
    if a.cmd == "sample":
        end = time.time() + a.seconds
        with open(a.out, "a", encoding="utf-8", newline="\n") as f:
            while True:
                f.write(json.dumps(sample()) + "\n")
                f.flush()
                if time.time() + a.interval > end:
                    break
                time.sleep(a.interval)
    elif a.cmd == "summarize":
        print(json.dumps(summarize([json.loads(x) for x in open(a.file, encoding="utf-8") if x.strip()]), indent=1))
    else:
        o = Obs.connect()
        try:
            print(json.dumps(o.request("StartRecord" if a.cmd == "record-start" else "StopRecord")))
        finally:
            o.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
