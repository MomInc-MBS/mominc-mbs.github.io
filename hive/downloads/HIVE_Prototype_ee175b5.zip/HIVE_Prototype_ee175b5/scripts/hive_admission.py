"""C4 admission authority. The only code that can sign an admission; the runtime verifies with configs/admission_signers only.

  python scripts/hive_admission.py init [--key-dir DIR] [--signers FILE]
  python scripts/hive_admission.py admit --store S --exp EXP_ID [--key PATH]
  python scripts/hive_admission.py revoke --store S --cap CAP_ID --version N --reason R [--global] [--key PATH]
  python scripts/hive_admission.py rollback --store S --cap CAP_ID [--key PATH]

The private key lives OUTSIDE the repo and the store (default %USERPROFILE%/.hive-admission/admission_ed25519). Stdlib + OpenSSH
`ssh-keygen -Y sign/verify`. No model calls."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from hive import capability_registry as CR  # noqa: E402
from hive import capcontract as CC  # noqa: E402
from hive import discovery as D  # noqa: E402
from hive import operator_runtime as O  # noqa: E402
from hive.operator_runtime import Refused, _now, _sha  # noqa: E402
from hive.storage import Store  # noqa: E402

DEFAULT_KEY = Path(os.environ.get("USERPROFILE") or Path.home()) / ".hive-admission" / "admission_ed25519"


def _outside(path, *roots):
    p = Path(path).resolve()
    for r in roots:
        if r and (p == Path(r).resolve() or Path(r).resolve() in p.parents):
            raise Refused(f"the private key must not be inside the repo or the store: {p}")
    return p


def init(key_dir=None, signers=None):
    key = _outside(Path(key_dir) / "admission_ed25519" if key_dir else DEFAULT_KEY, ROOT)
    key.parent.mkdir(parents=True, exist_ok=True)
    if not key.exists():
        p = subprocess.run([CR.keygen(), "-q", "-t", "ed25519", "-N", "", "-C", CR.PRINCIPAL, "-f", str(key)], capture_output=True, text=True)
        if p.returncode:
            raise Refused("ssh-keygen failed: " + p.stderr[:200])
    pub = Path(str(key) + ".pub").read_text().split()
    out = Path(signers or CR.SIGNERS)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(f'{CR.PRINCIPAL} namespaces="{CR.NAMESPACE}" {pub[0]} {pub[1]}\n'.encode())
    fp = subprocess.run([CR.keygen(), "-l", "-f", str(key) + ".pub"], capture_output=True, text=True).stdout.split()
    return {"key": str(key), "signers": str(out), "fingerprint": fp[1] if len(fp) > 1 else None}


def _reject(store, cap, exp_id, reason):
    CR.append(store, cap, "rejected", exp_id=exp_id, reason=reason[:300])
    raise Refused(reason)


def admit(store_root, exp_id, key=None, *, rerun=None):
    """Independently re-check a CANDIDATE_PASSED experiment (read-only), re-run the evaluator, then sign + record ONE admit event.
    rerun(rec, outdir, body_path) -> (receipt, path) is a test seam; the default launches evaluate.py as a separate python -I process."""
    key = _outside(key or DEFAULT_KEY, ROOT, store_root)
    s = Store(store_root)
    try:
        rec = next((e for e in D.experiments(s) if e["exp_id"] == exp_id), None)
        if rec is None:
            raise Refused(f"unknown experiment {exp_id}")
        c = D.contract_of(rec)  # no contract = nothing to name the chain: refused without a chain event
        cap = c["capability_id"]
        try:
            body, r, base_r, rr, ieval = _recheck(store_root, rec, c, rerun)
        except (Refused, OSError, ValueError, KeyError, RuntimeError) as e:
            _reject(s, cap, exp_id, f"admission refused: {type(e).__name__ if not isinstance(e, Refused) else 'check'}: {str(e)[:240]}")
        hist = CR.versions(s, cap)
        fz, gap = rec["frozen"], rec["gap_key"]
        prev = max(hist) if hist else None
        v3 = CC.is_v2(c)  # a v2 contract is admitted under statement v3 (derived environment recorded); v1 contracts keep v2 statements
        st = {"schema": CC.V3 if v3 else CR.SCHEMA, "cap_id": cap, "version": (prev or 0) + 1, "contract": c, "contract_sha256": CC.sha(c),
              "impl_sha256": _sha(body), "body": body, "harness_sha256": CC.harness_sha(c), "pin": CC.pin(c),
              "evaluation": {"exp_id": exp_id, "frozen_sha": rec["frozen_sha"], "receipt_sha256": r["receipt_sha256"], "pass_count": r["pass_count"], "n": r["n"],
                             "admission_rerun_receipt_sha256": rr["receipt_sha256"], "case_result_sha256_match": True},
              "lineage": {"prev_version_statement_sha": _prev_sha(s, cap), "gap_key": gap, "proposer_model": fz["proposer"]["model"]},
              "authority": {"principal": CR.PRINCIPAL, **CR.authority_info()}, "admitted_at": _now()}
        if fz.get("authored"):  # signed provenance: a human wrote this body; it is never counted as learned
            st["route"], st["author"] = "operator-authored", fz["authored"]["author"]
        if fz.get("sealed_final"):  # signed provenance of the campaign final this body came from; the route stays "learned"
            st["sealed_final"] = fz["sealed_final"]
        if fz.get("improve"):  # signed lineage of an improvement: what it replaced and the objective it met
            st["improvement"] = {"base_version": fz["improve"]["base_version"], "base_statement_sha": fz["improve"]["base_statement_sha"], "base_impl_sha256": fz["improve"]["base_impl_sha256"],
                                 "objective": ieval["objective"], "objective_result": ieval["objective_result"], "regression": ieval["regression"]}  # recomputed here, never read from the record
        if v3 and c["execution"]["environment_ref"]["kind"] == "derived":
            st["environment"] = fz["environment"]
            for k in ("tool", "acquisition"):  # provenance recorded by the acquisition driver (S4), when present
                if k in fz:
                    st[k] = fz[k]
        sig = CR.sign(CR.canon(st), key)
        ref = CR.append(s, cap, "admit", statement=st, statement_sha=_sha(CR.canon(st)), signature=sig, exp_id=exp_id,
                        rerun_receipt=s.put_artifact(rr))
        return {"cap_id": cap, "version": st["version"], "statement_sha": _sha(CR.canon(st)), "event_ref": ref, "rerun_receipt_sha256": rr["receipt_sha256"], "route": st.get("route", "learned")}
    finally:
        s.close()


def _prev_sha(s, cap):
    ev = [e for e in CR.history(s, cap) if e["type"] == "admit"]
    return ev[-1]["statement_sha"] if ev else None


def _recheck(store_root, rec, c, rerun):
    """Every check the spec lists, from the files on disk. Raises Refused / RuntimeError with the reason."""
    fz, d = rec["frozen"], Path(store_root) / "discovery" / rec["exp_id"]
    if rec["state"] != "CANDIDATE_PASSED":
        raise Refused(f"state is {rec['state']}, not CANDIDATE_PASSED")
    if rec["frozen_sha"] != _sha(O._json(fz)) or rec["exp_id"] != "d-" + rec["frozen_sha"][:20]:
        raise Refused("frozen protocol sha does not recompute")
    D.check_frozen(rec, c)  # evaluator path/suite come from the contract, not from the store record
    cand = rec["candidate_sha256"]
    body_path = d / f"cand-{cand}.py"
    body = D._read_lf(body_path)
    if _sha(body) != cand:
        raise Refused("candidate body sha does not match the record")
    r = json.loads((d / rec["receipt"]["path"]).read_text(encoding="utf-8"))
    bad = D.receipt_problems(rec, r, cand, "candidate")
    if bad or r["receipt_sha256"] != rec["receipt"]["receipt_sha256"]:
        raise Refused("candidate receipt does not recompute / match the record: " + ", ".join(bad or ["record sha"]))
    if fz["evaluator"]["pin"] != CC.pin(c):
        raise Refused("evaluator pin differs from the frozen one")
    if "environment" in fz:
        CC.verify_tar(fz["environment"], CC.images_dir(store_root))  # the tar is hashed at every admission, image present or not
        if CC.ensure_image(fz["environment"], CC.images_dir(store_root)) != fz["environment"]["id"]:
            raise Refused("the staged image is not present with its frozen ID")
    if r["verdict"] != "PASS" or r["pass_count"] != r["n"]:
        raise Refused("receipt is not a full pass")
    s = Store(store_root)
    try:
        why = CC.holdout_problem(s, c, cand)
    finally:
        s.close()
    if why:
        raise Refused(why)
    ieval = _chain_and_improvement(store_root, rec, c, body, fz, d, rerun)
    sb = rec["baselines"]["scripted"]
    base_r = json.loads((d / f"receipt-scripted_baseline-{sb['candidate_sha256'][:12]}.json").read_text(encoding="utf-8"))
    bad = D.receipt_problems(rec, base_r, sb["candidate_sha256"], "scripted_baseline")
    if bad or base_r["receipt_sha256"] != sb["receipt_sha256"]:
        raise Refused("scripted baseline receipt invalid: " + ", ".join(bad or ["record sha"]))
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as t:
        rr, _ = (rerun or (lambda rec, out, bp: D._evaluate(rec, out, bp, "admission_rerun", None)))(rec, t, body_path)
    if rr["verdict"] != "PASS" or rr["case_result_sha256"] != r["case_result_sha256"]:
        raise Refused("admission re-run did not reproduce the PASS with identical per-case hashes")
    return body, r, base_r, rr, ieval


def _chain_and_improvement(store_root, rec, c, body, fz, d, rerun):
    """Whether this is a first admission or an improvement is read from the signed registry chain, never from a record flag. A candidate equal to any
    admitted or revoked version, or an experiment already admitted, is refused; a capability that already has a version needs a valid improvement whose
    objective verdict is recomputed here from the hash-bound evaluator receipts. Returns the recomputed improvement evaluation (or None)."""
    cap, cand = c["capability_id"], _sha(body)
    s = Store(store_root)
    try:
        adm, revoked, cur = CR._state(s, cap)  # verifies every signed event
        if cand in CR.revoked_impls(cap, s):  # holds even when the chain head was deleted or rewound
            raise Refused("this implementation is listed in configs/capability_revocations.json")
        if any(e["type"] == "admit" and e.get("exp_id") == rec["exp_id"] for e in CR.history(s, cap)):
            raise Refused("this experiment was already admitted")
        for v, (st, _e) in adm.items():
            if st["impl_sha256"] == cand:
                raise Refused(f"this implementation is {'a revoked' if v in revoked else 'an already admitted'} version ({v}) of the capability")
        imp = fz.get("improve")
        if not adm:
            if imp:
                raise Refused("improvement of a capability with no admitted version")
            return None
        if not imp:
            raise Refused("the capability already has an admitted version: only an explicit improvement can add another")
        if imp["cap_id"] != cap:
            raise Refused("improvement names another capability")
        c_now = CR.resolve_discovered(s, cap)  # Unavailable (a Refused) when nothing is active
    finally:
        s.close()
    if c_now["version"] != imp["base_version"] or c_now["statement_sha"] != imp["base_statement_sha"]:
        raise Refused("improvement is stale: the active version is no longer the one it was made from")
    base = c_now["statement"]["body"]
    if not (_sha(imp["base_body"]) == imp["base_impl_sha256"] == c_now["statement"]["impl_sha256"] == _sha(base)):
        raise Refused("improvement base body does not match the admitted version")
    obj = D.check_objective(imp["objective"])
    prev = json.loads((d / f"receipt-previous_version-{imp['base_impl_sha256'][:12]}.json").read_text(encoding="utf-8"))
    bad = D.receipt_problems(rec, prev, imp["base_impl_sha256"], "previous_version")
    if bad:
        raise Refused("previous-version receipt invalid: " + ", ".join(bad))
    if rerun is None:  # the real path measures the admitted version again with the separate evaluator process; the test seam trusts the hash-bound receipt
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as t:
            bp = Path(t) / "previous.py"
            D._write_lf(bp, base)
            pr, _ = D._evaluate(rec, t, bp, "admission_previous", None)
        if (pr["pass_count"], pr["n"], pr["run_error"]) != (prev["pass_count"], prev["n"], prev["run_error"]):
            raise Refused("previous-version receipt does not reproduce")
    r = json.loads((d / rec["receipt"]["path"]).read_text(encoding="utf-8"))
    res = D.objective_result(obj, prev, r)
    if not res["met"]:
        raise Refused("improvement: the declared objective did not improve")
    dev = D._load("gen_public", c).cases()
    if D._sha(D._json(dev)) != fz["dev_set_sha256"]:
        raise Refused("dev set no longer matches the frozen protocol")
    ok, _ = D._dev_ok(body, dev, D._load("harness", c), 60, **CC.exec_args(c, fz.get("environment")))
    if not all(ok):
        raise Refused("improvement: a regression fixture failed")
    return {"objective": obj, "objective_result": res, "regression": {"fixtures": [k["name"] for k in dev], "new_passes_all": True}}


def revoke(store_root, cap, version, reason, key=None, *, global_scope=False):
    version = int(version)
    s = Store(store_root)
    try:
        adm = CR._state(s, cap)[0]  # chain must verify before anything is recorded
        uid = CR.store_uuid(s)
    finally:
        s.close()
    st, e = adm.get(version, ({}, {}))
    _outside(key or DEFAULT_KEY, ROOT, store_root)
    path = CR.revocations_path()
    before = path.read_bytes() if path.is_file() else None
    CR.record_revocation(cap, version, st.get("impl_sha256"), e.get("statement_sha"), reason,
                         scope="global" if global_scope else "store", store_uuid=uid)  # first, so a crash can only over-revoke
    try:
        return _signed(store_root, cap, "revoke", key, version=version, reason=reason[:300])
    except Exception:  # signing refused: nothing changes
        path.write_bytes(before) if before is not None else path.unlink()
        raise


def rollback(store_root, cap, key=None):
    s = Store(store_root)
    try:
        frm, to = CR.rollback_target(s, cap)  # raises Unavailable with the reason when there is nothing to roll back to
    finally:
        s.close()
    return _signed(store_root, cap, "rollback", key, from_version=frm, to_version=to)


def _signed(store_root, cap, typ, key, **fields):
    key = _outside(key or DEFAULT_KEY, ROOT, store_root)
    s = Store(store_root)
    try:
        sp = CR.signed_payload(typ, cap, CR.head(s, cap), **fields)
        ref = CR.append(s, cap, typ, signed=sp, signature=CR.sign(CR.canon(sp), key))
        return {"cap_id": cap, "type": typ, "event_ref": ref, **fields}
    finally:
        s.close()


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("init"); a.add_argument("--key-dir"); a.add_argument("--signers")
    for n in ("admit", "revoke", "rollback"):
        p = sub.add_parser(n); p.add_argument("--store", required=True); p.add_argument("--key")
        if n == "admit": p.add_argument("--exp", required=True)
        else: p.add_argument("--cap", required=True)
        if n == "revoke": p.add_argument("--version", required=True, type=int); p.add_argument("--reason", required=True); p.add_argument("--global", dest="global_scope", action="store_true")
    args = ap.parse_args(argv)
    try:
        out = (init(args.key_dir, args.signers) if args.cmd == "init" else admit(args.store, args.exp, args.key) if args.cmd == "admit"
               else revoke(args.store, args.cap, args.version, args.reason, args.key, global_scope=args.global_scope) if args.cmd == "revoke" else rollback(args.store, args.cap, args.key))
    except Refused as e:
        print(json.dumps({"ok": False, "reason": str(e)}), file=sys.stderr)
        return 2
    print(json.dumps(out, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
