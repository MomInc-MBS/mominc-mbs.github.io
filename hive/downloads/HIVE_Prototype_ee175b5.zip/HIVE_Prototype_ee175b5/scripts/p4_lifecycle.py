"""P4 lifecycle demo, 0 model calls: store-scoped revoke invalidates a stored plan in ONE store and leaves an independent store untouched.

  HIVE_REAL_DOCKER=1 python scripts/p4_lifecycle.py --out build/prototype-final/p4-lifecycle

Store LC (new, own identity) gets site.release-diff through the operator-authored route (the same gates, signed; body = the learned body admitted in
proto1, so only the admission differs). Two B goals are planned in LC; plan 1 runs VERIFIED; release-diff is revoked in LC (store scope); plan 2 must be
refused at run time; the same goal then runs VERIFIED in proto1 (independent admission, other uuid and statement)."""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src")]
from hive import capability_registry as CR  # noqa: E402
from hive.storage import Store  # noqa: E402

PROTO, LC, G1 = "C:/hive-work/demo/proto1", "C:/hive-work/demo/lc1", "C:/hive-work/demo/g1-inputs"
B = "Compare these two site releases: list the changed files and the broken references they affect."
SRC = ["0b3854a", "0b3854a.scope.json", "e3fcce6", "e3fcce6.scope.json"]
SRC2 = ["2633d9b", "2633d9b.scope.json", "0b3854a", "0b3854a.scope.json"]  # a distinct goal (identical contracts share one goal id)


def cli(store, *args):
    p = subprocess.run([sys.executable, "-m", "hive", "--store", store, "operator", *args], cwd=G1, capture_output=True, text=True, encoding="utf-8",
                       errors="replace", env=dict(os.environ, PYTHONPATH=str(ROOT / "src")), timeout=3600)
    try:
        out = json.loads(p.stdout)
    except ValueError:
        out = {"stdout": p.stdout[-500:]}
    return dict(out, _exit=p.returncode, _stderr=p.stderr[-400:])


def uid(store):
    s = Store(store)
    try:
        return CR.store_uuid(s)
    finally:
        s.close()


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    out = Path(ap.parse_args(argv).out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    s = Store(PROTO)
    try:
        body = CR.resolve_discovered(s, "site.release-diff")["statement"]["body"]
    finally:
        s.close()
    bf = out / "release-diff-body.py"
    bf.write_text(body, encoding="utf-8", newline="\n")
    rep = {"stores": {"lc": LC, "proto": PROTO}}
    rep["author"] = cli(LC, "cap", "author", "site.release-diff", str(bf), "--author", "conductor P4 lifecycle demo", "--json")
    rep["uuids"] = {"lc": uid(LC), "proto": uid(PROTO)}
    d = ["--deliverable", "release_change_report", "--allowed-root", G1]
    p1, p2 = cli(LC, "plan", B, *SRC, *d), cli(LC, "plan", B, *SRC2, *d)
    rep["plans"] = [{k: p.get(k) for k in ("goal_id", "state", "_exit")} for p in (p1, p2)]
    rep["run_plan_1_before_revoke"] = {k: cli(LC, "run-plan", p1["goal_id"], "--allowed-root", G1).get(k) for k in ("state", "reason", "usage", "_exit", "error")}
    rv = subprocess.run([sys.executable, str(ROOT / "scripts" / "hive_admission.py"), "revoke", "--store", LC, "--cap", "site.release-diff", "--version", "1",
                         "--reason", "P4 lifecycle demo: store-scoped revoke"], capture_output=True, text=True, encoding="utf-8", errors="replace")
    rep["revoke"] = {"exit": rv.returncode, "out": rv.stdout[-400:], "err": rv.stderr[-300:]}
    r2 = cli(LC, "run-plan", p2["goal_id"], "--allowed-root", G1)
    rep["run_plan_2_after_revoke"] = {k: r2.get(k) for k in ("state", "reason", "usage", "_exit", "error", "stdout")}
    rp = cli(PROTO, "goal", B, *SRC, *d)
    rep["proto1_after_revoke"] = {k: rp.get(k) for k in ("state", "reason", "usage", "_exit")}
    ok = (rep["run_plan_1_before_revoke"].get("state") == "VERIFIED" and rep["run_plan_2_after_revoke"].get("state") != "VERIFIED"
          and rep["proto1_after_revoke"].get("state") == "VERIFIED" and rep["uuids"]["lc"] != rep["uuids"]["proto"])
    rep["verdict"] = "PASS" if ok else "FAIL"
    (out / "P4_LIFECYCLE.json").write_text(json.dumps(rep, indent=1, sort_keys=True, default=str) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({k: rep[k] for k in ("verdict", "plans", "run_plan_1_before_revoke", "run_plan_2_after_revoke", "proto1_after_revoke")}, default=str)[:1500])


if __name__ == "__main__":
    main()
