"""P3 live backend probes: at most 3 local + 3 hosted calls, through the production campaign driver on the sealed-final policy.

  python scripts/probe_backends.py OUT [--inputs DIR]

One campaign per backend on site.ref-check (not a screen capability), each experiment frozen with 1 call, so <= 3 experiments x 1 call = <= 3 calls per backend.
Resource samples (scripts/resource_profile.py) every 2 s while each campaign runs. Never reruns: an existing store refuses. Nothing is scored or admitted.
"""
import argparse
import json
import sys
import threading
import time
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "scripts")]
import backend_screen as B  # noqa: E402
import coop_pilot as P  # noqa: E402
import g3_qualify as Q  # noqa: E402
import resource_profile as RP  # noqa: E402
from hive import discovery as D, m2_model as M, operator_runtime as O  # noqa: E402
from hive.storage import Store  # noqa: E402
from hive.usage_ledger import HostedLedger  # noqa: E402

CAP = "site.ref-check"


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("--inputs", default="D:/HIVE-operator-inputs/mom-site/exports")
    a = ap.parse_args(argv)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    Q.EXP_BUDGET = dict(Q.EXP_BUDGET, calls=1)  # ponytail: probe-only override of the module budget (frozen into each probe experiment); the screen keeps 3
    cfg = M._dispatch_cfg()
    ledger = HostedLedger(B.hosted_ledger_path(cfg), cfg["pricing"])
    goal, files = P.CAPS[CAP]
    ins = [(f, "file", (Path(a.inputs) / P.OLD / f).read_bytes()) for f in files]
    res = {}
    for name in ("local", "hosted"):
        store = out / f"store-{name}"
        store.mkdir(parents=True)  # raises if it exists: a probe is never rerun
        s = Store(store)
        try:
            O.import_bundle(s)
        finally:
            s.close()
        rows, stop = [], threading.Event()

        def loop():
            while not stop.is_set():
                rows.append(RP.sample())
                stop.wait(2)
        th = threading.Thread(target=loop, daemon=True)
        usd0, t0 = ledger.totals(), time.time()
        th.start()
        try:
            r = Q.acquire_gap(SimpleNamespace(private=None, model=B.BACKENDS[name], stub_endpoint=None, admit_key=None, manifest=None),
                              str(store), f"probe.{name}", CAP, goal, ins, seed_base=9000000, policy=D.SEALED)
        finally:
            stop.set()
            th.join()
            (out / f"samples-{name}.jsonl").write_text("".join(json.dumps(x) + "\n" for x in rows), encoding="utf-8", newline="\n")
        usd1 = ledger.totals()
        rc = json.loads(Path(r["final_receipt"]["path"]).read_text(encoding="utf-8")) if r.get("final_receipt") else {}
        res[name] = {"model": B.BACKENDS[name], "state": r["state"], "cost": r.get("cost"), "wall_s": round(time.time() - t0, 1),
                     "returned_models": (rc.get("backend") or {}).get("returned_models"), "calls": rc.get("calls"), "final_dev_pass": rc.get("final_dev_pass"), "dev_n": rc.get("dev_n"),
                     "hosted_usd_delta": round(usd1["usd_measured"] + usd1["usd_estimated"] - usd0["usd_measured"] - usd0["usd_estimated"], 6),
                     "resources": RP.summarize(rows)}
    (out / "probe-report.json").write_text(json.dumps(res, indent=1, sort_keys=True), encoding="utf-8", newline="\n")
    print(json.dumps({k: {x: v[x] for x in ("state", "cost", "wall_s", "returned_models", "final_dev_pass", "dev_n", "hosted_usd_delta")} for k, v in res.items()}, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
