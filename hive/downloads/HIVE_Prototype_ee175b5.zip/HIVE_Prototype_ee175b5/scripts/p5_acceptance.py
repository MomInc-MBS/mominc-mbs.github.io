"""P5 acceptance: run frozen goals from build/prototype-final/ACCEPTANCE_MANIFEST.json, each in a NEW process through the ordinary operator CLI.

  HIVE_REAL_DOCKER=1 python scripts/p5_acceptance.py --store S --out DIR GOAL_ID [GOAL_ID ...]

Per goal it records the exact command, exit code, state, usage deltas (model calls, experiments) and deliverable hashes, and compares the
broken-refs deliverable byte-for-byte with the sealed evaluator answer in C:/hive-work/eval-private/g1/<commit>/ when one exists.
Failures are recorded, never retried or replaced."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EVAL = Path("C:/hive-work/eval-private/g1")
G1 = "C:/hive-work/demo/g1-inputs"
MS = "D:/HIVE-operator-inputs/mom-site"
A = "Check the references in this site snapshot against its files and list the broken links."
B = "Compare these two site releases: list the changed files and the broken references they affect."
C = "Audit these image assets: list each file's properties, the duplicate groups, and a reconciled report."


def rel(c):  # (allowed root, folder, scope file) for a raw release
    return (G1, c, f"{c}.scope.json") if Path(G1, c).is_dir() else (MS, c, f"{c}.SCOPE.json")


GOALS = {  # frozen in ACCEPTANCE_MANIFEST.json; B carries the operator's answer to the planner's clarification (two deliverables matched)
    "A1": (A, ["2633d9b"], None), "A2": (A, ["0b3854a"], None), "A3": (A, ["e3fcce6"], None), "A4": (A, ["fd6d09b"], None),
    "B1": (B, ["2633d9b", "0b3854a"], "release_change_report"), "B2": (B, ["0b3854a", "e3fcce6"], "release_change_report"),
    "B3": (B, ["e3fcce6", "fd6d09b"], "release_change_report"), "B4": (B, ["2633d9b", "fd6d09b"], "release_change_report"),
}


def counters(store):
    code = ("import json,sys; sys.path.insert(0, %r); from hive.storage import Store; s = Store(%r); "
            "print(json.dumps({'experiments': s.db.execute(\"SELECT COUNT(*) FROM kv WHERE key LIKE 'operator/discovery/d-%%'\").fetchone()[0]})); s.close()") % (str(ROOT / "src"), str(store))
    return json.loads(subprocess.check_output([sys.executable, "-c", code], text=True))


def run(store, gid, out):
    text, rels, deliv = GOALS[gid]
    roots = {rel(c)[0] for c in rels}
    if len(roots) != 1:  # one allowed root per goal: link the release folders under one root is NOT done; record the limit instead
        return {"goal": gid, "state": "NOT_RUN", "reason": f"releases live under different roots {sorted(roots)}"}
    root = roots.pop()
    srcs = [x for c in rels for x in rel(c)[1:]]
    cmd = [sys.executable, "-m", "hive", "--store", str(store), "operator", "goal", text, *srcs, "--allowed-root", root] + (["--deliverable", deliv] if deliv else [])
    env = dict(os.environ, PYTHONPATH=str(ROOT / "src"))
    before, t0 = counters(store), time.monotonic()
    p = subprocess.run(cmd, cwd=root, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=3600)
    rec = {"goal": gid, "cmd": cmd, "cwd": root, "exit": p.returncode, "wall_s": round(time.monotonic() - t0, 1), "stderr_tail": p.stderr[-600:]}
    try:
        o = json.loads(p.stdout)
    except ValueError:
        rec.update(state="NO_JSON", stdout_tail=p.stdout[-600:])
        return rec
    rec.update(state=o.get("state"), reason=o.get("reason"), goal_id=o.get("goal_id"), usage=o.get("usage"),
               plan=[(st.get("cap_id") or st.get("step") or st.get("op")) for st in (o.get("plan") or {}).get("steps", [])] if isinstance(o.get("plan"), dict) else o.get("plan"),
               deliverable=[{k: d.get(k) for k in ("name", "sha256", "bytes")} for d in (o.get("deliverable") or [])])
    rec["new_experiments"] = counters(store)["experiments"] - before["experiments"]
    if gid.startswith("A"):
        exp = EVAL / rels[0] / f"expected-broken-refs-{rels[0]}.json"
        want = hashlib.sha256(exp.read_bytes()).hexdigest() if exp.exists() else None
        got = [d.get("sha256") for d in rec["deliverable"]]
        rec["evaluator_match"] = None if want is None else want in got
    (out / f"{gid}.json").write_text(json.dumps(dict(rec, raw=o), indent=1, sort_keys=True, default=str) + "\n", encoding="utf-8", newline="\n")
    return rec


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--store", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("goals", nargs="+")
    a = ap.parse_args(argv)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    for gid in a.goals:
        r = run(Path(a.store), gid, out)
        print(json.dumps({k: r.get(k) for k in ("goal", "state", "reason", "usage", "new_experiments", "evaluator_match", "plan")}, default=str)[:900], flush=True)


if __name__ == "__main__":
    main()
