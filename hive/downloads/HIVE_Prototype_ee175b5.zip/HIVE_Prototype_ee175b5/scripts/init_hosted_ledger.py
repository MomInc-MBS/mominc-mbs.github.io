"""Operator-run, once: create the hosted-spend ledger named in configs/model_dispatch.json (budget.ledger, under the user profile, outside the store)
and optionally import the live smoke receipt's measured spend into it. Refuses to touch an existing ledger. A missing ledger refuses every hosted call.
Usage: python scripts/init_hosted_ledger.py [--import-receipt build/prototype/approvals/nim-smoke-receipt.json]"""
import argparse, json, os, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from hive.usage_ledger import HostedLedger, UsageRecord  # noqa: E402


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--import-receipt", default=None)
    a = ap.parse_args(argv)
    cfg = json.loads((ROOT / "configs" / "model_dispatch.json").read_text(encoding="utf-8-sig"))
    path = ROOT / os.path.expandvars(os.path.expanduser(cfg["budget"]["ledger"]))
    led = HostedLedger(path, cfg["pricing"])
    led.init()
    if a.import_receipt:
        r = json.loads(Path(a.import_receipt).read_text(encoding="utf-8"))
        for i, c in enumerate(r.get("calls", [])):
            u = c.get("usage") or {}
            if c.get("status") != "ok" or not u: continue
            cached = int((u.get("prompt_tokens_details") or {}).get("cached_tokens") or 0)
            led.record(UsageRecord("smoke-receipt-import", None, f"smoke#{i + 1}", r["model_id"], int(u["prompt_tokens"]) - cached, cached, 0, int(u["completion_tokens"]),
                                   float(c.get("latency_s") or 0.0), True, "smoke_receipt_import"))
    led.check()
    print(f"hosted ledger ready: {path}\nspent so far (measured): ${led.totals()['usd_measured']:.6f}")


if __name__ == "__main__":
    main()
