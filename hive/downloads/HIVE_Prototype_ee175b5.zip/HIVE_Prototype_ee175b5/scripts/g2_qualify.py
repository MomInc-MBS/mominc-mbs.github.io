"""G2 qualification: real GitHub search, the local model and Docker drive one acquisition; a FRESH process then reuses the admitted capability.

  python scripts/g2_qualify.py --phase run   --store S [--run-seed N] [--exec-seed N] [--require-new-external] [--model ID]
                                             [--admit-key PATH] [--resume RUN_ID] [--out DIR] [--private DIR]
  python scripts/g2_qualify.py --phase reuse --store S --unseen-seed N [--drop-image] [--out DIR]

run   makes a goal (images from --run-seed) with acquisition allowed, queues the acquisition, runs the state machine with live GitHub
      (unauthenticated unless env HIVE_GITHUB_TOKEN is set; never logged), the LM Studio model and Docker staging, and writes
      <out>/manifest.json (hive-g2-run-v1 + commit, commands, environment). Without --admit-key it stops at AWAITING_ADMISSION and prints the
      exact admit command; run it, then repeat with --resume RUN_ID (and --admit-key to admit in-process instead).
reuse a new process on unseen inputs (--unseen-seed): optionally `docker rmi` the staged image first (proves the verified tar reload), then
      run_goal must end VERIFIED by retained execution with no model call and no new experiment. Exit code 0 only then.
The fixture author is a conductor-side agent, not Ian. Seeds are recorded only as hashes."""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import platform
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))
from hive import acq_github as AG, acq_stage as ST, acquire as A, capability_registry as CR, capcontract as CC, discovery as D  # noqa: E402
from hive import goal_runner as G, operator_runtime as O, repo_intel as RI  # noqa: E402
from hive.storage import Store  # noqa: E402

CAP = "image.asset-match"
GOAL = "Match these duplicate images and write a manifest"
DISCLOSURE = "conductor-side agent, not Ian (independent of any adapter and of every candidate tool)"


def sha(x): return hashlib.sha256(str(x).encode("utf-8")).hexdigest()


def images(seed):
    """One unseen picture set as goal inputs [(name, 'file', bytes)], from the contract's own generator (the private-set seeding rule)."""
    c = CC.get(CAP)
    env = CC.load_module("gen_private", c).generate(seed, 1)[0]["env"]
    return [(f["name"], "file", base64.b64decode(f["data"])) for f in env["files"]]


def goal_for(seed, **kw):
    ins = images(seed)
    return G.make_contract(GOAL, ins, deliverable="image_match_manifest", **kw), ins


def sh(*argv):
    try:
        return subprocess.run(list(argv), capture_output=True, text=True, timeout=30).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return None


def env_info():
    try:
        import PIL
        pil = PIL.__version__
    except ImportError:
        pil = None
    return {"python": platform.python_version(), "platform": platform.platform(), "pillow_host": pil, "docker": sh("docker", "version", "--format", "{{.Server.Version}}"),
            "git_commit": sh("git", "-C", str(ROOT), "rev-parse", "HEAD"), "git_dirty": bool(sh("git", "-C", str(ROOT), "status", "--porcelain"))}


def real_hooks(store):
    pol = A.policy()
    return {"github": AG.GitHubSearch(Path(store) / "acquisition" / "github-cache", pol), "resolve": RI.resolve_ref,
            "clone": lambda url, sha, dest: RI.clone_pinned(url, sha, dest, timeout=pol["limits"]["git_timeout_s"], max_bytes=pol["limits"]["max_clone_bytes"]), "stager": ST.Stager(pol), "policy": pol}


def phase_run(a):
    store = Path(a.store)
    out = Path(a.out or ROOT / "build" / "g-series" / "g2" / "run-live")
    out.mkdir(parents=True, exist_ok=True)
    fresh = not (store / "hive.sqlite3").exists()
    s = Store(store)
    try:
        if fresh:
            O.import_bundle(s)  # the registry's built-in operations, once per new store
    finally:
        s.close()
    rid = a.resume
    if not rid:
        contract, ins = goal_for(a.run_seed, allow_acquisition=True)
        r = G.run_goal(store, contract, ins)
        if r["state"] != "ACQUISITION_QUEUED":
            print(json.dumps({"ok": False, "goal_state": r["state"], "reason": r["reason"]}))
            return 2
        rid = r["acquisition_run"]
        if a.require_new_external:
            s = Store(store)
            try:
                rec = s.get(A.KEY + rid)
                rec["frozen"]["require_new_external"] = True
                s.set(A.KEY + rid, rec)
            finally:
                s.close()
    admit = None
    hold = CC.get(CAP)["verification"].get("real_holdout")  # contract 2.0.0: admission needs the candidate's real-holdout PASS receipt first
    if a.admit_key and (not hold or a.resume):  # first pass with a holdout: stop at AWAITING_ADMISSION (the receipt needs the candidate); the resume admits
        import hive_admission as H
        admit = lambda store_root, exp_id: H.admit(store_root, exp_id, a.admit_key)

    def execute(store_root):
        contract, ins = goal_for(a.exec_seed)
        return G.run_goal(store_root, contract, ins)
    t0 = time.monotonic()
    run_kw = dict({"requested_model": a.model} if a.model else {}, **({"stub_endpoint": a.stub_endpoint} if a.stub_endpoint else {}))
    hooks = real_hooks(store)
    hooks.setdefault("suggest", A.make_suggest(store, run_kw))  # one model call per run for extra search queries
    rec = A.run(store, rid, hooks=hooks, private_dir=a.private, seed=a.private_seed, run_kw=run_kw, admit=admit, execute=execute)
    s = Store(store)
    try:
        m = A.manifest(s, rec)
    finally:
        s.close()
    m.update(commands=[" ".join([sys.executable, *sys.argv])], environment=env_info(), wall_s_this_invocation=round(time.monotonic() - t0, 1),
             seeds_sha256={"run": sha(a.run_seed), "exec": sha(a.exec_seed), "private": sha(a.private_seed)}, fixture_author=DISCLOSURE)
    (out / "manifest.json").write_text(json.dumps(m, sort_keys=True, indent=1), encoding="utf-8", newline="\n")
    exp = next((x["exp_id"] for x in rec["attempts"] if x["state"] == "PASSED"), None)
    print(json.dumps({"run_id": rid, "state": rec["state"], "reason": rec["reason"], "exp_id": exp, "manifest": str(out / "manifest.json"),
                      "next": ((f"python -I evaluator/g2/real_holdout.py --suite capabilities/{CAP}/suite --store {store} --candidate-file <cand-body.py> --candidate-sha <sha> (env {hold['dir_env']}; opens once); then " if hold else "")
                               + f"python scripts/hive_admission.py admit --store {store} --exp {exp} --key <external key>   (then: --phase run --store {store} --resume {rid})"
                               if rec["state"] == "AWAITING_ADMISSION" else None)}, indent=1))
    return 0 if rec["state"] == "DONE" else 3


def phase_reuse(a):
    store = Path(a.store)
    out = Path(a.out or ROOT / "build" / "g-series" / "g2" / "run-live")
    out.mkdir(parents=True, exist_ok=True)
    s = Store(store)
    try:
        r = CR.resolve_discovered(s, CAP)  # the signed, current statement
        env = r["statement"].get("environment") or {}
        before = {"experiments": len(D.experiments(s)), "counters": O._counters(s)}
    finally:
        s.close()
    dropped = None
    if a.drop_image and env.get("id"):
        dropped = subprocess.run(["docker", "rmi", "--force", env["id"]], capture_output=True, text=True, timeout=120).returncode == 0
    contract, ins = goal_for(a.unseen_seed)
    res = G.run_goal(store, contract, ins)
    s = Store(store)
    try:
        after = {"experiments": len(D.experiments(s)), "counters": O._counters(s)}
    finally:
        s.close()
    last = res["steps"][-1] if res.get("steps") else {}
    ok = (res["state"] == "VERIFIED" and last.get("mode") == "retained_capability_execution" and last.get("verdict") == "PASS"
          and after["experiments"] == before["experiments"] and after["counters"]["model_calls"] == before["counters"]["model_calls"]
          and after["counters"]["proposal_calls"] == before["counters"]["proposal_calls"])
    rep = {"schema": "hive-g2-reuse-v1", "ok": ok, "state": res["state"], "reason": res["reason"], "mode": last.get("mode"), "verdict": last.get("verdict"),
           "capability": last.get("capability"), "image_id": env.get("id"), "image_dropped_before_run": dropped, "fresh_process": True, "unseen_seed_sha256": sha(a.unseen_seed),
           "new_experiments": after["experiments"] - before["experiments"], "new_model_calls": after["counters"]["model_calls"] - before["counters"]["model_calls"],
           "fixture_author": DISCLOSURE, "environment": env_info(), "command": " ".join([sys.executable, *sys.argv])}
    (out / "reuse.json").write_text(json.dumps(rep, sort_keys=True, indent=1), encoding="utf-8", newline="\n")
    print(json.dumps(rep, indent=1))
    return 0 if ok else 1


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--phase", choices=("run", "reuse"), required=True)
    ap.add_argument("--store", required=True)
    ap.add_argument("--out")
    ap.add_argument("--run-seed", type=int, default=101)
    ap.add_argument("--exec-seed", type=int, default=202)
    ap.add_argument("--private-seed", type=int, default=None)
    ap.add_argument("--private")
    ap.add_argument("--unseen-seed", type=int, default=303)
    ap.add_argument("--model")
    ap.add_argument("--require-new-external", action="store_true")
    ap.add_argument("--admit-key")
    ap.add_argument("--resume")
    ap.add_argument("--drop-image", action="store_true")
    ap.add_argument("--stub-endpoint", help="test seam: a stub model endpoint instead of LM Studio")
    a = ap.parse_args(argv)
    return phase_run(a) if a.phase == "run" else phase_reuse(a)


if __name__ == "__main__":
    sys.exit(main())
