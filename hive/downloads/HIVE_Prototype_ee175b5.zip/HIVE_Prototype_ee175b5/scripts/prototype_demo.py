"""HIVE prototype demonstration: learn, reuse/extend, open-source acquisition, composition, cold restart, stored plans, alternatives, improve/rollback.

  python scripts/prototype_demo.py --store DIR --out DIR --phase P [options]

Phases run in order and are resumable; the state lives in <store>/demo/state.json and every phase checks its preconditions and refuses (exit 2) when they are unmet.

  init      fresh store, registry snapshot (cap list JSON + sha256), model id and weights pin, commit, input copies (read-only sources, sha-verified)
  learn-a   L1 site.ref-extract and L1b site.ref-resolve acquired by the local model (gap -> experiment -> independent evaluator -> signed admission); L2 site.ref-check
            is reused when already admitted in the store, never re-acquired
  goal-a    H1 broken-links goal on release 2633d9b (raw pages + manifest), planned as the 3-step chain extract -> resolve -> check
  goal-b    the same goal on 0b3854a (reuse of all three: 0 acquisitions, 0 model calls), then L3 site.release-diff acquired and run on the two manifests
  learn-c   image.asset-match from live GitHub (open source, pinned), asset.properties and report.reconcile by the local model on the real pictures
  goal-c    H2 (20 pictures, three steps) and H3 (19 pictures plus asset-properties-images-19.json) on the real images; an invalid edge is refused before execution
  restart   NEW processes: cap list, every admitted capability on valid inputs, stored plans via plan/run-plan with 0 model calls, H1-H3 held out
  alt       site.ref-check-alt acquired (--backend), ranking with both alternatives, preferred revoked, H1 reruns on the alternative, store restored
  improve   `cap improve` with a declared failure_class objective (ADMITTED or REJECTED, reported as it is), rollback to v1, revoke v2, others still VERIFIED
  report    OUT/SUMMARY.json and OUT/REPORT.md from everything above

Everything goes through the production entry points: `python -m hive --store S operator ...` (plan, run-plan, goal, cap list|show|revoke|rollback|improve,
acquisitions, receipt, overview), scripts/g3_qualify.acquire_gap (local-model acquisition), acquire.run with the real GitHub hooks (as g2_qualify), and
scripts/hive_admission.admit (signed admission). No mock runner, no adapter or answer written here. Each phase appends its exact commands/calls to
OUT/commands.log and writes receipts (the plan's minimum format) to OUT/receipts/<phase>-<test_id>.json. Unknown metrics are null. Failures are kept,
reported, and never retried by this script; only the retries the production code itself does happen (carry-best repair inside acquire_gap, <=3 experiments)."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

PHASES = ("init", "learn-a", "goal-a", "goal-b", "learn-c", "goal-c", "restart", "alt", "improve", "report")
SCHEMA = "hive-prototype-demo-v1"
DEFAULT_INPUTS = "D:/HIVE-operator-inputs/mom-site/exports"
OLD, NEW = "2633d9b", "0b3854a"
EXTRACT, RESOLVE, CHECK, ALT, DIFF = "site.ref-extract", "site.ref-resolve", "site.ref-check", "site.ref-check-alt", "site.release-diff"
H1_OPS = [EXTRACT, RESOLVE, CHECK]
H3_TABLE, H3_SKIP = "asset-properties-images-19.json", "little-boyfriend-app-icons-icon-512.png"
MATCH, PROPS, RECON = "image.asset-match", "asset.properties", "report.reconcile"
TEXT = {
    "L1": "Scan the pages of this site for every raw reference.",
    "L1b": "Resolve these scanned page references into a reference table.",
    "L2": "Check these references against the site manifest and list the broken links.",
    "L3": "Produce the release change report for these two site manifests.",
    "H1": "Check the references in these site pages against the site manifest and list the broken links.",
    "H2": "Write a reconciliation report: which of these pictures are copies, and how much space can I reclaim?",
    "MATCH": "Match these duplicate images and write a manifest",
    "PROPS": "Write the image properties table for these pictures",
    "RECON": "Write a reconciliation report using these two files",
}
PAGES, RAW, MANIFEST, TABLE = (lambda c: f"{c}/site-pages-{c}.json"), (lambda c: f"{c}/raw-reference-table-{c}.json"), (lambda c: f"{c}/site-manifest-{c}.json"), (lambda c: f"{c}/reference-table-{c}.json")
DERIVED = ("derived/manifest.json", "derived/properties.json")  # real outputs of image.asset-match and asset.properties (learn-c), fed to report.reconcile
TESTS = {"T02": "General acquisition (distinct typed capabilities admitted or reused)", "T03": "Multi-match planner (same-interface alternatives, fallback)",
         "T06": "Real open-source import", "T10": "Cold restart", "T11": "Inference-free reuse (stored plan, 0 model calls)", "T12": "Composition (3 steps, invalid edge refused)",
         "T13": "Novel composition (held-out H1-H3)", "T14": "Version repair / improve", "T15": "Rollback and revocation", "T18": "Model portability (selectable backend)",
         "T20": "Three live demonstrations on real inputs (init, A learn, B reuse/extend, C compose)"}


class Refuse(Exception):
    """A phase precondition is unmet (exit 2, nothing changed)."""


def sha_b(b): return hashlib.sha256(b).hexdigest()
def canon(o): return json.dumps(o, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
def now(): return time.strftime("%Y-%m-%dT%H:%M:%S%z")


def git(*argv):
    try:
        return subprocess.run(["git", "-C", str(ROOT), *argv], capture_output=True, text=True, timeout=30).stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return None


def commit_id():
    head = git("rev-parse", "HEAD")
    dirty = git("status", "--porcelain", "--", "src", "scripts", "configs", "capabilities", "evaluator", "schemas")
    return (head or "unknown") + ("+dirty" if dirty else "")


class Demo:
    def __init__(self, a):
        self.a, self.store, self.out = a, Path(a.store), Path(a.out)
        self.state_path = self.store / "demo" / "state.json"
        self.inputs = self.out / "inputs"
        self.phase = None
        self.n = 0
        self.key = a.admit_key

    # ------------------------------------------------------------ state, log
    def load(self):
        if self.state_path.is_file():
            return json.loads(self.state_path.read_text(encoding="utf-8"))
        return {"schema": SCHEMA, "phases": {}, "goals": {}, "receipts": []}

    def save(self, st):
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.state_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(st, sort_keys=True, indent=1), encoding="utf-8", newline="\n")
        os.replace(tmp, self.state_path)

    def log(self, text):
        self.out.mkdir(parents=True, exist_ok=True)
        with open(self.out / "commands.log", "a", encoding="utf-8", newline="\n") as f:
            f.write(f"{now()} [{self.phase}] {text}\n")

    def evidence(self, name, data):
        p = self.out / "evidence" / self.phase / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(data if isinstance(data, str) else json.dumps(data, sort_keys=True, indent=1), encoding="utf-8", newline="\n")
        return p.relative_to(self.out).as_posix()

    # ------------------------------------------------------------ production calls
    def cli(self, label, *argv, timeout=3600):
        """One real `python -m hive --store S operator ...` process; returns (rc, parsed stdout JSON or None, elapsed_ms). Exact command is logged."""
        cmd = [sys.executable, "-m", "hive", "--store", str(self.store), "operator", *argv]
        self.log("$ " + " ".join(json.dumps(c) if " " in c else c for c in cmd))
        env = dict(os.environ, PYTHONPATH=str(ROOT / "src"), PYTHONUTF8="1", PYTHONIOENCODING="utf-8")
        t0 = time.monotonic()
        p = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", cwd=str(ROOT), env=env, timeout=timeout)
        ms = int((time.monotonic() - t0) * 1000)
        self.n += 1
        tag = f"{self.n:02d}-{label}"
        self.evidence(tag + ".stdout.json", p.stdout)
        if p.stderr.strip():
            self.evidence(tag + ".stderr.txt", p.stderr)
        try:
            data = json.loads(p.stdout)
        except ValueError:
            data = None
        return p.returncode, data, ms, f"evidence/{self.phase}/{tag}.stdout.json"

    def goal(self, label, text, rels, *, root=None):
        rc, d, ms, ev = self.cli(label, "goal", text, *rels, "--allowed-root", str(root or self.inputs))
        return d, ms, ev

    def plan(self, label, text, rels):
        rc, d, ms, ev = self.cli(label, "plan", text, *rels, "--allowed-root", str(self.inputs))
        return d, ms, ev

    def caps(self):
        """cap list --json through the CLI (exact command logged); returns the rows."""
        rc, d, ms, ev = self.cli("cap-list", "cap", "list", "--json")
        if rc or not isinstance(d, list):
            raise Refuse("cap list failed (rc %s)" % rc)
        return d

    def snapshot(self):
        rows = self.caps()
        return rows, sha_b(canon(rows).encode("utf-8"))

    def active(self):
        return {r["id"]: r["version"] for r in self.caps() if r["kind"] == "discovered" and r["lifecycle"] == "active"}

    def meter(self):
        from hive import acquire as A, discovery as D, operator_runtime as O
        from hive.storage import Store
        s = Store(self.store)
        try:
            return {"counters": dict(O._counters(s)), "ledger": dict(s.get(D.LEDGER) or {}), "experiments": len(D.experiments(s)), "runs": len(A.runs(s))}
        finally:
            s.close()

    @staticmethod
    def spent(a, b):
        c = {k: b["counters"].get(k, 0) - a["counters"].get(k, 0) for k in ("model_calls", "proposal_calls", "container_runs", "executions", "replays")}
        l = {k: b["ledger"].get(k, 0) - a["ledger"].get(k, 0) for k in ("calls", "proposals", "in_tokens", "out_tokens", "container_runs")}
        return {"model_calls": c["model_calls"] + l["calls"], "proposal_calls": c["proposal_calls"] + l["proposals"], "in_tokens": l["in_tokens"], "out_tokens": l["out_tokens"],
                "container_runs": c["container_runs"], "replays": c["replays"], "new_experiments": b["experiments"] - a["experiments"], "new_acquisition_runs": b["runs"] - a["runs"]}

    # ------------------------------------------------------------ inputs
    def src(self, rel): return self.inputs / rel

    def file_info(self, rel):
        b = self.src(rel).read_bytes()
        return {"path": rel, "bytes": len(b), "sha256": sha_b(b)}

    def read(self, rel):
        if not self.src(rel).is_file() and (Path(self.a.inputs) / rel).is_file():  # exports added after init: copy from the read-only source
            self.src(rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(Path(self.a.inputs) / rel, self.src(rel))
            self.log(f"copy {Path(self.a.inputs) / rel} -> {self.src(rel)} (added after init)")
        return (self.src(rel).name, "file", self.src(rel).read_bytes())

    # ------------------------------------------------------------ receipts
    def receipt(self, test_id, fixture, expected, observed, status, elapsed_ms, *, calls=None, tin=None, tout=None, cost=None, evidence=None, details=None, snap=None):
        assert status in ("pass", "fail", "skip", "blocked")
        r = {"test_id": test_id, "baseline_commit": self.a.baseline_commit, "candidate_commit": commit_id(), "fixture_id": fixture,
             "registry_snapshot": snap or self.snapshot()[1], "expected": expected, "observed": observed, "status": status, "elapsed_ms": elapsed_ms,
             "model_calls": calls, "input_tokens": tin, "cached_input_tokens": None, "output_tokens": tout, "cost_usd": cost,
             "evidence_path": evidence, "phase": self.phase, "at": now(), "details": details or {}}
        p = self.out / "receipts" / f"{self.phase}-{test_id}.json"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(r, sort_keys=True, indent=1), encoding="utf-8", newline="\n")
        return r

    # ------------------------------------------------------------ goal summaries
    def gsum(self, rec, ms=None, ev=None):
        if not isinstance(rec, dict):
            return {"state": "NO_OUTPUT"}
        steps = [{"op": s["op"], "kind": s["kind"], "mode": s.get("mode"), "state": s.get("state"), "verdict": s.get("verdict"),
                  "version": (s.get("capability") or {}).get("version")} for s in rec.get("steps", [])]
        art = next((a for a in rec.get("deliverable") or [] if not a["name"].endswith("report.json")), None)
        plan = rec.get("plan") or {}
        u = rec.get("usage") or {}
        return {"goal_id": rec.get("goal_id"), "state": rec.get("state"), "reason": rec.get("reason"), "gap_ref": rec.get("gap_ref"), "missing_step": rec.get("missing_step"),
                "plan": [x["op"] + "(" + ",".join(x["inputs"]) + ")" for x in plan.get("steps", [])], "plan_ops": [x["op"] for x in plan.get("steps", [])],
                "ranking": [{"step": x["step_id"], "alternatives": [a.get("op") if isinstance(a, dict) and "op" in a else a for a in (x.get("ranking") or {}).get("alternatives", [])]}
                           for x in plan.get("steps", []) if x.get("ranking")],
                "steps": steps, "usage": u, "fallbacks": rec.get("fallbacks"), "stored_plan": rec.get("stored_plan"), "output": art and {"name": art["name"], "sha256": art.get("sha256"), "ref": art.get("ref")},
                "wall_ms": ms, "evidence": ev}

    def goal_ok(self, g, ops=None, allow_replay=True):
        if g.get("state") != "VERIFIED":
            return False
        if any(s["kind"] == "discovered" and s["verdict"] != "PASS" for s in g["steps"]):
            return False
        u = g.get("usage") or {}
        if u.get("model_calls") != 0 or u.get("proposal_calls") != 0:  # missing or null is unknown, not zero
            return False
        return ops is None or g["plan_ops"] == ops

    def note(self, st, key, **kw):
        st["goals"].setdefault(key, {}).update(kw)

    # ------------------------------------------------------------ acquisition (local model): G3's production driver
    def acquire_local(self, label, cap, text, rels, *, direct=None):
        import g3_qualify as Q3
        ins = direct if direct is not None else [self.read(r) for r in rels]
        ns = SimpleNamespace(private=None, model=self.a.model, stub_endpoint=self.a.stub_endpoint, admit_key=str(self.key))
        self.log(f"call g3_qualify.acquire_gap(store, {label!r}, {cap!r}, {text!r}, inputs={[i[0] for i in ins]}) with admit_key={self.key} model={ns.model or 'policy default'}")
        t0 = time.monotonic()
        out = Q3.acquire_gap(ns, str(self.store), label, cap, text, ins)
        out["wall_s_total"] = round(time.monotonic() - t0, 1)
        out["inputs"] = [self.file_info(r) for r in rels] if direct is None else [{"name": n, "bytes": len(b), "sha256": sha_b(b)} for n, _, b in direct]
        self.evidence(f"acquire-{label}-{cap}.json", out)
        return out

    def acq_receipt_fields(self, outs):
        t = {k: 0 for k in ("calls", "in_tokens", "out_tokens", "wall_s")}
        for o in outs:
            for k in t:
                t[k] += (o.get("cost") or {}).get(k, 0)
        return t

    def goal_doc(self, s):
        """The JSON deliverable a VERIFIED goal exported under <store>/output/goal/<goal_id>/, or None."""
        o = s.get("output")
        if not o or not s.get("goal_id"):
            return None
        try:
            return json.loads((self.store / "output" / "goal" / s["goal_id"] / o["name"]).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None

    def chain_ready(self):
        """True only when ref-extract and ref-resolve are both admitted and active (the 3-step H1 chain exists)."""
        return {EXTRACT, RESOLVE} <= set(self.active())

    def bl_goal(self, commit):
        """The broken-links goal for a release: the 3-step H1 when the chain is admitted, else the evaluator-exported reference table + manifest."""
        return (TEXT["H1"], [PAGES(commit), MANIFEST(commit)], H1_OPS) if self.chain_ready() else (TEXT["L2"], [TABLE(commit), MANIFEST(commit)], [CHECK])

    def run_acq(self, test_id, fixture, items, expected, blocked=()):
        """Acquire several gaps (items = [(label, cap, text, rels|None, direct|None)]), one receipt for the set.
        `blocked` = [(label, cap, reason)] not attempted: they never count as admitted, and the receipt is never `pass` while any exists."""
        outs = []
        for label, cap, text, rels, direct in items:
            outs.append(self.acquire_local(label, cap, text, rels or [], direct=direct))
        adm = [o["capability"] for o in outs if o["state"] in ("ADMITTED", "ALREADY_RETAINED")]
        ok = len(adm) == len(outs)
        tot = self.acq_receipt_fields(outs)
        obs = "; ".join([f"{o['label']} {o['capability']}: {o['state']}" + (f" ({o.get('attempts', [{}])[-1].get('reason')})" if o["state"] not in ("ADMITTED", "ALREADY_RETAINED") else "") for o in outs]
                        + [f"{l} {c}: BLOCKED ({why})" for l, c, why in blocked])
        r = self.receipt(test_id, fixture, expected, obs, ("pass" if not blocked else "blocked") if ok else "fail", int(tot["wall_s"] * 1000), calls=int(tot["calls"]), tin=int(tot["in_tokens"]), tout=int(tot["out_tokens"]),
                         cost=0.0, evidence=f"evidence/{self.phase}/", details={"admitted": adm, "blocked": [{"label": l, "capability": c, "reason": why} for l, c, why in blocked],
                                  "acquisitions": [{k: o.get(k) for k in ("label", "capability", "state", "goal_state", "reason", "missing_step", "attempts", "admission", "cost", "wall_s_total")} for o in outs]})
        return outs, r, ok


# ===================================================================== phases
def ph_init(d, st):
    a = d.a
    if d.store.exists() and any(d.store.iterdir()):
        raise Refuse(f"store {d.store} is not empty: init needs a fresh store")
    if not Path(a.inputs).is_dir():
        raise Refuse(f"input exports not found: {a.inputs}")
    if not Path(d.key).is_file():
        raise Refuse(f"admission key {d.key} not found (python scripts/hive_admission.py init)")
    d.store.mkdir(parents=True, exist_ok=True)
    d.out.mkdir(parents=True, exist_ok=True)
    d.log(f"copy read-only inputs {a.inputs} -> {d.inputs} (sha256-checked)")
    shutil.copytree(a.inputs, d.inputs, dirs_exist_ok=True)
    bad = [p.name for p in Path(a.inputs).rglob("*") if p.is_file() and sha_b(p.read_bytes()) != sha_b((d.inputs / p.relative_to(a.inputs)).read_bytes())]
    if bad:
        raise Refuse(f"input copy differs from source: {bad[:3]}")
    from hive import m2_model as M, m2_workflow as W
    pol = W.load_policy()
    model = pol["model"]
    listing = None
    try:
        with urllib.request.urlopen(model["endpoint"].rstrip("/") + "/models", timeout=10) as r:
            listing = [x["id"] for x in json.loads(r.read())["data"]]
    except (OSError, ValueError, KeyError) as e:
        listing = f"unavailable: {type(e).__name__}"
    rows, snap = d.snapshot()
    (d.out / "registry-initial.json").write_text(json.dumps(rows, sort_keys=True, indent=1), encoding="utf-8", newline="\n")
    rc, ready, ms, ev = d.cli("readiness", "readiness")
    info = {"commit": commit_id(), "baseline_commit": a.baseline_commit, "branch": git("rev-parse", "--abbrev-ref", "HEAD"),
            "model": {"id": model["id"], "endpoint": model["endpoint"], "weights_file": model["file"], "weights_sha256_pinned": model["sha256"], "weights_bytes": model["bytes"],
                      "endpoint_lists": listing, "weights_rehashed_at": "each experiment (m2_model.check_weights, see discovery/<exp>/model/weight_checks.jsonl)"},
            "backends": M.list_backends(), "registry_initial": {"sha256": snap, "rows": len(rows), "file": "registry-initial.json"},
            "inputs": {"source": a.inputs, "copy": str(d.inputs), "files": len([p for p in d.inputs.rglob("*") if p.is_file()]), "read_only_source_verified": True},
            "readiness": ready, "admission_key": str(d.key), "python": sys.version.split()[0]}
    (d.out / "init.json").write_text(json.dumps(info, sort_keys=True, indent=1), encoding="utf-8", newline="\n")
    clean = not [r for r in rows if r["kind"] == "discovered"]
    h1 = [d.file_info(PAGES(OLD)), d.file_info(MANIFEST(OLD))]
    plan, ms2, ev2 = d.plan("initial-gap-H1", TEXT["H1"], [PAGES(OLD), MANIFEST(OLD)])
    g = d.gsum(plan)
    d.note(st, "A", label="Goal A (learn): H1-style broken links on release " + OLD, text=TEXT["H1"], inputs=h1, initial_gap={"plan_state": g["state"], "reason": g["reason"], "registry_rows": len(rows)})
    r = d.receipt("T20", "init: declared clean registry", "no admitted capability; H1 goal UNRESOLVED (a genuine gap)", f"{len(rows)} registry rows, discovered={not clean}; H1 plan {g['state']}: {g['reason']}",
                  "pass" if clean and g["state"] == "UNRESOLVED" else "fail", ms + ms2, calls=0, tin=0, tout=0, cost=0.0, evidence="init.json", details=info, snap=snap)
    return r["status"] == "pass"


def ph_learn_a(d, st):
    need_phase(st, "init")
    # L2 is reused when already admitted (acquire_gap returns ALREADY_RETAINED, 0 calls); L1 and L1b are real acquisitions unless --skip-unlearnable names them
    skip = {c.strip() for c in d.a.skip_unlearnable.split(",") if c.strip()}
    neg = [x.strip() for x in d.a.negative_evidence.split(",") if x.strip()]
    for x in neg:
        if not Path(x).exists():
            raise Refuse(f"negative evidence path not found: {x}")
    kept = []
    for x in neg:  # unique name from the last three path parts (o3/evidence/learn-a), so runs do not collide
        dest = d.out / "evidence" / "negative" / "-".join(Path(x).parts[-3:]).replace(":", "")
        dest.parent.mkdir(parents=True, exist_ok=True)
        if Path(x).is_dir():
            shutil.copytree(x, dest, dirs_exist_ok=True)
        else:
            shutil.copyfile(x, dest)
        kept.append(dest.relative_to(d.out).as_posix())
    if neg:
        d.log(f"copy negative evidence {neg} -> {kept}")
    why = f"skipped: not learnable by available models (evidence: {', '.join(neg) or 'none given'})"
    allitems = [("L1", EXTRACT, TEXT["L1"], [PAGES(OLD)], None), ("L1b", RESOLVE, TEXT["L1b"], [RAW(OLD)], None), ("L2", CHECK, TEXT["L2"], [TABLE(OLD), MANIFEST(OLD)], None)]
    items = [i for i in allitems if i[1] not in skip]
    blocked = [(i[0], i[1], why) for i in allitems if i[1] in skip]
    outs, r, ok = d.run_acq("T02", "L1 site.ref-extract + L1b site.ref-resolve acquired unless skipped as unlearnable, L2 site.ref-check reused if admitted (release " + OLD + ")", items,
                            "L1 and L1b acquired, evaluated, admitted (signed) or blocked; L2 admitted or reused; T02 passes only if nothing is blocked or failed", blocked=blocked)
    for o, lab in zip(outs, [i[0] for i in items]):
        d.note(st, lab, label=f"Learning goal {lab}", text=o["goal"], inputs=o["inputs"], initial_gap={"goal_state": o.get("goal_state"), "reason": o.get("reason"), "missing_step": o.get("missing_step")},
               candidates=[{"exp_id": x["exp_id"], "state": x["state"], "best_dev_pass": x.get("best_dev_pass")} for x in o.get("attempts", [])],
               evaluation=[x.get("receipt") for x in o.get("attempts", [])], admission=o.get("admission"), retained=o.get("retained"), state=o["state"], cost=o.get("cost"))
    for lab, cap, _ in blocked:
        d.note(st, lab, label=f"Learning goal {lab} ({cap})", state="blocked", result=why, evidence=kept)
    if blocked:
        st["rescope"] = {"blocked": {c: why for _, c, _ in blocked}, "evidence": kept, "evidence_sources": neg}
    return any(o["capability"] == CHECK and o["state"] in ("ADMITTED", "ALREADY_RETAINED") for o in outs)  # the phase passes when L2 is admitted


BL_NOTE = ("The reference table is a deterministic evaluator-side export of the real pages (scripts/export_site_inputs.py plus the ref-extract oracle), "
           "because HIVE could not learn the extract and resolve steps.")


def broken_summary(doc):
    """(count, list) from a site.ref-check output ({'broken': [...], 'totals': {...}}); (None, None) when the output is not that shape."""
    b = doc.get("broken") if isinstance(doc, dict) else None
    return (len(b), b) if isinstance(b, list) else (None, None)


def ph_goal_a(d, st):
    need_phase(st, "learn-a")
    chain = d.chain_ready()
    need_caps(d, *(H1_OPS if chain else [CHECK]))
    text, rels, ops = d.bl_goal(OLD)
    m0 = d.meter()
    g, ms, ev = d.goal(("H1-" if chain else "BL-") + OLD, text, rels)
    s = d.gsum(g, ms, ev)
    delta = d.spent(m0, d.meter())
    rc, rcp, ms2, ev2 = d.cli("receipt", "receipt", str(s.get("goal_id")), "--json") if s.get("goal_id") else (1, None, 0, None)
    ok = d.goal_ok(s, ops) and delta["model_calls"] == 0 and delta["new_experiments"] == 0 and delta["new_acquisition_runs"] == 0
    cnt, lst = broken_summary(d.goal_doc(s)) if ok else (None, None)
    extra = {} if chain else {"label": "Goal A (re-scoped): broken links on release " + OLD + " from the exported reference table", "text": text, "inputs": [d.file_info(r) for r in rels]}
    d.note(st, "A", plan=s["plan"], steps=s["steps"], output=s["output"], reuse={"acquisitions": delta["new_acquisition_runs"], "model_calls": delta["model_calls"], "run": "fresh retained execution of the admitted capabilities"},
           result={"state": s["state"], "reason": s["reason"], "usage": s["usage"], "broken_count": cnt, "broken": lst, **({} if chain else {"note": BL_NOTE})}, receipt_cmd=rcp, **extra)
    d.receipt("T20", "Goal A: broken links on " + OLD + (" raw pages + manifest" if chain else " reference table + manifest (evaluator-side export)"),
              ("VERIFIED by chaining the three admitted capabilities, " if chain else "VERIFIED by retained execution of site.ref-check, ") + "0 model calls, 0 new experiments",
              f"{s['state']} plan={s['plan']} steps={[(x['op'], x['mode'], x['verdict']) for x in s['steps']]} {delta}; broken links: {cnt}" + ("" if chain else "; " + BL_NOTE), "pass" if ok else "fail", ms,
              calls=delta["model_calls"], tin=0 if not delta["model_calls"] else None, tout=0 if not delta["model_calls"] else None, cost=0.0, evidence=ev,
              details={"goal": s, "delta": delta, "broken_count": cnt, "broken": lst, **({} if chain else {"input_note": BL_NOTE})})
    if not chain:
        rs = st.get("rescope") or {}
        d.receipt("H1", "H1 3-step chain extract -> resolve -> check on " + OLD, "VERIFIED chain of three admitted capabilities",
                  "not run: site.ref-extract and site.ref-resolve are not admitted (" + str(rs.get("blocked", "not learnable by available models")) + ")", "blocked", 0,
                  calls=0, tin=0, tout=0, cost=0.0, evidence="; ".join(rs.get("evidence", [])) or None, details={"blocked": rs})
    return ok


def ph_goal_b(d, st):
    need_phase(st, "goal-a")
    chain = d.chain_ready()
    need_caps(d, *(H1_OPS if chain else [CHECK]))
    text, rels, ops = d.bl_goal(NEW)
    m0 = d.meter()
    g, ms, ev = d.goal(("H1-" if chain else "BL-") + NEW, text, rels)
    s = d.gsum(g, ms, ev)
    delta = d.spent(m0, d.meter())
    ok_b = d.goal_ok(s, ops) and delta["model_calls"] == 0 and delta["new_experiments"] == 0 and delta["new_acquisition_runs"] == 0
    cnt, lst = broken_summary(d.goal_doc(s)) if ok_b else (None, None)
    d.note(st, "B", label="Goal B (reuse and extend): the same goal on release " + NEW, text=text, inputs=[d.file_info(r) for r in rels],
           initial_gap={"gap": "none: the admitted capabilities already cover the goal", "plan_ops": s["plan_ops"]}, plan=s["plan"], steps=s["steps"], output=s["output"],
           reuse={"acquisitions": delta["new_acquisition_runs"], "model_calls": delta["model_calls"], "new_experiments": delta["new_experiments"]},
           result={"state": s["state"], "usage": s["usage"], "broken_count": cnt, "broken": lst, **({} if chain else {"note": BL_NOTE})})
    d.receipt("T20", "Goal B reuse: " + OLD + " capabilities on " + NEW, "VERIFIED with 0 acquisitions and 0 model calls",
              f"{s['state']} {delta}; broken links: {cnt}" + ("" if chain else "; " + BL_NOTE), "pass" if ok_b else "fail", ms, calls=delta["model_calls"], tin=0 if not delta["model_calls"] else None,
              tout=0 if not delta["model_calls"] else None, cost=0.0, evidence=ev, details={"goal": s, "delta": delta, "broken_count": cnt, "broken": lst})
    # the new requirement: L3 release-diff is a genuine gap
    gap_plan, _, _ = d.plan("L3-gap", TEXT["L3"], [MANIFEST(OLD), MANIFEST(NEW)])
    outs, r, ok_c = d.run_acq("T02", "L3 site.release-diff on the two manifests", [("L3", DIFF, TEXT["L3"], [MANIFEST(OLD), MANIFEST(NEW)], None)], "release-diff acquired (genuine gap), evaluated, admitted")
    o = outs[0]
    ok_run = False
    if ok_c:
        g3, ms3, ev3 = d.goal("L3-run", TEXT["L3"], [MANIFEST(OLD), MANIFEST(NEW)])
        s3 = d.gsum(g3, ms3, ev3)
        ok_run = d.goal_ok(s3, [DIFF])
        tot = ((d.goal_doc(s3) or {}).get("totals") or {}) if ok_run else {}
        d.note(st, "L3", plan=s3["plan"], steps=s3["steps"], output=s3["output"], result={"state": s3["state"], "usage": s3["usage"], "release_diff": {k: tot.get(k) for k in ("added", "removed", "modified")}})
        d.evidence("L3-run.json", s3)
        d.receipt("L3", "site.release-diff on the two real manifests " + OLD + " -> " + NEW, "VERIFIED run, counts reported", f"{s3['state']}; added/removed/modified = {tot.get('added')}/{tot.get('removed')}/{tot.get('modified')}",
                  "pass" if ok_run else "fail", ms3, calls=0 if ok_run else None, cost=0.0, evidence=ev3, details={"goal": s3, "totals": tot})
    d.note(st, "L3", label="Learning goal L3 (the new requirement of Goal B)", text=TEXT["L3"], inputs=o["inputs"], initial_gap={"plan_state": d.gsum(gap_plan)["state"], "reason": d.gsum(gap_plan)["reason"], "missing_step": o.get("missing_step")},
           candidates=[{"exp_id": x["exp_id"], "state": x["state"], "best_dev_pass": x.get("best_dev_pass")} for x in o.get("attempts", [])], evaluation=[x.get("receipt") for x in o.get("attempts", [])],
           admission=o.get("admission"), cost=o.get("cost"), state=o["state"])
    return ok_b and ok_c and ok_run


def ph_learn_c(d, st):
    need_phase(st, "goal-b")
    imgs = sorted(p.relative_to(d.inputs).as_posix() for p in (d.inputs / "images").glob("*.png"))
    if len(imgs) != 20:
        raise Refuse(f"expected the 20 real pictures in {d.inputs / 'images'}, found {len(imgs)}")
    import g2_qualify as Q2
    from hive import acquire as A, capability_registry as CR, goal_runner as G
    from hive.storage import Store
    import hive_admission as H
    store = d.store
    ins = [d.read(r) for r in imgs]
    t0 = time.monotonic()
    res = {"capability": MATCH, "inputs": [d.file_info(r) for r in imgs]}
    s_ = Store(store)
    try:
        have = CR.head(s_, MATCH) is not None
    finally:
        s_.close()
    ok_match = False
    if have:
        res.update(state="ALREADY_RETAINED")
        ok_match = True
    else:
        contract = G.make_contract(TEXT["MATCH"], ins, deliverable="image_match_manifest", allow_acquisition=True)
        d.log(f"call goal_runner.run_goal(store, make_contract({TEXT['MATCH']!r}, 20 real pictures, deliverable=image_match_manifest, allow_acquisition=True))")
        r = G.run_goal(store, contract, ins)
        res.update(goal_state=r["state"], reason=r.get("reason"), missing_step=r.get("missing_step"), gap_ref=r.get("gap_ref"))
        d.note(st, "C", initial_gap={"goal_state": r["state"], "reason": r.get("reason"), "missing_step": r.get("missing_step")})
        if r["state"] != "ACQUISITION_QUEUED":
            res["state"] = "GOAL_NOT_QUEUED"
        else:
            rid = r["acquisition_run"]
            if d.a.require_new_external:
                s_ = Store(store)
                try:
                    rec = s_.get(A.KEY + rid)
                    rec["frozen"]["require_new_external"] = True
                    s_.set(A.KEY + rid, rec)
                finally:
                    s_.close()
            admit = lambda root, exp_id: H.admit(root, exp_id, str(d.key))
            execute = lambda root: G.run_goal(root, contract, ins)
            run_kw = {k: v for k, v in (("requested_model", d.a.model), ("stub_endpoint", d.a.stub_endpoint)) if v}
            hooks = Q2.real_hooks(store)
            hooks.setdefault("suggest", A.make_suggest(store, run_kw))
            d.log(f"call acquire.run(store, {rid}, hooks=g2_qualify.real_hooks(store) [live GitHub search, pinned clone, Docker staging], admit=hive_admission.admit, execute=run_goal, require_new_external={d.a.require_new_external})")
            rec = A.run(store, rid, hooks=hooks, run_kw=run_kw, admit=admit, execute=execute)
            s_ = Store(store)
            try:
                man = A.manifest(s_, rec)
            finally:
                s_.close()
            d.evidence("acquisition-manifest.json", man)
            res.update(run_id=rid, state=rec["state"], reason=rec["reason"], ledger=rec["ledger"], attempts=[{k: x.get(k) for k in ("n", "repo", "revision", "state", "license", "exp_id", "rejection", "results", "admission")} for x in man["attempts"]],
                       cost_usd=man["cost_usd"], outcome=man.get("outcome"))
            ok_match = rec["state"] == "DONE"
    led = res.get("ledger") or {}
    git_att = next((x for x in res.get("attempts", []) if x.get("state") in ("PASSED", "ADMITTED", "DONE")), (res.get("attempts") or [{}])[-1])
    d.note(st, "C", label="Goal C (compose) on the real pictures of " + NEW, text=TEXT["H2"], inputs=res["inputs"],
           candidates=res.get("attempts"), evaluation=[a.get("results") for a in res.get("attempts", [])], admission=[a.get("admission") for a in res.get("attempts", [])], state_match=res.get("state"))
    d.receipt("T06", "image.asset-match from live GitHub search on the 20 real pictures", "an approved open-source repo, pinned revision + licence + hash, adapter, independent verification, admitted",
              f"{res.get('state')}: {res.get('reason') or ''}; repo={git_att.get('repo')}@{str(git_att.get('revision'))[:10]}; license={git_att.get('license')}", "pass" if ok_match else "fail",
              int((time.monotonic() - t0) * 1000), calls=led.get("model_calls"), tin=led.get("in_tokens"), tout=led.get("out_tokens"), cost=res.get("cost_usd"), evidence=f"evidence/{d.phase}/acquisition-manifest.json", details=res)
    if not ok_match:
        return False
    # real outputs of the two admitted capabilities become the direct inputs of the third acquisition
    _, _, ok_props = d.run_acq("T02", "asset.properties on the real pictures", [("props", PROPS, TEXT["PROPS"], imgs, None)], "asset.properties acquired and admitted on the real pictures")
    if not ok_props:
        return False
    derived = derive_inputs(d, imgs)
    if not derived:
        d.receipt("T02", "report.reconcile inputs", "real outputs of image.asset-match and asset.properties as direct inputs", "could not derive them", "blocked", 0, evidence=f"evidence/{d.phase}/")
        return False
    _, _, ok_rec = d.run_acq("T02", "report.reconcile on the real derived outputs", [("recon", RECON, TEXT["RECON"], list(DERIVED), None)], "report.reconcile acquired and admitted on real outputs of the earlier capabilities")
    return ok_rec


def derive_inputs(d, imgs):
    """Run the admitted image.asset-match and asset.properties goals on the real pictures (CLI) and keep their artifacts as the direct inputs for report.reconcile."""
    got = {}
    for rel, text in ((DERIVED[0], TEXT["MATCH"]), (DERIVED[1], TEXT["PROPS"])):
        g, ms, ev = d.goal("derive-" + Path(rel).stem, text, imgs)
        s = d.gsum(g, ms, ev)
        if s["state"] != "VERIFIED" or not s["output"]:
            return False
        data = (d.store / s["output"]["ref"]).read_bytes()
        p = d.inputs / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
        got[rel] = {"sha256": sha_b(data), "bytes": len(data), "goal_id": s["goal_id"]}
    d.evidence("derived-inputs.json", got)
    return True


def ph_goal_c(d, st):
    need_phase(st, "learn-c")
    need_caps(d, MATCH, PROPS, RECON)
    imgs = sorted(p.relative_to(d.inputs).as_posix() for p in (d.inputs / "images").glob("*.png"))
    m0 = d.meter()
    # H2: pictures only; planned, an invalid edge refused before any execution, then run
    plan, mp, evp = d.plan("H2-plan", TEXT["H2"], imgs)
    ps = d.gsum(plan)
    bad = invalid_edge_refused(d, plan)
    g, ms, ev = d.goal("H2", TEXT["H2"], imgs)
    s = d.gsum(g, ms, ev)
    delta = d.spent(m0, d.meter())
    ops2 = [PROPS, MATCH, RECON]
    ok2 = d.goal_ok(s) and sorted(s["plan_ops"]) == sorted(ops2) and len(s["plan_ops"]) == 3 and s["plan_ops"][-1] == RECON and delta["model_calls"] == 0
    d.note(st, "C", plan=s["plan"], steps=s["steps"], output=s["output"], reuse={"acquisitions": delta["new_acquisition_runs"], "model_calls": delta["model_calls"]}, result={"state": s["state"], "usage": s["usage"]})
    d.receipt("T12", "H2 on the 20 real pictures (3 steps) + invalid edge", "3-step plan (fan-out then join) VERIFIED; a tampered plan is refused before execution",
              f"{s['state']} plan={s['plan']}; invalid edge refused: {bad['refused']} ({bad['problems'][:2]})", "pass" if ok2 and bad["refused"] else "fail", ms, calls=delta["model_calls"], tin=0, tout=0, cost=0.0, evidence=ev,
              details={"plan_state": ps["state"], "goal": s, "invalid_edge": bad, "delta": delta})
    d.receipt("T20", "Goal C: H2 on the real pictures", "composite goal VERIFIED over three learned capabilities incl. the open-source one", f"{s['state']} {s['plan_ops']}", "pass" if ok2 else "fail", ms,
              calls=delta["model_calls"], tin=0, tout=0, cost=0.0, evidence=ev, details={"goal": s})
    # H3: 19 pictures (all but H3_SKIP) plus the evaluator-derived property table = 20 inputs, the goal cap
    h3 = run_h3(d, imgs)
    d.receipt("T13", "H2 and H3 held-out compositions on real pictures", "H2 (3 steps) and H3 (2 steps, property step skipped) VERIFIED with 0 model calls", f"H2 {s['state']}; H3 {h3['summary']}",
              "pass" if ok2 and h3["ok"] else "fail", ms + h3["ms"], calls=delta["model_calls"] if not h3.get("model_calls") else delta["model_calls"] + h3["model_calls"], tin=0, tout=0, cost=0.0, evidence=f"evidence/{d.phase}/", details={"H2": s, "H3": h3})
    d.note(st, "H3", label="H3 (19 pictures + " + H3_TABLE + ")", **{k: h3[k] for k in ("inputs", "plan", "steps", "output")})
    return ok2 and bad["refused"] and h3["ok"]


def h3_inputs(d, imgs):
    """19 pictures plus the shipped property table; the table is copied from the read-only exports only if init predates it (sha-checked)."""
    pics = [r for r in imgs if Path(r).name != H3_SKIP]
    tab = d.inputs / H3_TABLE
    if not tab.is_file():
        src = Path(d.a.inputs) / H3_TABLE
        if not src.is_file():
            raise Refuse(f"{H3_TABLE} not found in {d.a.inputs}")
        tab.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, tab)
        d.log(f"copy {src} -> {tab}")
    return pics + [H3_TABLE]


def run_h3(d, imgs):
    rels = h3_inputs(d, imgs)
    m0 = d.meter()
    g, ms, ev = d.goal("H3", TEXT["H2"], rels)
    s = d.gsum(g, ms, ev)
    delta = d.spent(m0, d.meter())
    ok = d.goal_ok(s) and s["plan_ops"] == [MATCH, RECON] and delta["model_calls"] == 0
    return {"ok": ok, "ms": ms, "model_calls": delta["model_calls"], "summary": f"{s['state']} plan={s['plan_ops']} ({len(rels) - 1} pictures + {H3_TABLE}, {len(rels)} inputs)",
            "inputs": [d.file_info(r) for r in rels], "plan": s["plan"], "steps": s["steps"], "output": s["output"], "goal": s}


def invalid_edge_refused(d, plan):
    """T12: take the stored plan and break one edge (the last step reads its own output); validate_plan must refuse it, nothing runs."""
    import copy
    from hive import goal_runner as G
    from hive.storage import Store
    s = Store(d.store)
    try:
        rec = s.get("operator/goal/" + plan["goal_id"])
        contract, p = s.read_artifact(rec["contract_ref"]), copy.deepcopy(rec["plan"])
        last = p["steps"][-1]
        last["inputs"] = ["step:" + last["step_id"]] * len(last["inputs"])
        problems = G.validate_plan(s, contract, p)
    finally:
        s.close()
    d.log("call goal_runner.validate_plan(store, contract, plan with the final step's inputs rewired to itself)")
    return {"refused": bool(problems), "problems": problems}


def ph_restart(d, st):
    need_phase(st, "goal-c")
    adm = sorted(d.active())
    if CHECK not in adm:
        raise Refuse(f"restart needs at least site.ref-check admitted, registry has {adm}")
    chain = d.chain_ready()
    rows, snap = d.snapshot()  # a new process (the CLI) loads the persisted registry
    imgs = sorted(p.relative_to(d.inputs).as_posix() for p in (d.inputs / "images").glob("*.png"))
    one = {EXTRACT: (TEXT["L1"], [PAGES(OLD)]), RESOLVE: (TEXT["L1b"], [RAW(OLD)]), CHECK: (TEXT["L2"], [TABLE(OLD), MANIFEST(OLD)]), DIFF: (TEXT["L3"], [MANIFEST(NEW), MANIFEST(OLD)]),
           MATCH: (TEXT["MATCH"], imgs), PROPS: (TEXT["PROPS"], imgs), RECON: (TEXT["RECON"], list(DERIVED))}
    m0, per, ok10, t0 = d.meter(), [], True, time.monotonic()
    for cap in [c for c in adm if c in one]:
        g, ms, ev = d.goal("cold-" + cap, *one[cap])
        s = d.gsum(g, ms, ev)
        good = d.goal_ok(s, [cap])
        ok10 &= good
        per.append({"cap": cap, "state": s["state"], "mode": [x["mode"] for x in s["steps"]], "version": [x["version"] for x in s["steps"]], "ok": good})
    delta = d.spent(m0, d.meter())
    ok10 &= delta["model_calls"] == 0 and delta["new_experiments"] == 0
    d.receipt("T10", "cold restart: every admitted capability on valid inputs", f"all {len(adm)} admitted capabilities VERIFIED in new processes, 0 model calls",
              f"{sum(p['ok'] for p in per)}/{len(per)} VERIFIED; {delta}", "pass" if ok10 and len(per) == len(adm) else "fail", int((time.monotonic() - t0) * 1000), calls=delta["model_calls"], tin=0, tout=0, cost=0.0,
              evidence=f"evidence/{d.phase}/", details={"registry_rows": rows, "per_capability": per, "delta": delta}, snap=snap)
    # stored plans (T11) and held-out workflows (T13): plan in one process, run-plan in another
    m1, held, ok11, ok13, t1 = d.meter(), {}, True, True, time.monotonic()
    pairs = {"H2": (TEXT["H2"], imgs, [PROPS, MATCH, RECON]), "H3": (TEXT["H2"], h3_inputs(d, imgs), [MATCH, RECON])}
    pairs = {("H1" if chain else "BL"): d.bl_goal(NEW), **pairs}  # BL = the re-scoped broken-links goal (reference table + manifest); H1 is blocked without the chain
    for h, (text, rels, ops) in pairs.items():
        plan, _, evp = d.plan(h + "-plan", text, rels)
        ps = d.gsum(plan)
        run = None
        if ps["state"] == "PLANNED":
            rc, out, ms, ev = d.cli(h + "-run-plan", "run-plan", ps["goal_id"], "--allowed-root", str(d.inputs))
            run = d.gsum(out, ms, ev)
        good = bool(run) and d.goal_ok(run) and (run["usage"].get("model_calls") == 0) and sorted(run["plan_ops"]) == sorted(ops) and (run["stored_plan"] or {}).get("replanned") is False and (run["stored_plan"] or {}).get("model_calls") == 0
        ok11 &= good
        g, ms2, ev2 = d.goal(h + "-goal", text, rels)
        gs = d.gsum(g, ms2, ev2)
        good13 = d.goal_ok(gs) and gs["usage"].get("model_calls") == 0 and sorted(gs["plan_ops"]) == sorted(ops)
        ok13 &= good13 or h == "BL"  # BL is a stored-plan check only, not a held-out workflow
        held[h] = {"plan_state": ps["state"], "stored_plan_run": run, "stored_ok": good, "goal": gs, "goal_ok": good13, "expected_chain": ops}
        d.note(st, h, restart={"plan_state": ps["state"], "stored_plan": run and run["plan"], "run_state": run and run["state"], "stored_plan_meta": run and run["stored_plan"], "goal_state": gs["state"], "modes": [x["mode"] for x in gs["steps"]]})
    delta1 = d.spent(m1, d.meter())
    zero = delta1["model_calls"] == 0 and delta1["new_experiments"] == 0 and delta1["new_acquisition_runs"] == 0
    d.receipt("T11", "stored plans H1-H3 via plan then run-plan (new processes)", "each stored plan re-validated and run without replanning, 0 model calls", f"{[(h, v['stored_ok']) for h, v in held.items()]} {delta1}",
              "pass" if ok11 and zero else "fail", int((time.monotonic() - t1) * 1000), calls=delta1["model_calls"], tin=0, tout=0, cost=0.0, evidence=f"evidence/{d.phase}/", details={"held": held, "delta": delta1})
    held13 = {h: v for h, v in held.items() if h != "BL"}
    if not chain:
        held13["H1"] = {"blocked": "site.ref-extract/site.ref-resolve not admitted: the 3-step chain does not exist"}
    d.receipt("T13", "H1-H3 held-out workflows in fresh processes", "three distinct workflows planned from raw inputs by chaining admitted capabilities, no new code, 0 model calls",
              f"{[(h, v.get('goal_ok', 'blocked'), (v.get('goal') or {}).get('plan_ops')) for h, v in held13.items()]}" + ("" if chain else "; partial: 2 of 3 (H2, H3 run, H1 blocked)"),
              ("pass" if chain else "blocked") if ok13 and zero else "fail", int((time.monotonic() - t1) * 1000), calls=delta1["model_calls"], tin=0, tout=0, cost=0.0,
              evidence=f"evidence/{d.phase}/", details={"held": held13})
    d.cli("acquisitions", "acquisitions", "--json")
    d.cli("overview", "overview", "--json")
    return ok10 and ok11 and ok13 and zero


def ph_alt(d, st):
    need_phase(st, "restart")
    need_caps(d, CHECK)
    h1text, h1rels, _ = d.bl_goal(NEW)
    from hive import acquire as A, capability_registry as CR, discovery as D, m2_model as M, m2_workflow as W
    from hive.storage import Store
    import g3_qualify as Q3
    import hive_admission as H
    backend = d.a.backend or M.list_backends()[0]
    if backend not in M.list_backends():
        raise Refuse(f"backend {backend!r} is not qualified: {M.list_backends()}")
    try:
        resolved = M.apply_backend(W.load_policy(), None if backend == M.list_backends()[0] else backend)["model"]
    except (M.Refused, M.Invalidated) as e:  # a non-default backend needs an ACTIVE, sha-bound approval (scripts/activate_backend_approval.py)
        raise Refuse(f"backend {backend!r} has no usable approval: {e} (activate it with scripts/activate_backend_approval.py)")
    d.evidence("backend.json", {"selected": backend, "available": M.list_backends(), "resolved": {k: resolved.get(k) for k in ("id", "endpoint", "file", "sha256", "context")}})
    s = Store(d.store)
    try:
        gap_key = CR.resolve_discovered(s, CHECK)["statement"]["lineage"]["gap_key"]
        have_alt = CR.head(s, ALT) is not None
    finally:
        s.close()
    t0, attempts, state = time.monotonic(), [], "ALREADY_RETAINED"
    if not have_alt:
        d.log(f"call discovery.open_experiment(store, gap_key, capability_id={ALT!r}) + run_experiment(requested_model={backend!r}) up to 3 experiments (carry-best), then hive_admission.admit")
        exp, kw, seed = None, {"requested_model": backend, **({"stub_endpoint": d.a.stub_endpoint} if d.a.stub_endpoint else {})}, None
        for n in range(3):
            s = Store(d.store)
            try:
                exp = D.open_experiment(s, gap_key, budget=dict(Q3.EXP_BUDGET), acq_run="p-demo-alt", capability_id=ALT, seed_best=seed, proposer_model=backend)["exp_id"]
            finally:
                s.close()
            t1 = time.monotonic()
            r = D.run_experiment(str(d.store), exp, **kw)
            attempts.append({"exp_id": exp, "state": r["state"], "reason": r.get("reason"), "ledger": r["ledger"], "wall_s": round(time.monotonic() - t1, 1), "seeded_with_best": n > 0,
                             "receipt": r.get("receipt") and {k: r["receipt"].get(k) for k in ("pass_count", "n", "verdict", "receipt_sha256")}})
            if r["state"] == "CANDIDATE_PASSED" or r["state"] not in ("NO_QUALIFYING_CANDIDATE", "BUDGET_EXHAUSTED"):
                break
            b = r.get("best")
            seed = {"body": b["body"], "dev_pass": b["dev_pass"], "feedback": r.get("feedback") or ""} if b else None
        state = attempts[-1]["state"]
        adm = None
        if state == "CANDIDATE_PASSED":
            adm = H.admit(str(d.store), attempts[-1]["exp_id"], str(d.key))
            state = "ADMITTED"
        d.evidence("acquire-alt.json", {"backend": backend, "attempts": attempts, "admission": adm})
    tot = {k: sum(a["ledger"][k] for a in attempts) for k in ("calls", "in_tokens", "out_tokens")} if attempts else {"calls": 0, "in_tokens": 0, "out_tokens": 0}
    d.note(st, "ALT", label="Alternative candidate site.ref-check-alt", backend=backend, state=state, candidates=[{k: a.get(k) for k in ("exp_id", "state", "reason")} for a in attempts], evaluation=[a.get("receipt") for a in attempts])
    if state not in ("ADMITTED", "ALREADY_RETAINED"):
        # the planner part: ranking and fallback need two admitted same-contract capabilities, so with one the ranking is recorded as it is and T03 is blocked, not faked
        plan1, _, ev1 = d.plan("H1-ranking-single", h1text, h1rels)
        p1 = d.gsum(plan1)
        d.evidence("ranking-single-candidate.json", p1)
        d.receipt("T03", "alternative acquisition", "alt admitted, then ranking lists both and a revoked preferred falls back to the alternative",
                  f"blocked: {ALT} {state}: {attempts[-1].get('reason') if attempts else None}; ranking with the single admitted candidate: {p1['ranking']}", "blocked", int((time.monotonic() - t0) * 1000),
                  calls=tot["calls"], tin=tot["in_tokens"], tout=tot["out_tokens"], cost=0.0, evidence=f"evidence/{d.phase}/acquire-alt.json", details={"ranking_single": p1["ranking"], "plan_state": p1["state"]})
        d.receipt("T18", "selectable backend " + backend, "second backend completes a goal on the same registry", f"{state}: {attempts[-1].get('reason') if attempts else None}", "blocked" if backend != M.list_backends()[0] else "skip",
                  int((time.monotonic() - t0) * 1000), calls=tot["calls"], tin=tot["in_tokens"], tout=tot["out_tokens"], cost=0.0, evidence=f"evidence/{d.phase}/backend.json")
        return False
    # ranking with both alternatives
    plan, _, evp = d.plan("H1-ranking", h1text, h1rels)
    ps = d.gsum(plan)
    both = any(CHECK in str(r["alternatives"]) and ALT in str(r["alternatives"]) for r in ps["ranking"])
    backup = Path(str(d.store) + ".pre-revoke")
    d.log(f"copy store {d.store} -> {backup} (a revoke is irreversible by design; the copy is how the demo restores)")
    shutil.copytree(d.store, backup)
    rc, rv, ms_r, ev_r = d.cli("revoke-preferred", "cap", "revoke", CHECK, "--reason", "demo: take the preferred candidate away to show the alternative", "--key", str(d.key), "--json")
    g, ms, ev = d.goal("H1-after-revoke", h1text, h1rels)
    s2 = d.gsum(g, ms, ev)
    used_alt = ALT in s2["plan_ops"] and any(x["op"] == ALT and x["verdict"] == "PASS" for x in s2["steps"]) and d.goal_ok(s2)
    # restore: the revoked store is kept as evidence, the pre-revoke copy becomes the store again
    kept = Path(str(d.store) + ".revoked-evidence")
    if kept.exists():
        shutil.rmtree(kept)
    os.replace(d.store, kept)
    os.replace(backup, d.store)
    d.log(f"restore: {d.store} is the pre-revoke copy again; the revoked store is kept at {kept}")
    rows, snap = d.snapshot()
    alt_notes = dict(st["goals"].get("ALT", {}))
    st2 = d.load()  # the restored store carries the state as of the copy
    st.clear()
    st.update(st2)
    d.note(st, "ALT", **alt_notes)
    d.note(st, "ALT", ranking=ps["ranking"], after_revoke={"plan": s2["plan"], "used_alt": used_alt, "output": s2["output"]}, revoked_store_kept=str(kept))
    restored = {r["id"]: r["lifecycle"] for r in rows if r["id"] in (CHECK, ALT)}
    ok = both and used_alt and restored.get(CHECK) == "active" and restored.get(ALT) == "active"
    d.receipt("T03", "H1 with two same-interface candidates", "ranking lists both; with the preferred revoked H1 reruns on the alternative; store restored afterwards",
              f"alternatives in ranking: {ps['ranking']}; after revoke plan={s2['plan']} used_alt={used_alt}; restored={restored}", "pass" if ok else "fail", ms + ms_r, calls=0, tin=0, tout=0, cost=0.0,
              evidence=f"evidence/{d.phase}/", details={"ranking": ps["ranking"], "revoke": rv, "after_revoke": s2, "restored": restored, "revoked_store": str(kept)}, snap=snap)
    second = backend != M.list_backends()[0]
    d.receipt("T18", "selectable backend " + backend, "a second compatible backend acquires a capability into the same registry and the registry serves it",
              f"acquired {ALT} with backend {backend}: {state}" if second else f"only the default backend {backend} was selected; no second backend ran", ("pass" if ok and state == "ADMITTED" else "fail") if second else "skip",
              int((time.monotonic() - t0) * 1000), calls=tot["calls"], tin=tot["in_tokens"], tout=tot["out_tokens"], cost=0.0, evidence=f"evidence/{d.phase}/backend.json",
              details={"selected": backend, "available": M.list_backends(), "alt_state": state}, snap=snap)
    return ok


def ph_improve(d, st):
    need_phase(st, "alt")
    cap, obj = d.a.improve_cap, d.a.objective
    if not obj.startswith("failure_class:"):
        raise Refuse(f"objective must be failure_class:<value> (there is no latency objective): {obj!r}")
    act = d.active()
    if cap not in act:
        raise Refuse(f"{cap} is not an active capability: {sorted(act)}")
    texts = {EXTRACT: (TEXT["L1"], [PAGES(OLD)]), RESOLVE: (TEXT["L1b"], [RAW(OLD)]), CHECK: (TEXT["L2"], [TABLE(OLD), MANIFEST(OLD)]), DIFF: (TEXT["L3"], [MANIFEST(OLD), MANIFEST(NEW)]), RECON: (TEXT["RECON"], list(DERIVED))}
    imgs = sorted(p.relative_to(d.inputs).as_posix() for p in (d.inputs / "images").glob("*.png"))
    texts.update({MATCH: (TEXT["MATCH"], imgs), PROPS: (TEXT["PROPS"], imgs)})
    t0 = time.monotonic()
    before = d.snapshot()[0]
    rc, imp, ms, ev = d.cli("improve", "cap", "improve", cap, "--objective", obj, "--key", str(d.key), "--json")
    imp = imp or {}
    state = imp.get("state")
    led = None
    s = None
    from hive import discovery as D
    from hive.storage import Store
    s = Store(d.store)
    try:
        e = next((x for x in D.experiments(s) if x["exp_id"] == imp.get("exp_id")), None)
        led = e and e["ledger"]
    finally:
        s.close()
    d.note(st, "IMPROVE", label=f"Improve {cap} (objective {obj})", result=imp, state=state)
    call = dict(calls=(led or {}).get("calls"), tin=(led or {}).get("in_tokens"), tout=(led or {}).get("out_tokens"), cost=0.0 if led else None)
    if state != "ADMITTED":
        d.receipt("T14", f"cap improve {cap} {obj}", "improved v2 admitted, or honestly REJECTED with evidence and v1 kept", f"{state}: {imp.get('reason')} active v{imp.get('active_version')}", "pass" if state == "REJECTED" else "fail",
                  int((time.monotonic() - t0) * 1000), evidence=ev, details={"improve": imp}, **call)
        d.receipt("T15", f"rollback/revoke of {cap}", "v2 rolled back to v1, v2 revoked, others still VERIFIED", f"no v2 exists ({state}); nothing to roll back to", "blocked", 0, calls=0, tin=0, tout=0, cost=0.0, evidence=ev,
                  details={"improve": imp, "note": "rollback and revoke of a genuinely admitted v2 need an ADMITTED improvement; their mechanics are covered in tests/test_p_cli.py and tests/test_p_improve.py"})
        return state == "REJECTED"
    ok14 = imp.get("version") == 2 and imp.get("active_version") == 2
    gv2, ms2, ev2 = d.goal("goal-on-v2", *texts[cap])
    s2 = d.gsum(gv2, ms2, ev2)
    rc, rb, ms3, ev3 = d.cli("rollback", "cap", "rollback", cap, "--key", str(d.key), "--json")
    g1, ms4, ev4 = d.goal("goal-after-rollback", *texts[cap])
    s4 = d.gsum(g1, ms4, ev4)
    rc, rv, ms5, ev5 = d.cli("revoke-v2", "cap", "revoke", cap, "--version", "2", "--reason", "demo: revoke the improved version", "--key", str(d.key), "--json")
    rc, shown, _, evs = d.cli("cap-show", "cap", "show", cap, "--json")
    after = d.snapshot()[0]
    life = {r["version"]: r["lifecycle"] for r in after if r["id"] == cap}
    others = {}
    for c in sorted(set(act) - {cap}):
        if c in texts:
            go, mo, evo = d.goal("other-" + c, *texts[c])
            others[c] = d.gsum(go, mo, evo)["state"]
    ok15 = (s4["state"] == "VERIFIED" and all(x["version"] == 1 for x in s4["steps"]) and life.get(1) == "active" and life.get(2) == "revoked" and bool(others) and all(v == "VERIFIED" for v in others.values())
            and bool(shown and shown.get("chain_ok")))
    d.receipt("T14", f"cap improve {cap} {obj}", "improved v2 admitted by the signed authority", f"ADMITTED v2 active; goal on v2 {s2['state']} {[x['version'] for x in s2['steps']]}", "pass" if ok14 and s2["state"] == "VERIFIED" else "fail",
              int((time.monotonic() - t0) * 1000), evidence=ev, details={"improve": imp, "goal_on_v2": s2}, **call)
    d.receipt("T15", f"rollback then revoke v2 of {cap}", "back on v1 (VERIFIED), v2 revoked, other capabilities still VERIFIED, chain verifies",
              f"after rollback goal {s4['state']} v{[x['version'] for x in s4['steps']]}; lifecycle {life}; chain_ok={shown and shown.get('chain_ok')}; others {others}", "pass" if ok15 else "fail", ms3 + ms4 + ms5, calls=0, tin=0, tout=0, cost=0.0,
              evidence=f"evidence/{d.phase}/", details={"rollback": rb, "after_rollback": s4, "revoke": rv, "history": shown, "others": others})
    return ok14 and ok15


# ===================================================================== report
def ph_report(d, st):
    recs = sorted((d.out / "receipts").glob("*.json")) if (d.out / "receipts").is_dir() else []
    receipts = [json.loads(p.read_text(encoding="utf-8")) for p in recs]
    rows = {}
    for t in TESTS:
        rs = [r for r in receipts if r["test_id"] == t]
        sts = [r["status"] for r in rs]
        need = {"init", "goal-a", "goal-b", "goal-c"} - {r["phase"] for r in rs} if t == "T20" else set()
        agg = "skip (phase not run)" if not rs else "fail" if "fail" in sts else "blocked" if "blocked" in sts else "pass" if all(s == "pass" for s in sts) else "skip" if "skip" in sts and "pass" not in sts else "pass (with skips)"
        if need and rs and agg in ("pass", "pass (with skips)"):
            agg = "incomplete (no receipt from " + ", ".join(sorted(need)) + ")"
        rows[t] = {"title": TESTS[t], "status": agg, "receipts": [f"receipts/{r['phase']}-{r['test_id']}.json" for r in rs], "observed": [f"{r['phase']}: {r['observed']}" for r in rs]}
    caps = d.caps() if d.store.exists() else []
    adm = sorted({c["id"] for c in caps if c["kind"] == "discovered" and c.get("route") != "operator-authored" and c["lifecycle"] in ("active", "superseded", "revoked")})
    authored = sorted({c["id"] for c in caps if c.get("route") == "operator-authored" and c["lifecycle"] in ("active", "superseded", "revoked")})
    tot = lambda k: sum(r[k] for r in receipts if isinstance(r.get(k), (int, float)))
    unknown = sorted({k for r in receipts for k in ("model_calls", "input_tokens", "output_tokens", "cost_usd") if r.get(k) is None})
    summary = {"schema": SCHEMA, "generated_at": now(), "candidate_commit": commit_id(), "baseline_commit": d.a.baseline_commit, "phases": st["phases"], "tests": rows, "admitted_capabilities": adm, "operator_authored_capabilities": authored,
               "totals": {"receipts": len(receipts), "model_calls": tot("model_calls"), "input_tokens": tot("input_tokens"), "output_tokens": tot("output_tokens"), "cost_usd": tot("cost_usd"), "elapsed_ms": tot("elapsed_ms"),
                          "metrics_unknown_in_some_receipts": unknown},
               "goals": st["goals"], "registry": caps, "init": json.loads((d.out / "init.json").read_text(encoding="utf-8")) if (d.out / "init.json").is_file() else None}
    (d.out / "SUMMARY.json").write_text(json.dumps(summary, sort_keys=True, indent=1), encoding="utf-8", newline="\n")
    L = ["# HIVE prototype demonstration report", "", f"Generated {summary['generated_at']} from commit `{summary['candidate_commit']}` (baseline `{summary['baseline_commit']}`). "
         "Every command and call is in `commands.log`; every receipt in `receipts/`; raw outputs in `evidence/`.", "", "## Test table", "", "| Test | What | Status | Receipts |", "|---|---|---|---|"]
    for t, r in rows.items():
        L.append(f"| {t} | {r['title']} | **{r['status']}** | " + ", ".join(f"`{x}`" for x in r["receipts"]) + " |")
    L += ["", "Phases: " + ", ".join(f"{p}={v['status']}" for p, v in st["phases"].items()), "",
          f"Admitted capabilities ({len(adm)}): " + ", ".join(adm), "",
          f"Totals over receipts: model_calls={summary['totals']['model_calls']}, input_tokens={summary['totals']['input_tokens']}, output_tokens={summary['totals']['output_tokens']}, cost_usd={summary['totals']['cost_usd']}"
          + (f" (null in some receipts: {', '.join(unknown)})" if unknown else ""), "", "## Observed per test", ""]
    for t, r in rows.items():
        for o in r["observed"]:
            L.append(f"- {t} {o}")
    blocked = [r for r in receipts if r["status"] == "blocked"]
    if blocked:
        L += ["", "## Blocked", ""] + [f"- {r['test_id']} ({r['phase']}): {r['observed']}" for r in blocked]
    rs = st.get("rescope")
    if rs:
        L += ["", "## Re-scope (26 Nov)", "",
              "No available proposer model (local gpt-oss-20b, hosted kimi, hosted nemotron) learned these capabilities within the approved caps: " + ", ".join(rs["blocked"]) + ". "
              "They were not attempted again here and are recorded as blocked, never as passed. " + BL_NOTE,
              "Negative evidence (copied under `evidence/negative/`): " + ", ".join(rs["evidence"]) + "; sources: " + ", ".join(rs.get("evidence_sources", [])),
              "H1 (the 3-step chain) is blocked; broken links were checked by the learned site.ref-check on the exported reference table (see Goals A and B for the real counts and lists)."]
    L += ["", "## Goals"]
    for key, g in st["goals"].items():
        L += ["", f"### {key}: {g.get('label', '')}", ""]
        for f in ("text", "inputs", "initial_gap", "candidates", "evaluation", "admission", "plan", "steps", "output", "reuse", "result", "state", "backend"):
            if f in g and g[f] is not None:
                v = g[f]
                L.append(f"- **{f}**: " + (f"`{v}`" if not isinstance(v, (dict, list)) else "`" + json.dumps(v, sort_keys=True)[:1500] + "`"))
    (d.out / "REPORT.md").write_text("\n".join(L) + "\n", encoding="utf-8", newline="\n")
    d.log("wrote SUMMARY.json and REPORT.md")
    return True


# ===================================================================== plumbing
def need_phase(st, prev):
    if prev not in st["phases"]:
        raise Refuse(f"phase {prev!r} has not been run yet (order: {' -> '.join(PHASES)})")


def need_caps(d, *caps):
    have = d.active()
    miss = [c for c in caps if c not in have]
    if miss:
        raise Refuse(f"capabilities not admitted and active in this store: {miss} (active: {sorted(have)})")


RUN = {"init": ph_init, "learn-a": ph_learn_a, "goal-a": ph_goal_a, "goal-b": ph_goal_b, "learn-c": ph_learn_c, "goal-c": ph_goal_c, "restart": ph_restart, "alt": ph_alt, "improve": ph_improve, "report": ph_report}


def parser():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--store", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--phase", required=True, choices=PHASES)
    ap.add_argument("--inputs", default=DEFAULT_INPUTS, help="read-only real exports (init copies them under OUT/inputs)")
    ap.add_argument("--admit-key", default=str(Path(os.environ.get("USERPROFILE") or Path.home()) / ".hive-admission" / "admission_ed25519"))
    ap.add_argument("--model", help="requested proposer model id (default: the policy model)")
    ap.add_argument("--backend", help="alt: selectable backend id (m2_model.list_backends); default the first")
    ap.add_argument("--stub-endpoint", help="test seam: a loopback stub model endpoint")
    ap.add_argument("--baseline-commit", default="0e9e0d3")
    ap.add_argument("--improve-cap", default=EXTRACT)
    ap.add_argument("--objective", default="failure_class:wrong_output", help="failure_class:wrong_output | failure_class:run_error")
    ap.add_argument("--no-require-new-external", dest="require_new_external", action="store_false", help="learn-c: allow retained/installed tiers before GitHub")
    ap.add_argument("--skip-unlearnable", default="", help="learn-a: comma-separated capability ids not attempted (recorded as blocked: not learnable by available models)")
    ap.add_argument("--negative-evidence", default="", help="learn-a: comma-separated paths of earlier failed-acquisition evidence, copied into OUT/evidence/negative/")
    ap.add_argument("--force", action="store_true", help="re-run a phase that already has a record (never done implicitly)")
    return ap


def main(argv=None):
    a = parser().parse_args(argv)
    d = Demo(a)
    d.phase = a.phase
    try:
        st = d.load()
        if a.phase != "init" and not d.state_path.is_file():
            raise Refuse(f"no demo state in {d.store}: run --phase init first")
        if a.phase in st["phases"] and a.phase != "report" and not a.force:
            raise Refuse(f"phase {a.phase} already ran ({st['phases'][a.phase]['status']}); it is not retried silently (use --force to run it again)")
        t0 = time.monotonic()
        d.log(f"phase start: {' '.join(sys.argv)}")
        try:
            ok = bool(RUN[a.phase](d, st))
            status, err = ("done" if ok else "failed"), None
        except Refuse:
            raise
        except Exception as e:  # kept as evidence; the phase is not retried
            ok, status, err = False, "failed", f"{type(e).__name__}: {str(e)[:500]}"
            d.log("phase error: " + err)
            d.receipt("ERR", f"{a.phase} crashed", "phase completes", err, "fail", int((time.monotonic() - t0) * 1000), evidence="commands.log") if d.out.exists() else None
        st["phases"][a.phase] = {"status": status, "at": now(), "wall_s": round(time.monotonic() - t0, 1), "error": err}
        d.save(st)
        print(json.dumps({"phase": a.phase, "status": status, "wall_s": st["phases"][a.phase]["wall_s"], "error": err, "out": str(d.out)}, indent=1))
        return 0 if ok else 3
    except Refuse as e:
        print(json.dumps({"phase": a.phase, "refused": str(e)}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
