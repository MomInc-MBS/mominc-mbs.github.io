"""Offline selector replay of the 63-campaign coop development pilot: ZERO HIVE model calls, public fields only (never a hidden label).

  python scripts/coop_replay.py manifest            # P0: build/coop/continuation_manifest.json
  python scripts/coop_replay.py replay [--plan]     # build/coop/replay/{selections.json,selections.sha256,runs.json}; --plan only counts container runs
Evidence stores are opened read-only (sqlite immutable) and never modified. Re-execution reuses discovery._outputs (Docker); hard cap --max-runs (600)."""
import argparse
import collections
import hashlib
import json
import re
import sqlite3
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from hive import capcontract as CC  # noqa: E402
from hive import coop as CP  # noqa: E402
from hive import discovery as D  # noqa: E402

EVID = Path("C:/hive-work/demo")
BATCHES = {"57f6a94": "coop-pilot-57f6a94", "04fe137": "coop-pilot-04fe137", "c3x-fbc2ddb": "coop-pilot-c3x-fbc2ddb"}
OUT = ROOT / "build" / "coop"
RUN_CAP = 600


def write(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    data = (json.dumps(obj, indent=1, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")
    path.write_bytes(data)
    return hashlib.sha256(data).hexdigest()


def runs(batch):
    """[(run, cap, recipe, store_dir, exp_ids, calls)] from rows.jsonl: ONLY the run listing and call counts are read from it (it also holds private labels)."""
    base = EVID / BATCHES[batch]
    for line in (base / "rows.jsonl").read_text(encoding="utf-8").splitlines():
        if line.strip():
            r = json.loads(line)
            yield r["run"], r["cap"], r["recipe"], base / "stores" / r["run"], r.get("exp_ids", []), r.get("calls")


def load_rec(store, exp_id):
    db = sqlite3.connect(f"file:{(Path(store) / 'hive.sqlite3').as_posix()}?mode=ro&immutable=1", uri=True)
    try:
        return json.loads(db.execute("SELECT value FROM kv WHERE key=?", (D.KEY + exp_id,)).fetchone()[0])
    finally:
        db.close()


def model_rows(store, exp_id):
    f = Path(store) / "discovery" / exp_id / "model" / "model_calls.jsonl"
    return [json.loads(x) for x in f.read_text(encoding="utf-8").splitlines() if x.strip()] if f.is_file() else []


def sha_file(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def git(*a):
    return subprocess.run(["git", *a], cwd=ROOT, capture_output=True, text=True).stdout.strip()


# ---------------------------------------------------------------- P0
def manifest():
    m = {"version": "coop-continuation-v1", "code_commit": git("rev-parse", "--short", "HEAD"), "tree_dirty_tracked_files": git("diff", "--name-only").splitlines(),
         "select": CP.SELECT, "evidence_label": "development evidence", "allowance": {"total": 576, "recorded": 0, "remaining": None}, "batches": {}, "problems": [],
         "gpu_seconds": "not instrumented", "peak_vram": "not instrumented", "models_seen": set(), "gen_public_sha256": {}}
    for b in BATCHES:
        rows, calls, tin, tout, usage_missing = list(runs(b)), 0, 0, 0, 0
        nocode, refusal, ts, by_recipe = [], [], [], collections.defaultdict(lambda: [0, 0, 0])
        for run, cap, recipe, store, exps, rcalls in rows:
            n = 0
            for e in exps:
                rec, mr = load_rec(store, e), model_rows(store, e)
                n += len(mr)
                if len(mr) != len(rec["calls"]):
                    m["problems"].append(f"{b} {run} {e}: {len(mr)} model_calls rows vs {len(rec['calls'])} record calls")
                for p in rec["proposals"]:
                    if not (Path(store) / "discovery" / e / f"cand-{p['sha256']}.py").is_file():
                        m["problems"].append(f"{b} {run} {e}: candidate body missing for {p['sha256'][:12]}")
                for r in mr:
                    m["models_seen"].add(r.get("response_model") or r.get("model"))
                    u = r.get("usage") or {}
                    if isinstance(u.get("prompt_tokens"), int):
                        tin += u["prompt_tokens"]
                    else:
                        usage_missing += 1
                    tout += u.get("completion_tokens", 0) if isinstance(u.get("completion_tokens"), int) else 0
                    ts.append(r["ts"])
                    try:
                        text = json.loads(r["response_text"])["choices"][0]["message"].get("content") or ""
                    except (KeyError, ValueError, TypeError):
                        text = ""
                    by_recipe[recipe][0] += 1
                    if "```" not in text:
                        nocode.append(r["ts"])
                        by_recipe[recipe][1] += 1
                        if re.search(r"sorry|can.t (help|provide)|cannot", text, re.I):
                            refusal.append(r["ts"])
                            by_recipe[recipe][2] += 1
            calls += n
            if n != (rcalls or 0):
                m["problems"].append(f"{b} {run}: ledger {n} calls vs rows.jsonl {rcalls}")
            if rcalls is None:
                m["problems"].append(f"{b} {run}: rows.jsonl has no calls field")
        m["batches"][b] = {"campaigns": len(rows), "calls": calls, "in_tokens": tin if not usage_missing else "unknown", "in_tokens_recorded_sum": tin,
                           "calls_missing_input_usage": usage_missing, "out_tokens": tout, "first_call_utc": min(ts), "last_call_utc": max(ts),
                           "calls_without_code_block": len(nocode), "calls_refusal_text": len(refusal),
                           "first_refusal_utc": min(refusal) if refusal else None, "last_refusal_utc": max(refusal) if refusal else None,
                           "by_recipe_calls_nocode_refusal": {k: v for k, v in sorted(by_recipe.items())}}
    tot = sum(v["calls"] for v in m["batches"].values())
    m["totals"] = {"campaigns": sum(v["campaigns"] for v in m["batches"].values()), "calls": tot, "expected_campaigns": 63, "expected_calls": 489,
                   "in_tokens": "unknown" if any(v["in_tokens"] == "unknown" for v in m["batches"].values()) else sum(v["in_tokens"] for v in m["batches"].values()),
                   "out_tokens": sum(v["out_tokens"] for v in m["batches"].values())}
    m["allowance"].update(recorded=tot, remaining=576 - tot)
    m["models_seen"] = sorted(m["models_seen"])
    for cap in ("site.ref-check", "site.ref-extract", "site.ref-resolve"):
        m["gen_public_sha256"][cap] = sha_file(ROOT / "capabilities" / cap / "suite" / "gen_public.py")
    m["refusal_surge"] = {"batch": "04fe137", "claim": "observed period association, cause unknown",
                          "note": "share of calls whose reply has no code block / refusal text per batch above; no recorded field identifies a cause"}
    m["campaign_labels"] = "all campaigns: development evidence"
    write(OUT / "continuation_manifest.json", m)
    print(json.dumps({"totals": m["totals"], "problems": m["problems"][:10], "n_problems": len(m["problems"])}, indent=1))


# ---------------------------------------------------------------- replay
def pools():
    """Every experiment record having rec['coop'] (incumbent experiments are counted as not applicable)."""
    na = 0
    for b in BATCHES:
        for run, cap, recipe, store, exps, _ in runs(b):
            for e in exps:
                rec = load_rec(store, e)
                if rec.get("coop"):
                    yield b, run, cap, recipe, store, e, rec
                else:
                    na += 1
    pools.not_applicable = na


def cands_of(rec, store, e):
    out = []
    for p in rec["proposals"]:
        d = p.get("dev") or {}
        out.append({"sha": p["sha256"], "static": bool(p.get("static")), "dev_pass": d.get("pass_count", -1), "dev_n": d.get("n"), "dev_ms": p.get("dev_ms"), "agreement": p.get("agreement"),
                    "branch": p.get("branch")})
    return out


def execute(rec, store, e, c, cache, state):
    """Receipts of every non-static candidate of a >=2-dev-pass pool over the frozen differential inputs (deduped by body sha + inputs digest)."""
    fz = rec["frozen"]
    mod = state["mods"].setdefault(c["capability_id"], (D._load("harness", c), D._load("gen_public", c)))
    harness, gen = mod
    cp = fz["coop"]
    cases = CP.diff_cases(gen, cp["diff_seed"], cp["diff_inputs"])
    if cases is None:
        return None, None, "no public generator"
    envs = [x["env"] for x in cases]
    inputs = CP.digest(envs)
    note = None
    if rec["coop"].get("diff_inputs_sha") and rec["coop"]["diff_inputs_sha"] != inputs:
        return None, inputs, "recomputed inputs digest != recorded diff_inputs_sha"
    if not rec["coop"].get("diff_inputs_sha"):
        note = "recorded diff_inputs_sha absent (S0 agreement was skipped); digest recomputed"
    expected = [x["expected"] for x in cases]
    got = {}
    for p in rec["proposals"]:
        if p.get("static"):
            continue
        h = p["sha256"]
        if (h, inputs) not in cache:
            if state["runs"] >= RUN_CAP:
                raise SystemExit(f"HARD CAP {RUN_CAP} container runs reached; stopping")
            body = (Path(store) / "discovery" / e / f"cand-{h}.py").read_text(encoding="utf-8")
            state["runs"] += 1
            try:
                cache[(h, inputs)] = CP.receipt(h, inputs, D._outputs(body, envs, harness, 60, **CC.exec_args(c, fz.get("environment"))), expected)
            except Exception as ex:
                cache[(h, inputs)] = CP.receipt(h, inputs, None, expected, "timeout" if "timed out" in str(ex) else "error")
                cache[(h, inputs)]["detail"] = f"{type(ex).__name__}: {str(ex)[:120]}"
        got[h] = cache[(h, inputs)]
    return got, inputs, note


def replay(plan):
    state, cache, rows, mism = {"mods": {}, "runs": 0}, {}, [], []
    rp = OUT / "replay" / "runs.json"
    if rp.is_file() and not plan:
        cache = {(r["cand"], r["inputs"]): r for r in json.loads(rp.read_text(encoding="utf-8"))}
    need = 0
    for b, run, cap, recipe, store, e, rec in pools():
        cs = cands_of(rec, store, e)
        perfect = [c for c in cs if not c["static"] and c["dev_n"] and c["dev_pass"] == c["dev_n"]]
        pool = {"batch": b, "run": run, "exp_id": e, "cap": cap, "recipe": recipe, "candidates": len(cs), "dev_pass": len(perfect),
                "eligible": sorted(c["sha"] for c in cs if not c["static"]), "dev_pass_shas": sorted(c["sha"] for c in perfect), "executed": False, "notes": []}
        receipts, inputs, n = {}, None, 0
        if len(perfect) >= 2:  # with <2 dev-pass candidates dev alone fixes the winner: no run can change any variant's decision
            if plan:
                need += sum(1 for c in cs if not c["static"])
                rows.append(pool)
                continue
            c = D.contract_of(rec)
            r, inputs, note = execute(rec, store, e, c, cache, state)
            if note:
                pool["notes"].append(note)
            if r is None:
                pool["notes"].append("replay variants S1-S3 not run for this pool")
            else:
                receipts, pool["executed"], n = r, True, rec["frozen"]["coop"]["diff_inputs"]
        pool["inputs_sha"] = inputs
        rec_sel = rec["coop"]["selected"]
        for v in CP.VARIANTS:
            pool[v] = CP.pool_select(v, cs, receipts, inputs, n)
        pool["recorded_selected"], pool["recorded_key"] = rec_sel, rec["coop"]["selection_key"]
        pool["S0_reproduces"] = pool["S0"]["selected"] == rec_sel and pool["S0"]["key"] == rec["coop"]["selection_key"]
        if not pool["S0_reproduces"]:
            mism.append(f"{run}/{e}")
        # fidelity: re-executed canon outputs reproduce the recorded agreement ints among dev-perfect voters
        if pool["executed"]:
            rep = CP.agreement({h: [x for x in receipts[h]["canon"]] for h in pool["dev_pass_shas"] if CP.receipt_ok(receipts.get(h), h, inputs, n)})
            rec_ag = {c["sha"]: c["agreement"] for c in cs if c["sha"] in pool["dev_pass_shas"]}
            pool["agreement_recomputed_equals_recorded"] = all(rep.get(h) == a for h, a in rec_ag.items() if isinstance(a, int)) if any(isinstance(a, int) for a in rec_ag.values()) else None
        rows.append(pool)
    if plan:
        print("pools", len(rows), "container runs needed (before dedupe)", need)
        return
    sel = {"version": "coop-replay-v1", "code_commit": git("rev-parse", "--short", "HEAD"), "variants": CP.VARIANTS, "check_id": CP.CHECK_ID, "hive_model_calls": 0,
           "container_runs": state["runs"], "container_run_cap": RUN_CAP, "incumbent_experiments_not_applicable": pools.not_applicable, "s0_not_reproduced": mism, "pools": rows}
    h = write(OUT / "replay" / "selections.json", sel)
    (OUT / "replay" / "selections.sha256").write_text(h + "\n", encoding="utf-8", newline="\n")
    write(rp, sorted(cache.values(), key=lambda r: (r["cand"], r["inputs"])))
    print("pools", len(rows), "container runs", state["runs"], "S0 not reproduced", mism, "sha256", h)


def main(argv=None):
    global RUN_CAP
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("cmd", choices=["manifest", "replay"])
    ap.add_argument("--plan", action="store_true")
    ap.add_argument("--max-runs", type=int, default=RUN_CAP)
    a = ap.parse_args(argv)
    RUN_CAP = min(RUN_CAP, a.max_runs)
    manifest() if a.cmd == "manifest" else replay(a.plan)
    return 0


if __name__ == "__main__":
    sys.exit(main())
