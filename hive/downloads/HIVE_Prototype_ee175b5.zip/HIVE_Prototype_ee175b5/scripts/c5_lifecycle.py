"""C5 live lifecycle, 0 model calls: v1 operator-authored -> v2 sealed-final acceptance (learned) -> fresh-process reuse -> independent comparison -> not-a-cache -> rollback.

  HIVE_REAL_DOCKER=1 python scripts/c5_lifecycle.py --phase run  [--store S] [--out build/coop/c5]
  python -I scripts/c5_lifecycle.py --phase goal --store S --cap CAP --release 0b3854a --out FILE     (the fresh process; run by --phase run)

Every step records its state and the exact refusal when an existing gate blocks it; nothing is bypassed. Uses the default admission key (hive_admission.DEFAULT_KEY)."""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))
from hive import cap_cli as K, capability_registry as CR, capcontract as CC, discovery as D, experiment_compare as EC  # noqa: E402
from hive import goal_runner as G, operator_runtime as O  # noqa: E402
from hive.operator_runtime import Refused, _sha  # noqa: E402
from hive.storage import Store  # noqa: E402
import coop_pilot as P  # noqa: E402
import hive_admission as H  # noqa: E402

EXPORTS = Path("D:/HIVE-operator-inputs/mom-site/exports")
SCREEN = Path("C:/hive-work/demo/backend-screen-12b1ba4/stores")
NEW, OLD = "0b3854a", P.OLD
SHIPS = {"site.ref-extract": "raw-reference-table-{}.json", "site.ref-resolve": "reference-table-{}.json"}
HERE = Path(__file__).resolve()


def counters(store):
    s = Store(store)
    try:
        return {"experiments": len(D.experiments(s)), "model_calls": O._counters(s)["model_calls"], "proposal_calls": O._counters(s)["proposal_calls"],
                "container_runs": O._counters(s)["container_runs"], "discovery_ledger_calls": (s.get(D.LEDGER) or {}).get("calls", 0)}
    finally:
        s.close()


def inputs(cap, rel):
    goal, files = P.CAPS[cap]
    return goal, [(f.replace(OLD, rel), "file", (EXPORTS / rel / f.replace(OLD, rel)).read_bytes()) for f in files]


def phase_goal(a):
    """The fresh process: the ordinary operator goal for the capability. Writes the result + output bytes."""
    if a.signers:
        CR.SIGNERS = Path(a.signers)
    goal, ins = inputs(a.cap, a.release)
    before = counters(a.store)
    res = G.run_goal(a.store, G.make_contract(goal, ins, allow_discovery=False), ins)
    after = counters(a.store)
    last = (res.get("steps") or [{}])[-1]
    art = next((x for x in last.get("artifacts") or [] if x["name"] != "report.json"), None)
    out = Path(a.store, art["ref"]).read_bytes() if art else b""
    rep = {"state": res["state"], "reason": res["reason"], "mode": last.get("mode"), "verdict": last.get("verdict"), "capability": last.get("capability"),
           "output_sha256": _sha(out.decode("utf-8")) if out else None, "new_experiments": after["experiments"] - before["experiments"],
           "new_model_calls": after["model_calls"] - before["model_calls"] + after["proposal_calls"] - before["proposal_calls"], "before": before, "after": after}
    Path(a.out).write_text(json.dumps(rep, sort_keys=True, indent=1), encoding="utf-8", newline="\n")
    Path(a.out).with_suffix(".bin").write_bytes(out)


def fresh_goal(store, cap, rel, out_dir, tag, signers=None):
    out = Path(out_dir) / f"goal-{cap}-{tag}.json"
    cmd = [sys.executable, "-I", str(HERE), "--phase", "goal", "--store", str(store), "--cap", cap, "--release", rel, "--out", str(out)] + (["--signers", str(signers)] if signers else [])
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=1800)
    rep = json.loads(out.read_text(encoding="utf-8")) if out.exists() else {"state": "PROCESS_FAILED", "stderr": p.stderr[-600:]}
    rep["returncode"], rep["command"] = p.returncode, " ".join(cmd)
    rep["output_bytes"] = out.with_suffix(".bin").read_bytes() if out.with_suffix(".bin").exists() else b""
    return rep


def run_body(cap, body, rel):
    """A body run on its own, in its own container run, exactly as the goal runner does it."""
    c = CC.get(cap)
    _, ins = inputs(cap, rel)
    env = CC.build_env(c, [(n, d) for n, _, d in ins])
    res = json.loads(EC.run_isolated(CC.load_module("harness", c, c["verification"]["harness"]).wrap(body), json.dumps([env]), {}, timeout=c["execution"]["timeout_seconds"],
                                     max_out=c["execution"]["max_output_bytes"], backend="container", operator_class="generated", **CC.exec_args(c, None)))
    return res[0].encode("utf-8")


def attempt(fn):
    try:
        return {"ok": True, "result": fn()}
    except Refused as e:  # an existing gate refused: recorded verbatim, never bypassed
        return {"ok": False, "refused": str(e)}


def v2_try(store, cap, label):
    camp = SCREEN / f"{cap}.{label}.hosted"
    rp = camp / "campaign" / cap / "final-receipt.json"
    row = {"campaign": camp.name, "receipt": str(rp), "receipt_sha256": json.loads(rp.read_text(encoding="utf-8"))["receipt_sha256"]}
    s = Store(store)
    try:
        o = attempt(lambda: D.open_sealed_acceptance(s, camp, rp)["exp_id"])
    finally:
        s.close()
    if not o["ok"]:
        return dict(row, state="OPEN_REFUSED", refused=o["refused"])
    exp = row["exp_id"] = o["result"]
    d = D.run_experiment(store, exp)
    row.update(state=d["state"], reason=d.get("reason"), fresh_hidden=(d.get("receipt") or {}).get("pass_count") and f"{d['receipt']['pass_count']}/{d['receipt']['n']}",
               model_calls=d["ledger"]["calls"], proposals=d["ledger"]["proposals"])
    if d["state"] != "CANDIDATE_PASSED":
        return row
    adm = attempt(lambda: H.admit(store, exp))
    return dict(row, admission=adm["result"] if adm["ok"] else None, admission_refused=adm.get("refused"), state="ADMITTED" if adm["ok"] else "ADMIT_REFUSED")


def phase_run(a):
    store, out = Path(a.store), Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    s = Store(store)
    try:
        O.import_bundle(s)
    finally:
        s.close()
    rep = {"schema": "hive-c5-lifecycle-v1", "store": str(store), "new_release": NEW, "old_release": OLD, "caps": {}, "counters_start": counters(store),
           "commands": {"run": " ".join([sys.executable, *sys.argv])}}
    for cap in SHIPS:
        r = rep["caps"][cap] = {}
        body1 = D._read_lf(ROOT / "build" / "g1" / "authored" / f"{cap}.py")
        v1 = attempt(lambda: K.author(store, cap, ROOT / "build" / "g1" / "authored" / f"{cap}.py", "C5 lifecycle"))
        r["v1"] = v1["result"] if v1["ok"] else {"refused": v1["refused"]}
        if not v1["ok"]:
            continue
        tries = r["v2_attempts"] = []
        for label in ("r1", "r2"):
            tries.append(v2_try(store, cap, label))
            if tries[-1]["state"] != "NO_QUALIFYING_CANDIDATE":  # only a failed fresh hidden gate moves on to the other campaign; never the same one twice
                break
        s = Store(store)
        try:
            cur = CR.resolve_discovered(s, cap)
        finally:
            s.close()
        active = cur["version"]
        r["active_version_after_v2"] = active
        r["v2_admitted"] = any(t["state"] == "ADMITTED" for t in tries)
        if not r["v2_admitted"]:
            r["note"] = "v2 not admitted: steps 3-5 below run against the ACTIVE version (v1), labelled as such; rollback has no previous version"
        before = counters(store)
        g_new = fresh_goal(store, cap, NEW, out, "new")
        authored_out = run_body(cap, body1, NEW)
        shipped = (EXPORTS / NEW / SHIPS[cap].format(NEW)).read_bytes()
        g_old = fresh_goal(store, cap, OLD, out, "old")
        after = counters(store)
        gout = g_new.pop("output_bytes")
        oout = g_old.pop("output_bytes")
        r["reuse"] = dict(g_new, executed_version=(g_new.get("capability") or {}).get("version"), verified=g_new["state"] == "VERIFIED" and g_new.get("mode") == "retained_capability_execution")
        r["comparison"] = {"a_authored_v1_body_separate_run_identical": gout == authored_out and bool(gout), "authored_sha256": _sha(authored_out.decode("utf-8")),
                           "b_shipped_export": SHIPS[cap].format(NEW), "b_shipped_identical": gout == shipped, "shipped_sha256": _sha(shipped.decode("utf-8")), "goal_output_sha256": g_new.get("output_sha256")}
        r["not_a_cache"] = dict(g_old, output_differs=gout != oout, verified=g_old["state"] == "VERIFIED")
        r["counters_steps_3_5"] = {"before": before, "after": after}
        rb = attempt(lambda: H.rollback(store, cap))
        r["rollback"] = rb["result"] if rb["ok"] else {"refused": rb["refused"]}
        if rb["ok"]:
            g_rb = fresh_goal(store, cap, NEW, out, "rollback")
            g_rb.pop("output_bytes")
            r["rollback_goal"] = g_rb
        s = Store(store)
        try:
            r["chain"] = [{k: e.get(k) for k in ("type", "statement_sha", "exp_id", "ref")} for e in CR.history(s, cap)]
        finally:
            s.close()
    rep["counters_end"] = counters(store)
    (out / "C5_REPORT.json").write_text(json.dumps(rep, sort_keys=True, indent=1), encoding="utf-8", newline="\n")
    lines = [f"# C5 lifecycle ({rep['store']})", "", f"counters start {rep['counters_start']}", f"counters end {rep['counters_end']}", ""]
    for cap, r in rep["caps"].items():
        lines += [f"## {cap}", f"- v1: {r['v1']}", *[f"- v2 {t['campaign']}: {t['state']} {t.get('admission_refused') or t.get('refused') or t.get('reason') or ''}" for t in r.get("v2_attempts", [])],
                  f"- reuse verified: {r.get('reuse', {}).get('verified')} (version {r.get('reuse', {}).get('executed_version')})", f"- comparison: {r.get('comparison')}",
                  f"- not-a-cache: output differs {r.get('not_a_cache', {}).get('output_differs')}, verified {r.get('not_a_cache', {}).get('verified')}", f"- rollback: {r.get('rollback')}", ""]
    (out / "C5_REPORT.md").write_text("\n".join(lines), encoding="utf-8", newline="\n")
    print(json.dumps({c: {k: r.get(k) for k in ("active_version_after_v2", "v2_admitted")} for c, r in rep["caps"].items()}, indent=1))


def phase_learned(a):
    """Learned-first: v1 = the sealed-final r1 campaign body (route learned), reuse, comparisons, not-a-cache, signed revoke. The revocation list lives beside the
    signers file, so a scratch copy keeps the repo's configs/capability_revocations.json (global by cap id + version) untouched."""
    import shutil
    store, out = Path(a.store if a.store != "C:/hive-work/demo/c5-c9681d6" else "C:/hive-work/demo/c5l-c9681d6"), Path(a.out)
    sd = Path("D:/tmp/c5l-signers")
    sd.mkdir(parents=True, exist_ok=True)
    signers = sd / "admission_signers"
    shutil.copyfile(CR.SIGNERS, signers)
    CR.SIGNERS = signers
    s = Store(store)
    try:
        O.import_bundle(s)
    finally:
        s.close()
    rep = {"schema": "hive-c5-learned-v1", "store": str(store), "scratch_signers": str(signers), "caps": {}, "counters_start": counters(store),
           "commands": {"run": " ".join([sys.executable, *sys.argv])}}
    for cap in SHIPS:
        r = rep["caps"][cap] = {}
        r["v1"] = v2_try(store, cap, "r1")
        if r["v1"]["state"] != "ADMITTED":
            continue
        s = Store(store)
        try:
            st = CR.resolve_discovered(s, cap)["statement"]
        finally:
            s.close()
        r["statement"] = {"version": st["version"], "route": st.get("route", "learned"), "sealed_final": st.get("sealed_final"), "proposer_model": st["lineage"]["proposer_model"]}
        authored = run_body(cap, D._read_lf(ROOT / "build" / "g1" / "authored" / f"{cap}.py"), NEW)
        shipped = (EXPORTS / NEW / SHIPS[cap].format(NEW)).read_bytes()
        g_new = fresh_goal(store, cap, NEW, out, "l-new", signers)
        g_old = fresh_goal(store, cap, OLD, out, "l-old", signers)
        gout, oout = g_new.pop("output_bytes"), g_old.pop("output_bytes")
        r["reuse"] = dict(g_new, verified=g_new["state"] == "VERIFIED" and g_new.get("mode") == "retained_capability_execution")
        r["comparison"] = {"a_authored_body_separate_run_identical": gout == authored and bool(gout), "b_shipped_export": SHIPS[cap].format(NEW), "b_shipped_identical": gout == shipped,
                           "goal_output_sha256": g_new.get("output_sha256"), "authored_sha256": _sha(authored.decode("utf-8")), "shipped_sha256": _sha(shipped.decode("utf-8"))}
        r["not_a_cache"] = dict(g_old, output_differs=gout != oout, verified=g_old["state"] == "VERIFIED")
        rv = attempt(lambda: H.revoke(store, cap, 1, "C5 revocation test"))
        r["revoke"] = rv["result"] if rv["ok"] else {"refused": rv["refused"]}
        g_rv = fresh_goal(store, cap, NEW, out, "l-revoked", signers)
        g_rv.pop("output_bytes")
        r["post_revoke_goal"] = g_rv
        s = Store(store)
        try:
            r["chain"] = [{k: e.get(k) for k in ("type", "statement_sha", "exp_id", "ref")} for e in CR.history(s, cap)]
        finally:
            s.close()
    rep["counters_end"] = counters(store)
    (out / "C5_LEARNED_REPORT.json").write_text(json.dumps(rep, sort_keys=True, indent=1), encoding="utf-8", newline="\n")
    lines = ["", "## Learned-first (c5l store)", f"store {store}; counters start {rep['counters_start']} end {rep['counters_end']}",
             "authored v1 reuse VERIFIED in the c5-c9681d6 store above (the existing route)", ""]
    for cap, r in rep["caps"].items():
        lines += [f"### {cap}", f"- v1: {r['v1'].get('state')} {r.get('statement')}", f"- reuse verified: {r.get('reuse', {}).get('verified')}", f"- comparison: {r.get('comparison')}",
                  f"- not-a-cache: differs {r.get('not_a_cache', {}).get('output_differs')}, verified {r.get('not_a_cache', {}).get('verified')}", f"- revoke: {r.get('revoke')}",
                  f"- post-revoke goal: {(r.get('post_revoke_goal') or {}).get('state')} / {(r.get('post_revoke_goal') or {}).get('reason')}", ""]
    with open(out / "C5_REPORT.md", "a", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(lines))
    print(json.dumps({c: {"v1": r["v1"].get("state"), "post_revoke": (r.get("post_revoke_goal") or {}).get("state")} for c, r in rep["caps"].items()}, indent=1))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--phase", choices=("run", "goal", "learned"), required=True)
    ap.add_argument("--signers", help="signers file whose directory also holds capability_revocations.json (learned phase: a scratch copy, so the repo's revocation list is never written)")
    ap.add_argument("--store", default="C:/hive-work/demo/c5-c9681d6")
    ap.add_argument("--out", default=str(ROOT / "build" / "coop" / "c5"))
    ap.add_argument("--cap")
    ap.add_argument("--release")
    a = ap.parse_args(argv)
    {"run": phase_run, "goal": phase_goal, "learned": phase_learned}[a.phase](a)


if __name__ == "__main__":
    main()
