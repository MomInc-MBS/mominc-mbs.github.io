"""Derive build/coop/model_choice_evidence_v1.json from PUBLIC files only (sealed scores, screen ledger, resource probe); numbers and enums, no record text.

  python scripts/model_evidence.py [derive]        write the evidence file
  python scripts/model_evidence.py choose <cap>    read-only: print the ranking JSON for a capability (opt-in model choice, docs/GAP_MODEL_CHOICE.md)"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
OUT = ROOT / "build" / "coop" / "model_choice_evidence_v1.json"
SRC = {"public_score": "build/coop/screen/public-score.json", "screen_ledger": "build/coop/screen/screen-ledger.json",
       "screen_manifest": "build/coop/screen/screen-manifest.json", "probe_report": "build/coop/resource/probe-report.json"}


def derive():
    raw = {k: (ROOT / v).read_bytes() for k, v in SRC.items()}
    score, ledger, man, probe = (json.loads(raw[k]) for k in ("public_score", "screen_ledger", "screen_manifest", "probe_report"))
    model = {c: b["model"] for c, b in man["backends"].items()}  # class ("local"/"hosted") -> model id
    ppc = {c: round(p["hosted_usd_delta"] / p["cost"]["calls"], 6) for c, p in probe.items() if isinstance(p, dict) and "hosted_usd_delta" in p and p["cost"]["calls"]}
    rows = {}
    for blk in score["blocks"]:
        for cls, verdict in blk["results"].items():
            r = rows.setdefault((blk["cap"], model[cls]), dict(capability=blk["cap"], backend=model[cls], campaigns=0, sealed_pass=0, calls=0, wall_s=0.0, out_tokens=0, _cls=cls))
            camp = ledger["campaigns"][f"{blk['block_id']}.{cls}"]
            r["campaigns"] += 1
            r["sealed_pass"] += verdict == "PASS"
            r["calls"] += camp["ledger"]["calls"]
            r["wall_s"] = round(r["wall_s"] + camp["ledger"]["wall_s"], 1)
            r["out_tokens"] += camp["ledger"]["out_tokens"]
    out = []
    for r in rows.values():
        cls = r.pop("_cls")
        # per-call usd is not in any public file: local is $0 by config pricing; hosted is the probe's measured usd per call x calls (an estimate), else unknown (never 0)
        r["usd"], r["usd_basis"] = (0.0, "local_zero") if cls == "local" else (round(r["calls"] * ppc[cls], 4), "probe_per_call_estimate") if cls in ppc else (None, "unknown")
        out.append(r)
    ev = {"schema": "hive-model-choice-evidence-v1", "sources": {k: hashlib.sha256(v).hexdigest() for k, v in raw.items()},
          "rows": sorted(out, key=lambda r: (r["capability"], r["backend"]))}
    OUT.write_bytes((json.dumps(ev, indent=1, sort_keys=True) + "\n").encode("utf-8"))
    return ev


def main(argv):
    if argv[:1] == ["choose"] and len(argv) == 2:
        from hive import model_choice as MC
        print(json.dumps(MC.choose(argv[1]), indent=1, sort_keys=True))
        return 0
    if argv in ([], ["derive"]):
        print(json.dumps({"rows": len(derive()["rows"]), "out": str(OUT)}))
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
