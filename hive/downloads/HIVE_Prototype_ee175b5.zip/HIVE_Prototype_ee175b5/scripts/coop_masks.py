"""Build the masking-arm word masks (coop recipes maskpos3 / maskrand3) offline. Needs nltk, so run it with the isolated tagger venv:
  C:/hive-work/tools/postag-venv/Scripts/python.exe scripts/coop_masks.py --caps site.ref-extract,site.ref-resolve,site.ref-check --out build/coop/masks
HIVE itself never imports nltk: it only reads the JSON this writes (src/hive/coop.py load_mask). Rules live in coop.classify()."""
import argparse
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
_s = importlib.util.spec_from_file_location("hive_coop", ROOT / "src" / "hive" / "coop.py")  # by path: the tagger venv has no yaml, so no `import hive`
CP = importlib.util.module_from_spec(_s)
_s.loader.exec_module(CP)

NLTK_DATA = "C:/hive-work/tools/nltk_data"


def nltk_tagger():
    import nltk
    nltk.data.path.insert(0, NLTK_DATA)
    return lambda words: [t for _, t in nltk.pos_tag(words, lang="eng")]


def spec_of(cap):
    """The same text capcontract.text_ref gives the proposer prompt (CRLF -> LF), read without importing hive."""
    ref = json.loads((ROOT / "capabilities" / cap / "contract.json").read_text(encoding="utf-8"))["proposer"]["behaviour_spec_ref"]
    f, _, key = ref.partition("#")
    raw = (ROOT / f).read_text(encoding="utf-8").replace("\r\n", "\n")
    v = json.loads(raw) if key else raw
    for k in key.split(".") if key else ():
        v = v[k]
    return v


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--caps", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    tag = nltk_tagger()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    for cap in a.caps.split(","):
        spec = spec_of(cap)
        m = CP.build_mask(cap, spec, tag)
        (out / f"{cap}.json").write_bytes(CP.mask_bytes(m))
        r = m["realized"]
        print(f"{cap}: spec_words={len(m['words'])} protected={len(m['protected'])} eligible_nv={len(m['eligible_nv'])} eligible_any={len(m['eligible_any'])} "
              f"|A|={r['maskpos-A']['masked_words']} |B|={r['maskpos-B']['masked_words']} rates={ {k: v['rate'] for k, v in r.items()} }")
        if len(m["eligible_nv"]) < 10:
            print(f"  WARNING: eligible_nv is tiny ({len(m['eligible_nv'])}) for {cap}")


if __name__ == "__main__":
    main()
